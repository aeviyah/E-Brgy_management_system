<?php

declare(strict_types=1);

/**
 * Shared shell for the public pages (portal, track, verify).
 * Needs includes/layout.php loaded first (for icon() and bg_scene()).
 */
function pub_header(string $title, string $active = ''): void
{
    $logo = app_url('assets/img/logo.svg');
    $links = [
        'home'   => ['public/index.php', 'Home', null],
        'track'  => ['public/track.php', 'Track request', null],
        'verify' => ['public/verify.php', 'Verify document', 'qr'],
    ];
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#08130d">
    <title><?= e($title) ?> · E-Barangay Bigaan</title>
    <link rel="icon" href="<?= e($logo) ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="<?= e(app_url('assets/css/bg-scene.css')) ?>">
    <link rel="stylesheet" href="<?= e(app_url('assets/css/public.css')) ?>">
</head>
<body class="public-site">
<?= bg_scene() ?>
<header class="pub-nav">
    <div class="pub-nav-inner">
        <a class="pub-brand" href="<?= e(app_url('public/index.php')) ?>" aria-label="E-Barangay public portal">
            <img src="<?= e($logo) ?>" alt="Seal of <?= e(APP_BARANGAY) ?>">
            <span><strong>E-Barangay</strong><small>Bigaan, Calauag, Quezon</small></span>
        </a>
        <nav class="pub-links" aria-label="Public pages">
            <?php foreach ($links as $key => [$href, $label, $ico]): ?>
                <a href="<?= e(app_url($href)) ?>" class="<?= $key === $active ? 'is-active' : '' ?>"<?= $key === $active ? ' aria-current="page"' : '' ?>><?= $ico ? icon($ico) : '' ?><?= e($label) ?></a>
            <?php endforeach; ?>
            <a class="pub-cta" href="<?= e(app_url('login.php')) ?>">Log in</a>
        </nav>
    </div>
</header>
<main class="pub-main">
<?php
}

function pub_footer(): void
{
    ?>
<footer class="pub-footer"><strong>Mapagdalita, Mark Luigi B. | Mendez, Justin Lloyd B. | Prada, Angel Ivy D.</strong><span>BSIT-LQ-2-1 | PROGRAMMING 3</span></footer>
</main>
</body>
</html>
<?php
}