<?php

require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accountType = ($_POST['account_type'] ?? 'Resident') === 'Barangay Official' ? 'Barangay Official' : 'Resident';
    $isOfficial = $accountType === 'Barangay Official';
    $position = (string) ($_POST['position'] ?? '');
    $username = trim((string) ($_POST['username'] ?? ''));
    $required = $isOfficial ? ['first_name', 'last_name', 'email', 'username', 'password'] : ['first_name', 'last_name', 'email', 'address', 'password'];
    $missing = [];

    foreach ($required as $field) {
        if (trim((string) ($_POST[$field] ?? '')) === '') {
            $missing[] = $field;
        }
    }

    if ($missing) {
        flash('danger', 'Please complete all required fields.');
    } elseif (strlen((string) $_POST['password']) < 6) {
        flash('danger', 'Password must be at least 6 characters.');
    } elseif (($username !== '' || $isOfficial) && !preg_match('/^[A-Za-z0-9_]{4,30}$/', $username)) {
        flash('danger', 'Username must be 4 to 30 characters: letters, numbers and underscore only.');
    } elseif ($isOfficial && !array_key_exists($position, official_positions())) {
        flash('danger', 'Please choose a valid position.');
    } elseif ($isOfficial) {
        // Barangay officials are active immediately after successful registration.
        try {
            $roleId = (int) fetch_value('SELECT id FROM roles WHERE slug = ?', [official_positions()[$position]]);
            $fullName = trim((string) $_POST['first_name'] . ' ' . (string) $_POST['last_name']);
            run_query(
                'INSERT INTO users (role_id, resident_id, full_name, username, email, position, password, status, created_at, updated_at)
                 VALUES (?, NULL, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
                [$roleId, $fullName, $username, trim((string) $_POST['email']), $position, password_hash((string) $_POST['password'], PASSWORD_DEFAULT), 'Active']
            );
            audit_log('Official sign-up requested', 'User', (int) db()->lastInsertId(), $fullName . ' as ' . $position);
            flash('success', 'Official account created. You can log in now.');
            redirect('login.php');
        } catch (PDOException $error) {
            flash('danger', 'Registration failed. The email or username may already be used.');
        }
    } else {
        $pdo = null;
        try {
            $pdo = db();
            $pdo->beginTransaction();
            $residentNo = generate_reference('RES');
            run_query(
                'INSERT INTO residents
                 (resident_no, first_name, middle_name, last_name, suffix, gender, birth_date, civil_status, contact_no, email, address, purok_id, occupation, education, voter_status, residency_status, is_pwd, is_senior, is_solo_parent, is_4ps, is_ofw, is_other, special_classification, status, notes, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
                [
                    $residentNo,
                    trim((string) $_POST['first_name']),
                    trim((string) ($_POST['middle_name'] ?? '')),
                    trim((string) $_POST['last_name']),
                    trim((string) ($_POST['suffix'] ?? '')),
                    trim((string) ($_POST['gender'] ?? '')),
                    $_POST['birth_date'] ?: null,
                    trim((string) ($_POST['civil_status'] ?? '')),
                    trim((string) ($_POST['contact_no'] ?? '')),
                    trim((string) $_POST['email']),
                    trim((string) $_POST['address']),
                    $_POST['purok_id'] ?: null,
                    trim((string) ($_POST['occupation'] ?? '')),
                    trim((string) ($_POST['education'] ?? '')),
                    trim((string) ($_POST['voter_status'] ?? '')),
                    'Resident',
                    isset($_POST['is_pwd']) ? 1 : 0,
                    isset($_POST['is_senior']) ? 1 : 0,
                    isset($_POST['is_solo_parent']) ? 1 : 0,
                    isset($_POST['is_4ps']) ? 1 : 0,
                    isset($_POST['is_ofw']) ? 1 : 0,
                    isset($_POST['is_other']) ? 1 : 0,
                    trim((string) ($_POST['special_classification'] ?? '')) ?: null,
                    'Pending Verification',
                    'Registered through resident portal.',
                ]
            );

            $residentId = (int) $pdo->lastInsertId();
            $roleId = (int) fetch_value('SELECT id FROM roles WHERE slug = ?', ['resident']);
            $fullName = trim((string) $_POST['first_name'] . ' ' . (string) $_POST['last_name']);

            run_query(
                'INSERT INTO users (role_id, resident_id, full_name, username, email, password, status, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
                [$roleId, $residentId, $fullName, $username !== '' ? $username : null, trim((string) $_POST['email']), password_hash((string) $_POST['password'], PASSWORD_DEFAULT), 'Active']
            );

            $pdo->commit();
            flash('success', 'Registration submitted. You can log in while your resident record is pending verification.');
            redirect('login.php');
        } catch (Throwable $error) {
            if ($pdo instanceof PDO && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            flash('danger', 'Registration failed. The email or username may already be used, or the database is not ready.');
        }
    }
}

$puroks = [];
try {
    $puroks = fetch_all('SELECT id, name FROM puroks ORDER BY name');
} catch (Throwable $error) {
    $puroks = [];
}


$logo = app_url('assets/img/logo.svg');
$flashes = flash_messages();
$allowedTypes = ['success', 'warning', 'danger', 'info'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Create account · E-Barangay Bigaan</title>
    <link rel="icon" href="<?= e($logo) ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap">
    <style>
:root {
    --nav-h: 76px;
    --lime: #A7F432; --dark: #0F1F16; --light: #EAF3E7; --teal: #3B8F7B; --bg: #08130d;
    --panel-line: rgba(167, 244, 50, .16);
    --muted: #b3c4b9; --ink: #0F1F16; --ink-muted: #51635a; --line: #cfdccb;
    --font: 'Plus Jakarta Sans', system-ui, -apple-system, 'Segoe UI', Roboto, Arial, sans-serif;
}
*, *::before, *::after { box-sizing: border-box; }
html { scroll-behavior: smooth; }
body { margin: 0; min-height: 100vh; font-family: var(--font); color: var(--light); line-height: 1.55; -webkit-font-smoothing: antialiased;
    background: radial-gradient(ellipse 60% 45% at 78% 12%, rgba(60, 200, 90, .20), transparent 70%),
                radial-gradient(ellipse 55% 40% at 8% 92%, rgba(59, 143, 123, .22), transparent 70%), var(--bg); background-attachment: fixed; }
img, svg { display: block; max-width: 100%; }
:focus-visible { outline: 3px solid var(--lime); outline-offset: 2px; }
.sr-only { position: absolute; width: 1px; height: 1px; margin: -1px; padding: 0; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; border: 0; }

.site-nav { position: fixed; inset: 0 0 auto 0; height: var(--nav-h); z-index: 50; background: rgba(8, 19, 13, .88); -webkit-backdrop-filter: blur(10px); backdrop-filter: blur(10px); border-bottom: 1px solid var(--panel-line); }
.nav-inner { height: 100%; max-width: 1240px; margin: 0 auto; padding: 0 24px; display: flex; align-items: center; justify-content: space-between; gap: 24px; }
.brand { display: flex; align-items: center; gap: 12px; color: #fff; text-decoration: none; }
.brand img { width: 50px; height: 50px; border-radius: 50%; }
.brand strong { display: block; font-size: 1.05rem; font-weight: 800; line-height: 1.2; }
.brand small { display: block; font-size: .72rem; color: var(--muted); }
.nav-links { display: flex; align-items: center; gap: 10px; }
.nav-links a { color: var(--light); font-size: .85rem; font-weight: 600; text-decoration: none; padding: 8px 16px; border-radius: 999px; transition: color .2s ease; }
.nav-links a:hover { color: var(--lime); }
.nav-links .nav-cta { margin-left: 8px; background: var(--lime); color: var(--dark); font-weight: 800; box-shadow: 0 0 22px rgba(167, 244, 50, .35); }
.nav-links .nav-cta:hover { color: var(--dark); box-shadow: 0 0 32px rgba(167, 244, 50, .6); }

.page { min-height: 100vh; padding: calc(var(--nav-h) + 28px) 24px 28px; display: flex; flex-direction: column; }
.container { width: 100%; max-width: 1240px; margin: 0 auto; flex: 1; }
.shell { padding: 40px 44px 44px; border-radius: 30px; background: linear-gradient(160deg, #0f1d16, #0a140f); border: 1px solid rgba(167, 244, 50, .22); box-shadow: 0 0 80px rgba(80, 230, 110, .22), inset 0 0 50px rgba(167, 244, 50, .04); }
.reg-grid { display: grid; grid-template-columns: minmax(0, 360px) minmax(0, 1fr); gap: 40px; align-items: start; }

/* Left copy */
.reg-copy { position: sticky; top: calc(var(--nav-h) + 28px); }
.eyebrow { margin: 0 0 18px; font-size: .7rem; font-weight: 600; letter-spacing: .3em; color: #c9d5cd; }
.reg-copy h1 { margin: 0; font-size: clamp(2rem, 3.6vw, 3rem); font-weight: 700; line-height: 1.06; letter-spacing: -.02em; color: #fff; }
.reg-copy .lead { margin: 18px 0 26px; font-size: .95rem; color: #cfd9d2; }
.steps { list-style: none; margin: 0; padding: 0; display: grid; gap: 10px; }
.steps li { display: flex; gap: 14px; align-items: center; padding: 12px 16px; background: rgba(255, 255, 255, .04); border: 1px solid var(--panel-line); border-radius: 16px; font-size: .82rem; color: #d8e4db; }
.steps li b { display: block; color: #fff; font-size: .85rem; }
.tile { flex: none; width: 38px; height: 38px; display: grid; place-items: center; border-radius: 12px; color: var(--lime); background: rgba(167, 244, 50, .12); border: 1px solid rgba(167, 244, 50, .3); }
.tile svg { width: 19px; height: 19px; }

/* Form card */
.reg-card { background: var(--light); color: var(--ink); border-radius: 24px; padding: 32px 32px 28px; box-shadow: 0 30px 60px -24px rgba(0, 0, 0, .7), 0 0 40px rgba(167, 244, 50, .12); }
.reg-card h2 { margin: 0 0 4px; font-size: 1.6rem; font-weight: 800; letter-spacing: -.02em; }
.card-sub { margin: 0 0 20px; font-size: .84rem; color: var(--ink-muted); }
.alert { margin: 0 0 16px; padding: 11px 14px; border-radius: 12px; font-size: .8rem; font-weight: 600; line-height: 1.45; }
.alert-danger { background: #fde8e6; color: #8a2018; }
.alert-warning { background: #fff3d6; color: #6b4a00; }
.alert-success { background: #dcf3d2; color: #1d5a35; }
.alert-info { background: #dcebe6; color: #17475a; }

.form-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px 16px; }
.full { grid-column: 1 / -1; }
.group-title { grid-column: 1 / -1; margin: 10px 0 -2px; padding-top: 14px; border-top: 1px dashed #b9c9b4; font-size: .74rem; font-weight: 800; letter-spacing: .08em; color: #1f6f5c; }
.group-title:first-of-type { margin-top: 0; padding-top: 0; border: 0; }
.form-field label, .form-field .label { display: block; margin-bottom: 6px; font-size: .78rem; font-weight: 700; }
.form-field .muted { font-weight: 500; color: var(--ink-muted); }
.req { color: #b3261e; }
.form-control { width: 100%; height: 46px; padding: 0 14px; font: inherit; font-size: .88rem; color: var(--ink); background: #fff; border: 1px solid var(--line); border-radius: 14px; transition: border-color .2s ease, box-shadow .2s ease; }
textarea.form-control { height: auto; padding: 12px 14px; resize: vertical; }
select.form-control { appearance: none; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8' fill='none' stroke='%2351635a' stroke-width='2'%3E%3Cpath d='m1 1 5 5 5-5'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 14px center; padding-right: 38px; }
.form-control::placeholder { color: #8a9c92; }
.form-control:focus { outline: none; border-color: var(--teal); box-shadow: 0 0 0 3px rgba(59, 143, 123, .28); }
.input-wrap { position: relative; }
.input-wrap .form-control { padding-right: 46px; }
.toggle-pass { position: absolute; right: 6px; top: 50%; transform: translateY(-50%); width: 36px; height: 36px; display: grid; place-items: center; padding: 0; border: 0; border-radius: 50%; background: transparent; color: #51635a; cursor: pointer; }
.toggle-pass:hover { background: rgba(0, 0, 0, .06); }
.toggle-pass svg { width: 19px; height: 19px; }
.toggle-pass .icon-off { display: none; }
.toggle-pass[aria-pressed="true"] .icon-on { display: none; }
.toggle-pass[aria-pressed="true"] .icon-off { display: block; }
.hint { margin: 6px 0 0; font-size: .72rem; color: var(--ink-muted); }

/* Segmented switch + chips */
.seg { display: grid; grid-template-columns: 1fr 1fr; gap: 4px; padding: 4px; background: #d9e6d5; border-radius: 999px; }
.seg label { position: relative; margin: 0; cursor: pointer; }
.seg input { position: absolute; opacity: 0; inset: 0; margin: 0; cursor: pointer; }
.seg span { display: block; padding: 10px 8px; border-radius: 999px; text-align: center; font-size: .8rem; font-weight: 700; color: #476055; transition: background-color .2s ease, color .2s ease; }
.seg input:checked + span { background: var(--dark); color: var(--lime); }
.seg input:focus-visible + span { outline: 3px solid var(--teal); outline-offset: 2px; }
.chips { display: flex; flex-wrap: wrap; gap: 8px; }
.chips label { position: relative; margin: 0; cursor: pointer; }
.chips input { position: absolute; opacity: 0; inset: 0; margin: 0; cursor: pointer; }
.chips span { display: block; padding: 8px 14px; font-size: .78rem; font-weight: 700; color: #36493f; background: #fff; border: 1px solid var(--line); border-radius: 999px; transition: background-color .2s ease, border-color .2s ease; }
.chips input:checked + span { background: var(--dark); border-color: var(--dark); color: var(--lime); }
.chips input:focus-visible + span { outline: 3px solid var(--teal); outline-offset: 2px; }
.chips + .form-control { margin-top: 10px; }

.form-actions { display: flex; gap: 12px; flex-wrap: wrap; margin-top: 8px; }
.btn { display: inline-flex; align-items: center; justify-content: center; height: 48px; padding: 0 28px; font: inherit; font-size: .92rem; font-weight: 800; text-decoration: none; border: 0; border-radius: 999px; cursor: pointer; transition: transform .15s ease, box-shadow .2s ease; }
.btn-primary { flex: 1; min-width: 200px; color: var(--dark); background: var(--lime); box-shadow: 0 10px 24px -10px rgba(120, 200, 20, .9); }
.btn-primary:hover { box-shadow: 0 12px 30px -8px rgba(120, 200, 20, 1); }
.btn-primary:active { transform: translateY(1px); }
.btn-ghost { color: var(--dark); background: transparent; border: 1px solid #b9c9b4; }
.btn-ghost:hover { background: #dbe9d6; }

.site-footer { padding-top: 24px; text-align: center; font-size: .74rem; color: #cfdcd2; }
.site-footer strong { display: block; font-weight: 700; color: #eef5ef; }

@media (max-width: 1000px) {
    .reg-grid { grid-template-columns: minmax(0, 1fr); gap: 28px; }
    .reg-copy { position: static; }
}
@media (max-width: 720px) {
    .page { padding-left: 14px; padding-right: 14px; }
    .shell { padding: 24px 16px 26px; border-radius: 24px; }
    .reg-card { padding: 26px 18px 22px; }
    .form-grid { grid-template-columns: minmax(0, 1fr); }
    .nav-links a:not(.nav-cta) { display: none; }
}
@media (prefers-reduced-motion: reduce) { * { transition-duration: .01ms !important; } }

/* Glassmorphism background glowing effect for register.php */
body .hero-shell, body .shell {
    background: linear-gradient(160deg, rgba(15, 29, 22, .70), rgba(10, 20, 15, .55));
    -webkit-backdrop-filter: blur(6px); backdrop-filter: blur(6px);
}
body .panel { 
    background: rgba(15, 31, 22, .72); 
    -webkit-backdrop-filter: blur(8px); 
    backdrop-filter: blur(8px); 
}
    </style>
    <link rel="stylesheet" href="<?= e(app_url('assets/css/bg-scene.css')) ?>">
</head>
<body>
<?= bg_scene() ?>

<header class="site-nav">
    <div class="nav-inner">
        <a class="brand" href="<?= e(app_url('login.php')) ?>" aria-label="E-Barangay, back to sign in">
            <img src="<?= e($logo) ?>" alt="Seal of <?= e(APP_BARANGAY) ?>">
            <span><strong>E-Barangay</strong><small>Bigaan, Calauag, Quezon</small></span>
        </a>
        <nav class="nav-links" aria-label="Account">
            <a href="<?= e(app_url('login.php#services')) ?>">Public services</a>
            <a href="<?= e(app_url('login.php#about')) ?>">About</a>
            <a class="nav-cta" href="<?= e(app_url('login.php')) ?>">Sign in</a>
        </nav>
    </div>
</header>

<main class="page">
<div class="container shell">
    <div class="reg-grid">

        <!-- Left: copy -->
        <aside class="reg-copy">
            <p class="eyebrow">BARANGAY BIGAAN · CALAUAG, QUEZON</p>
            <h1>Gumawa ng account, simulan na.</h1>
            <p class="lead">Register once, then request documents and track every step online. Your resident record is checked by the barangay.</p>
            <ol class="steps">
                <li><span class="tile"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg></span><span><b>Fill in your details</b>Name, contact and address.</span></li>
                <li><span class="tile"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="m8.5 12.5 2.5 2.5 4.5-5"/></svg></span><span><b>Barangay verifies</b>You can sign in while it is pending.</span></li>
                <li><span class="tile"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h4"/></svg></span><span><b>Request documents</b>Clearance, residency, indigency and more.</span></li>
            </ol>
        </aside>

        <!-- Right: form -->
        <section class="reg-card" aria-labelledby="reg-title">
            <h2 id="reg-title">Create your account</h2>
            <p class="card-sub">Fields marked <span class="req">*</span> are required.</p>

            <?php foreach ($flashes as $flash): ?>
                <?php $ftype = in_array($flash['type'] ?? '', $allowedTypes, true) ? $flash['type'] : 'info'; ?>
                <div class="alert alert-<?= e($ftype) ?>" role="alert"><?= e($flash['message'] ?? '') ?></div>
            <?php endforeach; ?>

            <form method="post" class="form-grid" autocomplete="on">

                <div class="form-field full">
                    <span class="label">I am registering as</span>
                    <div class="seg">
                        <label><input type="radio" name="account_type" value="Resident" data-account-type <?= checked(old('account_type', 'Resident') !== 'Barangay Official') ?>><span>Resident</span></label>
                        <label><input type="radio" name="account_type" value="Barangay Official" data-account-type <?= checked(old('account_type', 'Resident') === 'Barangay Official') ?>><span>Barangay official</span></label>
                    </div>
                    <p class="hint" data-official-hint hidden>Official accounts are active immediately after registration.</p>
                </div>

                <h3 class="group-title">PERSONAL</h3>
                <div class="form-field">
                    <label for="first_name">First name <span class="req">*</span></label>
                    <input class="form-control" id="first_name" name="first_name" value="<?= e(old('first_name')) ?>" autocomplete="given-name" required>
                </div>
                <div class="form-field">
                    <label for="last_name">Last name <span class="req">*</span></label>
                    <input class="form-control" id="last_name" name="last_name" value="<?= e(old('last_name')) ?>" autocomplete="family-name" required>
                </div>
                <div class="form-field">
                    <label for="middle_name">Middle name</label>
                    <input class="form-control" id="middle_name" name="middle_name" value="<?= e(old('middle_name')) ?>" autocomplete="additional-name">
                </div>
                <div class="form-field">
                    <label for="suffix">Suffix</label>
                    <input class="form-control" id="suffix" name="suffix" value="<?= e(old('suffix')) ?>" placeholder="Jr., Sr., III">
                </div>
                <div class="form-field">
                    <label for="gender">Gender</label>
                    <select class="form-control" id="gender" name="gender">
                        <option value="">Select</option>
                        <option <?= selected(old('gender'), 'Female') ?>>Female</option>
                        <option <?= selected(old('gender'), 'Male') ?>>Male</option>
                    </select>
                </div>
                <div class="form-field">
                    <label for="birth_date">Birth date</label>
                    <input class="form-control" id="birth_date" type="date" name="birth_date" value="<?= e(old('birth_date')) ?>" autocomplete="bday">
                </div>

                <h3 class="group-title">ACCOUNT</h3>
                <div class="form-field">
                    <label for="email">Email <span class="req">*</span></label>
                    <input class="form-control" id="email" type="email" name="email" value="<?= e(old('email')) ?>" autocomplete="email" required>
                </div>
                <div class="form-field">
                    <label for="contact_no">Contact no.</label>
                    <input class="form-control" id="contact_no" name="contact_no" value="<?= e(old('contact_no')) ?>" autocomplete="tel" inputmode="tel">
                </div>
                <div class="form-field">
                    <label for="username">Username <small class="muted">(required for officials)</small></label>
                    <input class="form-control" id="username" name="username" value="<?= e(old('username')) ?>" pattern="[A-Za-z0-9_]{4,30}" autocomplete="username">
                    <p class="hint">4 to 30 characters: letters, numbers, underscore.</p>
                </div>
                <div class="form-field">
                    <label for="password">Password <span class="req">*</span></label>
                    <div class="input-wrap">
                        <input class="form-control" id="password" type="password" name="password" minlength="6" autocomplete="new-password" required>
                        <button class="toggle-pass" type="button" aria-label="Show password" aria-pressed="false">
                            <svg class="icon-on" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>
                            <svg class="icon-off" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3l18 18"/><path d="M10.6 5.1A10 10 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4M6.5 6.6C3.7 8.3 2 12 2 12s3.5 7 10 7c1.6 0 3-.4 4.3-1"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>
                        </button>
                    </div>
                    <p class="hint">At least 6 characters.</p>
                </div>
                <div class="form-field full" data-official-only>
                    <label for="position">Position</label>
                    <select class="form-control" id="position" name="position">
                        <?php foreach (array_keys(official_positions()) as $positionName): ?>
                            <option <?= selected(old('position'), $positionName) ?>><?= e($positionName) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <h3 class="group-title">ADDRESS &amp; BACKGROUND</h3>
                <div class="form-field full">
                    <label for="purok_id">Purok / Sitio</label>
                    <select class="form-control" id="purok_id" name="purok_id">
                        <option value="">Select</option>
                        <?php foreach ($puroks as $purok): ?>
                            <option value="<?= (int) $purok['id'] ?>" <?= selected(old('purok_id'), $purok['id']) ?>><?= e($purok['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-field full">
                    <label for="address">Address <span class="req" data-resident-req>*</span> <small class="muted">(residents)</small></label>
                    <textarea class="form-control" id="address" name="address" rows="3" autocomplete="street-address"><?= e(old('address')) ?></textarea>
                </div>
                <div class="form-field">
                    <label for="occupation">Occupation</label>
                    <input class="form-control" id="occupation" name="occupation" value="<?= e(old('occupation')) ?>">
                </div>
                <div class="form-field">
                    <label for="education">Education</label>
                    <input class="form-control" id="education" name="education" value="<?= e(old('education')) ?>">
                </div>

                <div class="form-field full" data-resident-only>
                    <span class="label">Classifications</span>
                    <div class="chips">
                        <label><input type="checkbox" name="is_pwd" <?= checked(isset($_POST['is_pwd'])) ?>><span>PWD</span></label>
                        <label><input type="checkbox" name="is_senior" <?= checked(isset($_POST['is_senior'])) ?>><span>Senior Citizen</span></label>
                        <label><input type="checkbox" name="is_solo_parent" <?= checked(isset($_POST['is_solo_parent'])) ?>><span>Solo Parent</span></label>
                        <label><input type="checkbox" name="is_4ps" <?= checked(isset($_POST['is_4ps'])) ?>><span>4Ps</span></label>
                        <label><input type="checkbox" name="is_ofw" <?= checked(isset($_POST['is_ofw'])) ?>><span>OFW</span></label>
                        <label><input type="checkbox" name="is_other" <?= checked(isset($_POST['is_other'])) ?>><span>Other</span></label>
                    </div>
                    <input class="form-control" name="special_classification" placeholder="If Other, describe classification" value="<?= e(old('special_classification')) ?>" aria-label="Other classification">
                </div>

                <div class="form-actions full">
                    <button class="btn btn-primary" type="submit">Submit registration</button>
                    <a class="btn btn-ghost" href="<?= e(app_url('login.php')) ?>">Back to sign in</a>
                </div>
            </form>
        </section>
    </div>
</div>

<footer class="site-footer">
    <strong>Mapagdalita, Mark Luigi B. | Mendez, Justin Lloyd B. | Prada, Angel Ivy D.</strong>
    <span>BSIT-LQ-2-1 | PROGRAMMING 3</span>
</footer>
</main>

<script>
(() => {
    'use strict';

    /* Show the position field and official note only for barangay officials; hide resident-only parts */
    const radios = document.querySelectorAll('[data-account-type]');
    const officialOnly = document.querySelector('[data-official-only]');
    const hint = document.querySelector('[data-official-hint]');
    const residentOnly = document.querySelector('[data-resident-only]');
    const residentReq = document.querySelector('[data-resident-req]');
    const sync = () => {
        const checked = document.querySelector('[data-account-type]:checked');
        const official = !!checked && checked.value === 'Barangay Official';
        if (officialOnly) officialOnly.style.display = official ? '' : 'none';
        if (hint) hint.hidden = !official;
        if (residentOnly) residentOnly.style.display = official ? 'none' : '';
        if (residentReq) residentReq.style.display = official ? 'none' : '';
    };
    radios.forEach((r) => r.addEventListener('change', sync));
    sync();

    /* Password show / hide */
    const password = document.getElementById('password');
    const togglePass = document.querySelector('.toggle-pass');
    togglePass.addEventListener('click', () => {
        const show = password.type === 'password';
        password.type = show ? 'text' : 'password';
        togglePass.setAttribute('aria-pressed', String(show));
        togglePass.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    });
})();
</script>
</body>
</html>