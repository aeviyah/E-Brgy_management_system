<?php

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';

require_login();

$user = current_user();
$residentId = current_resident_id();
$resident = $residentId ? fetch_one('SELECT * FROM residents WHERE id = ?', [$residentId]) : null;
$puroks = fetch_all('SELECT id, name FROM puroks ORDER BY name');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'password') {
        $old = (string) ($_POST['old_password'] ?? '');
        $new = (string) ($_POST['new_password'] ?? '');
        $confirm = (string) ($_POST['confirm_password'] ?? '');

        if (!password_verify($old, (string) $user['password'])) {
            flash('danger', 'Your current password is incorrect.');
        } elseif (strlen($new) < 6) {
            flash('danger', 'The new password must be at least 6 characters.');
        } elseif ($new !== $confirm) {
            flash('danger', 'The two new passwords do not match.');
        } else {
            run_query('UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), (int) $user['id']]);
            audit_log('Changed password', 'User', (int) $user['id'], '');
            flash('success', 'Password changed.');
        }
        redirect('modules/profile.php');
    }

    if ($action === 'details' && $resident && role_slug() === 'resident') {
        $address = trim((string) ($_POST['address'] ?? ''));
        if ($address === '') {
            flash('danger', 'Address is required.');
            redirect('modules/profile.php');
        }
        $pdo = db();
        try {
            $pdo->beginTransaction();
            run_query(
                'UPDATE residents SET middle_name = ?, suffix = ?, gender = ?, birth_date = ?, civil_status = ?, contact_no = ?, email = ?, address = ?, purok_id = ?, occupation = ?, education = ?, voter_status = ?, is_pwd = ?, is_senior = ?, is_solo_parent = ?, is_4ps = ?, is_ofw = ?, is_other = ?, is_youth = ?, is_head_of_family = ?, pwd_id_number = ?, solo_parent_id_number = ?, special_classification = ?, updated_at = NOW() WHERE id = ?',
                [
                    trim((string) ($_POST['middle_name'] ?? '')) ?: null,
                    trim((string) ($_POST['suffix'] ?? '')) ?: null,
                    trim((string) ($_POST['gender'] ?? '')) ?: null,
                    ($_POST['birth_date'] ?? '') ?: null,
                    trim((string) ($_POST['civil_status'] ?? '')) ?: null,
                    trim((string) ($_POST['contact_no'] ?? '')) ?: null,
                    trim((string) ($_POST['email'] ?? '')) ?: null,
                    $address,
                    ($_POST['purok_id'] ?? '') !== '' ? (int) $_POST['purok_id'] : null,
                    trim((string) ($_POST['occupation'] ?? '')) ?: null,
                    trim((string) ($_POST['education'] ?? '')) ?: null,
                    trim((string) ($_POST['voter_status'] ?? '')) ?: null,
                    isset($_POST['is_pwd']) ? 1 : 0,
                    isset($_POST['is_senior']) ? 1 : 0,
                    isset($_POST['is_solo_parent']) ? 1 : 0,
                    isset($_POST['is_4ps']) ? 1 : 0,
                    isset($_POST['is_ofw']) ? 1 : 0,
                    isset($_POST['is_other']) ? 1 : 0,
                    isset($_POST['is_youth']) ? 1 : 0,
                    isset($_POST['is_head_of_family']) ? 1 : 0,
                    trim((string) ($_POST['pwd_id_number'] ?? '')) ?: null,
                    trim((string) ($_POST['solo_parent_id_number'] ?? '')) ?: null,
                    trim((string) ($_POST['special_classification'] ?? '')) ?: null,
                    $residentId,
                ]
            );

            $household = fetch_one('SELECT households.* FROM households LEFT JOIN household_members ON household_members.household_id = households.id WHERE household_members.resident_id = ? OR households.household_head_id = ? ORDER BY households.id DESC LIMIT 1', [$residentId, $residentId]);
            $householdValues = [
                $address,
                ($_POST['purok_id'] ?? '') !== '' ? (int) $_POST['purok_id'] : null,
                trim((string) ($_POST['household_classification'] ?? '')) ?: null,
                trim((string) ($_POST['income_bracket'] ?? '')) ?: null,
                trim((string) ($_POST['housing_type'] ?? '')) ?: null,
                trim((string) ($_POST['utilities'] ?? '')) ?: null,
            ];
            if ($household) {
                run_query('UPDATE households SET address = ?, purok_id = ?, classification = ?, income_bracket = ?, housing_type = ?, utilities = ?, updated_at = NOW() WHERE id = ?', [...$householdValues, (int) $household['id']]);
                run_query("INSERT IGNORE INTO household_members (household_id, resident_id, relationship, created_at) VALUES (?, ?, 'Household Head', NOW())", [(int) $household['id'], $residentId]);
            } else {
                run_query('INSERT INTO households (household_no, household_head_id, address, purok_id, classification, income_bracket, housing_type, utilities, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, \'Pending Review\', NOW(), NOW())', [generate_reference('HH'), $residentId, ...$householdValues]);
                $householdId = (int) $pdo->lastInsertId();
                run_query("INSERT INTO household_members (household_id, resident_id, relationship, created_at) VALUES (?, ?, 'Household Head', NOW())", [$householdId, $residentId]);
            }
            $pdo->commit();
            audit_log('Submitted resident profile and household form', 'Resident', $residentId, 'Resident-submitted information saved.');
            flash('success', 'Your resident profile and household information were saved for barangay review.');
        } catch (Throwable $error) {
            if ($pdo->inTransaction()) { $pdo->rollBack(); }
            flash('danger', 'Your information could not be saved. Please check the form and try again.');
        }
        redirect('modules/profile.php');
    }
}

render_header('My Profile');
page_header('My Profile', 'Your account and personal details.');
?>

<section class="grid grid-2">
    <div class="panel">
        <div class="panel-header"><h2>Account</h2><span class="status status-active"><?= e($user['role_name']) ?></span></div>
        <div class="panel-body">
            <p><strong>Name</strong><br><?= e($user['full_name']) ?></p>
            <p><strong>Email</strong><br><?= e($user['email']) ?></p>
            <p><strong>Username</strong><br><?= e($user['username'] ?: 'Not set') ?></p>
            <?php if ($user['position']): ?><p><strong>Position</strong><br><?= e($user['position']) ?></p><?php endif; ?>
        </div>
    </div>

    <div class="panel">
        <div class="panel-header"><h2>Change password</h2></div>
        <div class="panel-body">
            <form method="post" class="form-grid">
                <input type="hidden" name="action" value="password">
                <div class="form-field full"><label>Current password</label><input class="form-control" type="password" name="old_password" autocomplete="current-password" required></div>
                <div class="form-field"><label>New password</label><input class="form-control" type="password" name="new_password" autocomplete="new-password" required></div>
                <div class="form-field"><label>Confirm new password</label><input class="form-control" type="password" name="confirm_password" autocomplete="new-password" required></div>
                <div class="form-actions full"><button class="btn" type="submit">Change password</button></div>
            </form>
        </div>
    </div>
</section>

<?php if ($resident && role_slug() === 'resident'): ?>
<section class="panel">
    <div class="panel-header">
        <h2>Resident details</h2>
        <span class="<?= e(status_class($resident['status'])) ?>"><?= e($resident['status']) ?></span>
    </div>
    <div class="panel-body">
        <p class="muted">Resident No. <?= e($resident['resident_no']) ?>. Submit your profile and household details here. Barangay officials review and verify submitted information.</p>
        <form method="post" class="form-grid">
            <input type="hidden" name="action" value="details">
            <div class="form-field"><label>First name</label><input class="form-control" value="<?= e($resident['first_name']) ?>" disabled></div>
            <div class="form-field"><label>Last name</label><input class="form-control" value="<?= e($resident['last_name']) ?>" disabled></div>
            <div class="form-field"><label>Middle name</label><input class="form-control" name="middle_name" value="<?= e($resident['middle_name']) ?>"></div>
            <div class="form-field"><label>Suffix</label><input class="form-control" name="suffix" value="<?= e($resident['suffix']) ?>"></div>
            <div class="form-field"><label>Email</label><input class="form-control" type="email" name="email" value="<?= e($resident['email']) ?>"></div>
            <div class="form-field"><label>Gender</label>
                <select class="form-control" name="gender"><option value="">Select</option><?php foreach (['Female', 'Male', 'Other'] as $g): ?><option <?= selected($resident['gender'], $g) ?>><?= e($g) ?></option><?php endforeach; ?></select>
            </div>
            <div class="form-field"><label>Birth date</label><input class="form-control" type="date" name="birth_date" value="<?= e($resident['birth_date']) ?>"></div>
            <div class="form-field"><label>Civil status</label>
                <select class="form-control" name="civil_status"><option value="">Select</option><?php foreach (['Single', 'Married', 'Widowed', 'Separated'] as $c): ?><option <?= selected($resident['civil_status'], $c) ?>><?= e($c) ?></option><?php endforeach; ?></select>
            </div>
            <div class="form-field"><label>Contact no.</label><input class="form-control" name="contact_no" value="<?= e($resident['contact_no']) ?>"></div>
            <div class="form-field"><label>Purok / Sitio</label>
                <select class="form-control" name="purok_id"><option value="">Select</option><?php foreach ($puroks as $purok): ?><option value="<?= (int) $purok['id'] ?>" <?= selected($resident['purok_id'], $purok['id']) ?>><?= e($purok['name']) ?></option><?php endforeach; ?></select>
            </div>
            <div class="form-field"><label>Occupation</label><input class="form-control" name="occupation" value="<?= e($resident['occupation']) ?>"></div>
            <div class="form-field"><label>Education</label><input class="form-control" name="education" value="<?= e($resident['education']) ?>"></div>
            <div class="form-field"><label>Voter status</label><input class="form-control" name="voter_status" value="<?= e($resident['voter_status']) ?>"></div>
            <div class="form-field full"><label>Address</label><textarea class="form-control" name="address" rows="2"><?= e($resident['address']) ?></textarea></div>
            <div class="form-field full"><label>Classifications</label><div class="split-actions">
                <?php foreach (['is_pwd' => 'PWD', 'is_senior' => 'Senior Citizen', 'is_solo_parent' => 'Solo Parent', 'is_4ps' => '4Ps', 'is_ofw' => 'OFW', 'is_other' => 'Other', 'is_youth' => 'Youth', 'is_head_of_family' => 'Head of Family'] as $key => $label): ?><label><input type="checkbox" name="<?= e($key) ?>" <?= checked((bool) $resident[$key]) ?>> <?= e($label) ?></label><?php endforeach; ?>
            </div></div>
            <div class="form-field"><label>PWD ID number</label><input class="form-control" name="pwd_id_number" value="<?= e($resident['pwd_id_number']) ?>"></div>
            <div class="form-field"><label>Solo parent ID number</label><input class="form-control" name="solo_parent_id_number" value="<?= e($resident['solo_parent_id_number']) ?>"></div>
            <div class="form-field full"><label>Other classification details</label><input class="form-control" name="special_classification" value="<?= e($resident['special_classification']) ?>"></div>
            <?php $myHousehold = fetch_one('SELECT households.* FROM households LEFT JOIN household_members ON household_members.household_id = households.id WHERE household_members.resident_id = ? OR households.household_head_id = ? ORDER BY households.id DESC LIMIT 1', [$residentId, $residentId]); ?>
            <div class="form-field full"><h3>Household Management Form</h3></div>
            <div class="form-field"><label>Household classification</label><input class="form-control" name="household_classification" value="<?= e($myHousehold['classification'] ?? '') ?>"></div>
            <div class="form-field"><label>Monthly income bracket</label><input class="form-control" name="income_bracket" value="<?= e($myHousehold['income_bracket'] ?? '') ?>"></div>
            <div class="form-field"><label>Housing type</label><input class="form-control" name="housing_type" value="<?= e($myHousehold['housing_type'] ?? '') ?>"></div>
            <div class="form-field full"><label>Household utilities</label><textarea class="form-control" name="utilities" rows="2"><?= e($myHousehold['utilities'] ?? '') ?></textarea></div>
            <div class="form-actions full"><button class="btn" type="submit">Submit profile and household information</button></div>
        </form>
    </div>
</section>
<?php endif; ?>
