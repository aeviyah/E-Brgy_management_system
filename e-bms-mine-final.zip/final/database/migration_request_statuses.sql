-- Normalize existing service request statuses to Pending, Approved, or Rejected.
-- Run once against the configured e-bms-mine database after backing it up.
USE `e-bms-mine`;

-- An approved payment completes the request approval gate.
UPDATE service_records
JOIN payments ON payments.record_id = service_records.id
SET service_records.status = 'Approved'
WHERE payments.payment_status IN ('Approved', 'Paid')
  AND service_records.module_slug <> 'announcements'
  AND service_records.deleted_at IS NULL;

UPDATE service_records
SET status = CASE
    WHEN status IN ('Approved', 'For Approval', 'Processing', 'Ready for Release', 'Completed') THEN 'Approved'
    WHEN status IN ('Rejected', 'Cancelled', 'Archived', 'Returned for Correction') THEN 'Rejected'
    ELSE 'Pending'
END;

UPDATE service_records
SET deleted_status = CASE
    WHEN deleted_status IN ('Approved', 'For Approval', 'Processing', 'Ready for Release', 'Completed') THEN 'Approved'
    WHEN deleted_status IN ('Rejected', 'Cancelled', 'Archived', 'Returned for Correction') THEN 'Rejected'
    WHEN deleted_status IS NULL OR deleted_status = '' THEN NULL
    ELSE 'Pending'
END
WHERE deleted_status IS NOT NULL;

UPDATE record_history
SET status = CASE
    WHEN status IN ('Approved', 'For Approval', 'Processing', 'Ready for Release', 'Completed') THEN 'Approved'
    WHEN status IN ('Rejected', 'Cancelled', 'Archived', 'Returned for Correction') THEN 'Rejected'
    ELSE 'Pending'
END;
