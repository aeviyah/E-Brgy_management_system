-- Run once in phpMyAdmin on your existing database (no data is deleted).
-- Only 3 payment methods are used: Cash, E-Wallet, Bank Transfer.
UPDATE payments SET payment_method = 'E-Wallet'
 WHERE LOWER(payment_method) IN ('gcash','maya','maribank','e-wallet','ewallet','paymaya');
UPDATE payments SET payment_method = 'Bank Transfer'
 WHERE LOWER(payment_method) IN ('online transfer','bank transfer','bank');
UPDATE payments SET payment_method = 'Cash'
 WHERE payment_method IS NULL OR payment_method = '' OR LOWER(payment_method) = 'cash';
UPDATE service_records SET payment_method = 'E-Wallet'
 WHERE LOWER(payment_method) IN ('gcash','maya','maribank','e-wallet','ewallet','paymaya');
UPDATE service_records SET payment_method = 'Bank Transfer'
 WHERE LOWER(payment_method) IN ('online transfer','bank transfer','bank');
SELECT payment_method, COUNT(*) AS total FROM payments GROUP BY payment_method;
