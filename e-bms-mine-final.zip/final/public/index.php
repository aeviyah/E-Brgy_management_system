<?php

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';

$announcements = [];
$events = [];
$feedPosts = [];
$contacts = [];
$portalNotice = '';

try {
    $announcements = fetch_all(
        "SELECT * FROM service_records
         WHERE module_slug = 'announcements' AND status = 'Approved' AND deleted_at IS NULL
         ORDER BY due_date DESC, updated_at DESC
         LIMIT 6"
    );
    $events = fetch_all(
        "SELECT * FROM events
         WHERE status = 'Scheduled' AND event_date >= CURDATE()
         ORDER BY event_date ASC, event_time ASC
         LIMIT 6"
    );
    $feedPosts = fetch_all('SELECT * FROM posts ORDER BY created_at DESC, id DESC LIMIT 3');
    $contacts = fetch_all("SELECT * FROM public_contacts WHERE status = 'Active' ORDER BY id");
} catch (Throwable $error) {
    $portalNotice = 'Import database/schema.sql in phpMyAdmin to show live announcements and events.';
}

render_header('Public Portal', ['body_class' => 'public-page', 'public' => true]);
?>
<nav class="portal-nav">
    <?= brand_block('brand', 'public/index.php') ?>
    <a class="btn btn-ghost" href="<?= e(app_url('public/track.php')) ?>">Track request</a>
    <a class="btn btn-ghost" href="<?= e(app_url('public/verify.php')) ?>"><?= icon('qr') ?>Verify document</a>
    <button class="theme-toggle" type="button" data-theme-toggle aria-label="Switch theme" title="Switch theme"><span class="theme-toggle-icon" data-theme-icon aria-hidden="true">☾</span><span class="theme-toggle-label">Dark mode</span></button>
    <a class="btn btn-secondary" href="<?= e(app_url('login.php')) ?>">Log in</a>
</nav>
<div class="portal-wrap">
<section class="portal-hero">
    <img class="brand-logo" src="<?= e(app_url('assets/img/logo.svg')) ?>" alt="Seal of <?= e(APP_BARANGAY) ?>">
    <span class="eyebrow">Opisyal na website ng barangay &middot; <?= e(APP_MUNICIPALITY) ?>, <?= e(APP_PROVINCE) ?></span>
    <h1>Welcome to <?= e(APP_BARANGAY) ?></h1>
    <p>Announcements, events, services, requirements and fees in one place. Private resident information is only available after login.</p>
    <?php if ($portalNotice): ?><div class="alert alert-warning"><?= e($portalNotice) ?></div><?php endif; ?>
    <div class="hero-actions">
        <a class="btn btn-secondary" href="<?= e(app_url('register.php')) ?>"><?= icon('users') ?>Register as resident</a>
        <a class="btn btn-ghost" href="<?= e(app_url('login.php')) ?>">Request a document</a>
    </div>
</section>

<section class="community-gallery reveal-section" aria-labelledby="gallery-title">
    <div class="gallery-heading">
        <div><span class="eyebrow">Buhay Barangay</span><h2 id="gallery-title">Our Community in Pictures</h2><p>Mga larawan ng serbisyo, pasilidad, at mga gawain sa komunidad.</p></div>
        <span class="gallery-note"><span aria-hidden="true">📷</span> Gallery ng Komunidad</span>
    </div>
    <div class="community-photo-grid">
        <button class="community-photo" type="button" data-photo-open data-full="https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=1600&q=85" data-caption="Community gathering and bayanihan" aria-label="View community gathering photo">
            <span class="photo-frame"><img src="https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=900&q=80" alt="People gathered together for a community activity" loading="lazy"><span class="photo-zoom" aria-hidden="true">⤢</span></span><span class="photo-label"><strong>Bayanihan at Pagkakaisa</strong><small>Community activities</small></span></button>
        <button class="community-photo" type="button" data-photo-open data-full="https://images.unsplash.com/photo-1559027615-cd4628902d4a?auto=format&fit=crop&w=1600&q=85" data-caption="Volunteers working together" aria-label="View volunteer activity photo">
            <span class="photo-frame"><img src="https://images.unsplash.com/photo-1559027615-cd4628902d4a?auto=format&fit=crop&w=800&q=80" alt="Volunteers working together on a community project" loading="lazy"><span class="photo-zoom" aria-hidden="true">⤢</span></span><span class="photo-label"><strong>Serbisyong Bayan</strong><small>Volunteer activities</small></span></button>
        <button class="community-photo" type="button" data-photo-open data-full="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1600&q=85" data-caption="Community support and outreach" aria-label="View community outreach photo">
            <span class="photo-frame"><img src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=800&q=80" alt="Community members taking part in a local outreach activity" loading="lazy"><span class="photo-zoom" aria-hidden="true">⤢</span></span><span class="photo-label"><strong>Programa para sa Pamilya</strong><small>Community outreach</small></span></button>
        <button class="community-photo" type="button" data-photo-open data-full="https://images.unsplash.com/photo-1509099836639-18ba1795216d?auto=format&fit=crop&w=1600&q=85" data-caption="Youth and family community program" aria-label="View youth program photo">
            <span class="photo-frame"><img src="https://images.unsplash.com/photo-1509099836639-18ba1795216d?auto=format&fit=crop&w=800&q=80" alt="Children and families participating in a community program" loading="lazy"><span class="photo-zoom" aria-hidden="true">⤢</span></span><span class="photo-label"><strong>Kabataan at Kinabukasan</strong><small>Youth programs</small></span></button>
        <button class="community-photo" type="button" data-photo-open data-full="https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=1600&q=85" data-caption="Clean and green community initiative" aria-label="View clean and green activity photo">
            <span class="photo-frame"><img src="https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=800&q=80" alt="Volunteers helping with a clean and green community initiative" loading="lazy"><span class="photo-zoom" aria-hidden="true">⤢</span></span><span class="photo-label"><strong>Malinis at Ligtas na Barangay</strong><small>Clean-up drives</small></span></button>
    </div>
</section>
<div class="photo-lightbox" data-photo-lightbox hidden role="dialog" aria-modal="true" aria-label="Community photo viewer">
    <button class="lightbox-close" type="button" data-photo-close aria-label="Close photo viewer">×</button>
    <button class="lightbox-arrow lightbox-prev" type="button" data-photo-prev aria-label="Previous photo">‹</button>
    <figure><img src="" alt="" data-lightbox-image><figcaption data-lightbox-caption></figcaption></figure>
    <button class="lightbox-arrow lightbox-next" type="button" data-photo-next aria-label="Next photo">›</button>
</div>

<section class="grid grid-3">
    <article class="module-card">
        <h3>Office Hours</h3>
        <p>Monday to Friday, 8:00 AM to 5:00 PM. Emergency concerns may be reported through the barangay contact desk.</p>
    </article>
    <article class="module-card">
        <h3>Services</h3>
        <p>Barangay clearance, residency, indigency, good moral, business clearance, assistance requests and facility reservations.</p>
    </article>
    <article class="module-card">
        <h3>Emergency Contacts</h3>
        <?php if ($contacts): ?>
            <?php foreach ($contacts as $contact): ?>
                <p><strong><?= e($contact['label']) ?>:</strong> <?= e($contact['value']) ?><?= $contact['availability'] ? ' <small>(' . e($contact['availability']) . ')</small>' : '' ?></p>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Barangay Hall: 0917-000-0000. Tanod Desk: 0917-111-1111. Email: info@barangay.test.</p>
        <?php endif; ?>
    </article>
</section>

<section class="grid grid-2">
    <div class="panel">
        <div class="panel-header"><h2>Announcements</h2></div>
        <div class="panel-body">
            <ul class="timeline">
                <?php foreach ($announcements as $item): ?>
                    <li><strong><?= e($item['title']) ?></strong><p><?= e($item['description']) ?></p><small><?= e($item['updated_at']) ?></small></li>
                <?php endforeach; ?>
                <?php if (!$announcements): ?><li>No announcements posted.</li><?php endif; ?>
            </ul>
        </div>
    </div>
    <div class="panel">
        <div class="panel-header"><h2>Events</h2></div>
        <div class="panel-body">
            <ul class="timeline">
                <?php foreach ($events as $item): ?>
                    <li><strong><?= e($item['title']) ?></strong><p><?= e($item['description']) ?></p><small><?= e(date('M j, Y', strtotime($item['event_date']))) ?><?= $item['event_time'] ? ' ' . e(date('g:i A', strtotime($item['event_time']))) : '' ?> - <?= e($item['location']) ?></small></li>
                <?php endforeach; ?>
                <?php if (!$events): ?><li>No events scheduled.</li><?php endif; ?>
            </ul>
        </div>
    </div>
</section>

<section class="panel">
    <div class="panel-header"><h2>About <?= e(APP_BARANGAY) ?></h2></div>
    <div class="panel-body">
        <p><?= e(APP_BARANGAY) ?> is in <?= e(APP_MUNICIPALITY) ?>, <?= e(APP_PROVINCE) ?>. The barangay seal shows <strong>niyog</strong> (coconut palms), the <strong>riles ng tren</strong> (the railway that runs through the community) and the <strong>gabi at palay</strong> that grow here.</p>
    </div>
</section>

<section class="panel">
    <div class="panel-header"><h2>Public Requirements & Fees</h2></div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Service</th><th>Typical Requirements</th><th>Fee</th></tr></thead>
            <tbody>
                <tr><td>Barangay Clearance</td><td>Valid ID, resident verification, purpose</td><td><?= e(peso(document_fee('Barangay Clearance'))) ?></td></tr>
                <tr><td>Certificate of Residency</td><td>Valid ID, proof of address</td><td><?= e(peso(document_fee('Certificate of Residency'))) ?></td></tr>
                <tr><td>Certificate of Indigency</td><td>Valid ID, interview or eligibility review</td><td>Free / as assessed</td></tr>
                <tr><td>Business Clearance</td><td>Application, location, business details, assessment</td><td>As assessed</td></tr>
            </tbody>
        </table>
    </div>
</section>

<?php
$officialCards = [];
try {
    $officialCards = fetch_all(
        "SELECT users.id, users.full_name, users.position, roles.slug AS role_slug
         FROM users JOIN roles ON roles.id = users.role_id
         WHERE users.status = 'Active' AND users.position IS NOT NULL AND users.position <> ''
           AND roles.slug IN ('punong_barangay','secretary','treasurer','staff')
         ORDER BY FIELD(users.position,'Barangay Captain','Barangay Kagawad','Barangay Secretary','Barangay Treasurer','SK Chairperson','SK Kagawad'), users.id
         LIMIT 12"
    );
} catch (Throwable $error) {
    $officialCards = [];
}
if (!$officialCards) {
    $officialCards = [
        ['id' => 0, 'full_name' => 'Barangay Captain', 'position' => 'Barangay Captain'],
        ['id' => 0, 'full_name' => 'Barangay Kagawad', 'position' => 'Barangay Kagawad'],
        ['id' => 0, 'full_name' => 'Barangay Secretary', 'position' => 'Barangay Secretary'],
        ['id' => 0, 'full_name' => 'Barangay Treasurer', 'position' => 'Barangay Treasurer'],
    ];
}
$kagawadCommittees = ['Peace & Order', 'Health & Sanitation', 'Education & Culture', 'Infrastructure', 'Finance & Appropriations', 'Agriculture & Environment', 'Women, Family & Youth'];
$roleInfo = [
    'Barangay Captain'   => ['Punong Barangay', 'Chief executive of the barangay; leads Sangguniang Barangay sessions and community programs.'],
    'Barangay Kagawad'   => ['Sangguniang Barangay', 'Legislative council member; drafts ordinances and oversees a committee.'],
    'Barangay Secretary' => ['Records & Documentation', 'Keeps barangay records, certificates and meeting minutes.'],
    'Barangay Treasurer' => ['Finance & Budget', 'Handles collections, receipts and barangay funds.'],
    'SK Chairperson'     => ['Sangguniang Kabataan', 'Leads youth programs, sports and scholarships.'],
    'SK Kagawad'         => ['Sangguniang Kabataan', 'Supports youth council projects and activities.'],
];
$kagIndex = 0;
?>
<section class="officials-section reveal-on-scroll" aria-labelledby="officials-title">
    <div class="officials-heading"><span class="eyebrow">Lingkod-Bayan</span><h2 id="officials-title">Our Barangay Officials</h2><p>Mga opisyal na nangunguna sa serbisyo at pagpapaunlad ng komunidad. I-click ang ID para makita ang detalye.</p></div>
    <div class="id-grid">
        <?php foreach ($officialCards as $n => $official):
            $pos = (string) $official['position'];
            $info = $roleInfo[$pos] ?? [$pos, 'Serving the community of ' . APP_BARANGAY . '.'];
            $committee = $pos === 'Barangay Kagawad' ? $kagawadCommittees[$kagIndex++ % count($kagawadCommittees)] : $info[0];
            $idNo = 'BRGY-OFC-' . str_pad((string) ($official['id'] ?: $n + 1), 4, '0', STR_PAD_LEFT);
            $initials = '';
            foreach (array_slice(preg_split('/\s+/', trim((string) $official['full_name'])) ?: [], 0, 2) as $part) { $initials .= mb_strtoupper(mb_substr($part, 0, 1)); }
        ?>
        <div class="id-card" role="button" tabindex="0" aria-pressed="false" aria-label="<?= e($official['full_name'] . ', ' . $pos . '. Press to flip the ID card.') ?>" data-id-card>
            <div class="id-inner">
                <div class="id-face id-front">
                    <div class="id-top"><img src="<?= e(app_url('assets/img/logo.svg')) ?>" alt=""><div><strong><?= e(APP_BARANGAY) ?></strong><small>Official ID &middot; <?= e(APP_MUNICIPALITY) ?></small></div></div>
                    <div class="id-photo"><svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="22" r="12"/><path d="M10 60c1-14 9-22 22-22s21 8 22 22z"/></svg><span class="id-initials"><?= e($initials) ?></span></div>
                    <h3 class="id-name"><?= e($official['full_name']) ?></h3>
                    <span class="id-pos"><?= e($pos) ?></span>
                    <div class="id-meta"><span><?= e($idNo) ?></span><span class="id-bars" aria-hidden="true"></span></div>
                    <small class="id-hint">↻ I-click para i-flip</small>
                </div>
                <div class="id-face id-back">
                    <div class="id-top"><img src="<?= e(app_url('assets/img/logo.svg')) ?>" alt=""><div><strong>Impormasyon</strong><small><?= e($idNo) ?></small></div></div>
                    <dl class="id-info">
                        <dt>Posisyon</dt><dd><?= e($pos) ?></dd>
                        <dt><?= $pos === 'Barangay Kagawad' ? 'Komite' : 'Tanggapan' ?></dt><dd><?= e($committee) ?></dd>
                        <dt>Tungkulin</dt><dd><?= e($info[1]) ?></dd>
                        <dt>Oras ng Opisina</dt><dd>Lun-Biy, 8:00 AM - 5:00 PM</dd>
                        <dt>Barangay</dt><dd><?= e(barangay_place()) ?></dd>
                    </dl>
                    <small class="id-hint">↻ I-click para bumalik</small>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <p class="officials-note">Ang mga larawan ay pare-pareho ang laki; ang opisyal na litrato ay maaaring idagdag kapag available na.</p>
</section>

</div>
<?php render_footer(); ?>
