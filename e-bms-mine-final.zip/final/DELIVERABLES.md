# E-Barangay update package

This package contains the complete updated application source. The implementation changes cover:

- Facility and reservation edits/deletes, overlap checks, and a print summary action.
- Resident profile and household form submissions saved together to `residents`, `households`, and `household_members`; staff can review and edit submitted data in the existing management modules.
- Request statuses limited to Pending, Approved, and Rejected. New announcements publish as Approved and display on the public and account dashboards.
- Official-only certificate printing, payment approval removal from the pending assessment queue, and resident feed role filtering.
- PDF, Excel, and Word exports only; removal of the standalone reports print button and system footer.

## Existing database installation

Back up the database, then run `database/migration_request_statuses.sql` against the configured `e-bms-mine` database to normalize existing request and history statuses. Fresh installations use the updated `database/schema.sql` directly.

The application uses the existing database connection settings in `config/database.php`.
