<?php

require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

if (is_logged_in()) {
    redirect('dashboard.php');
}

/* ------------------------------------------------------------------
 * Page-local helpers (prefixed lg_ so they never clash with yours)
 * ------------------------------------------------------------------ */

/** Inline SVG icon (stroke style). */
function lg_icon(string $name): string
{
    static $paths = [
        'file'    => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h4"/>',
        'check'   => '<circle cx="12" cy="12" r="9"/><path d="m8.5 12.5 2.5 2.5 4.5-5"/>',
        'chart'   => '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
        'user'    => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
        'lock'    => '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
        'eye'     => '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
        'eye-off' => '<path d="M3 3l18 18"/><path d="M10.6 5.1A10 10 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4M6.5 6.6C3.7 8.3 2 12 2 12s3.5 7 10 7c1.6 0 3-.4 4.3-1"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
        'home'    => '<path d="M3 11.5 12 4l9 7.5"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
        'heart'   => '<path d="M12 20s-8-4.7-8-10.5A4.5 4.5 0 0 1 12 7a4.5 4.5 0 0 1 8 2.5C20 15.3 12 20 12 20z"/>',
    ];

    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'
        . ($paths[$name] ?? '') . '</svg>';
}

/**
 * Pull messages that other pages left in the session (e.g. after registering).
 * If your flash() helper uses a different session key, add it to the list.
 */
function lg_take_flashes(): array
{
    $allowed = ['success', 'warning', 'danger', 'info'];
    $out = [];

    foreach (['flashes', 'flash', 'flash_messages'] as $key) {
        if (empty($_SESSION[$key]) || !is_array($_SESSION[$key])) {
            continue;
        }
        foreach ($_SESSION[$key] as $k => $item) {
            if (is_array($item) && isset($item['message'])) {
                $type = (string) ($item['type'] ?? 'info');
                $out[] = ['type' => in_array($type, $allowed, true) ? $type : 'info', 'message' => (string) $item['message']];
            } elseif (is_string($item) && is_string($k)) {
                $out[] = ['type' => in_array($k, $allowed, true) ? $k : 'info', 'message' => $item];
            }
        }
        unset($_SESSION[$key]);
    }

    return $out;
}

/* ------------------------------------------------------------------
 * Login handling (same logic as before)
 * ------------------------------------------------------------------ */

$alerts = lg_take_flashes();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim((string) ($_POST['identifier'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $portal = ($_POST['portal'] ?? 'Resident') === 'Official' ? 'Official' : 'Resident';

    try {
        // Accept either the account email or the username.
        $user = fetch_one(
            'SELECT users.*, roles.slug AS role_slug, roles.name AS role_name
             FROM users
             JOIN roles ON roles.id = users.role_id
             WHERE users.email = ? OR users.username = ?',
            [$identifier, $identifier]
        );

        $portalMatches = $user && (($portal === 'Resident') === ($user['role_slug'] === 'resident'));

        if ($user && password_verify($password, $user['password']) && $portalMatches) {
            if ($user['status'] === 'Pending') {
                $alerts[] = ['type' => 'warning', 'message' => 'Your official account is waiting for approval by the System Administrator.'];
            } elseif ($user['status'] !== 'Active') {
                $alerts[] = ['type' => 'danger', 'message' => 'Your account is inactive. Please contact your barangay administrator.'];
            } else {
                session_regenerate_id(true);
                $_SESSION['user_id'] = (int) $user['id'];
                audit_log('Login', 'User', (int) $user['id'], 'User logged in successfully.');
                redirect('dashboard.php');
            }
        } else {
            audit_log('Failed login', 'User', null, 'Failed login attempt for ' . $identifier . ' (' . $portal . ' portal)');
            $alerts[] = ['type' => 'danger', 'message' => 'Wrong username/email, password, or portal. Check that you picked the right portal above.'];
        }
    } catch (Throwable $error) {
        $alerts[] = ['type' => 'danger', 'message' => 'Database connection failed. Check config/database.php and follow the setup or safe migration instructions in README.md.'];
    }
}

$logo = app_url('assets/img/logo.svg');

$points = [
    ['file',  'Request documents online', 'Clearance, residency and indigency certificates without the queue.'],
    ['check', 'Track every request',      'See each step from submitted to ready for pickup.'],
    ['chart', 'Open barangay budget',     'Read how public funds and projects are being used.'],
];

$services = [
    ['file',  'Barangay clearance',        'For jobs, IDs, and other official transactions.',          'Sign in to request'],
    ['home',  'Certificate of residency', 'Proof that you live in Barangay Bigaan.',                    'Sign in to request'],
    ['heart', 'Certificate of indigency', 'For assistance programs, scholarships, and medical help.',  'Sign in to request'],
    ['check', 'Track my request',         'Follow each step until your document is ready for pickup.', 'Sign in to track'],
];

$stats = [
    ['7',    'Document types'],
    ['24/7', 'Online access'],
    ['2',    'Portals'],
];

$quick = [
    ['file',  'Clearance',   'Barangay clearance'],
    ['home',  'Residency',   'Certificate of residency'],
    ['heart', 'Indigency',   'Certificate of indigency'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sign in · E-Barangay Bigaan</title>
    <link rel="icon" href="<?= e($logo) ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap">
    <style>
:root {
    --nav-h: 76px;
    --lime: #A7F432;
    --dark: #0F1F16;
    --light: #EAF3E7;
    --teal: #3B8F7B;
    --bg: #08130d;
    --panel: rgba(15, 31, 22, .82);
    --panel-line: rgba(167, 244, 50, .16);
    --muted: #b3c4b9;
    --ink: #0F1F16;
    --ink-muted: #51635a;
    --line: #cfdccb;
    --font: 'Plus Jakarta Sans', system-ui, -apple-system, 'Segoe UI', Roboto, Arial, sans-serif;
}
*, *::before, *::after { box-sizing: border-box; }
html { scroll-behavior: smooth; }
body { margin: 0; min-height: 100vh; font-family: var(--font); color: var(--light); line-height: 1.55; -webkit-font-smoothing: antialiased;
    background: radial-gradient(ellipse 60% 45% at 78% 18%, rgba(60, 200, 90, .20), transparent 70%),
                radial-gradient(ellipse 55% 40% at 10% 90%, rgba(59, 143, 123, .22), transparent 70%), var(--bg); background-attachment: fixed; }
img, svg { display: block; max-width: 100%; }
:focus-visible { outline: 3px solid var(--lime); outline-offset: 2px; }
.sr-only { position: absolute; width: 1px; height: 1px; margin: -1px; padding: 0; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; border: 0; }

/* Navigation */
.site-nav { position: fixed; inset: 0 0 auto 0; height: var(--nav-h); z-index: 50; background: rgba(8, 19, 13, .88); -webkit-backdrop-filter: blur(10px); backdrop-filter: blur(10px); border-bottom: 1px solid var(--panel-line); }
.nav-inner { height: 100%; max-width: 1240px; margin: 0 auto; padding: 0 24px; display: flex; align-items: center; justify-content: space-between; gap: 24px; }
.brand { display: flex; align-items: center; gap: 12px; color: #fff; text-decoration: none; }
.brand img { width: 50px; height: 50px; border-radius: 50%; }
.brand strong { display: block; font-size: 1.05rem; font-weight: 800; line-height: 1.2; }
.brand small { display: block; font-size: .72rem; color: var(--muted); }
.nav-links { display: flex; align-items: center; gap: 10px; }
.nav-links a { color: var(--light); font-size: .85rem; font-weight: 600; text-decoration: none; padding: 8px 16px; border-radius: 999px; transition: color .2s ease, background-color .2s ease; }
.nav-links a:hover { color: var(--lime); }
.nav-links a.is-active { color: var(--lime); background: rgba(167, 244, 50, .1); }
.nav-links .nav-cta { margin-left: 8px; background: var(--lime); color: var(--dark); font-weight: 800; box-shadow: 0 0 22px rgba(167, 244, 50, .35); }
.nav-links .nav-cta:hover { color: var(--dark); box-shadow: 0 0 32px rgba(167, 244, 50, .6); }
.nav-toggle { display: none; width: 44px; height: 44px; padding: 0; border: 1px solid var(--panel-line); border-radius: 50%; background: rgba(255, 255, 255, .04); cursor: pointer; flex-direction: column; align-items: center; justify-content: center; gap: 5px; }
.nav-toggle span { width: 18px; height: 2px; background: #fff; border-radius: 2px; }

/* Layout */
.page-section { padding: 16px 24px 40px; }
.page-section--home { min-height: 100vh; min-height: 100svh; display: flex; align-items: center; justify-content: center; padding: calc(var(--nav-h) + 28px) 24px 40px; }
.page-section--end { display: flex; flex-direction: column; min-height: calc(100svh - var(--nav-h) - 12px); }
.page-section--end .container { flex: 1; display: flex; flex-direction: column; }
.container { width: 100%; max-width: 1240px; margin: 0 auto; }

/* Hero: one rounded shell, three columns (copy / sign-in / quick links) */
.hero-shell { padding: 40px 44px 44px; border-radius: 30px; background: linear-gradient(160deg, #0f1d16, #0a140f); border: 1px solid rgba(167, 244, 50, .22); box-shadow: 0 0 80px rgba(80, 230, 110, .22), inset 0 0 50px rgba(167, 244, 50, .04); }
.hero-grid { display: grid; grid-template-columns: minmax(0, 1fr) 420px 200px; gap: 22px; align-items: stretch; }
.auth-hero { display: flex; flex-direction: column; justify-content: center; padding-right: 8px; }
.eyebrow { margin: 0 0 20px; font-size: .7rem; font-weight: 600; letter-spacing: .3em; color: #c9d5cd; }
.auth-hero h1 { margin: 0; font-size: clamp(2.2rem, 4vw, 3.5rem); font-weight: 700; line-height: 1.05; letter-spacing: -.02em; color: #fff; }
.auth-hero .lead { margin: 20px 0 26px; max-width: 40ch; font-size: .95rem; color: #cfd9d2; }
.cta { align-self: flex-start; display: inline-flex; align-items: center; gap: 12px; padding: 14px 26px; font-size: .9rem; font-weight: 800; color: var(--dark); text-decoration: none; background: var(--lime); border-radius: 999px; box-shadow: 0 0 26px rgba(167, 244, 50, .45); transition: transform .2s ease, box-shadow .2s ease; }
.cta:hover { transform: translateY(-2px); box-shadow: 0 0 38px rgba(167, 244, 50, .7); }
.stats { display: flex; margin: 44px 0 0; padding: 0; list-style: none; }
.stats li { padding: 0 20px; border-left: 1px solid rgba(255, 255, 255, .2); }
.stats li:first-child { padding-left: 0; border: 0; }
.stats b { display: block; font-size: 1.35rem; font-weight: 700; color: #fff; }
.stats span { font-size: .74rem; color: var(--muted); }

/* Sign-in card (light, so it is the focus of the hero) */
.auth-card { position: relative; overflow: hidden; padding: 34px 30px 24px; background: var(--light); color: var(--ink); border-radius: 24px; border: 1px solid rgba(255, 255, 255, .5); box-shadow: 0 30px 60px -24px rgba(0, 0, 0, .7), 0 0 40px rgba(167, 244, 50, .12); }
.auth-card h2 { margin: 0 0 4px; font-size: 1.65rem; font-weight: 800; letter-spacing: -.02em; }
.card-sub { margin: 0 0 18px; font-size: .84rem; color: var(--ink-muted); }
.login-form { display: grid; gap: 14px; }
.portal-field { margin: 0; padding: 0; border: 0; min-width: 0; }
.portal-switch { display: grid; grid-template-columns: 1fr 1fr; gap: 4px; padding: 4px; background: #d9e6d5; border-radius: 999px; }
.portal-option { position: relative; cursor: pointer; }
.portal-option input { position: absolute; opacity: 0; inset: 0; margin: 0; cursor: pointer; }
.portal-option span { display: block; padding: 10px 8px; border-radius: 999px; text-align: center; font-size: .8rem; font-weight: 700; color: #476055; transition: background-color .2s ease, color .2s ease; }
.portal-option input:checked + span { background: var(--dark); color: var(--lime); }
.portal-option input:focus-visible + span { outline: 3px solid var(--teal); outline-offset: 2px; }
.field label { display: block; margin-bottom: 6px; font-size: .78rem; font-weight: 700; }
.input-wrap { position: relative; }
.lead-icon { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #6f8378; pointer-events: none; }
.lead-icon svg { width: 18px; height: 18px; }
.form-control { width: 100%; height: 46px; padding: 0 46px 0 42px; font: inherit; font-size: .88rem; color: var(--ink); background: #fff; border: 1px solid var(--line); border-radius: 14px; transition: border-color .2s ease, box-shadow .2s ease; }
.form-control::placeholder { color: #8a9c92; }
.form-control:focus { outline: none; border-color: var(--teal); box-shadow: 0 0 0 3px rgba(59, 143, 123, .28); }
.toggle-pass { position: absolute; right: 6px; top: 50%; transform: translateY(-50%); width: 36px; height: 36px; display: grid; place-items: center; padding: 0; border: 0; border-radius: 50%; background: transparent; color: #51635a; cursor: pointer; }
.toggle-pass:hover { background: rgba(0, 0, 0, .06); }
.toggle-pass svg { width: 19px; height: 19px; }
.toggle-pass .icon-off { display: none; }
.toggle-pass[aria-pressed="true"] .icon-on { display: none; }
.toggle-pass[aria-pressed="true"] .icon-off { display: block; }
.btn { display: flex; align-items: center; justify-content: center; width: 100%; height: 48px; padding: 0 18px; font: inherit; font-size: .92rem; font-weight: 800; color: var(--dark); background: var(--lime); border: 0; border-radius: 999px; cursor: pointer; box-shadow: 0 10px 24px -10px rgba(120, 200, 20, .9); transition: transform .15s ease, box-shadow .2s ease; }
.btn:hover { box-shadow: 0 12px 30px -8px rgba(120, 200, 20, 1); }
.btn:active { transform: translateY(1px); }
.card-foot { margin: 16px 0 0; text-align: center; font-size: .8rem; color: var(--ink-muted); }
.card-foot a { color: #1f6f5c; font-weight: 800; text-decoration: none; }
.card-foot a:hover { text-decoration: underline; }
.alert { margin: 0 0 14px; padding: 11px 14px; border-radius: 12px; font-size: .8rem; font-weight: 600; line-height: 1.45; }
.alert-danger { background: #fde8e6; color: #8a2018; }
.alert-warning { background: #fff3d6; color: #6b4a00; }
.alert-success { background: #dcf3d2; color: #1d5a35; }
.alert-info { background: #dcebe6; color: #17475a; }
.demo-box { margin-top: 14px; padding-top: 12px; border-top: 1px dashed #b9c9b4; font-size: .8rem; }
.demo-box summary { cursor: pointer; font-weight: 700; color: #1f6f5c; }
.demo-chips { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px; }
.demo-chips button { padding: 6px 12px; font: inherit; font-size: .76rem; font-weight: 700; color: var(--dark); background: #fff; border: 1px solid var(--line); border-radius: 999px; cursor: pointer; }
.demo-chips button:hover { background: #e3f2d6; }

/* Quick links (the three tiles on the right) */
.side { display: flex; flex-direction: column; gap: 14px; }
.quick { flex: 1; position: relative; display: flex; flex-direction: column; justify-content: flex-end; gap: 4px; padding: 16px; min-height: 110px; color: #fff; text-decoration: none; font-size: .82rem; font-weight: 600; background: linear-gradient(160deg, #415349, #2a3a31); border: 1px solid var(--panel-line); border-radius: 20px; transition: transform .2s ease, border-color .2s ease; }
.quick:nth-child(2) { background: linear-gradient(160deg, #76865a, #3a4a35); }
.quick:hover { transform: translateY(-3px); border-color: rgba(167, 244, 50, .55); }
.quick .tile { position: absolute; top: 14px; left: 14px; }
.quick small { font-size: .7rem; font-weight: 500; color: #d3dfd6; }
.quick .go { position: absolute; right: 14px; bottom: 14px; }
.tile { flex: none; width: 40px; height: 40px; display: grid; place-items: center; border-radius: 12px; color: var(--lime); background: rgba(167, 244, 50, .12); border: 1px solid rgba(167, 244, 50, .3); }
.tile svg { width: 20px; height: 20px; }

/* Other sections */
.panel { padding: 44px; background: var(--panel); border: 1px solid var(--panel-line); border-radius: 28px; box-shadow: 0 30px 70px -30px rgba(0, 0, 0, .7); }
.panel h2 { margin: 0 0 12px; font-size: clamp(1.9rem, 3.6vw, 2.7rem); font-weight: 800; line-height: 1.05; letter-spacing: -.025em; color: #fff; }
.panel-lead { margin: 0; max-width: 62ch; font-size: .92rem; color: #d8e4db; }
.service-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 16px; margin-top: 30px; }
.service-card { display: flex; flex-direction: column; padding: 20px; color: inherit; text-decoration: none; background: rgba(255, 255, 255, .04); border: 1px solid var(--panel-line); border-radius: 20px; transition: border-color .2s ease, transform .2s ease; }
.service-card:hover { border-color: rgba(167, 244, 50, .55); transform: translateY(-3px); }
.service-card h3 { margin: 22px 0 6px; font-size: 1rem; font-weight: 800; color: #fff; }
.service-card p { margin: 0; font-size: .8rem; color: var(--muted); }
.card-link { margin-top: auto; padding-top: 16px; font-size: .8rem; font-weight: 800; color: var(--lime); }
.about-panel { display: grid; grid-template-columns: 230px minmax(0, 1fr); gap: 40px; align-items: center; }
.about-seal-img { width: 220px; height: 220px; border-radius: 50%; box-shadow: 0 0 40px rgba(167, 244, 50, .2); }
.seal-facts { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; margin: 22px 0 0; }
.seal-facts div { padding: 12px 14px; background: rgba(255, 255, 255, .04); border: 1px solid var(--panel-line); border-radius: 16px; }
.seal-facts dt { font-size: .84rem; font-weight: 800; color: var(--lime); }
.seal-facts dd { margin: 2px 0 0; font-size: .76rem; color: var(--muted); }
.site-footer { margin-top: auto; padding-top: 40px; text-align: center; font-size: .76rem; color: #cfdcd2; }

/* Responsive */
@media (max-width: 1100px) {
    .hero-grid { grid-template-columns: minmax(0, 1fr) 400px; }
    .side { grid-column: 1 / -1; flex-direction: row; }
}
@media (max-width: 860px) {
    .nav-toggle { display: flex; }
    .nav-links { position: absolute; top: calc(var(--nav-h) - 4px); left: 12px; right: 12px; flex-direction: column; align-items: stretch; gap: 4px; padding: 10px; background: rgba(8, 19, 13, .98); border: 1px solid var(--panel-line); border-radius: 18px; display: none; }
    .nav-links.is-open { display: flex; }
    .nav-links a { padding: 12px 14px; }
    .nav-links .nav-cta { margin: 4px 0 0; text-align: center; }
    .hero-shell { padding: 26px 20px 28px; border-radius: 24px; }
    .hero-grid { grid-template-columns: minmax(0, 1fr); }
    .auth-card { width: 100%; }
    .stats { margin-top: 30px; }
    .service-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
@media (max-width: 720px) {
    .panel { padding: 28px 22px; }
    .about-panel { grid-template-columns: 1fr; justify-items: center; text-align: center; gap: 24px; }
    .about-seal-img { width: 160px; height: 160px; }
    .seal-facts { grid-template-columns: 1fr; text-align: left; }
}
@media (max-width: 560px) {
    .page-section { padding-left: 14px; padding-right: 14px; }
    .service-grid { grid-template-columns: 1fr; }
    .side { flex-direction: column; }
    .auth-card { padding: 30px 20px 20px; }
    .stats li { padding: 0 12px; }
}
@media (prefers-reduced-motion: reduce) {
    html { scroll-behavior: auto; }
    * { transition-duration: .01ms !important; }
}

/* Glassmorphism background glowing effect for login.php */
body .hero-shell, body .shell {
    background: linear-gradient(160deg, rgba(15, 29, 22, .70), rgba(10, 20, 15, .55));
    -webkit-backdrop-filter: blur(6px); backdrop-filter: blur(6px);
}
body .panel { 
    background: rgba(15, 31, 22, .72); 
    -webkit-backdrop-filter: blur(8px); 
    backdrop-filter: blur(8px); 
}
    
/* Community photo rail beside sign-in + universal theme controls */
.login-theme-toggle{border:1px solid rgba(255,255,255,.25);background:rgba(255,255,255,.10);color:inherit;border-radius:999px;padding:9px 13px;display:inline-flex;align-items:center;gap:8px;cursor:pointer;font:600 12px var(--font)}
.login-community-gallery{display:flex;flex-direction:column;gap:12px;min-width:0}.login-gallery-heading h2{font-size:1.3rem;margin:.25rem 0}.login-gallery-heading p,.login-gallery-note{font-size:.78rem;color:var(--muted);margin:0}.login-gallery-photo{position:relative;display:block;width:100%;height:118px;padding:0;border:1px solid rgba(255,255,255,.18);border-radius:15px;overflow:hidden;background:#15251d;text-align:left;cursor:pointer;box-shadow:0 10px 24px #0002;transition:transform .25s,border-color .25s}.login-gallery-photo:hover{transform:translateY(-3px);border-color:var(--lime)}.login-gallery-photo img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .5s}.login-gallery-photo:hover img{transform:scale(1.06)}.login-gallery-photo:after{content:"";position:absolute;inset:25% 0 0;background:linear-gradient(transparent,rgba(0,0,0,.82))}.login-gallery-photo>span{position:absolute;z-index:1;left:12px;right:10px;bottom:10px;color:#fff;display:grid;gap:2px}.login-gallery-photo strong{font-size:.82rem}.login-gallery-photo small{font-size:.7rem;color:#e1e8e3}.login-gallery-note{font-size:.68rem}.photo-lightbox{position:fixed;z-index:99999;inset:0;background:rgba(4,9,7,.95);display:flex;align-items:center;justify-content:center;gap:16px;padding:60px 16px 24px;backdrop-filter:blur(12px)}.photo-lightbox[hidden]{display:none}.photo-lightbox figure{margin:0;max-width:min(900px,75vw);text-align:center}.photo-lightbox figure img{max-width:100%;max-height:75vh;object-fit:contain;border-radius:14px}.photo-lightbox figcaption{color:white;margin-top:10px}.lightbox-close,.lightbox-arrow{border:1px solid #ffffff35;background:#ffffff18;color:#fff;border-radius:50%;display:grid;place-items:center;cursor:pointer;width:44px;height:44px;font-size:2rem}.lightbox-close{position:absolute;right:20px;top:16px}
body[data-theme="light"]{--bg:#dfeadf;--panel:rgba(255,255,255,.55);--panel-line:#dce5df;--muted:#52645a;color:#17251c;background:#eef3f0}body[data-theme="light"] .auth-card,body[data-theme="light"] .panel{background:rgba(255,255,255,.94);color:#17251c;border-color:#dce5df}body[data-theme="light"] .card-sub,body[data-theme="light"] .lead,body[data-theme="light"] .auth-hero .lead{color:#52645a}body[data-theme="light"] .login-theme-toggle{background:#fff;color:#24352b;border-color:#d3ddd6}
@media(max-width:1100px){.login-community-gallery{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));grid-column:1/-1}.login-gallery-heading,.login-gallery-note{grid-column:1/-1}.login-gallery-photo{height:145px}}
@media(max-width:600px){.login-community-gallery{grid-template-columns:1fr}.login-gallery-photo{height:155px}.login-theme-toggle .theme-toggle-label{display:none}}


/* ===== Final design: framed photo cards + flip ID cards (login landing page) ===== */
.lg-grid{display:grid;gap:18px;margin-top:8px}
.lg-grid-4{grid-template-columns:repeat(4,minmax(0,1fr))}.lg-grid-3{grid-template-columns:repeat(3,minmax(0,1fr))}
.lg-card{display:flex;flex-direction:column;min-width:0;padding:10px;border-radius:20px;border:1px solid var(--panel-line);background:rgba(15,31,22,.72);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);color:inherit;font:inherit;text-align:left;cursor:zoom-in;box-shadow:0 14px 30px -20px rgba(0,0,0,.8);transition:transform .3s ease,box-shadow .3s ease,border-color .3s}
.lg-card:hover,.lg-card:focus-visible{transform:translateY(-5px);border-color:var(--lime);box-shadow:0 0 0 1px var(--lime),0 18px 34px -16px rgba(167,244,50,.35);outline:none}
.lg-photo{position:relative;display:block;width:100%;aspect-ratio:4/3;overflow:hidden;border-radius:14px;border:1px solid var(--panel-line);background:#17231c}
.lg-photo img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transition:transform .6s ease}
.lg-card:hover .lg-photo img{transform:scale(1.07)}
.lg-zoom{position:absolute;right:8px;top:8px;width:30px;height:30px;display:grid;place-items:center;border-radius:50%;background:rgba(5,16,10,.7);color:#fff;opacity:0;transform:scale(.8);transition:.25s}
.lg-card:hover .lg-zoom,.lg-card:focus-visible .lg-zoom{opacity:1;transform:none}
.lg-label{display:flex;flex-direction:column;gap:3px;padding:12px 6px 6px;text-align:center;flex:1}
.lg-label small{font-size:.68rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--lime)}
.lg-label strong{font-size:1rem;line-height:1.3;color:#fff}
.lg-label em{font-style:normal;font-size:.8rem;line-height:1.45;color:var(--muted)}
.lg-card-rail{flex-direction:row;align-items:center;gap:10px;padding:8px}.lg-card-rail .lg-photo{width:44%;flex:none;aspect-ratio:4/3}.lg-card-rail .lg-label{padding:0;text-align:left}.lg-card-rail .lg-label strong{font-size:.9rem}
.login-community-gallery{gap:10px}
@media(max-width:1100px){.lg-grid-4{grid-template-columns:repeat(2,minmax(0,1fr))}.lg-card-rail{flex-direction:column;align-items:stretch}.lg-card-rail .lg-photo{width:100%}.lg-card-rail .lg-label{text-align:center;padding:10px 4px 4px}}
@media(max-width:700px){.lg-grid-3{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:480px){.lg-grid-4,.lg-grid-3{grid-template-columns:1fr}}
.officials-section{padding-top:20px}
@property --id-angle{syntax:"<angle>";inherits:false;initial-value:0deg}
.id-grid{display:flex;flex-wrap:wrap;justify-content:center;gap:1.4rem;perspective:1400px}
.id-card{position:relative;width:250px;height:370px;cursor:pointer;outline:none;-webkit-tap-highlight-color:transparent}
.id-inner{position:relative;width:100%;height:100%;transform-style:preserve-3d;transition:transform .8s cubic-bezier(.2,.75,.2,1)}
.id-card.is-flipped .id-inner{transform:rotateY(180deg)}
.id-card:hover:not(.is-flipped) .id-inner{transform:rotateY(8deg) translateY(-4px)}
.id-face{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;padding:14px 16px 12px;border-radius:20px;color:#e9f6ec;text-align:center;backface-visibility:hidden;-webkit-backface-visibility:hidden;overflow:hidden;
  border:3px solid transparent;
  background:linear-gradient(160deg,#10281c,#0a1a12 70%) padding-box,conic-gradient(from var(--id-angle),#a7f432,#34d399,#22d3ee,#a7f432 55%,#1b4d33 70%,#a7f432) border-box;
  animation:id-spin 4s linear infinite;box-shadow:0 0 18px rgba(167,244,50,.35),0 12px 28px rgba(0,0,0,.35)}
.id-face:before{content:"";position:absolute;inset:0;pointer-events:none;background:linear-gradient(115deg,transparent 35%,rgba(255,255,255,.09) 48%,transparent 60%);background-size:250% 100%;animation:id-shine 5s ease-in-out infinite}
.id-back{transform:rotateY(180deg);justify-content:flex-start}
.id-card:hover .id-face,.id-card:focus-visible .id-face{box-shadow:0 0 30px rgba(167,244,50,.65),0 16px 34px rgba(0,0,0,.4)}
.id-card:focus-visible{outline:2px solid #a7f432;outline-offset:6px;border-radius:22px}
.id-top{width:100%;display:flex;align-items:center;gap:8px;padding-bottom:8px;border-bottom:1px solid rgba(167,244,50,.3);text-align:left}
.id-top img{width:32px;height:32px;border-radius:50%;background:#fff;object-fit:contain;flex:none}
.id-top strong{display:block;font-size:.8rem;line-height:1.15;color:#dff7c2}
.id-top small{display:block;font-size:.62rem;color:#9fc4ad;letter-spacing:.04em}
.id-photo{position:relative;width:120px;height:120px;flex:none;margin:16px 0 12px;border-radius:50%;display:grid;place-items:center;overflow:hidden;background:linear-gradient(145deg,#2f6b4a,#143626);border:3px solid #a7f432;box-shadow:0 0 16px rgba(167,244,50,.45)}
.id-photo svg{width:78px;height:78px;fill:rgba(223,247,194,.88)}
.id-initials{position:absolute;bottom:6px;font-size:.7rem;font-weight:800;letter-spacing:.1em;color:#0a1a12;background:#a7f432;padding:1px 8px;border-radius:999px}
.id-name{margin:0;font-size:1.02rem;line-height:1.25;color:#fff;min-height:2.5em;display:flex;align-items:center;justify-content:center}
.id-pos{margin-top:4px;font-size:.7rem;font-weight:800;letter-spacing:.07em;text-transform:uppercase;color:#a7f432}
.id-meta{margin-top:auto;width:100%;display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:.65rem;color:#9fc4ad;font-family:ui-monospace,Consolas,monospace}
.id-bars{height:20px;width:70px;background:repeating-linear-gradient(90deg,#cfe9d6 0 2px,transparent 2px 4px,#cfe9d6 4px 5px,transparent 5px 8px)}
.id-hint{margin-top:8px;font-size:.62rem;color:#7fa08c;letter-spacing:.05em}
.id-info{width:100%;margin:12px 0 0;text-align:left;font-size:.74rem;display:grid;gap:2px}
.id-info dt{margin-top:6px;font-size:.58rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:#a7f432}
.id-info dd{margin:0;line-height:1.35;color:#e9f6ec}
.id-back .id-hint{margin-top:auto}
@keyframes id-spin{to{--id-angle:360deg}}
@keyframes id-shine{0%,100%{background-position:150% 0}50%{background-position:-50% 0}}
@media(max-width:560px){.id-card{width:min(250px,86vw)}}
@media(prefers-reduced-motion:reduce){.id-face,.id-face:before{animation:none!important}.id-inner{transition:none}}


/* ===== Unified light/dark (matches the app): glass panels in both modes ===== */
body[data-theme="light"]{color:#14231a;background:#dfeadf}
body[data-theme="light"] :is(.auth-card,.panel,.lg-card,.steps li,.service-card,.hero-shell,.shell,.stats li){background:rgba(255,255,255,.55)!important;color:#14231a!important;border:1px solid rgba(255,255,255,.8)!important;-webkit-backdrop-filter:blur(16px) saturate(150%);backdrop-filter:blur(16px) saturate(150%);box-shadow:0 18px 40px -22px rgba(15,31,22,.5)!important}
body[data-theme="light"] :is(h1,h2,h3,h4,p,label,li,dt,dd,small,.lead,.card-sub,.panel-lead,.hint,.stats strong,.stats span,.service-card p,.service-card h3){color:#14231a!important}
body[data-theme="light"] :is(.muted,.card-sub,.login-gallery-heading p,.login-gallery-note,.lg-label em){color:#41554a!important}
body[data-theme="light"] .eyebrow,body[data-theme="light"] .lg-label small,body[data-theme="light"] .card-link{color:#1f6f5c!important}
body[data-theme="light"] .site-nav{background:rgba(255,255,255,.72)!important;border-bottom:1px solid rgba(255,255,255,.8)}
body[data-theme="light"] .site-nav :is(.brand,.brand strong,.brand small,.nav-links a:not(.nav-cta)){color:#14231a!important}
body[data-theme="light"] .nav-links a.is-active{background:rgba(31,111,92,.12);color:#1f6f5c!important}
body[data-theme="light"] :is(input,select,textarea){background:rgba(255,255,255,.75)!important;color:#14231a!important;border-color:rgba(15,31,22,.22)!important}
body[data-theme="light"] .login-theme-toggle{background:rgba(255,255,255,.7);border-color:rgba(15,31,22,.22);color:#14231a}
body[data-theme="light"] .site-footer,body[data-theme="light"] .site-footer strong{color:#41554a}
body[data-theme="light"] .site-footer span{color:#1f6f5c}
body[data-theme="light"] .lg-label strong,body[data-theme="light"] .community-section-heading h2,body[data-theme="light"] .community-disclaimer{color:#14231a!important}
body[data-theme="light"] .bg-scene{background:#dfeadf}
body[data-theme="light"] .auth-hero h1,body[data-theme="light"] .auth-hero .lead{color:#14231a!important}
body[data-theme="light"] .portal-option input:checked + span{background:#0F1F16;color:#A7F432}
body[data-theme="light"] .btn,body[data-theme="light"] .cta,body[data-theme="light"] .nav-cta{color:#0F1F16!important}
body[data-theme="light"] .eyebrow{color:#1f6f5c}
body[data-theme="light"] :is(strong,b,.steps li strong,.steps strong){color:#14231a!important}
body[data-theme="light"] :is(.btn,.cta,.nav-cta,.btn strong){color:#0F1F16!important}
</style>
    <link rel="stylesheet" href="<?= e(app_url('assets/css/bg-scene.css')) ?>">
</head>
<body class="auth-page" data-theme="light">
<?= bg_scene() ?>

<!-- Navigation -->
<header class="site-nav">
    <div class="nav-inner">
        <a class="brand" href="#home" aria-label="E-Barangay, back to top">
            <img src="<?= e($logo) ?>" alt="Seal of <?= e(APP_BARANGAY) ?>">
            <span>
                <strong>E-Barangay</strong>
                <small>Bigaan, Calauag, Quezon</small>
            </span>
        </a>
        <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="nav-menu" aria-label="Toggle menu">
            <span></span><span></span><span></span>
        </button>
        <nav id="nav-menu" class="nav-links" aria-label="Page sections">
            <a href="#home">Home</a>
            <a href="#services">Public services</a>
            <a href="#activities">Activities</a>
            <a href="#facilities">Facilities</a>
            <a href="#officials">Officials</a>
            <a href="#about">About</a>
            <button class="theme-toggle login-theme-toggle" type="button" data-theme-toggle aria-label="Switch theme" title="Switch theme"><span class="theme-toggle-icon" data-theme-icon aria-hidden="true">☾</span><span class="theme-toggle-label">Dark mode</span></button>
            <a class="nav-cta" href="<?= e(app_url('register.php')) ?>">Create account</a>
        </nav>
    </div>
</header>

<main>
    <!-- HOME -->
    <section id="home" class="page-section page-section--home" data-section>
        <div class="container hero-shell">
            <div class="hero-grid">

                <!-- Column 1: copy -->
                <div class="auth-hero">
                    <p class="eyebrow">BARANGAY BIGAAN · CALAUAG, QUEZON</p>
                    <h1>Serbisyo ng Barangay, abot-kamay na.</h1>
                    <p class="lead">Request barangay documents, follow your application, and see what is happening in the community, all from one secure portal.</p>
                    <a class="cta" href="#services">Explore services <span aria-hidden="true">→</span></a>
                    <ul class="stats">
                        <?php foreach ($stats as [$num, $label]): ?>
                            <li><b><?= e($num) ?></b><span><?= e($label) ?></span></li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <!-- Column 2: sign in -->
                <div class="auth-card">
                    <h2>Welcome back</h2>
                    <p class="card-sub">Sign in to request and track your documents.</p>

                    <?php foreach ($alerts as $alert): ?>
                        <div class="alert alert-<?= e($alert['type']) ?>" role="alert"><?= e($alert['message']) ?></div>
                    <?php endforeach; ?>

                    <form method="post" class="login-form" autocomplete="on">
                        <fieldset class="portal-field">
                            <legend class="sr-only">Sign in to</legend>
                            <div class="portal-switch">
                                <label class="portal-option">
                                    <input type="radio" name="portal" value="Resident" <?= checked(old('portal', 'Resident') !== 'Official') ?>>
                                    <span>Resident</span>
                                </label>
                                <label class="portal-option">
                                    <input type="radio" name="portal" value="Official" <?= checked(old('portal', 'Resident') === 'Official') ?>>
                                    <span>Official / Admin</span>
                                </label>
                            </div>
                        </fieldset>

                        <div class="field">
                            <label for="identifier">Username</label>
                            <div class="input-wrap">
                                <span class="lead-icon"><?= lg_icon('user') ?></span>
                                <input class="form-control" id="identifier" type="text" name="identifier" placeholder="Enter your username" autocomplete="username" required>
                            </div>
                        </div>

                        <div class="field">
                            <label for="password">Password</label>
                            <div class="input-wrap">
                                <span class="lead-icon"><?= lg_icon('lock') ?></span>
                                <input class="form-control" id="password" type="password" name="password" placeholder="Enter your password" autocomplete="current-password" required>
                                <button class="toggle-pass" type="button" aria-label="Show password" aria-pressed="false">
                                    <span class="icon-on"><?= lg_icon('eye') ?></span>
                                    <span class="icon-off"><?= lg_icon('eye-off') ?></span>
                                </button>
                            </div>
                        </div>

                        <button class="btn" type="submit">Sign in</button>
                    </form>

                    <p class="card-foot">New to the portal? <a href="<?= e(app_url('register.php')) ?>">Register as a resident</a></p>

                    <?php if (APP_DEMO): ?>
                    <details class="demo-box">
                        <summary>Demo / Test Credentials (Click to Autofill)</summary>
                        <div class="demo-chips">
                            <?php foreach (['admin' => 'Administrator', 'secretary' => 'Secretary', 'treasurer' => 'Treasurer', 'captain' => 'Punong Barangay', 'staff' => 'Staff', 'juan' => 'Resident'] as $uname => $label): ?>
                                <button type="button" data-demo-email="<?= e($uname) ?>" data-demo-portal="<?= $uname === 'juan' ? 'Resident' : 'Official' ?>" data-demo-password="password"><?= e($label) ?></button>
                            <?php endforeach; ?>
                        </div>
                    </details>
                    <?php endif; ?>
                </div>

                <!-- Column 3: barangay photo gallery, beside sign-in -->
                <aside class="side login-community-gallery" aria-label="Barangay community photos">
                    <div class="login-gallery-heading"><span class="eyebrow">Buhay Barangay</span><h2>Our Community</h2><p>Mga larawan ng bayanihan at serbisyong pangkomunidad.</p></div>
                    <button class="lg-card lg-card-rail" type="button" data-login-photo-open data-full="https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=1400&q=85" data-caption="Bayanihan at Pagkakaisa" aria-label="View photo: Bayanihan at Pagkakaisa"><span class="lg-photo"><img loading="lazy" src="https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=700&q=80" alt="Community gathering"><span class="lg-zoom" aria-hidden="true">&#x2922;</span></span><span class="lg-label"><strong>Bayanihan at Pagkakaisa</strong></span></button>
                    <button class="lg-card lg-card-rail" type="button" data-login-photo-open data-full="https://images.unsplash.com/photo-1559027615-cd4628902d4a?auto=format&fit=crop&w=1400&q=85" data-caption="Serbisyong Bayan" aria-label="View photo: Serbisyong Bayan"><span class="lg-photo"><img loading="lazy" src="https://images.unsplash.com/photo-1559027615-cd4628902d4a?auto=format&fit=crop&w=700&q=80" alt="Volunteers helping with a community project"><span class="lg-zoom" aria-hidden="true">&#x2922;</span></span><span class="lg-label"><strong>Serbisyong Bayan</strong></span></button>
                    <button class="lg-card lg-card-rail" type="button" data-login-photo-open data-full="https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=1400&q=85" data-caption="Malinis at Ligtas na Barangay" aria-label="View photo: Malinis at Ligtas na Barangay"><span class="lg-photo"><img loading="lazy" src="https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=700&q=80" alt="Community clean-up activity"><span class="lg-zoom" aria-hidden="true">&#x2922;</span></span><span class="lg-label"><strong>Malinis at Ligtas na Barangay</strong></span></button>
                    <p class="login-gallery-note">Sample community photos. Palitan ng aktuwal na larawan ng inyong barangay.</p>
                </aside>

            </div>
        </div>
    </section>

    <!-- PUBLIC SERVICES -->
    <section id="services" class="page-section" data-section aria-labelledby="services-title">
        <div class="container">
            <div class="panel">
                <h2 id="services-title">Public services</h2>
                <p class="panel-lead">Services you can request online from Barangay Bigaan. Sign in to your resident account to start a request.</p>
                <div class="service-grid">
                    <?php foreach ($services as [$icon, $title, $text, $cta]): ?>
                        <a class="service-card" href="#home" data-focus="identifier">
                            <span class="tile"><?= lg_icon($icon) ?></span>
                            <h3><?= e($title) ?></h3>
                            <p><?= e($text) ?></p>
                            <span class="card-link"><?= e($cta) ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- COMMUNITY ACTIVITIES -->
    <section id="activities" class="page-section community-section" data-section aria-labelledby="activities-title">
      <div class="container">
        <div class="community-section-heading"><span class="eyebrow">Buhay Barangay</span><h2 id="activities-title">Activities &amp; Community Life</h2><p>Mga programang nagpapakita ng bayanihan, kalusugan, kalinisan, at pakikiisa.</p></div>
        <div class="lg-grid lg-grid-4"><button class="lg-card" type="button" data-login-photo-open data-full="https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&amp;fit=crop&amp;w=1400&amp;q=85" data-caption="Bayanihan at Pagkakaisa" aria-label="View photo: Bayanihan at Pagkakaisa"><span class="lg-photo"><img loading="lazy" src="https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&amp;fit=crop&amp;w=1200&amp;q=85" alt="Community gathering and residents spending time together"><span class="lg-zoom" aria-hidden="true">&#x2922;</span></span><span class="lg-label"><small>Community</small><strong>Bayanihan at Pagkakaisa</strong><em>Mga aktibidad na naglalapit sa bawat pamilya sa barangay.</em></span></button><button class="lg-card" type="button" data-login-photo-open data-full="https://images.unsplash.com/photo-1559027615-cd4628902d4a?auto=format&amp;fit=crop&amp;w=1400&amp;q=85" data-caption="Volunteer Programs" aria-label="View photo: Volunteer Programs"><span class="lg-photo"><img loading="lazy" src="https://images.unsplash.com/photo-1559027615-cd4628902d4a?auto=format&amp;fit=crop&amp;w=900&amp;q=85" alt="Volunteers working together on a community project"><span class="lg-zoom" aria-hidden="true">&#x2922;</span></span><span class="lg-label"><small>Serbisyong Bayan</small><strong>Volunteer Programs</strong><em>Sama-samang pagkilos para sa komunidad.</em></span></button><button class="lg-card" type="button" data-login-photo-open data-full="https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&amp;fit=crop&amp;w=1400&amp;q=85" data-caption="Community Outreach" aria-label="View photo: Community Outreach"><span class="lg-photo"><img loading="lazy" src="https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&amp;fit=crop&amp;w=900&amp;q=85" alt="Volunteers participating in a service activity"><span class="lg-zoom" aria-hidden="true">&#x2922;</span></span><span class="lg-label"><small>Kalusugan at Kalinisan</small><strong>Community Outreach</strong><em>Mga programa para sa mas malinis at mas ligtas na paligid.</em></span></button><button class="lg-card" type="button" data-login-photo-open data-full="https://images.unsplash.com/photo-1509099836639-18ba1795216d?auto=format&amp;fit=crop&amp;w=1400&amp;q=85" data-caption="Youth Activities" aria-label="View photo: Youth Activities"><span class="lg-photo"><img loading="lazy" src="https://images.unsplash.com/photo-1509099836639-18ba1795216d?auto=format&amp;fit=crop&amp;w=900&amp;q=85" alt="Children participating in a community activity"><span class="lg-zoom" aria-hidden="true">&#x2922;</span></span><span class="lg-label"><small>Kabataan</small><strong>Youth Activities</strong><em>Pagbibigay ng ligtas at positibong espasyo sa kabataan.</em></span></button></div>
        <p class="community-disclaimer">Mga sample photo para sa layout. Palitan ng aktuwal at aprubadong larawan ng Barangay Bigaan.</p>
      </div>
    </section>

    <!-- BARANGAY FACILITIES -->
    <section id="facilities" class="page-section community-section facilities-section" data-section aria-labelledby="facilities-title">
      <div class="container">
        <div class="community-section-heading"><span class="eyebrow">Mga Pasilidad</span><h2 id="facilities-title">Barangay Facilities</h2><p>Mga lugar at serbisyong ginagamit ng mga residente.</p></div>
        <div class="lg-grid lg-grid-3"><button class="lg-card" type="button" data-login-photo-open data-full="https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&amp;fit=crop&amp;w=1400&amp;q=85" data-caption="Barangay Hall" aria-label="View photo: Barangay Hall"><span class="lg-photo"><img loading="lazy" src="https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&amp;fit=crop&amp;w=900&amp;q=85" alt="Civic building exterior"><span class="lg-zoom" aria-hidden="true">&#x2922;</span></span><span class="lg-label"><small>Pasilidad</small><strong>Barangay Hall</strong><em>Para sa mga transaksyon at serbisyong pampubliko.</em></span></button><button class="lg-card" type="button" data-login-photo-open data-full="https://images.unsplash.com/photo-1588072432836-e10032774350?auto=format&amp;fit=crop&amp;w=1400&amp;q=85" data-caption="Learning & Youth Spaces" aria-label="View photo: Learning & Youth Spaces"><span class="lg-photo"><img loading="lazy" src="https://images.unsplash.com/photo-1588072432836-e10032774350?auto=format&amp;fit=crop&amp;w=900&amp;q=85" alt="Classroom and learning facility"><span class="lg-zoom" aria-hidden="true">&#x2922;</span></span><span class="lg-label"><small>Pasilidad</small><strong>Learning &amp; Youth Spaces</strong><em>Mga espasyong sumusuporta sa pagkatuto at kabataan.</em></span></button><button class="lg-card" type="button" data-login-photo-open data-full="https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&amp;fit=crop&amp;w=1400&amp;q=85" data-caption="Community Projects" aria-label="View photo: Community Projects"><span class="lg-photo"><img loading="lazy" src="https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&amp;fit=crop&amp;w=900&amp;q=85" alt="Community infrastructure and public works"><span class="lg-zoom" aria-hidden="true">&#x2922;</span></span><span class="lg-label"><small>Pasilidad</small><strong>Community Projects</strong><em>Mga proyektong nagpapabuti sa ating kapaligiran.</em></span></button></div>
        <p class="community-disclaimer">Placeholder images lamang; hindi pa kumpirmadong aktuwal na pasilidad ng barangay.</p>
      </div>
    </section>

    <!-- BARANGAY OFFICIALS -->
    <section id="officials" class="page-section community-section officials-section" data-section aria-labelledby="officials-title">
      <div class="container">
        <div class="community-section-heading"><span class="eyebrow">Pamunuan</span><h2 id="officials-title">Barangay Officials</h2><p>Mga opisyal na nangunguna sa serbisyo at pagpapaunlad ng komunidad.</p></div>
        <?php
$officialCards = [];
try {
    $officialCards = fetch_all(
        "SELECT users.id, users.full_name, users.position
         FROM users JOIN roles ON roles.id = users.role_id
         WHERE users.status = 'Active' AND users.position IS NOT NULL AND users.position <> ''
           AND roles.slug IN ('punong_barangay','secretary','treasurer','staff')
         ORDER BY FIELD(users.position,'Barangay Captain','Barangay Kagawad','Barangay Secretary','Barangay Treasurer','SK Chairperson','SK Kagawad'), users.id
         LIMIT 12"
    );
} catch (Throwable $officialError) {
    $officialCards = [];
}
if (!$officialCards) {
    $officialCards = [
        ['id' => 0, 'full_name' => 'Punong Barangay', 'position' => 'Barangay Captain'],
        ['id' => 0, 'full_name' => 'Barangay Kagawad', 'position' => 'Barangay Kagawad'],
        ['id' => 0, 'full_name' => 'Barangay Secretary', 'position' => 'Barangay Secretary'],
        ['id' => 0, 'full_name' => 'Barangay Treasurer', 'position' => 'Barangay Treasurer'],
    ];
}
$kagawadCommittees = ['Peace & Order', 'Health & Sanitation', 'Education & Culture', 'Infrastructure', 'Finance & Appropriations', 'Agriculture & Environment', 'Women, Family & Youth'];
$roleInfo = [
    'Barangay Captain'   => ['Punong Barangay', 'Chief executive of the barangay; leads Sangguniang Barangay sessions and community programs.'],
    'Barangay Kagawad'   => ['Sangguniang Barangay', 'Legislative council member; drafts ordinances and oversees a committee.'],
    'Barangay Secretary' => ['Records & Documentation', 'Keeps barangay records, certificates and meeting minutes.'],
    'Barangay Treasurer' => ['Finance & Budget', 'Handles collections, receipts and barangay funds.'],
    'SK Chairperson'     => ['Sangguniang Kabataan', 'Leads youth programs, sports and scholarships.'],
    'SK Kagawad'         => ['Sangguniang Kabataan', 'Supports youth council projects and activities.'],
];
$kagIndex = 0;
?>
        <div class="id-grid">
        <?php foreach ($officialCards as $n => $official):
            $pos = (string) $official['position'];
            $info = $roleInfo[$pos] ?? [$pos, 'Serving the community of ' . APP_BARANGAY . '.'];
            $committee = $pos === 'Barangay Kagawad' ? $kagawadCommittees[$kagIndex++ % count($kagawadCommittees)] : $info[0];
            $idNo = 'BRGY-OFC-' . str_pad((string) ($official['id'] ?: $n + 1), 4, '0', STR_PAD_LEFT);
            $initials = '';
            foreach (array_slice(preg_split('/\s+/', trim((string) $official['full_name'])) ?: [], 0, 2) as $part) { $initials .= mb_strtoupper(mb_substr($part, 0, 1)); }
        ?>
        <div class="id-card" role="button" tabindex="0" aria-pressed="false" aria-label="<?= e($official['full_name'] . ', ' . $pos . '. Press to flip the ID card.') ?>" data-id-card>
            <div class="id-inner">
                <div class="id-face id-front">
                    <div class="id-top"><img src="<?= e($logo) ?>" alt=""><div><strong><?= e(APP_BARANGAY) ?></strong><small>Official ID &middot; <?= e(APP_MUNICIPALITY) ?></small></div></div>
                    <div class="id-photo"><svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="22" r="12"/><path d="M10 60c1-14 9-22 22-22s21 8 22 22z"/></svg><span class="id-initials"><?= e($initials) ?></span></div>
                    <h3 class="id-name"><?= e($official['full_name']) ?></h3>
                    <span class="id-pos"><?= e($pos) ?></span>
                    <div class="id-meta"><span><?= e($idNo) ?></span><span class="id-bars" aria-hidden="true"></span></div>
                    <small class="id-hint">&#8635; I-click para i-flip</small>
                </div>
                <div class="id-face id-back">
                    <div class="id-top"><img src="<?= e($logo) ?>" alt=""><div><strong>Impormasyon</strong><small><?= e($idNo) ?></small></div></div>
                    <dl class="id-info">
                        <dt>Posisyon</dt><dd><?= e($pos) ?></dd>
                        <dt><?= $pos === 'Barangay Kagawad' ? 'Komite' : 'Tanggapan' ?></dt><dd><?= e($committee) ?></dd>
                        <dt>Tungkulin</dt><dd><?= e($info[1]) ?></dd>
                        <dt>Oras ng Opisina</dt><dd>Lun-Biy, 8:00 AM - 5:00 PM</dd>
                        <dt>Barangay</dt><dd><?= e(barangay_place()) ?></dd>
                    </dl>
                    <small class="id-hint">&#8635; I-click para bumalik</small>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        </div>
        <p class="community-disclaimer">I-click ang ID para i-flip. Pare-pareho ang laki ng larawan; idagdag ang opisyal na litrato kapag available na.</p>
      </div>
    </section>

    <!-- ABOUT -->
    <section id="about" class="page-section page-section--end" data-section aria-labelledby="about-title">
        <div class="container">
            <div class="panel about-panel">
                <img class="about-seal-img" src="<?= e($logo) ?>" alt="Seal of <?= e(APP_BARANGAY) ?>">
                <div>
                    <h2 id="about-title">About Barangay Bigaan</h2>
                    <p class="panel-lead">Barangay Bigaan is in Calauag, Quezon. E-Barangay brings its everyday services online, so residents can request documents and follow their applications without waiting in line.</p>
                    <dl class="seal-facts">
                        <div><dt>Niyog</dt><dd>Coconut palms on the barangay seal.</dd></div>
                        <div><dt>Riles ng tren</dt><dd>The railway that runs through the seal.</dd></div>
                        <div><dt>Gabi at palay</dt><dd>Crops that grow in the community.</dd></div>
                    </dl>
                </div>
            </div>
            <footer class="site-footer">Barangay Bigaan, Calauag, Quezon &middot; E-Barangay System</footer>
        </div>
    </section>
</main>

<script>
(() => {
    'use strict';

    const nav = document.querySelector('.site-nav');
    const toggle = document.querySelector('.nav-toggle');
    const menu = document.getElementById('nav-menu');
    const navLinks = Array.from(document.querySelectorAll('.nav-links a[href^="#"]'));
    const sections = Array.from(document.querySelectorAll('[data-section]'));
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    const GAP = 12; // space kept between the nav bar and the top of a section

    /* Mobile menu */
    const setMenu = (open) => {
        menu.classList.toggle('is-open', open);
        toggle.setAttribute('aria-expanded', String(open));
    };
    toggle.addEventListener('click', () => setMenu(!menu.classList.contains('is-open')));
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setMenu(false); });
    document.addEventListener('click', (e) => {
        if (menu.classList.contains('is-open') && !nav.contains(e.target)) setMenu(false);
    });

    /* Active nav link */
    const setActive = (id) => {
        navLinks.forEach((a) => {
            const on = a.getAttribute('href') === '#' + id;
            a.classList.toggle('is-active', on);
            if (on) a.setAttribute('aria-current', 'true'); else a.removeAttribute('aria-current');
        });
    };

    /* Smooth scroll to a section (just below the nav bar) */
    const scrollToId = (id, opts = {}) => {
        const target = document.getElementById(id);
        if (!target) return false;
        const push = opts.push !== false;
        const top = id === 'home'
            ? 0
            : Math.max(0, target.getBoundingClientRect().top + window.scrollY - nav.offsetHeight - GAP);

        window.scrollTo({ top, behavior: reduceMotion.matches ? 'auto' : 'smooth' });
        if (push && location.hash !== '#' + id) history.pushState(null, '', '#' + id);

        if (opts.focusId) {
            window.setTimeout(() => {
                const el = document.getElementById(opts.focusId);
                if (el) el.focus({ preventScroll: true });
            }, reduceMotion.matches ? 0 : 700);
        }
        return true;
    };

    document.addEventListener('click', (e) => {
        const link = e.target.closest('a[href^="#"]');
        if (!link) return;
        const hash = link.getAttribute('href');
        if (hash.length < 2) return;
        if (scrollToId(decodeURIComponent(hash.slice(1)), { focusId: link.dataset.focus || null })) {
            e.preventDefault();
            setMenu(false);
        }
    });

    window.addEventListener('popstate', () => {
        scrollToId(decodeURIComponent(location.hash.slice(1)) || 'home', { push: false });
    });

    /* Scrollspy: the active section is the last one whose top has passed the nav bar */
    let ticking = false;
    const updateActive = () => {
        ticking = false;
        const line = nav.offsetHeight + GAP + 60;
        let current = sections[0].id;
        sections.forEach((s) => { if (s.getBoundingClientRect().top <= line) current = s.id; });
        if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 2) {
            current = sections[sections.length - 1].id;
        }
        setActive(current);
    };
    window.addEventListener('scroll', () => {
        if (!ticking) { ticking = true; window.requestAnimationFrame(updateActive); }
    }, { passive: true });
    window.addEventListener('resize', updateActive);
    updateActive();

    /* Password show / hide */
    const password = document.getElementById('password');
    const togglePass = document.querySelector('.toggle-pass');
    togglePass.addEventListener('click', () => {
        const show = password.type === 'password';
        password.type = show ? 'text' : 'password';
        togglePass.setAttribute('aria-pressed', String(show));
        togglePass.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    });

    /* Demo credentials autofill */
    const identifier = document.getElementById('identifier');
    document.querySelectorAll('[data-demo-email]').forEach((btn) => {
        btn.addEventListener('click', () => {
            identifier.value = btn.dataset.demoEmail || '';
            password.value = btn.dataset.demoPassword || '';
            const radio = document.querySelector('input[name="portal"][value="' + (btn.dataset.demoPortal || 'Resident') + '"]');
            if (radio) radio.checked = true;
            identifier.focus();
        });
    });
})();
</script>
<div class="photo-lightbox" data-login-lightbox hidden role="dialog" aria-modal="true" aria-label="Barangay photo viewer"><button class="lightbox-close" type="button" data-login-photo-close aria-label="Close photo viewer">×</button><button class="lightbox-arrow" type="button" data-login-photo-prev aria-label="Previous photo">‹</button><figure><img src="" alt="" data-login-lightbox-image><figcaption data-login-lightbox-caption></figcaption></figure><button class="lightbox-arrow" type="button" data-login-photo-next aria-label="Next photo">›</button></div>
<script src="<?= e(app_url('assets/js/app.js')) ?>"></script>
</body>
</html>