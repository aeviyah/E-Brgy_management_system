document.addEventListener('click', function (event) {
    if (event.target.closest('[data-toggle-sidebar]')) {
        return; // handled once in the theme/sidebar block below
    }
    if (document.body.classList.contains('sidebar-open') && !event.target.closest('.sidebar')) {
        document.body.classList.remove('sidebar-open');
    }
    var demo = event.target.closest('[data-demo-email]');
    if (demo) {
        document.getElementById('identifier').value = demo.dataset.demoEmail;
        var portal = document.querySelector('input[name="portal"][value="' + (demo.dataset.demoPortal || 'Resident') + '"]');
        if (portal) { portal.checked = true; }
        document.getElementById('password').value = demo.dataset.demoPassword;
        document.getElementById('password').focus();
    }
});

document.addEventListener('change', function (event) {
    var autosubmit = event.target.closest('[data-autosubmit]');
    if (autosubmit && autosubmit.form) {
        autosubmit.form.submit();
    }
});

document.addEventListener('submit', function (event) {
    var form = event.target;
    if (form.dataset.confirm && !window.confirm(form.dataset.confirm)) {
        event.preventDefault();
    }
});

// Registration: show the position field only for barangay officials.
(function () {
    var radios = document.querySelectorAll('[data-account-type]');
    var official = document.querySelector('[data-official-only]');
    if (!radios.length || !official) { return; }
    function sync() {
        var checked = document.querySelector('[data-account-type]:checked');
        official.style.display = checked && checked.value === 'Barangay Official' ? '' : 'none';
    }
    radios.forEach(function (r) { r.addEventListener('change', sync); });
    sync();
}());


/* Theme and sidebar preferences; existing app interactions are preserved. */
(function () {
  var body = document.body;
  var stored = null;
  try { stored = localStorage.getItem('eBarangayTheme'); } catch (e) {}
  var theme = (stored === 'dark' || stored === 'light') ? stored : ((window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light');
  function applyTheme(value) {
    theme = value === 'dark' ? 'dark' : 'light';
    body.setAttribute('data-theme', theme); document.documentElement.setAttribute('data-theme', theme);
    var button = document.querySelector('[data-theme-toggle]'); var icon = document.querySelector('[data-theme-icon]'); var label = document.querySelector('.theme-toggle-label');
    if (button) { var next = theme === 'dark' ? 'light' : 'dark'; button.setAttribute('aria-label', 'Switch to ' + next + ' mode'); button.setAttribute('title', 'Switch to ' + next + ' mode'); button.setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false'); }
    if (icon) icon.textContent = theme === 'dark' ? '☀' : '☾'; if (label) label.textContent = theme === 'dark' ? 'Light mode' : 'Dark mode';
  }
  applyTheme(theme);
  try { if (localStorage.getItem('eBarangaySidebarCollapsed') === '1' && matchMedia('(min-width: 901px)').matches) body.classList.add('sidebar-collapsed'); } catch (e) {}
  document.addEventListener('click', function (event) {
    var themeButton = event.target.closest('[data-theme-toggle]');
    if (themeButton) { var next = theme === 'dark' ? 'light' : 'dark'; applyTheme(next); try { localStorage.setItem('eBarangayTheme', next); } catch (e) {} }
    if (event.target.closest('[data-collapse-sidebar]')) { body.classList.toggle('sidebar-collapsed'); try { localStorage.setItem('eBarangaySidebarCollapsed', body.classList.contains('sidebar-collapsed') ? '1' : '0'); } catch (e) {} }
    if (event.target.closest('[data-toggle-sidebar]')) body.classList.toggle('sidebar-open');
    if (event.target.closest('.sidebar .nav-link') && window.matchMedia('(max-width: 900px)').matches) body.classList.remove('sidebar-open');
  });
})();


/* Public portal photo gallery lightbox: keyboard accessible, no auto-advance. */
(function () {
  var dialog = document.querySelector('[data-photo-lightbox]');
  if (!dialog) return;
  var buttons = Array.prototype.slice.call(document.querySelectorAll('[data-photo-open]'));
  var image = dialog.querySelector('[data-lightbox-image]');
  var caption = dialog.querySelector('[data-lightbox-caption]');
  var current = 0, opener = null;
  function show(index) {
    current = (index + buttons.length) % buttons.length;
    var card = buttons[current];
    image.src = card.getAttribute('data-full'); image.alt = card.querySelector('img').alt;
    caption.textContent = (current + 1) + ' / ' + buttons.length + ' — ' + card.getAttribute('data-caption');
  }
  function close() { dialog.hidden = true; document.body.style.overflow = ''; if (opener) opener.focus(); }
  buttons.forEach(function (button, index) { button.addEventListener('click', function () { opener = button; show(index); dialog.hidden = false; document.body.style.overflow = 'hidden'; dialog.querySelector('[data-photo-close]').focus(); }); });
  dialog.querySelector('[data-photo-close]').addEventListener('click', close);
  dialog.querySelector('[data-photo-prev]').addEventListener('click', function () { show(current - 1); });
  dialog.querySelector('[data-photo-next]').addEventListener('click', function () { show(current + 1); });
  dialog.addEventListener('click', function (event) { if (event.target === dialog) close(); });
  document.addEventListener('keydown', function (event) { if (dialog.hidden) return; if (event.key === 'Escape') close(); if (event.key === 'ArrowLeft') show(current - 1); if (event.key === 'ArrowRight') show(current + 1); });
}());

/* Subtle reveal-on-scroll for public portal sections; respects reduced motion. */
(function () {
  if (!('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var sections = document.querySelectorAll('.public-page .panel, .public-page .module-card, .public-page .community-gallery, .public-page .officials-section');
  sections.forEach(function (el) { el.classList.add('reveal-on-scroll'); });
  var observer = new IntersectionObserver(function (entries) { entries.forEach(function (entry) { if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); } }); }, { threshold: 0.12 });
  sections.forEach(function (el) { observer.observe(el); });
}());


/* Login-page community gallery lightbox. */
(function(){var dialog=document.querySelector('[data-login-lightbox]');if(!dialog)return;var cards=Array.prototype.slice.call(document.querySelectorAll('[data-login-photo-open]'));var img=dialog.querySelector('[data-login-lightbox-image]'),cap=dialog.querySelector('[data-login-lightbox-caption]'),i=0,opener=null;function show(n){i=(n+cards.length)%cards.length;img.src=cards[i].dataset.full;img.alt=cards[i].querySelector('img').alt;cap.textContent=cards[i].dataset.caption;}function close(){dialog.hidden=true;document.body.style.overflow='';if(opener)opener.focus();}cards.forEach(function(c,n){c.addEventListener('click',function(){opener=c;show(n);dialog.hidden=false;document.body.style.overflow='hidden';dialog.querySelector('[data-login-photo-close]').focus();});});dialog.querySelector('[data-login-photo-close]').addEventListener('click',close);dialog.querySelector('[data-login-photo-prev]').addEventListener('click',function(){show(i-1);});dialog.querySelector('[data-login-photo-next]').addEventListener('click',function(){show(i+1);});dialog.addEventListener('click',function(e){if(e.target===dialog)close();});document.addEventListener('keydown',function(e){if(dialog.hidden)return;if(e.key==='Escape')close();if(e.key==='ArrowLeft')show(i-1);if(e.key==='ArrowRight')show(i+1);});})();


/* Officials ID cards: click / tap / Enter / Space to flip. */
(function () {
  var cards = document.querySelectorAll('[data-id-card]');
  cards.forEach(function (card) {
    function flip() { var on = card.classList.toggle('is-flipped'); card.setAttribute('aria-pressed', on ? 'true' : 'false'); }
    card.addEventListener('click', flip);
    card.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); flip(); } });
  });
}());
