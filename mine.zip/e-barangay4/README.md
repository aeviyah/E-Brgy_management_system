# E-Barangay Management System

Functional Programming 3 web application based on the approved E-Barangay Management System scope, workflow, UI/UX blueprint, and beginner-friendly PHP/MySQL stack.

## Stack

- HTML5, CSS3, basic JavaScript
- PHP with sessions, `password_hash()`, `password_verify()`, PDO prepared statements
- MySQL / phpMyAdmin
- XAMPP / Apache

## Setup

1. Copy this folder into `xampp/htdocs`.
2. For a **new demo database only**, open phpMyAdmin and import `database/schema.sql`.
   **Warning:** this script drops and recreates the app tables. Back up your database first; do not re-import it over data you need to keep.
3. Check database credentials in `config/database.php` (`ebarangay_management`, `root`, and the password configured in your XAMPP installation).
4. Visit `http://localhost/e-barangay/` (use whatever folder name you gave it in `htdocs`).

If you use PHP's built-in server instead of XAMPP, make sure the `pdo_mysql` extension is enabled. XAMPP normally includes it.

## Demo Accounts

All seeded accounts use password `password`.

- `admin@barangay.test` - System Administrator
- `secretary@barangay.test` - Barangay Secretary
- `treasurer@barangay.test` - Barangay Treasurer
- `captain@barangay.test` - Punong Barangay
- `staff@barangay.test` - Barangay Staff
- `juan@example.com` - Resident

## Implemented Scope

- Authentication, logout, registration, PHP sessions
- Role-based access control and hidden unauthorized actions
- Dashboard with KPIs, quick actions, pending workflow queue, notifications and audit activity
- Resident, household and Purok/Sitio management
- Shared workflow module for documents, permits, services, cases, governance, communication, events, facilities, assets, projects and operations
- Status tracking with timeline history
- Treasury payments, official receipt generation and collections
- Reports, global search, audit trail and user settings
- Public portal and document verification
- Locked future modules for SK, Health Center, Emergency/Disaster and other specialized systems

## Defense Flow

1. Log in as `admin@barangay.test`.
2. Show role-based sidebar and locked future modules.
3. Register or verify a resident.
4. Create a document request and move it through statuses.
5. Record payment and show the generated official receipt.
6. Show reports, global search and audit trail.
7. Log in as a resident to show the simplified resident view.


## Theme and customization

- Barangay name: edit `APP_BARANGAY` in `includes/app.php`.
- Logo: replace `assets/img/logo.svg` with your barangay seal.
- Background / "face of the barangay": drop a photo named `assets/img/brgy-photo.jpg` (hall, plaza, aerial shot). It is used automatically behind the glass UI and the hero; the illustrated scene `bg.svg` is the fallback.
- Demo shortcuts on the login page: set `APP_DEMO` to `false` in `includes/app.php` before real use.

## Hardening added in this version

- CSRF token on every POST form (automatic, see `includes/bootstrap.php`).
- Status changes follow a defined workflow (`workflow_transitions()`); document/permit approval is limited to Punong Barangay / Administrator.
- Facility double-booking is blocked on the same date.
- Failed logins are written to the audit trail; session cookie is HttpOnly + SameSite.
