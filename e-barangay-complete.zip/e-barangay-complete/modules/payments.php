<?php

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';

require_module_access('treasury');

$recordId = (int) ($_GET['record_id'] ?? $_POST['record_id'] ?? 0);
$selectedRecord = $recordId ? fetch_one(
    'SELECT service_records.*, residents.first_name, residents.last_name
     FROM service_records
     LEFT JOIN residents ON residents.id = service_records.resident_id
     WHERE service_records.id = ?',
    [$recordId]
) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $payer = trim((string) ($_POST['payer_name'] ?? ''));
    $purpose = trim((string) ($_POST['purpose'] ?? ''));
    $amount = (float) ($_POST['amount'] ?? 0);

    if ($payer === '' || $purpose === '' || $amount <= 0 || !in_array((string) ($_POST['payment_status'] ?? 'Paid'), payment_statuses(), true)) {
        flash('danger', 'Enter a payer, purpose, a positive amount, and a valid payment status.');
    } else {
        $record = $recordId ? fetch_one('SELECT * FROM service_records WHERE id = ?', [$recordId]) : null;
        $residentId = $record['resident_id'] ?? (($_POST['resident_id'] ?? '') !== '' ? (int) $_POST['resident_id'] : null);
        $receiptNo = generate_reference('OR');
        $transactionNo = generate_reference('TXN');

        $paidAt = ($_POST['paid_at'] ?? '') !== ''
            ? str_replace('T', ' ', (string) $_POST['paid_at']) . ':00'
            : date('Y-m-d H:i:s');

        run_query(
            'INSERT INTO payments
             (receipt_no, transaction_no, record_id, resident_id, payer_name, purpose, amount, payment_method, reference_number, payment_status, received_by, paid_at, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())',
            [
                $receiptNo,
                $transactionNo,
                $recordId ?: null,
                $residentId,
                $payer,
                $purpose,
                $amount,
                in_array((string) ($_POST['payment_method'] ?? 'Cash'), payment_methods(), true) ? (string) $_POST['payment_method'] : 'Cash',
                trim((string) ($_POST['reference_number'] ?? '')) ?: null,
                trim((string) ($_POST['payment_status'] ?? 'Paid')),
                (int) current_user()['id'],
                $paidAt,
            ]
        );

        $paymentId = (int) db()->lastInsertId();
        audit_log('Recorded payment', 'Payment', $paymentId, $receiptNo . ' - ' . $purpose);

        if ($record && $record['status'] === 'For Payment' && (string) ($_POST['payment_status'] ?? 'Paid') === 'Paid') {
            run_query('UPDATE service_records SET status = ?, updated_by = ?, updated_at = NOW() WHERE id = ?', ['For Approval', (int) current_user()['id'], $recordId]);
            record_history($recordId, 'For Approval', 'Payment recorded with OR ' . $receiptNo . '.');
        }

        if ($residentId) {
            $residentUser = fetch_one('SELECT id FROM users WHERE resident_id = ?', [$residentId]);
            notify_user($residentUser['id'] ?? null, 'Payment recorded', $receiptNo . ' for ' . peso($amount) . ' has been recorded.');
        }

        flash('success', 'Payment recorded and official receipt generated.');
        redirect('modules/payments.php?receipt=' . $paymentId);
    }
}

$receiptId = (int) ($_GET['receipt'] ?? 0);
$receipt = $receiptId ? fetch_one(
    'SELECT payments.*, users.full_name AS treasurer
     FROM payments
     LEFT JOIN users ON users.id = payments.received_by
     WHERE payments.id = ?',
    [$receiptId]
) : null;

$residents = fetch_all("SELECT id, resident_no, first_name, last_name FROM residents WHERE status != 'Archived' ORDER BY last_name, first_name");
$payableRecords = fetch_all(
    "SELECT id, reference_no, title, requester_name, amount, status
     FROM service_records
     WHERE amount > 0 AND status IN ('For Payment', 'Pending', 'Under Review')
     ORDER BY updated_at DESC"
);
$payments = fetch_all(
    'SELECT payments.*, service_records.reference_no
     FROM payments
     LEFT JOIN service_records ON service_records.id = payments.record_id
     ORDER BY payments.paid_at DESC
     LIMIT 100'
);
$collectionToday = (float) fetch_value("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE payment_status = 'Paid' AND DATE(paid_at) = CURDATE()");
$collectionMonth = (float) fetch_value("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE payment_status = 'Paid' AND YEAR(paid_at) = YEAR(CURDATE()) AND MONTH(paid_at) = MONTH(CURDATE())");

render_header('Treasury & Receipts');
page_header('Treasury & Official Receipts', 'Fee assessment, payment transactions, OR generation, collections and financial reporting.', '<button class="btn btn-ghost" type="button" onclick="window.print()">Print</button> ' . export_buttons('payments'));
?>
<section class="grid grid-3">
    <article class="metric-card"><span>Today Collections</span><strong><?= e(peso($collectionToday)) ?></strong></article>
    <article class="metric-card"><span>This Month</span><strong><?= e(peso($collectionMonth)) ?></strong></article>
    <article class="metric-card"><span>Transactions</span><strong><?= count($payments) ?></strong></article>
</section>

<?php if ($receipt): ?>
<section class="panel">
    <div class="panel-header">
        <h2>Official Receipt</h2>
        <span class="<?= e(status_class($receipt['payment_status'])) ?>"><?= e($receipt['payment_status']) ?></span>
    </div>
    <div class="panel-body">
        <div class="grid grid-3">
            <p><strong>OR Number</strong><br><?= e($receipt['receipt_no']) ?></p>
            <p><strong>Transaction ID</strong><br><?= e($receipt['transaction_no']) ?></p>
            <p><strong>Date</strong><br><?= e($receipt['paid_at']) ?></p>
            <p><strong>Payer</strong><br><?= e($receipt['payer_name']) ?></p>
            <p><strong>Purpose</strong><br><?= e($receipt['purpose']) ?></p>
            <p><strong>Amount</strong><br><?= e(peso($receipt['amount'])) ?></p>
            <p><strong>Payment Method</strong><br><?= e($receipt['payment_method']) ?><?= !empty($receipt['reference_number']) ? ' - Ref. ' . e($receipt['reference_number']) : '' ?></p>
            <p><strong>Treasurer</strong><br><?= e($receipt['treasurer'] ?? 'System') ?></p>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="grid grid-2">
    <div class="panel">
        <div class="panel-header"><h2>Record Payment</h2></div>
        <div class="panel-body">
            <form method="post" class="form-grid">
                <div class="form-field full">
                    <label>Related workflow record</label>
                    <select class="form-control" name="record_id">
                        <option value="">Manual payment</option>
                        <?php foreach ($payableRecords as $record): ?>
                            <option value="<?= (int) $record['id'] ?>" <?= selected($recordId, $record['id']) ?>><?= e($record['reference_no'] . ' - ' . $record['title']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-field">
                    <label>Payer name *</label>
                    <input class="form-control" name="payer_name" value="<?= e($selectedRecord['requester_name'] ?? '') ?>" required>
                </div>
                <div class="form-field">
                    <label>Purpose *</label>
                    <input class="form-control" name="purpose" value="<?= e($selectedRecord['title'] ?? '') ?>" required>
                </div>
                <div class="form-field">
                    <label>Amount *</label>
                    <input class="form-control" type="number" step="0.01" min="0" name="amount" value="<?= e((string) ($selectedRecord['amount'] ?? '')) ?>" required>
                </div>
                <div class="form-field">
                    <label>Resident</label>
                    <select class="form-control" name="resident_id">
                        <option value="">None</option>
                        <?php foreach ($residents as $resident): ?>
                            <option value="<?= (int) $resident['id'] ?>" <?= selected($selectedRecord['resident_id'] ?? '', $resident['id']) ?>><?= e($resident['resident_no'] . ' - ' . $resident['last_name'] . ', ' . $resident['first_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-field">
                    <label>Payment method</label>
                    <select class="form-control" name="payment_method"><?php foreach (payment_methods() as $method): ?><option><?= e($method) ?></option><?php endforeach; ?></select>
                </div>
            <div class="form-field">
                <label>Reference no. <small class="muted">(GCash / Maya / bank, optional)</small></label>
                <input class="form-control" name="reference_number">
            </div>
                <div class="form-field">
                    <label>Payment status</label>
                    <select class="form-control" name="payment_status"><?php foreach (payment_statuses() as $value): ?><option <?= selected('Paid', $value) ?>><?= e($value) ?></option><?php endforeach; ?></select>
                </div>
                <div class="form-field">
                    <label>Paid at</label>
                    <input class="form-control" type="datetime-local" name="paid_at" value="<?= e(date('Y-m-d\TH:i')) ?>">
                </div>
                <div class="form-actions full"><button class="btn" type="submit">Generate OR</button></div>
            </form>
        </div>
    </div>

    <div class="panel">
        <div class="panel-header"><h2>Pending Assessments</h2></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Record</th><th>Amount</th><th>Status</th></tr></thead>
                <tbody>
                <?php foreach ($payableRecords as $record): ?>
                    <tr>
                        <td><a href="<?= e(app_url('modules/payments.php?record_id=' . (int) $record['id'])) ?>"><?= e($record['reference_no']) ?><br><small><?= e($record['title']) ?></small></a></td>
                        <td><?= e(peso($record['amount'])) ?></td>
                        <td><span class="<?= e(status_class($record['status'])) ?>"><?= e($record['status']) ?></span></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$payableRecords): ?><tr><td colspan="3">No pending assessments.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<section class="panel">
    <div class="panel-header"><h2>Collection History</h2></div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>OR</th><th>Transaction</th><th>Payer</th><th>Purpose</th><th>Amount</th><th>Method</th><th>Date</th></tr></thead>
            <tbody>
            <?php foreach ($payments as $payment): ?>
                <tr>
                    <td><a href="<?= e(app_url('modules/payments.php?receipt=' . (int) $payment['id'])) ?>"><?= e($payment['receipt_no']) ?></a></td>
                    <td><?= e($payment['transaction_no']) ?></td>
                    <td><?= e($payment['payer_name']) ?></td>
                    <td><?= e($payment['purpose']) ?><br><small><?= e($payment['reference_no'] ?? 'Manual') ?></small></td>
                    <td><?= e(peso($payment['amount'])) ?></td>
                    <td><?= e($payment['payment_method']) ?></td>
                    <td><?= e($payment['paid_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$payments): ?><tr><td colspan="7">No payments found.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php render_footer(); ?>

