-- Run this on an EXISTING e-barangay-merged database (keeps your data).
-- Safe to run once. Use a fresh schema.sql only for a new demo database.
USE ebarangay_management;

ALTER TABLE residents
  ADD COLUMN is_youth TINYINT(1) DEFAULT 0 AFTER is_4ps,
  ADD COLUMN is_head_of_family TINYINT(1) DEFAULT 0 AFTER is_youth,
  ADD COLUMN pwd_id_number VARCHAR(80) NULL AFTER is_head_of_family,
  ADD COLUMN solo_parent_id_number VARCHAR(80) NULL AFTER pwd_id_number,
  ADD COLUMN special_classification VARCHAR(150) NULL AFTER solo_parent_id_number,
  ADD COLUMN status_notes TEXT NULL AFTER status,
  ADD COLUMN status_changed_at DATETIME NULL AFTER status_notes;

CREATE TABLE IF NOT EXISTS public_contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    label VARCHAR(150) NOT NULL,
    contact_type VARCHAR(60) NOT NULL DEFAULT 'Office',
    value VARCHAR(255) NOT NULL,
    availability VARCHAR(150),
    status VARCHAR(30) NOT NULL DEFAULT 'Active',
    created_at DATETIME NOT NULL
);

INSERT INTO public_contacts (label, contact_type, value, availability, status, created_at) VALUES
('Barangay Hall', 'Phone', '0917-000-0000', 'Mon-Fri, 8:00 AM - 5:00 PM', 'Active', NOW()),
('Tanod Desk', 'Phone', '0917-111-1111', '24/7', 'Active', NOW()),
('Barangay Email', 'Email', 'info@barangay.test', 'Replies within office hours', 'Active', NOW());
