document.addEventListener('click', function (event) {
    if (event.target.closest('[data-toggle-sidebar]')) {
        return; // handled once in the theme/sidebar block below
    }
    if (document.body.classList.contains('sidebar-open') && !event.target.closest('.sidebar')) {
        document.body.classList.remove('sidebar-open');
    }
    var demo = event.target.closest('[data-demo-email]');
    if (demo) {
        document.getElementById('identifier').value = demo.dataset.demoEmail;
        var portal = document.querySelector('input[name="portal"][value="' + (demo.dataset.demoPortal || 'Resident') + '"]');
        if (portal) { portal.checked = true; }
        document.getElementById('password').value = demo.dataset.demoPassword;
        document.getElementById('password').focus();
    }
});

document.addEventListener('change', function (event) {
    var autosubmit = event.target.closest('[data-autosubmit]');
    if (autosubmit && autosubmit.form) {
        autosubmit.form.submit();
    }
});

document.addEventListener('submit', function (event) {
    var form = event.target;
    if (form.dataset.confirm && !window.confirm(form.dataset.confirm)) {
        event.preventDefault();
    }
});

// Registration: show the position field only for barangay officials.
(function () {
    var radios = document.querySelectorAll('[data-account-type]');
    var official = document.querySelector('[data-official-only]');
    if (!radios.length || !official) { return; }
    function sync() {
        var checked = document.querySelector('[data-account-type]:checked');
        official.style.display = checked && checked.value === 'Barangay Official' ? '' : 'none';
    }
    radios.forEach(function (r) { r.addEventListener('change', sync); });
    sync();
}());


/* Theme and sidebar preferences; existing app interactions are preserved. */
(function () {
  var body = document.body;
  var stored = null;
  try { stored = localStorage.getItem('eBarangayTheme'); } catch (e) {}
  var theme = (stored === 'dark' || stored === 'light') ? stored : ((window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light');
  function applyTheme(value) {
    theme = value === 'dark' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', theme);
    var button = document.querySelector('[data-theme-toggle]'); var icon = document.querySelector('[data-theme-icon]'); var label = document.querySelector('.theme-toggle-label');
    if (button) { var next = theme === 'dark' ? 'light' : 'dark'; button.setAttribute('aria-label', 'Switch to ' + next + ' mode'); button.setAttribute('title', 'Switch to ' + next + ' mode'); button.setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false'); }
    if (icon) icon.textContent = theme === 'dark' ? '☀' : '☾'; if (label) label.textContent = theme === 'dark' ? 'Light mode' : 'Dark mode';
  }
  applyTheme(theme);
  try { if (localStorage.getItem('eBarangaySidebarCollapsed') === '1' && matchMedia('(min-width: 901px)').matches) document.documentElement.classList.add('sidebar-collapsed'); } catch (e) {}
  document.addEventListener('click', function (event) {
    var themeButton = event.target.closest('[data-theme-toggle]');
    if (themeButton) { var next = theme === 'dark' ? 'light' : 'dark'; applyTheme(next); try { localStorage.setItem('eBarangayTheme', next); } catch (e) {} }
    if (event.target.closest('[data-collapse-sidebar]')) { document.documentElement.classList.toggle('sidebar-collapsed'); try { localStorage.setItem('eBarangaySidebarCollapsed', document.documentElement.classList.contains('sidebar-collapsed') ? '1' : '0'); } catch (e) {} }
    if (event.target.closest('[data-toggle-sidebar]')) body.classList.toggle('sidebar-open');
    if (event.target.closest('.sidebar .nav-link') && window.matchMedia('(max-width: 900px)').matches) body.classList.remove('sidebar-open');
  });
})();


/* Activities + facilities: click a card, the picture zooms out of the card and the details open beside it. */
(function () {
  var modal = document.querySelector('[data-info-modal]');
  if (!modal) return;
  var sheet = modal.querySelector('[data-info-sheet]');
  var img = modal.querySelector('[data-info-image]');
  var photo = modal.querySelector('.info-photo');
  var cards = Array.prototype.slice.call(document.querySelectorAll('[data-info-open]'));
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var opener = null, current = 0, closing = null;

  function set(sel, text) { var el = modal.querySelector(sel); if (el) el.textContent = text || ''; }
  function fill(card) {
    img.src = card.dataset.img; img.alt = card.dataset.title;
    set('[data-info-tag]', card.dataset.tag);
    set('[data-info-title]', card.dataset.title);
    set('[data-info-about]', card.dataset.about);
    var list = modal.querySelector('[data-info-list]');
    list.textContent = '';
    var rows = [];
    try { rows = JSON.parse(card.dataset.info || '[]'); } catch (e) { rows = []; }
    rows.forEach(function (row) {
      var wrap = document.createElement('div');
      var dt = document.createElement('dt'); dt.textContent = row[0];
      var dd = document.createElement('dd'); dd.textContent = row[1];
      wrap.appendChild(dt); wrap.appendChild(dd); list.appendChild(wrap);
    });
  }
  function open(card, index) {
    window.clearTimeout(closing);
    opener = card; current = index; fill(card);
    modal.hidden = false; document.body.style.overflow = 'hidden';
    sheet.classList.remove('is-ready');
    photo.style.transition = 'none'; photo.style.transform = 'none';
    if (!reduce) {
      // FLIP: begin exactly on top of the small picture in the card, then grow into place.
      var from = card.querySelector('.photo-frame').getBoundingClientRect();
      var to = photo.getBoundingClientRect();
      if (to.width && to.height) {
        var dx = (from.left + from.width / 2) - (to.left + to.width / 2);
        var dy = (from.top + from.height / 2) - (to.top + to.height / 2);
        photo.style.transform = 'translate(' + dx + 'px,' + dy + 'px) scale(' + (from.width / to.width) + ',' + (from.height / to.height) + ')';
      }
    }
    void photo.offsetWidth;
    modal.classList.add('is-open');
    photo.style.transition = reduce ? 'none' : 'transform .5s cubic-bezier(.2,.8,.2,1)';
    photo.style.transform = 'none';
    window.setTimeout(function () { sheet.classList.add('is-ready'); }, reduce ? 0 : 280);
    modal.querySelector('.info-close').focus({ preventScroll: true });
  }
  function close() {
    modal.classList.remove('is-open'); sheet.classList.remove('is-ready');
    document.body.style.overflow = '';
    closing = window.setTimeout(function () { modal.hidden = true; }, reduce ? 0 : 260);
    if (opener) opener.focus({ preventScroll: true });
  }
  function step(n) {
    if (modal.hidden || !cards.length) return;
    current = (current + n + cards.length) % cards.length;
    opener = cards[current]; fill(opener);
  }
  cards.forEach(function (card, i) { card.addEventListener('click', function () { open(card, i); }); });
  modal.addEventListener('click', function (e) {
    if (e.target.closest('[data-info-close]')) close();
    if (e.target.closest('[data-info-prev]')) step(-1);
    if (e.target.closest('[data-info-next]')) step(1);
  });
  document.addEventListener('keydown', function (e) {
    if (modal.hidden) return;
    if (e.key === 'Escape') close();
    if (e.key === 'ArrowLeft') step(-1);
    if (e.key === 'ArrowRight') step(1);
  });
}());


/* Officials: round avatars. Click = the avatar zooms to the middle, then it opens as an ID card
 * (avatar + name + position on the left, details about the post on the right). */
(function () {
  var modal = document.querySelector('[data-id-modal]');
  if (!modal) return;
  // The glass panels use backdrop-filter, which would trap a fixed modal inside the panel. Keep the modal on <body>.
  document.body.appendChild(modal);
  var sheet = modal.querySelector('[data-id-sheet]');
  var avatar = modal.querySelector('[data-id-avatar]');
  var dots = Array.prototype.slice.call(document.querySelectorAll('[data-official]'));
  var closeBtn = modal.querySelector('.id-close');
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var opener = null, timer = null, current = -1;

  function set(sel, text) { var el = modal.querySelector(sel); if (el) el.textContent = text; }
  function fill(dot) {
    set('[data-id-name]', dot.dataset.name);
    set('[data-id-pos]', dot.dataset.pos);
    set('[data-id-pos2]', dot.dataset.pos);
    set('[data-id-unit]', dot.dataset.unit);
    set('[data-id-duty]', dot.dataset.duty);
    set('[data-id-no]', dot.dataset.idno);
    set('[data-id-initials]', dot.dataset.initials);
    avatar.className = 'avatar-circle id-avatar is-' + dot.dataset.group;
  }
  function toCard() {
    sheet.setAttribute('data-stage', 'card');
    closeBtn.focus({ preventScroll: true });
  }
  function open(dot) {
    opener = dot; current = dots.indexOf(dot);
    window.clearTimeout(timer);
    fill(dot);
    sheet.setAttribute('data-stage', 'zoom');
    modal.hidden = false;
    document.body.style.overflow = 'hidden';
    avatar.style.transition = 'none';
    avatar.style.transform = 'none';
    if (reduce) { modal.classList.add('is-open'); toCard(); return; }
    // FLIP: start the big avatar exactly on top of the small circle, then let it grow to the middle.
    var from = dot.querySelector('.avatar-circle').getBoundingClientRect();
    var to = avatar.getBoundingClientRect();
    var dx = (from.left + from.width / 2) - (to.left + to.width / 2);
    var dy = (from.top + from.height / 2) - (to.top + to.height / 2);
    avatar.style.transform = 'translate(' + dx + 'px,' + dy + 'px) scale(' + (from.width / to.width) + ')';
    void avatar.offsetWidth;
    modal.classList.add('is-open');
    avatar.style.transition = 'transform .55s cubic-bezier(.2,.8,.2,1)';
    avatar.style.transform = 'none';
    timer = window.setTimeout(toCard, 520);
  }
  function close() {
    window.clearTimeout(timer);
    modal.classList.remove('is-open');
    window.setTimeout(function () { modal.hidden = true; sheet.setAttribute('data-stage', 'zoom'); }, reduce ? 0 : 280);
    document.body.style.overflow = '';
    if (opener) opener.focus({ preventScroll: true });
  }
  function step(n) {
    if (modal.hidden || !dots.length) return;
    current = (current + n + dots.length) % dots.length;
    opener = dots[current]; fill(opener);
  }

  dots.forEach(function (dot) { dot.addEventListener('click', function () { open(dot); }); });
  modal.addEventListener('click', function (e) { if (e.target.closest('[data-id-close]')) close(); });
  document.addEventListener('keydown', function (e) {
    if (modal.hidden) return;
    if (e.key === 'Escape') close();
    if (e.key === 'ArrowRight') step(1);
    if (e.key === 'ArrowLeft') step(-1);
    if (e.key === 'Tab') { e.preventDefault(); closeBtn.focus(); }
  });
}());


/* ---------- Bigaan AI: chatbot, insights and draft writer (talks to modules/ai_api.php) ---------- */
(function () {
  function post(url, token, data) {
    var fd = new FormData();
    fd.append('_csrf', token);
    Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
    return fetch(url, { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'Hindi nabasa ang sagot ng server.' }; }); })
      .catch(function () { return { ok: false, error: 'Walang koneksyon sa server. Subukan ulit.' }; });
  }
  function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }

  /* Safe mini-Markdown: paragraphs, "- " bullets, "1." steps, **bold**, `code` (built with DOM nodes, never innerHTML) */
  function inline(parent, text) {
    String(text).split(/(\*\*[^*]+\*\*|`[^`]+`)/g).forEach(function (part) {
      if (!part) return;
      if (part.slice(0, 2) === '**' && part.slice(-2) === '**' && part.length > 4) parent.appendChild(el('strong', null, part.slice(2, -2)));
      else if (part.charAt(0) === '`' && part.slice(-1) === '`' && part.length > 2) parent.appendChild(el('code', null, part.slice(1, -1)));
      else parent.appendChild(document.createTextNode(part));
    });
  }
  function renderMd(box, text) {
    box.textContent = '';
    String(text).replace(/\r/g, '').trim().split(/\n{2,}/).forEach(function (block) {
      var lines = block.split('\n').filter(function (l) { return l.trim() !== ''; });
      var i = 0, para = [];
      function flush() {
        if (!para.length) return;
        var p = el('p'); para.forEach(function (l, k) { if (k) p.appendChild(document.createElement('br')); inline(p, l); }); box.appendChild(p); para = [];
      }
      while (i < lines.length) {
        var ul = /^\s*[-\u2022]\s+(.*)$/, ol = /^\s*\d+[.)]\s+(.*)$/, m;
        if (ul.test(lines[i])) {
          flush(); var u = el('ul');
          while (i < lines.length && (m = ul.exec(lines[i]))) { var li = el('li'); inline(li, m[1]); u.appendChild(li); i++; }
          box.appendChild(u);
        } else if (ol.test(lines[i])) {
          flush(); var o = el('ol');
          while (i < lines.length && (m = ol.exec(lines[i]))) { var li2 = el('li'); inline(li2, m[1]); o.appendChild(li2); i++; }
          box.appendChild(o);
        } else { para.push(lines[i]); i++; }
      }
      flush();
    });
  }
  function printLink(base, ids, label) {
    var a = el('a', 'ai-print-link', label || 'Print'); a.target = '_blank'; a.rel = 'noopener';
    a.href = base + '?ids=' + ids.join(','); return a;
  }

  /* Chatbot */
  document.querySelectorAll('[data-ai-chat]').forEach(function (root) {
    var url = root.dataset.aiUrl, token = root.dataset.aiToken, printBase = root.dataset.aiPrintUrl || '', history = [], busy = false, logIds = [];
    var suggestions = []; try { suggestions = JSON.parse(root.dataset.aiSuggestions || '[]'); } catch (e) {}
    var log = el('div', 'ai-log'); log.setAttribute('role', 'log'); log.setAttribute('aria-live', 'polite');
    var chips = el('div', 'ai-chips');
    var form = el('form', 'ai-form'); form.setAttribute('autocomplete', 'off');
    var input = el('input', 'ai-input'); input.type = 'text'; input.maxLength = 600; input.placeholder = 'Magtanong dito...'; input.setAttribute('aria-label', 'Ask Bigaan AI');
    var send = el('button', 'ai-send', 'Send'); send.type = 'submit';
    form.appendChild(input); form.appendChild(send);
    var tools = el('div', 'ai-tools');
    root.appendChild(log); root.appendChild(chips); root.appendChild(form); root.appendChild(tools);
    function refreshTools() {
      tools.textContent = '';
      if (printBase && logIds.length) {
        tools.appendChild(printLink(printBase, logIds, 'Print chat'));
        var clear = el('button', 'ai-print-link ai-clear', 'Clear'); clear.type = 'button';
        clear.addEventListener('click', function () { history = []; logIds = []; log.textContent = ''; bubble('bot', root.dataset.aiGreeting || 'Kumusta!'); refreshTools(); });
        tools.appendChild(clear);
      }
    }

    function bubble(role, text) {
      var b = el('div', 'ai-msg ai-' + role);
      if (role === 'bot') renderMd(b, text); else b.textContent = text;
      log.appendChild(b); log.scrollTop = log.scrollHeight; return b;
    }
    function renderChips(list) {
      chips.textContent = '';
      (list || []).slice(0, 4).forEach(function (s) {
        var c = el('button', 'ai-chip', s); c.type = 'button';
        c.addEventListener('click', function () { ask(s); });
        chips.appendChild(c);
      });
    }
    function ask(text) {
      text = (text || '').trim();
      if (!text || busy) return;
      busy = true; send.disabled = true; input.value = '';
      bubble('user', text);
      var typing = bubble('bot', '...'); typing.classList.add('ai-typing');
      post(url, token, { action: 'chat', message: text, history: JSON.stringify(history) }).then(function (res) {
        typing.classList.remove('ai-typing');
        if (res && res.ok) {
          renderMd(typing, res.reply);
          if (printBase && res.log_id) {
            logIds.push(res.log_id);
            var row = el('div', 'ai-msg-tools'); row.appendChild(printLink(printBase, [res.log_id], 'Print answer')); typing.appendChild(row);
            refreshTools();
          }
          history.push({ role: 'user', content: text }, { role: 'assistant', content: res.reply });
          history = history.slice(-8);
          if (res.provider) root.setAttribute('data-engine', res.provider);
          renderChips(res.suggestions);
        } else {
          typing.textContent = (res && res.error) || 'May problema. Subukan ulit.';
          typing.classList.add('ai-error');
        }
        log.scrollTop = log.scrollHeight;
        busy = false; send.disabled = false; input.focus({ preventScroll: true });
      });
    }
    form.addEventListener('submit', function (ev) { ev.preventDefault(); ask(input.value); });
    bubble('bot', root.dataset.aiGreeting || 'Kumusta! Ano ang maitutulong ko?');
    renderChips(suggestions);
  });

  /* Insights */
  var insights = document.querySelector('[data-ai-insights]');
  var runInsights = document.querySelector('[data-ai-insights-run]');
  if (insights && runInsights) {
    runInsights.addEventListener('click', function () {
      runInsights.disabled = true; runInsights.textContent = 'Sinusuri...';
      insights.textContent = '';
      insights.appendChild(el('p', 'muted', 'Sinusuri ang datos ng barangay...'));
      post(insights.dataset.aiUrl, insights.dataset.aiToken, { action: 'insights' }).then(function (res) {
        insights.textContent = '';
        if (!res || !res.ok) {
          insights.appendChild(el('p', 'ai-error', (res && res.error) || 'May problema. Subukan ulit.'));
        } else {
          var sum = el('div', 'ai-summary'); sum.appendChild(el('strong', null, 'Buod'));
          sum.appendChild(el('p', null, res.summary)); sum.appendChild(el('small', 'muted', 'Engine: ' + res.provider));
          insights.appendChild(sum);
          var list = el('ul', 'ai-insight-list');
          res.items.forEach(function (it) {
            var li = el('li', 'ai-insight ai-' + it.level);
            li.appendChild(el('b', null, it.title)); li.appendChild(el('span', null, it.text));
            list.appendChild(li);
          });
          insights.appendChild(list);
          if (res.log_id && insights.dataset.aiPrintUrl) {
            var pr = el('div', 'ai-actions'); pr.appendChild(printLink(insights.dataset.aiPrintUrl, [res.log_id], 'Print report')); insights.appendChild(pr);
          }
        }
        runInsights.disabled = false; runInsights.textContent = 'Refresh analysis';
      });
    });
  }

  /* Draft writer */
  var draft = document.querySelector('[data-ai-draft-form]');
  if (draft) {
    var out = document.querySelector('[data-ai-draft-out]');
    var area = document.querySelector('[data-ai-draft-text]');
    var engine = document.querySelector('[data-ai-draft-engine]');
    var runBtn = document.querySelector('[data-ai-draft-run]');
    draft.addEventListener('submit', function (ev) {
      ev.preventDefault();
      if (!draft.reportValidity()) return;
      var data = { action: 'draft' };
      new FormData(draft).forEach(function (v, k) { if (k !== '_csrf') data[k] = v; });
      runBtn.disabled = true;
      post(draft.dataset.aiUrl, draft.dataset.aiToken, data).then(function (res) {
        runBtn.disabled = false;
        out.hidden = false;
        var pl = document.querySelector('[data-ai-print="draft"]');
        if (res && res.ok) {
          area.value = res.text; engine.textContent = '(' + res.provider + ')';
          if (pl && res.log_id) { pl.href = draft.dataset.aiPrintUrl + '?id=' + res.log_id; pl.hidden = false; }
        }
        else { area.value = (res && res.error) || 'May problema. Subukan ulit.'; engine.textContent = ''; }
      });
    });
    var copy = document.querySelector('[data-ai-copy]');
    if (copy) copy.addEventListener('click', function () {
      area.select();
      var done = function () { copy.textContent = 'Copied!'; setTimeout(function () { copy.textContent = 'Copy text'; }, 1500); };
      if (navigator.clipboard) { navigator.clipboard.writeText(area.value).then(done, function () { document.execCommand('copy'); done(); }); }
      else { document.execCommand('copy'); done(); }
    });
  }
}());


/* Gentle entrance animation: cards rise in as they scroll into view (skipped for reduced motion). */
(function () {
  if (!('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var nodes = document.querySelectorAll('.app-page .hero, .app-page .panel, .app-page .metric-card, .app-page .module-card, .app-page .page-header');
  if (!nodes.length) return;
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      if (!en.isIntersecting) return;
      en.target.classList.add('rv-in'); io.unobserve(en.target);
    });
  }, { threshold: 0.08 });
  var i = 0;
  var fold = window.innerHeight || 800;
  nodes.forEach(function (n) {
    if (n.getBoundingClientRect().top < fold) return;   // visible right away, no waiting
    n.classList.add('rv'); io.observe(n);
  });
}());
