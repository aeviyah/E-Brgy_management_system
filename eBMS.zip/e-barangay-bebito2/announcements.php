<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
require_roles(['secretary','captain','staff','admin']);
require_once __DIR__ . '/includes/layout.php';
$s=db()->query("SELECT a.*,u.full_name creator FROM announcements a LEFT JOIN users u ON u.id=a.created_by ORDER BY a.created_at DESC");$rows=$s->fetchAll();
render_header('Announcements','announcements');
page_header('Announcements','Create and review barangay announcements and publication status.','<a class="button" href="'.e(app_url('communication.php')).'">Open Communication Center</a>');
?><div class="grid cards-3" style="margin-bottom:16px"><div class="card metric"><span>Published</span><strong><?=fetch_count('announcements',"status='Published'")?></strong></div><div class="card metric"><span>Scheduled</span><strong><?=fetch_count('announcements',"status='Scheduled'")?></strong></div><div class="card metric"><span>Drafts</span><strong><?=fetch_count('announcements',"status='Draft'")?></strong></div></div><div class="table-wrap"><table><thead><tr><th>Title</th><th>Audience</th><th>Channels</th><th>Schedule</th><th>Status</th><th>Created</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=e($r['title'])?></td><td><?=e($r['audience'])?></td><td><?=e($r['channels'])?></td><td><?=e($r['scheduled_at']?:'—')?></td><td><?=status_chip($r['status'])?></td><td><?=e($r['creator']?:'System')?></td></tr><?php endforeach;if(!$rows):?><tr><td colspan="6" class="empty-state">No announcements yet.</td></tr><?php endif;?></tbody></table></div><?php render_footer();
