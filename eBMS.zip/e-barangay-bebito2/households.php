<?php
$moduleKey = 'households';
require __DIR__ . '/module.php';
