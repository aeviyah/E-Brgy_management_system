<?php
require_once __DIR__ . '/includes/workflow.php';
render_request_workflow('permit');
