<?php
$moduleKey = 'residents';
require __DIR__ . '/module.php';
