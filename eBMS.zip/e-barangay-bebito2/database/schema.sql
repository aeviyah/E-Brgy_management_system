CREATE DATABASE IF NOT EXISTS e_barangay
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE e_barangay;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  resident_id INT NULL,
  full_name VARCHAR(160) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('resident','secretary','treasurer','captain','staff','admin') NOT NULL DEFAULT 'resident',
  status ENUM('pending','active','inactive') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS puroks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  leader VARCHAR(160) NULL,
  assigned_area VARCHAR(255) NULL,
  notes TEXT NULL,
  status ENUM('Active','Inactive','Archived') NOT NULL DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS households (
  id INT AUTO_INCREMENT PRIMARY KEY,
  household_code VARCHAR(60) NOT NULL UNIQUE,
  head_resident_id INT NULL,
  purok_id INT NULL,
  address VARCHAR(255) NOT NULL,
  classification VARCHAR(120) NULL,
  income_bracket VARCHAR(120) NULL,
  housing_type VARCHAR(120) NULL,
  utilities VARCHAR(255) NULL,
  status ENUM('Active','Inactive','Archived') NOT NULL DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (purok_id)
);

CREATE TABLE IF NOT EXISTS residents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  resident_code VARCHAR(60) NOT NULL UNIQUE,
  household_id INT NULL,
  purok_id INT NULL,
  first_name VARCHAR(120) NOT NULL,
  middle_name VARCHAR(120) NULL,
  last_name VARCHAR(120) NOT NULL,
  birth_date DATE NULL,
  sex ENUM('Female','Male','Other') NULL,
  civil_status VARCHAR(60) NULL,
  contact_number VARCHAR(60) NULL,
  email VARCHAR(160) NULL,
  address VARCHAR(255) NOT NULL,
  occupation VARCHAR(120) NULL,
  education VARCHAR(120) NULL,
  voter_status VARCHAR(80) NULL,
  classifications VARCHAR(255) NULL,
  status ENUM('Pending Verification','Active','Inactive','Transferred','Deceased','Archived') NOT NULL DEFAULT 'Pending Verification',
  photo_path VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  INDEX (household_id),
  INDEX (purok_id)
);

ALTER TABLE users
  ADD CONSTRAINT fk_users_resident
  FOREIGN KEY (resident_id) REFERENCES residents(id)
  ON DELETE SET NULL;

CREATE TABLE IF NOT EXISTS request_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  type ENUM('document','permit','service') NOT NULL,
  reference_no VARCHAR(80) NOT NULL UNIQUE,
  resident_id INT NULL,
  requester_name VARCHAR(160) NOT NULL,
  title VARCHAR(160) NOT NULL,
  requirements TEXT NULL,
  details TEXT NULL,
  fee DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  status ENUM('Pending','Under Review','For Payment','For Approval','Processing','Ready for Release','Completed','Rejected','Returned for Correction','Cancelled','Archived') NOT NULL DEFAULT 'Pending',
  assigned_to INT NULL,
  document_no VARCHAR(80) NULL,
  qr_code VARCHAR(120) NULL,
  remarks TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  INDEX (type),
  INDEX (resident_id),
  INDEX (status)
);

CREATE TABLE IF NOT EXISTS cases (
  id INT AUTO_INCREMENT PRIMARY KEY,
  case_type ENUM('complaint','blotter','katarungang','peace_order','bcpc','vawc') NOT NULL,
  case_no VARCHAR(80) NOT NULL UNIQUE,
  title VARCHAR(160) NOT NULL,
  complainant VARCHAR(160) NOT NULL,
  respondent VARCHAR(160) NULL,
  incident_at DATETIME NULL,
  location VARCHAR(255) NULL,
  description TEXT NULL,
  evidence TEXT NULL,
  assigned_to INT NULL,
  sensitivity ENUM('normal','restricted','confidential') NOT NULL DEFAULT 'normal',
  status ENUM('Pending','Under Review','Mediation','Referred','Resolved','Closed','Archived') NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  INDEX (case_type),
  INDEX (status),
  INDEX (sensitivity)
);

CREATE TABLE IF NOT EXISTS payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  transaction_no VARCHAR(80) NOT NULL UNIQUE,
  request_id INT NULL,
  resident_id INT NULL,
  purpose VARCHAR(180) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  method VARCHAR(80) NOT NULL DEFAULT 'Cash',
  status ENUM('Pending','Paid','Cancelled','Refunded') NOT NULL DEFAULT 'Pending',
  paid_at DATETIME NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (request_id),
  INDEX (resident_id),
  INDEX (status)
);

CREATE TABLE IF NOT EXISTS receipts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  or_number VARCHAR(80) NOT NULL UNIQUE,
  payment_id INT NOT NULL,
  issued_by INT NULL,
  issued_at DATETIME NOT NULL,
  INDEX (payment_id)
);

CREATE TABLE IF NOT EXISTS officials (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  position VARCHAR(120) NOT NULL,
  term_start DATE NULL,
  term_end DATE NULL,
  contact VARCHAR(120) NULL,
  signature_path VARCHAR(255) NULL,
  responsibilities TEXT NULL,
  status ENUM('Active','Inactive','Archived') NOT NULL DEFAULT 'Active'
);

CREATE TABLE IF NOT EXISTS governance_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  record_type ENUM('assembly','meeting','ordinance','resolution','memorandum','official_document') NOT NULL,
  record_no VARCHAR(80) NULL,
  title VARCHAR(180) NOT NULL,
  record_date DATE NULL,
  status ENUM('Draft','Scheduled','Approved','Published','Archived') NOT NULL DEFAULT 'Draft',
  details TEXT NULL,
  attachment VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS announcements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(180) NOT NULL,
  body TEXT NOT NULL,
  audience VARCHAR(160) NOT NULL DEFAULT 'All residents',
  channels VARCHAR(120) NOT NULL DEFAULT 'Portal, In-app',
  status ENUM('Draft','Scheduled','Published','Archived') NOT NULL DEFAULT 'Draft',
  scheduled_at DATETIME NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  subject VARCHAR(180) NOT NULL,
  body TEXT NOT NULL,
  recipients VARCHAR(180) NOT NULL,
  channels VARCHAR(120) NOT NULL DEFAULT 'In-app',
  status ENUM('Draft','Scheduled','Sent','Failed','Archived') NOT NULL DEFAULT 'Draft',
  sent_at DATETIME NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS events (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(180) NOT NULL,
  event_type VARCHAR(120) NOT NULL DEFAULT 'Community Activity',
  location VARCHAR(180) NULL,
  starts_at DATETIME NULL,
  ends_at DATETIME NULL,
  description TEXT NULL,
  status ENUM('Draft','Scheduled','Ongoing','Completed','Cancelled','Archived') NOT NULL DEFAULT 'Scheduled',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS projects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(180) NOT NULL,
  budget DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  beneficiaries VARCHAR(180) NULL,
  start_date DATE NULL,
  target_date DATE NULL,
  progress TINYINT NOT NULL DEFAULT 0,
  status ENUM('Proposed','Approved','Ongoing','Completed','Archived') NOT NULL DEFAULT 'Proposed',
  details TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS facilities (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  capacity INT NULL,
  location VARCHAR(180) NULL,
  notes TEXT NULL,
  status ENUM('Available','Reserved','Maintenance','Archived') NOT NULL DEFAULT 'Available'
);

CREATE TABLE IF NOT EXISTS reservations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  facility_id INT NOT NULL,
  resident_id INT NULL,
  requester_name VARCHAR(160) NOT NULL,
  purpose VARCHAR(180) NOT NULL,
  starts_at DATETIME NOT NULL,
  ends_at DATETIME NOT NULL,
  status ENUM('Pending','Under Review','Approved','Reserved','Completed','Rejected','Cancelled','Archived') NOT NULL DEFAULT 'Pending',
  remarks TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (facility_id),
  INDEX (status)
);

CREATE TABLE IF NOT EXISTS assets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  asset_code VARCHAR(80) NOT NULL UNIQUE,
  name VARCHAR(160) NOT NULL,
  category VARCHAR(100) NULL,
  quantity INT NOT NULL DEFAULT 1,
  condition_status VARCHAR(100) NULL,
  location VARCHAR(160) NULL,
  assigned_to VARCHAR(160) NULL,
  status ENUM('Active','For Maintenance','Disposed','Archived') NOT NULL DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS environment_reports (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(180) NOT NULL,
  category VARCHAR(120) NOT NULL,
  location VARCHAR(180) NULL,
  details TEXT NULL,
  status ENUM('Pending','Under Review','Processing','Completed','Rejected','Archived') NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS assistance_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  program VARCHAR(160) NOT NULL,
  beneficiary_name VARCHAR(160) NOT NULL,
  eligibility VARCHAR(180) NULL,
  distribution_date DATE NULL,
  details TEXT NULL,
  status ENUM('Pending','Under Review','Approved','Distributed','Rejected','Archived') NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  title VARCHAR(180) NOT NULL,
  body TEXT NOT NULL,
  status ENUM('Unread','Read','Archived') NOT NULL DEFAULT 'Unread',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (user_id),
  INDEX (status)
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  action VARCHAR(120) NOT NULL,
  table_name VARCHAR(120) NULL,
  record_id INT NULL,
  details TEXT NULL,
  ip_address VARCHAR(80) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (user_id),
  INDEX (table_name),
  INDEX (created_at)
);

CREATE TABLE IF NOT EXISTS settings (
  name VARCHAR(120) PRIMARY KEY,
  value TEXT NULL
);

INSERT INTO users (full_name, email, password_hash, role, status)
VALUES ('System Administrator', 'admin@barangay.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active')
ON DUPLICATE KEY UPDATE email = email;

INSERT INTO puroks (name, leader, assigned_area, notes) VALUES
('Purok 1', 'Unassigned', 'North area', 'Initial Purok record'),
('Purok 2', 'Unassigned', 'Central area', 'Initial Purok record'),
('Purok 3', 'Unassigned', 'South area', 'Initial Purok record')
ON DUPLICATE KEY UPDATE name = VALUES(name);

INSERT INTO facilities (name, capacity, location, notes) VALUES
('Barangay Hall', 80, 'Barangay Center', 'Meetings and official activities'),
('Covered Court', 300, 'Main Court', 'Sports, assemblies, and public events'),
('Function Room', 40, 'Barangay Hall', 'Small meetings and trainings')
ON DUPLICATE KEY UPDATE name = VALUES(name);

INSERT INTO settings (name, value) VALUES
('barangay_name', 'Barangay Bebito'),
('office_hours', 'Monday to Friday, 8:00 AM - 5:00 PM'),
('contact_number', '0917-000-0000'),
('email_address', 'bebito.lopez@example.com')
ON DUPLICATE KEY UPDATE value = VALUES(value);

CREATE TABLE IF NOT EXISTS case_events (
  id INT AUTO_INCREMENT PRIMARY KEY,
  case_id INT NOT NULL,
  event_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  event_type VARCHAR(100) NOT NULL,
  notes TEXT NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (case_id),
  INDEX (event_date)
);

CREATE TABLE IF NOT EXISTS public_contacts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  label VARCHAR(120) NOT NULL UNIQUE,
  contact_type VARCHAR(60) NOT NULL DEFAULT 'Office',
  value VARCHAR(180) NOT NULL,
  availability VARCHAR(180) NULL,
  status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active'
);

INSERT INTO public_contacts (label, contact_type, value, availability) VALUES
('Barangay Hall', 'Office', '0917-000-0000', 'Monday to Friday, 8:00 AM - 5:00 PM'),
('Emergency Hotline', 'Emergency', '911 / Local Hotline', '24/7')
ON DUPLICATE KEY UPDATE label = VALUES(label);
