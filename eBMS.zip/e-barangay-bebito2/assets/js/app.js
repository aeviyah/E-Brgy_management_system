document.addEventListener('click',function(e){
  var t=e.target.closest('[data-sidebar-toggle]');
  if(t){var s=document.getElementById('sidebar');if(s)s.classList.toggle('open');}
  var c=e.target.closest('[data-confirm]');
  if(c&&!window.confirm(c.getAttribute('data-confirm')||'Continue?'))e.preventDefault();
  var b=e.target.closest('.button');
  if(b){var r=document.createElement('span'),x=b.getBoundingClientRect();r.className='ripple';
    r.style.left=(e.clientX-x.left-15)+'px';r.style.top=(e.clientY-x.top-15)+'px';b.appendChild(r);setTimeout(function(){r.remove()},600);}
});
document.addEventListener('DOMContentLoaded',function(){
  document.querySelectorAll('.nav-list a').forEach(function(a,i){a.style.setProperty('--i',i)});
  // count-up for dashboard metrics
  document.querySelectorAll('.metric strong').forEach(function(el){
    var end=parseInt(el.textContent.replace(/\D/g,''),10);if(isNaN(end)||end===0)return;
    var t0=null;(function step(ts){t0=t0||ts;var p=Math.min((ts-t0)/900,1);
      el.textContent=Math.floor(end*(1-Math.pow(1-p,3)));if(p<1)requestAnimationFrame(step);else el.textContent=end;})(performance.now());
  });
  // scroll reveal
  var io='IntersectionObserver' in window?new IntersectionObserver(function(en){en.forEach(function(x){if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target)}})},{threshold:.1}):null;
  document.querySelectorAll('.reveal').forEach(function(el){io?io.observe(el):el.classList.add('in')});
  // live table filter (any table preceded by [data-table-filter])
  document.querySelectorAll('[data-table-filter]').forEach(function(inp){
    inp.addEventListener('input',function(){var q=inp.value.toLowerCase();
      document.querySelectorAll('.table-wrap tbody tr').forEach(function(tr){tr.style.display=tr.textContent.toLowerCase().indexOf(q)>-1?'':'none'})});
  });
  // greeting clock
  var clock=document.getElementById('live-clock');
  if(clock){(function tick(){clock.textContent=new Date().toLocaleString('en-PH',{weekday:'long',month:'long',day:'numeric',year:'numeric',hour:'2-digit',minute:'2-digit'});setTimeout(tick,30000)})();}
});
