<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';

render_header('Access restricted');
page_header('Access restricted', 'Your current role does not have permission to open this page.');
?>
<div class="card">
    <p>Please return to the dashboard or ask the system administrator to update your role permissions.</p>
    <a class="button" href="<?= e(app_url('dashboard.php')) ?>">Back to dashboard</a>
</div>
<?php render_footer(); ?>
