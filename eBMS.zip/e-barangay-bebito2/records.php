<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
require_roles(['secretary','captain','staff','admin']);
require_once __DIR__ . '/includes/layout.php';
$type=trim((string)($_GET['type']??''));
$allowed=['assembly','meeting','ordinance','resolution','memorandum','official_document'];
$where='1=1';$params=[];if(in_array($type,$allowed,true)){$where.=' AND record_type=?';$params[]=$type;}
$s=db()->prepare("SELECT * FROM governance_records WHERE $where ORDER BY record_date DESC,id DESC");$s->execute($params);$rows=$s->fetchAll();
render_header('Ordinances & Records','records');
page_header('Ordinances, Resolutions & Records','Central register for assemblies, meetings, ordinances, resolutions, memoranda, and official documents.','<a class="button" href="'.e(app_url('governance.php')).'">Manage Records</a>');
?>
<div class="filter-row"><a class="button ghost" href="<?=e(app_url('records.php'))?>">All</a><?php foreach($allowed as $t):?><a class="button ghost" href="<?=e(app_url('records.php?type='.$t))?>"><?=e(ucwords(str_replace('_',' ',$t)))?></a><?php endforeach;?></div>
<div class="table-wrap"><table><thead><tr><th>Record No.</th><th>Type</th><th>Title</th><th>Date</th><th>Status</th><th>Details</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=e($r['record_no']?:'—')?></td><td><?=e(ucwords(str_replace('_',' ',$r['record_type'])))?></td><td><?=e($r['title'])?></td><td><?=e($r['record_date']?:'—')?></td><td><?=status_chip($r['status'])?></td><td><?=e(mb_strimwidth((string)$r['details'],0,90,'…'))?></td></tr><?php endforeach;if(!$rows):?><tr><td colspan="6" class="empty-state">No records found.</td></tr><?php endif;?></tbody></table></div>
<?php render_footer();
