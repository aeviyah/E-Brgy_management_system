<?php
$moduleKey = 'officials';
require __DIR__ . '/module.php';
