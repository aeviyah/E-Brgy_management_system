<?php
$moduleKey = 'projects';
require __DIR__ . '/module.php';
