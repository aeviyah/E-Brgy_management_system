<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
require_roles(['secretary','captain','staff','admin']);
require_once __DIR__ . '/includes/layout.php';
$id=(int)($_GET['id']??0);
if($id>0){$s=db()->prepare('SELECT resident_code,first_name,last_name,status FROM residents WHERE id=?');$s->execute([$id]);$r=$s->fetch();if($r){db()->prepare("UPDATE residents SET status='Archived' WHERE id=?")->execute([$id]);audit_log('Archive resident','residents',$id,$r['resident_code'].' '.$r['first_name'].' '.$r['last_name']);flash('success','Resident archived.');}else{flash('error','Resident not found.');}}
redirect(app_url('residents.php'));
