<?php
$moduleKey = 'puroks';
require __DIR__ . '/module.php';
