<?php
$moduleKey = 'facilities';
require __DIR__ . '/module.php';
