<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
require_roles(['secretary','captain','staff','admin']);
require_once __DIR__ . '/includes/layout.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['form_action'] ?? '';
    if ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $data = [
            trim((string)($_POST['record_no'] ?? '')),
            trim((string)($_POST['title'] ?? '')),
            trim((string)($_POST['record_date'] ?? '')) ?: null,
            (string)($_POST['status'] ?? 'Scheduled'),
            trim((string)($_POST['details'] ?? '')),
        ];
        if ($data[1] === '') { flash('error','Meeting title is required.'); redirect(app_url('meetings.php')); }
        if ($id) {
            db()->prepare("UPDATE governance_records SET record_no=?, title=?, record_date=?, status=?, details=? WHERE id=? AND record_type='meeting'")->execute([...$data,$id]);
            audit_log('Update meeting','governance_records',$id,$data[1]);
            flash('success','Meeting updated.');
        } else {
            db()->prepare("INSERT INTO governance_records (record_type,record_no,title,record_date,status,details) VALUES ('meeting',?,?,?,?,?)")->execute($data);
            $newId=(int)db()->lastInsertId(); audit_log('Create meeting','governance_records',$newId,$data[1]);
            flash('success','Meeting recorded.');
        }
        redirect(app_url('meetings.php'));
    }
}

$edit=null;
if (isset($_GET['edit'])) { $s=db()->prepare("SELECT * FROM governance_records WHERE id=? AND record_type='meeting'"); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch()?:null; }
$rows=db()->query("SELECT * FROM governance_records WHERE record_type='meeting' ORDER BY record_date DESC, id DESC")->fetchAll();
render_header('Meetings','meetings');
page_header('Meetings','Council, committee, assembly, and special meeting records.','<a class="button ghost" href="'.e(app_url('governance.php')).'">Governance Records</a>');
?>
<div class="grid cards-2">
<form class="card" method="post"><input type="hidden" name="form_action" value="save"><input type="hidden" name="id" value="<?= (int)($edit['id']??0) ?>">
<h2><?= $edit?'Edit':'New' ?> Meeting</h2><div class="form-grid">
<div class="field"><label>Meeting No.</label><input name="record_no" value="<?=e($edit['record_no']??'')?>"></div>
<div class="field"><label>Date</label><input type="date" name="record_date" value="<?=e($edit['record_date']??'')?>"></div>
<div class="field full"><label>Title</label><input name="title" required value="<?=e($edit['title']??'')?>"></div>
<div class="field"><label>Status</label><select name="status"><?php foreach(['Draft','Scheduled','Approved','Published','Archived'] as $st): ?><option <?=selected($edit['status']??'Scheduled',$st)?>><?=e($st)?></option><?php endforeach;?></select></div>
<div class="field full"><label>Agenda / Minutes / Actions</label><textarea name="details"><?=e($edit['details']??'')?></textarea></div>
</div><div class="actions"><button class="button" type="submit">Save Meeting</button><?php if($edit): ?><a class="button ghost" href="<?=e(app_url('meetings.php'))?>">Cancel</a><?php endif;?></div></form>
<div class="card"><h2>Meeting Records</h2><div class="table-wrap"><table><thead><tr><th>No.</th><th>Title</th><th>Date</th><th>Status</th><th></th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=e($r['record_no']?:'—')?></td><td><?=e($r['title'])?></td><td><?=e($r['record_date']?:'—')?></td><td><?=status_chip($r['status'])?></td><td><a class="button ghost" href="<?=e(app_url('meetings.php?edit='.$r['id']))?>">Manage</a></td></tr><?php endforeach;if(!$rows):?><tr><td colspan="5" class="empty-state">No meetings recorded.</td></tr><?php endif;?></tbody></table></div></div>
</div>
<?php render_footer();
