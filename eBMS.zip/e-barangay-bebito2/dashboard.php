<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
require_roles(['resident','secretary','treasurer','captain','staff','admin']);
require_once __DIR__ . '/includes/layout.php';
$user=current_user(); $role=$user['role'];
render_header('Dashboard','dashboard');
page_header('Mabuhay, '.explode(' ',trim($user['full_name']))[0].'!','Barangay Bebito dashboard — requests, cases, payments and community activity.','<span id="live-clock" class="status-chip status-good"></span>');
if($role==='resident'):
$where=['resident_id = ?']; $params=[(int)($user['resident_id']??0)];
$requests=fetch_count('request_records','resident_id = ?',$params); $pending=fetch_count('request_records','resident_id = ? AND status NOT IN (\'Completed\',\'Rejected\',\'Cancelled\',\'Archived\')',$params); $cases=fetch_count('cases','complainant = ? AND status NOT IN (\'Closed\',\'Archived\')',[$user['full_name']]);
else:
$requests=fetch_count('request_records'); $pending=fetch_count('request_records','status NOT IN (\'Completed\',\'Rejected\',\'Cancelled\',\'Archived\')'); $cases=fetch_count('cases','status NOT IN (\'Closed\',\'Archived\')');
endif;
$paid=fetch_count('payments','status = ?',['Paid']); $ann=fetch_count('announcements','status = ?',['Published']);
?><div class="grid cards-4"><div class="card metric"><span><?= $role==='resident'?'My Requests':'All Requests' ?></span><strong><?= $requests ?></strong></div><div class="card metric"><span>Active Queue</span><strong><?= $pending ?></strong></div><div class="card metric"><span>Open Cases</span><strong><?= $cases ?></strong></div><div class="card metric"><span>Paid Transactions</span><strong><?= $paid ?></strong></div></div>
<div class="grid cards-2" style="margin-top:16px"><div class="card"><h3>Quick actions</h3><div class="actions"><a class="button" href="<?= e(app_url('documents.php?action=new')) ?>">Request Document</a><a class="button ghost" href="<?= e(app_url('services.php?action=new')) ?>">Request Service</a><a class="button ghost" href="<?= e(app_url('cases.php?action=new')) ?>">Report a Case</a><a class="button ghost" href="<?= e(app_url('public_portal.php')) ?>">Public Portal</a></div></div><div class="card"><h3>System status</h3><ul class="timeline"><li><span class="dot"></span><span>Announcements published: <?= $ann ?></span></li><li><span class="dot"></span><span>Role: <?= e(role_label($role)) ?></span></li><li><span class="dot"></span><span>Audit logging enabled</span></li><li><span class="dot"></span><span>Future specialized modules remain locked</span></li></ul></div></div>
<?php if($role!=='resident'): ?><div class="card" style="margin-top:16px"><h3>Defense flow</h3><p class="muted">Resident request → staff review → payment/approval → processing → release → notification → audit/report.</p><div class="actions"><a class="button ghost" href="<?= e(app_url('reports.php')) ?>">Open Reports</a><a class="button ghost" href="<?= e(app_url('audit.php')) ?>">Open Audit Trail</a></div></div><?php endif; ?><?php render_footer();
