<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
if (current_user()) { redirect(app_url('dashboard.php')); }
$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    if (login_attempt($email, $password)) {
        redirect(app_url('dashboard.php'));
    }
    $error = 'Invalid email/password or inactive account.';
}
$barangay = setting('barangay_name', 'E-Barangay');
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login | <?= e($barangay) ?></title><link rel="icon" href="<?= e(app_url('assets/img/logo.svg')) ?>"><link rel="stylesheet" href="<?= e(app_url('assets/css/style.css')) ?>"></head>
<body class="login-page"><span class="cloud"></span><span class="cloud c2"></span><div class="login-card"><div class="brand"><img class="brand-logo" src="<?= e(app_url('assets/img/logo.svg')) ?>" alt="Barangay seal"><div><strong><?= e($barangay) ?></strong><small>Lopez, Quezon · E-Barangay Management System</small></div></div><h1>Sign in</h1><p class="muted">Use your registered account to access the barangay system.</p><?php if($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?><form method="post"><div class="field"><label>Email</label><input type="email" name="email" required autofocus></div><div class="field"><label>Password</label><input type="password" name="password" required></div><button class="button" type="submit">Login</button></form><div class="actions" style="margin-top:14px"><a class="button ghost" href="<?= e(app_url('public_portal.php')) ?>">Public Portal</a><a class="button ghost" href="<?= e(app_url('portal_register.php')) ?>">Resident Registration</a></div><p class="muted" style="margin-top:18px">Demo administrator: admin@barangay.test / password</p></div><script src="<?= e(app_url('assets/js/app.js')) ?>"></script></body></html>
