<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';
$rows=db()->query("SELECT record_no,record_type,title,record_date,status,details FROM governance_records WHERE status='Published' AND record_type IN ('assembly','ordinance','resolution','memorandum','official_document') ORDER BY record_date DESC,id DESC LIMIT 100")->fetchAll();
render_header('Public Records','public');
page_header('Public Barangay Records','Published ordinances, resolutions, assemblies, memoranda, and official public records.');
?><div class="table-wrap"><table><thead><tr><th>No.</th><th>Type</th><th>Title</th><th>Date</th><th>Details</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=e($r['record_no']?:'—')?></td><td><?=e(ucwords(str_replace('_',' ',$r['record_type'])))?></td><td><?=e($r['title'])?></td><td><?=e($r['record_date']?:'—')?></td><td><?=e(mb_strimwidth((string)$r['details'],0,140,'…'))?></td></tr><?php endforeach;if(!$rows):?><tr><td colspan="5" class="empty-state">No published public records.</td></tr><?php endif;?></tbody></table></div><?php render_footer();
