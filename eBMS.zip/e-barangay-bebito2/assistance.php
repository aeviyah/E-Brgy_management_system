<?php
$moduleKey = 'assistance';
require __DIR__ . '/module.php';
