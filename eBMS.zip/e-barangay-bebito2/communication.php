<?php
$moduleKey = 'communication';
require __DIR__ . '/module.php';
