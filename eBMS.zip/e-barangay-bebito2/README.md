# E-Barangay Management System — Combined Final Package

This package is the combined final application built from the supplied `NotF.zip` project and the supplied Phase 1–7 E-Barangay package. It keeps the centralized NotF architecture while integrating the broader Phase 1–7 coverage, including dedicated meeting, records, announcements, archival, and public-record views.

## Technology

- PHP 8.x
- MySQL / MariaDB
- HTML5 + CSS3
- Basic JavaScript
- XAMPP / Apache / phpMyAdmin
- No Laravel, React, Node, Vue, Angular, or external framework required

## Installation in XAMPP

1. Extract this folder to `C:\xampp\htdocs\e-barangay\`.
2. Start **Apache** and **MySQL** in XAMPP.
3. Open phpMyAdmin: `http://localhost/phpmyadmin/`.
4. Import `database/schema.sql`.
5. If your MySQL credentials are not the XAMPP default, edit `config/database.php`.
6. Open `http://localhost/e-barangay/`.

### Demo administrator

- Email: `admin@barangay.test`
- Password: `password`

## Completed active areas

### Foundation
- Login / logout / PHP sessions
- Role-aware navigation
- Dashboard
- Residents
- Households
- Purok / Sitio
- Resident self-registration

### Core transactions
- Documents and certificates
- Permits and clearances
- Barangay services
- Request reference and QR values
- Request status workflow
- Payment creation from fee-bearing requests
- Treasury payment recording
- Official receipt issuance and printable receipt

### Governance and cases
- Complaints
- Blotter
- Katarungang Pambarangay
- Peace and Order
- BCPC
- VAWC
- Case status and case timeline
- VAWC restriction to Punong Barangay and System Administrator
- Barangay officials
- Governance records for assemblies, meetings, ordinances, resolutions, memoranda, and official documents
- Dedicated Meetings and Ordinances & Records views
- Dedicated announcements overview

### Communication and community
- Announcements
- Communication Center
- Events
- Notifications
- Public announcements/events

### Operations
- Projects
- Facilities
- Facility reservations
- Double-booking prevention
- Assets / inventory
- Environment / sanitation reports
- Assistance / livelihood records

### Reporting and control
- Reports and analytics summary
- Global search
- Audit trail
- System settings
- Public contact management
- SQL database backup

### Public portal
- Barangay information
- Public announcements
- Public events
- Officials
- Services / fees / requirements
- Resident registration
- Request tracking
- Public document/reference verification
- Public contacts
- Published public ordinances, resolutions, assemblies, and official records

## Locked future modules

The following remain visible as future scope but intentionally non-operational:

- SK Management
- Barangay Health Center
- Emergency & Disaster Response
- Agriculture and other specialized future sector systems
- Dedicated Senior Citizen Management
- Dedicated PWD Management

## Main defense workflow

A recommended demonstration is:

1. Admin login
2. Review dashboard
3. Open Residents and demonstrate resident records
4. Use a resident account to submit a document request
5. Staff reviews the request
6. Move a fee-bearing request to **For Payment**
7. Treasurer records payment
8. Treasurer issues an Official Receipt
9. Staff moves the request through processing/release/completion
10. Resident checks Notifications
11. Public portal verifies the reference/document number
12. Show Reports and Audit Trail

## Security and data handling

- Passwords use `password_hash()` / `password_verify()`.
- Database writes use prepared statements.
- Output is escaped with `htmlspecialchars()` through the `e()` helper.
- Session IDs are regenerated on login.
- Important changes are written to `audit_logs`.
- Residents are archived/deactivated through status instead of hard deletion.
- VAWC records are restricted by server-side role checks.
- Public verification exposes only non-sensitive workflow information.

## Important testing note

The source package has been syntax-checked with PHP and all navigation targets were checked for existence. The build environment used for packaging does not have a MySQL/MariaDB driver or running XAMPP database, so the final live database import and browser workflow must be performed on the user's XAMPP installation.
