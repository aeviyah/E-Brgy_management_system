<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/module_definitions.php';

$definitions = module_definitions();
$moduleKey = $moduleKey ?? ($_GET['m'] ?? '');

if (!isset($definitions[$moduleKey])) {
    http_response_code(404);
    echo 'Unknown module.';
    exit;
}

$module = $definitions[$moduleKey];
require_roles($module['view_roles']);

$canWrite = role_allows($module['write_roles']);
$table = $module['table'];
$fields = $module['fields'];
$action = $_GET['action'] ?? 'list';
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

function module_value(array $record, string $name): string
{
    return (string) ($record[$name] ?? '');
}

function module_input(array $field, array $record = []): void
{
    $name = $field['name'];
    $type = $field['type'] ?? 'text';
    $value = module_value($record, $name);
    $required = !empty($field['required']) ? 'required' : '';
    $placeholder = isset($field['placeholder']) ? ' placeholder="' . e($field['placeholder']) . '"' : '';

    if ($type === 'textarea') {
        echo '<textarea name="' . e($name) . '" ' . $required . $placeholder . '>' . e($value) . '</textarea>';
        return;
    }

    if ($type === 'select') {
        echo '<select name="' . e($name) . '" ' . $required . '>';
        foreach (($field['options'] ?? []) as $option) {
            echo '<option value="' . e($option) . '" ' . selected($value, $option) . '>' . e($option) . '</option>';
        }
        echo '</select>';
        return;
    }

    $inputType = in_array($type, ['date', 'datetime-local', 'email', 'number'], true) ? $type : 'text';
    if ($inputType === 'datetime-local' && $value !== '') {
        $value = str_replace(' ', 'T', substr($value, 0, 16));
    }
    echo '<input type="' . e($inputType) . '" name="' . e($name) . '" value="' . e($value) . '" ' . $required . $placeholder . '>';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$canWrite) {
        flash('error', 'Your role cannot change records in this module.');
        redirect(app_url($module['active'] . '.php'));
    }

    $postAction = $_POST['form_action'] ?? 'save';

    if ($postAction === 'archive') {
        $recordId = (int) ($_POST['id'] ?? 0);
        $stmt = db()->prepare("UPDATE {$table} SET status = 'Archived' WHERE id = ?");
        $stmt->execute([$recordId]);
        audit_log('Archive record', $table, $recordId, $module['title']);
        flash('success', 'Record archived.');
        redirect(app_url($module['active'] . '.php'));
    }

    $recordId = (int) ($_POST['id'] ?? 0);
    $data = [];
    foreach ($fields as $field) {
        $name = $field['name'];
        $value = trim((string) ($_POST[$name] ?? ''));
        $data[$name] = $value === '' ? null : $value;
    }

    foreach ($fields as $field) {
        if (!empty($field['required']) && empty($data[$field['name']])) {
            flash('error', $field['label'] . ' is required.');
            redirect(app_url($module['active'] . '.php?action=form&id=' . $recordId));
        }
    }

    if ($recordId > 0) {
        $assignments = [];
        foreach (array_keys($data) as $name) {
            $assignments[] = "{$name} = ?";
        }
        $params = array_values($data);
        $params[] = $recordId;
        $stmt = db()->prepare("UPDATE {$table} SET " . implode(', ', $assignments) . ' WHERE id = ?');
        $stmt->execute($params);
        audit_log('Update record', $table, $recordId, $module['title']);
        flash('success', 'Record updated.');
    } else {
        $columns = array_keys($data);
        $placeholders = array_fill(0, count($columns), '?');
        $stmt = db()->prepare("INSERT INTO {$table} (" . implode(', ', $columns) . ') VALUES (' . implode(', ', $placeholders) . ')');
        $stmt->execute(array_values($data));
        $recordId = (int) db()->lastInsertId();
        audit_log('Create record', $table, $recordId, $module['title']);
        flash('success', 'Record created.');
    }

    redirect(app_url($module['active'] . '.php'));
}

$record = [];
if ($id > 0) {
    $stmt = db()->prepare("SELECT * FROM {$table} WHERE id = ?");
    $stmt->execute([$id]);
    $record = $stmt->fetch() ?: [];
}

render_header($module['title'], $module['active']);

if ($action === 'form') {
    if (!$canWrite) {
        flash('error', 'Your role can view this module but cannot edit it.');
        redirect(app_url($module['active'] . '.php'));
    }

    page_header($id > 0 ? 'Edit ' . $module['title'] : 'Add ' . $module['title'], $module['subtitle'], '<a class="button ghost" href="' . e(app_url($module['active'] . '.php')) . '">Back</a>');
    ?>
    <form class="card" method="post">
        <input type="hidden" name="form_action" value="save">
        <input type="hidden" name="id" value="<?= (int) $id ?>">
        <div class="form-grid">
            <?php foreach ($fields as $field): ?>
                <div class="field <?= e($field['class'] ?? '') ?>">
                    <label for="<?= e($field['name']) ?>"><?= e($field['label']) ?></label>
                    <?php module_input($field, $record); ?>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="actions" style="margin-top: 16px;">
            <button class="button" type="submit">Save record</button>
            <a class="button ghost" href="<?= e(app_url($module['active'] . '.php')) ?>">Cancel</a>
        </div>
    </form>
    <?php
    render_footer();
    exit;
}

$q = trim((string) ($_GET['q'] ?? ''));
$status = trim((string) ($_GET['status'] ?? ''));
$where = [];
$params = [];

if ($q !== '') {
    $likeParts = [];
    foreach ($module['search'] as $column) {
        $likeParts[] = "{$column} LIKE ?";
        $params[] = '%' . $q . '%';
    }
    $where[] = '(' . implode(' OR ', $likeParts) . ')';
}

if ($status !== '' && array_key_exists('status', $module['columns'])) {
    $where[] = 'status = ?';
    $params[] = $status;
}

$sql = "SELECT * FROM {$table}";
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY id DESC LIMIT 200';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$records = $stmt->fetchAll();

$actionHtml = $canWrite ? '<a class="button" href="' . e(app_url($module['active'] . '.php?action=form')) . '">Add record</a>' : '';
page_header($module['title'], $module['subtitle'], $actionHtml);
?>

<?php if ($moduleKey === 'facilities'): ?>
    <div class="actions" style="margin-bottom: 14px;"><a class="button ghost" href="<?= e(app_url('reservations.php')) ?>">Facility Reservations</a></div>
<?php endif; ?>

<?php if ($moduleKey === 'governance'): ?>
    <div class="actions" style="margin-bottom: 14px;">
        <a class="button ghost" href="<?= e(app_url('officials.php')) ?>">Officials & personnel</a>
        <a class="button ghost" href="<?= e(app_url('meetings.php')) ?>">Meetings</a>
        <a class="button ghost" href="<?= e(app_url('records.php')) ?>">Ordinances & Records</a>
    </div>
<?php endif; ?>

<form class="inline-form" method="get">
    <input type="search" name="q" placeholder="Search <?= e(strtolower($module['title'])) ?>" value="<?= e($q) ?>">
    <?php if (array_key_exists('status', $module['columns'])): ?>
        <select name="status">
            <option value="">All statuses</option>
            <?php
            $statusOptions = [];
            foreach ($fields as $field) {
                if ($field['name'] === 'status') {
                    $statusOptions = $field['options'] ?? [];
                }
            }
            foreach ($statusOptions as $option):
            ?>
                <option value="<?= e($option) ?>" <?= selected($status, $option) ?>><?= e($option) ?></option>
            <?php endforeach; ?>
        </select>
    <?php endif; ?>
    <button class="button ghost" type="submit">Filter</button>
</form>

<div class="table-wrap">
    <table>
        <thead>
            <tr>
                <?php foreach ($module['columns'] as $label): ?>
                    <th><?= e($label) ?></th>
                <?php endforeach; ?>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!$records): ?>
                <tr><td colspan="<?= count($module['columns']) + 1 ?>" class="empty-state">No records found.</td></tr>
            <?php endif; ?>
            <?php foreach ($records as $row): ?>
                <tr>
                    <?php foreach ($module['columns'] as $column => $label): ?>
                        <td>
                            <?php if ($column === 'status'): ?>
                                <?= status_chip((string) $row[$column]) ?>
                            <?php elseif ($column === 'progress'): ?>
                                <?= (int) $row[$column] ?>%
                            <?php elseif ($column === 'budget'): ?>
                                PHP <?= number_format((float) $row[$column], 2) ?>
                            <?php else: ?>
                                <?= e((string) ($row[$column] ?? '')) ?>
                            <?php endif; ?>
                        </td>
                    <?php endforeach; ?>
                    <td>
                        <div class="actions">
                            <?php if ($canWrite): ?>
                                <a class="button ghost" href="<?= e(app_url($module['active'] . '.php?action=form&id=' . (int) $row['id'])) ?>">Edit</a>
                                <?php if (isset($row['status']) && $row['status'] !== 'Archived'): ?>
                                    <form method="post" style="display:inline">
                                        <input type="hidden" name="form_action" value="archive">
                                        <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                                        <button class="button danger" type="submit" data-confirm="Archive this record?">Archive</button>
                                    </form>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="muted">View only</span>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php render_footer(); ?>
