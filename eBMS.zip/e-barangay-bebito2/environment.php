<?php
$moduleKey = 'environment';
require __DIR__ . '/module.php';
