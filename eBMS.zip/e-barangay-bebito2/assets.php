<?php
$moduleKey = 'assets';
require __DIR__ . '/module.php';
