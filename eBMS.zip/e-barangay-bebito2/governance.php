<?php
$moduleKey = 'governance';
require __DIR__ . '/module.php';
