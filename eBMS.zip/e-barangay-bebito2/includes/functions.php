<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): void
{
    header('Location: ' . $path);
    exit;
}

function app_url(string $path = ''): string
{
    $base = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
    if ($base === '/' || $base === '\\') {
        $base = '';
    }

    return $base . '/' . ltrim($path, '/');
}

function setting(string $name, string $fallback = ''): string
{
    $stmt = db()->prepare('SELECT value FROM settings WHERE name = ?');
    $stmt->execute([$name]);
    $value = $stmt->fetchColumn();

    return $value === false ? $fallback : (string) $value;
}

function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }

    static $user = null;
    if ($user !== null) {
        return $user;
    }

    $stmt = db()->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([(int) $_SESSION['user_id']]);
    $user = $stmt->fetch() ?: null;

    return $user;
}

function role_label(string $role): string
{
    $labels = [
        'resident' => 'Resident',
        'secretary' => 'Barangay Secretary',
        'treasurer' => 'Barangay Treasurer',
        'captain' => 'Punong Barangay',
        'staff' => 'Barangay Staff',
        'admin' => 'System Administrator',
    ];

    return $labels[$role] ?? ucfirst($role);
}

function role_allows(array|string $roles): bool
{
    $user = current_user();
    if (!$user) {
        return false;
    }

    $roles = is_array($roles) ? $roles : [$roles];
    return in_array($user['role'], $roles, true);
}

function can_manage_records(): bool
{
    return role_allows(['secretary', 'captain', 'staff', 'admin']);
}

function can_manage_finance(): bool
{
    return role_allows(['treasurer', 'captain', 'admin']);
}

function can_manage_system(): bool
{
    return role_allows(['admin']);
}

function status_class(string $status): string
{
    $status = strtolower($status);
    if (str_contains($status, 'completed') || str_contains($status, 'active') || str_contains($status, 'paid') || str_contains($status, 'approved') || str_contains($status, 'published')) {
        return 'status-good';
    }
    if (str_contains($status, 'pending') || str_contains($status, 'review') || str_contains($status, 'payment') || str_contains($status, 'approval') || str_contains($status, 'processing') || str_contains($status, 'scheduled')) {
        return 'status-warn';
    }
    if (str_contains($status, 'rejected') || str_contains($status, 'cancelled') || str_contains($status, 'failed') || str_contains($status, 'inactive')) {
        return 'status-bad';
    }

    return 'status-muted';
}

function reference_no(string $prefix): string
{
    return strtoupper($prefix) . '-' . date('ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
}

function audit_log(string $action, ?string $tableName = null, ?int $recordId = null, ?string $details = null): void
{
    $user = current_user();
    $stmt = db()->prepare('INSERT INTO audit_logs (user_id, action, table_name, record_id, details, ip_address) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->execute([
        $user['id'] ?? null,
        $action,
        $tableName,
        $recordId,
        $details,
        $_SERVER['REMOTE_ADDR'] ?? null,
    ]);
}

function notify_user(?int $userId, string $title, string $body): void
{
    $stmt = db()->prepare('INSERT INTO notifications (user_id, title, body) VALUES (?, ?, ?)');
    $stmt->execute([$userId, $title, $body]);
}

function fetch_count(string $table, string $where = '1=1', array $params = []): int
{
    $stmt = db()->prepare("SELECT COUNT(*) FROM {$table} WHERE {$where}");
    $stmt->execute($params);

    return (int) $stmt->fetchColumn();
}

function flash(string $key, ?string $message = null): ?string
{
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return null;
    }

    if (!isset($_SESSION['flash'][$key])) {
        return null;
    }

    $value = $_SESSION['flash'][$key];
    unset($_SESSION['flash'][$key]);

    return $value;
}

function selected(string $actual, string $expected): string
{
    return $actual === $expected ? 'selected' : '';
}
