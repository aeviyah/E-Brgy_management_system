<?php

declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/layout.php';

function request_type_config(string $type): array
{
    $configs = [
        'document' => [
            'active' => 'documents',
            'title' => 'Documents & Certificates',
            'subtitle' => 'Request, verify, approve, generate, release, download, and QR/reference verification.',
            'catalog' => [
                'Barangay Clearance' => ['fee' => 50, 'requirements' => 'Valid ID, proof of residency, no pending barangay case'],
                'Certificate of Residency' => ['fee' => 30, 'requirements' => 'Valid ID, proof of address'],
                'Certificate of Indigency' => ['fee' => 0, 'requirements' => 'Valid ID, interview or assessment notes'],
                'Certificate of Good Moral Character' => ['fee' => 30, 'requirements' => 'Valid ID, barangay record check'],
                'Certificate of Low Income' => ['fee' => 0, 'requirements' => 'Valid ID, income declaration or assessment'],
                'Certificate of No Property' => ['fee' => 30, 'requirements' => 'Valid ID, declaration and verification'],
                'Solo Parent Certification' => ['fee' => 0, 'requirements' => 'Valid ID, supporting documents'],
            ],
        ],
        'permit' => [
            'active' => 'permits',
            'title' => 'Permits & Clearances',
            'subtitle' => 'Business clearance applications, requirements, assessment, approval, release, and permit history.',
            'catalog' => [
                'Barangay Business Clearance' => ['fee' => 200, 'requirements' => 'Business name, owner ID, proof of address, DTI/SEC if available'],
                'Business Clearance Renewal' => ['fee' => 150, 'requirements' => 'Previous clearance, owner ID, updated business details'],
                'Temporary Activity Permit' => ['fee' => 100, 'requirements' => 'Activity details, organizer ID, venue and date information'],
            ],
        ],
        'service' => [
            'active' => 'services',
            'title' => 'Barangay Services',
            'subtitle' => 'Service catalog, assistance requests, tracking, staff messages, and completion.',
            'catalog' => [
                'General Assistance Request' => ['fee' => 0, 'requirements' => 'Resident profile and request details'],
                'Community Program Registration' => ['fee' => 0, 'requirements' => 'Program selected and eligibility details'],
                'Facility or Vehicle Assistance' => ['fee' => 0, 'requirements' => 'Purpose, schedule, and responsible person'],
                'Barangay Certification Assistance' => ['fee' => 0, 'requirements' => 'Reason and supporting details'],
            ],
        ],
    ];

    return $configs[$type] ?? $configs['document'];
}

function request_statuses(): array
{
    return ['Pending', 'Under Review', 'For Payment', 'For Approval', 'Processing', 'Ready for Release', 'Completed', 'Rejected', 'Returned for Correction', 'Cancelled', 'Archived'];
}

function render_request_workflow(string $type): void
{
    $config = request_type_config($type);
    require_roles(['resident', 'secretary', 'captain', 'staff', 'admin']);

    $user = current_user();
    $canProcess = role_allows(['secretary', 'captain', 'staff', 'admin']);
    $catalog = $config['catalog'];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['form_action'] ?? '';

        if ($action === 'create') {
            $selectedTitle = trim((string) ($_POST['title'] ?? ''));
            $customTitle = trim((string) ($_POST['custom_title'] ?? ''));
            $title = $customTitle !== '' ? $customTitle : $selectedTitle;
            $requester = trim((string) ($_POST['requester_name'] ?? ''));
            $details = trim((string) ($_POST['details'] ?? ''));
            $requirements = trim((string) ($_POST['requirements'] ?? ''));
            $fee = (float) ($_POST['fee'] ?? 0);

            if ($title === '' || $requester === '') {
                flash('error', 'Request title and requester name are required.');
                redirect(app_url($config['active'] . '.php?action=new'));
            }

            $reference = reference_no(substr($type, 0, 3));
            $qr = reference_no('QR');
            $stmt = db()->prepare('INSERT INTO request_records (type, reference_no, resident_id, requester_name, title, requirements, details, fee, status, qr_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute([
                $type,
                $reference,
                $user['resident_id'] ?? null,
                $requester,
                $title,
                $requirements,
                $details,
                $fee,
                'Pending',
                $qr,
            ]);
            $id = (int) db()->lastInsertId();
            audit_log('Create ' . $type . ' request', 'request_records', $id, $reference);
            notify_user(null, 'New ' . $type . ' request', $requester . ' submitted ' . $title . '.');
            flash('success', 'Request submitted with reference ' . $reference . '.');
            redirect(app_url($config['active'] . '.php'));
        }

        if ($action === 'status' && $canProcess) {
            $id = (int) ($_POST['id'] ?? 0);
            $status = (string) ($_POST['status'] ?? 'Pending');
            if (!in_array($status, request_statuses(), true)) {
                flash('error', 'Invalid status.');
                redirect(app_url($config['active'] . '.php'));
            }

            $documentNo = null;
            if (in_array($status, ['Processing', 'Ready for Release', 'Completed'], true)) {
                $documentNo = reference_no($type === 'permit' ? 'PERMIT' : ($type === 'service' ? 'SERV' : 'DOC'));
            }

            $sql = 'UPDATE request_records SET status = ?, remarks = ?, assigned_to = ?';
            $params = [$status, trim((string) ($_POST['remarks'] ?? '')), (int) $user['id']];
            if ($documentNo !== null) {
                $sql .= ', document_no = COALESCE(document_no, ?)';
                $params[] = $documentNo;
            }
            $sql .= ' WHERE id = ? AND type = ?';
            $params[] = $id;
            $params[] = $type;
            $stmt = db()->prepare($sql);
            $stmt->execute($params);

            if ($status === 'For Payment') {
                $rowStmt = db()->prepare('SELECT * FROM request_records WHERE id = ?');
                $rowStmt->execute([$id]);
                $row = $rowStmt->fetch();
                if ($row && (float) $row['fee'] > 0) {
                    $existsStmt = db()->prepare("SELECT id FROM payments WHERE request_id = ? AND status IN ('Pending','Paid') LIMIT 1");
                    $existsStmt->execute([$id]);
                    if (!$existsStmt->fetch()) {
                        $paymentStmt = db()->prepare('INSERT INTO payments (transaction_no, request_id, resident_id, purpose, amount, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)');
                        $paymentStmt->execute([reference_no('PAY'), $id, $row['resident_id'], $row['title'], $row['fee'], 'Pending', (int) $user['id']]);
                    }
                }
            }

            $notifyStmt = db()->prepare('SELECT resident_id, requester_name, reference_no FROM request_records WHERE id = ?');
            $notifyStmt->execute([$id]);
            $notifyRow = $notifyStmt->fetch();
            if ($notifyRow && !empty($notifyRow['resident_id'])) {
                $recipientStmt = db()->prepare('SELECT id FROM users WHERE resident_id = ? LIMIT 1');
                $recipientStmt->execute([(int) $notifyRow['resident_id']]);
                $recipientId = $recipientStmt->fetchColumn();
                if ($recipientId) {
                    notify_user((int) $recipientId, 'Request updated', $notifyRow['reference_no'] . ' is now ' . $status . '.');
                }
            }
            audit_log('Update ' . $type . ' request status', 'request_records', $id, $status);
            flash('success', 'Request status updated.');
            redirect(app_url($config['active'] . '.php'));
        }
    }

    render_header($config['title'], $config['active']);

    if (($_GET['action'] ?? '') === 'new') {
        $selected = (string) ($_GET['title'] ?? array_key_first($catalog));
        $defaults = $catalog[$selected] ?? ['fee' => 0, 'requirements' => ''];
        page_header('New ' . $config['title'] . ' Request', $config['subtitle'], '<a class="button ghost" href="' . e(app_url($config['active'] . '.php')) . '">Back</a>');
        ?>
        <form class="card" method="post">
            <input type="hidden" name="form_action" value="create">
            <div class="form-grid">
                <div class="field">
                    <label>Catalog item</label>
                    <select name="title" data-catalog-select>
                        <?php foreach ($catalog as $title => $item): ?>
                            <option value="<?= e($title) ?>" data-fee="<?= e((string) $item['fee']) ?>" data-requirements="<?= e($item['requirements']) ?>" <?= selected($selected, (string) $title) ?>><?= e($title) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="field">
                    <label>Custom title</label>
                    <input type="text" name="custom_title" placeholder="Optional">
                </div>
                <div class="field">
                    <label>Requester name</label>
                    <input type="text" name="requester_name" required value="<?= e($user['full_name'] ?? '') ?>">
                </div>
                <div class="field">
                    <label>Fee</label>
                    <input type="number" step="0.01" name="fee" value="<?= e((string) $defaults['fee']) ?>" data-catalog-fee>
                </div>
                <div class="field full">
                    <label>Requirements checklist</label>
                    <textarea name="requirements" data-catalog-requirements><?= e($defaults['requirements']) ?></textarea>
                </div>
                <div class="field full">
                    <label>Request details</label>
                    <textarea name="details" placeholder="Purpose, supporting notes, uploaded file names, or staff notes"></textarea>
                </div>
            </div>
            <div class="actions" style="margin-top: 16px;">
                <button class="button" type="submit">Submit request</button>
                <a class="button ghost" href="<?= e(app_url($config['active'] . '.php')) ?>">Cancel</a>
            </div>
        </form>
        <?php
        render_footer();
        return;
    }

    $where = ['type = ?'];
    $params = [$type];
    if (!$canProcess) {
        $where[] = '(resident_id = ? OR requester_name = ?)';
        $params[] = $user['resident_id'] ?? 0;
        $params[] = $user['full_name'];
    }
    $status = trim((string) ($_GET['status'] ?? ''));
    if ($status !== '') {
        $where[] = 'status = ?';
        $params[] = $status;
    }
    $q = trim((string) ($_GET['q'] ?? ''));
    if ($q !== '') {
        $where[] = '(reference_no LIKE ? OR requester_name LIKE ? OR title LIKE ? OR details LIKE ?)';
        $params[] = '%' . $q . '%';
        $params[] = '%' . $q . '%';
        $params[] = '%' . $q . '%';
        $params[] = '%' . $q . '%';
    }

    $stmt = db()->prepare('SELECT * FROM request_records WHERE ' . implode(' AND ', $where) . ' ORDER BY id DESC LIMIT 200');
    $stmt->execute($params);
    $requests = $stmt->fetchAll();

    page_header($config['title'], $config['subtitle'], '<a class="button" href="' . e(app_url($config['active'] . '.php?action=new')) . '">New request</a>');
    ?>
    <div class="grid cards-3" style="margin-bottom: 14px;">
        <div class="card metric"><span>Pending</span><strong><?= fetch_count('request_records', 'type = ? AND status = ?', [$type, 'Pending']) ?></strong></div>
        <div class="card metric"><span>For Approval</span><strong><?= fetch_count('request_records', 'type = ? AND status = ?', [$type, 'For Approval']) ?></strong></div>
        <div class="card metric"><span>Completed</span><strong><?= fetch_count('request_records', 'type = ? AND status = ?', [$type, 'Completed']) ?></strong></div>
    </div>

    <form class="inline-form" method="get">
        <input type="search" name="q" placeholder="Search requests" value="<?= e($q) ?>">
        <select name="status">
            <option value="">All statuses</option>
            <?php foreach (request_statuses() as $option): ?>
                <option value="<?= e($option) ?>" <?= selected($status, $option) ?>><?= e($option) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="button ghost" type="submit">Filter</button>
    </form>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Reference</th>
                    <th>Requester</th>
                    <th>Title</th>
                    <th>Fee</th>
                    <th>Status</th>
                    <th>Document/QR</th>
                    <th>Next action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$requests): ?>
                    <tr><td colspan="7" class="empty-state">No requests found.</td></tr>
                <?php endif; ?>
                <?php foreach ($requests as $row): ?>
                    <tr>
                        <td><strong><?= e($row['reference_no']) ?></strong><br><span class="muted"><?= e($row['created_at']) ?></span></td>
                        <td><?= e($row['requester_name']) ?></td>
                        <td>
                            <strong><?= e($row['title']) ?></strong>
                            <p class="muted"><?= e($row['requirements']) ?></p>
                        </td>
                        <td>PHP <?= number_format((float) $row['fee'], 2) ?></td>
                        <td><?= status_chip($row['status']) ?></td>
                        <td>
                            <?= e($row['document_no'] ?: 'Not generated') ?><br>
                            <span class="muted"><?= e($row['qr_code'] ?: '') ?></span>
                        </td>
                        <td>
                            <?php if ($canProcess): ?>
                                <form method="post" class="stacked-form">
                                    <input type="hidden" name="form_action" value="status">
                                    <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                                    <select name="status">
                                        <?php foreach (request_statuses() as $option): ?>
                                            <option value="<?= e($option) ?>" <?= selected($row['status'], $option) ?>><?= e($option) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <input type="text" name="remarks" placeholder="Remarks" value="<?= e($row['remarks']) ?>">
                                    <button class="button secondary" type="submit">Update</button>
                                </form>
                            <?php else: ?>
                                <ul class="timeline">
                                    <?php foreach (['Submitted', $row['status'], 'Notification and audit'] as $step): ?>
                                        <li><span class="dot"></span><span><?= e($step) ?></span></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
    render_footer();
}
