<?php

declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/functions.php';

function require_login(): void
{
    if (!current_user()) {
        redirect(app_url('login.php'));
    }
}

function require_roles(array $roles): void
{
    require_login();
    if (!role_allows($roles)) {
        http_response_code(403);
        require __DIR__ . '/../partials/forbidden.php';
        exit;
    }
}

function login_attempt(string $email, string $password): bool
{
    $stmt = db()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        audit_log('Failed login', 'users', null, $email);
        return false;
    }

    if ($user['status'] === 'inactive') {
        return false;
    }

    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $user['id'];
    audit_log('Login', 'users', (int) $user['id'], $user['email']);

    return true;
}

function logout_user(): void
{
    audit_log('Logout', 'users', (int) ($_SESSION['user_id'] ?? 0));
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], (bool) $params['secure'], (bool) $params['httponly']);
    }
    session_destroy();
}
