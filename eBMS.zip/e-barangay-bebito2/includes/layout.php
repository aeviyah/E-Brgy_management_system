<?php

declare(strict_types=1);

require_once __DIR__ . '/navigation.php';

function render_header(string $title, string $active = ''): void
{
    $user = current_user();
    $barangay = setting('barangay_name', 'E-Barangay');
    ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title) ?> | <?= e($barangay) ?></title>
    <link rel="icon" href="<?= e(app_url('assets/img/logo.svg')) ?>">
    <link rel="stylesheet" href="<?= e(app_url('assets/css/style.css')) ?>">
</head>
<body>
<div class="app-shell">
    <aside class="sidebar" id="sidebar">
        <div class="brand">
            <img class="brand-logo" src="<?= e(app_url('assets/img/logo.svg')) ?>" alt="Barangay seal">
            <div>
                <strong><?= e($barangay) ?></strong>
                <small>Lopez, Quezon · E-Barangay</small>
            </div>
        </div>
        <nav class="nav-list">
            <?php foreach (navigation_items() as $item): ?>
                <?php if ($user && in_array($user['role'], $item['roles'], true)): ?>
                    <a class="<?= $active === $item['key'] ? 'active' : '' ?>" href="<?= e(app_url($item['href'])) ?>">
                        <span><?= e($item['label']) ?></span>
                    </a>
                <?php endif; ?>
            <?php endforeach; ?>
            <a class="<?= $active === 'public' ? 'active' : '' ?>" href="<?= e(app_url('public_portal.php')) ?>">
                <span>🌐 Public Portal</span>
            </a>
            <a class="<?= $active === 'locked' ? 'active' : '' ?>" href="<?= e(app_url('locked.php')) ?>">
                <span>🔒 Future Modules</span>
            </a>
        </nav>
    </aside>

    <main class="main">
        <header class="topbar">
            <button class="icon-button" type="button" data-sidebar-toggle aria-label="Toggle navigation">☰</button>
            <form class="top-search" action="<?= e(app_url('search.php')) ?>" method="get">
                <input type="search" name="q" placeholder="Search residents, requests, payments, cases" value="<?= e($_GET['q'] ?? '') ?>">
            </form>
            <div class="top-actions">
                <?php if ($user): ?>
                    <a class="notification-link" href="<?= e(app_url('notifications.php')) ?>">
                        Notifications
                        <?php
                        $unread = fetch_count('notifications', '(user_id = ? OR user_id IS NULL) AND status = ?', [(int) $user['id'], 'Unread']);
                        if ($unread > 0): ?>
                            <span class="badge"><?= $unread ?></span>
                        <?php endif; ?>
                    </a>
                    <div class="profile-chip">
                        <strong><?= e($user['full_name']) ?></strong>
                        <small><?= e(role_label($user['role'])) ?></small>
                    </div>
                    <a class="button ghost" href="<?= e(app_url('logout.php')) ?>">Logout</a>
                <?php else: ?>
                    <a class="button ghost" href="<?= e(app_url('login.php')) ?>">Login</a>
                <?php endif; ?>
            </div>
        </header>
        <section class="content">
            <?php if ($message = flash('success')): ?>
                <div class="alert success"><?= e($message) ?></div>
            <?php endif; ?>
            <?php if ($message = flash('error')): ?>
                <div class="alert error"><?= e($message) ?></div>
            <?php endif; ?>
    <?php
}

function render_footer(): void
{
    ?>
        </section>
    </main>
</div>
<script src="<?= e(app_url('assets/js/app.js')) ?>"></script>
</body>
</html>
    <?php
}

function page_header(string $title, string $subtitle = '', string $actionHtml = ''): void
{
    ?>
    <div class="page-header">
        <div>
            <p class="eyebrow">Barangay Bebito · Lopez, Quezon</p>
            <h1><?= e($title) ?></h1>
            <?php if ($subtitle !== ''): ?>
                <p><?= e($subtitle) ?></p>
            <?php endif; ?>
        </div>
        <?php if ($actionHtml !== ''): ?>
            <div class="page-actions"><?= $actionHtml ?></div>
        <?php endif; ?>
    </div>
    <?php
}

function status_chip(string $status): string
{
    return '<span class="status-chip ' . e(status_class($status)) . '">' . e($status) . '</span>';
}

function locked_module_cards(): void
{
    ?>
    <div class="grid cards-4">
        <?php foreach (locked_modules() as $module): ?>
            <article class="card muted-card">
                <div class="lock-label">Locked Future Module</div>
                <h3><?= e($module['label']) ?></h3>
                <p><?= e($module['description']) ?></p>
            </article>
        <?php endforeach; ?>
    </div>
    <?php
}
