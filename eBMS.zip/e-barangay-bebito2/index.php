<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
if (current_user()) { redirect(app_url('dashboard.php')); }
redirect(app_url('public_portal.php'));
