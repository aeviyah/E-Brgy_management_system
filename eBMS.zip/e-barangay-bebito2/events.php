<?php
$moduleKey = 'events';
require __DIR__ . '/module.php';
