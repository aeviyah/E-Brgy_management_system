<?php
// ORDINANCES & RESOLUTIONS (official records)
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'ordinances', 'title' => 'Ordinances & Resolutions', 'singular' => 'Official Document', 'table' => 'ordinances',
    'ref' => 'doc_number', 'order' => 't.doc_date DESC', 'archive' => ['value' => 'Archived', 'restore' => 'Active'], 'date_filter' => 'doc_date',
    'search' => ['t.doc_number', 't.title', 't.description'],
    'fields' => [
        'doc_type'    => ['label' => 'Type', 'type' => 'select', 'required' => true, 'filter' => true, 'options' => opts(['Ordinance', 'Resolution', 'Memorandum', 'Official Document'])],
        'doc_number'  => ['label' => 'Document Number', 'required' => true, 'unique' => true, 'max' => 40],
        'title'       => ['label' => 'Title / Subject', 'required' => true, 'max' => 200, 'full' => true],
        'doc_date'    => ['label' => 'Date', 'type' => 'date', 'required' => true],
        'is_public'   => ['label' => 'Show on Public Portal', 'type' => 'select', 'required' => true, 'default' => 'Yes', 'options' => opts(['Yes', 'No'])],
        'description' => ['label' => 'Description', 'type' => 'textarea'],
        'attachment'  => ['label' => 'Attachment (PDF/JPG/PNG)', 'type' => 'file'],
        'status'      => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Active', 'options' => opts(['Draft', 'Active'])],
        'created_by'  => ['label' => 'Created By', 'type' => 'select', 'sql' => "SELECT id, full_name FROM users", 'form' => false],
    ],
    'before_save' => function (&$data, $id) { if (!$id) $data['created_by'] = $GLOBALS['CURRENT_USER']['id']; },
    'columns' => ['doc_number', 'doc_type', 'title', 'doc_date', 'is_public', 'status'],
];
crud_run($cfg);
