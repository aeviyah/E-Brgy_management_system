-- E-BARANGAY SAMPLE DATA. Import AFTER schema.sql.
USE e_barangay;
SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO settings (setting_key, setting_value) VALUES
('barangay_name', 'Barangay Bebito'),
('municipality', 'Lopez'),
('province', 'Quezon'),
('address', 'Barangay Hall, Barangay Bebito, Lopez, Quezon'),
('contact_no', '(042) 555-0100'),
('email', 'barangay.bebito@example.com'),
('office_hours', 'Monday - Friday, 8:00 AM - 5:00 PM'),
('about', 'Barangay Bebito is a community in the Municipality of Lopez, Province of Quezon. This system helps residents request documents and services online and helps barangay officials manage records.'),
('emergency_contacts', 'Barangay Hall - (042) 555-0100\nBarangay Tanod Hotline - 0917 000 0001\nPolice Station - (042) 555-0911\nFire Station - (042) 555-0160\nRural Health Unit - (042) 555-0122');

INSERT INTO puroks (id, name, leader, assigned_area, description, status) VALUES
(1, 'Purok 1 - Sampaguita', 'Roberto Dela Cruz', 'North side near the chapel', 'Residential area', 'Active'),
(2, 'Purok 2 - Rosal', 'Maria Santos', 'Along the main road', 'Commercial and residential', 'Active'),
(3, 'Purok 3 - Ilang-Ilang', 'Eduardo Reyes', 'East side near the school', 'Residential area', 'Active'),
(4, 'Purok 4 - Camia', 'Lorna Garcia', 'South side near the river', 'Residential area', 'Active'),
(5, 'Purok 5 - Dahlia', 'Ramon Bautista', 'West side near the court', 'Residential area', 'Active');

INSERT INTO households (id, household_no, head_resident_id, address, purok_id, classification, income_bracket, housing_type, has_electricity, water_source, toilet_facility, status) VALUES
(1, 'HH-2026-0001', NULL, '12 Sampaguita St.', 1, 'Regular', '10,000 - 20,000', 'Owned', 'Yes', 'Piped Water', 'Water-sealed', 'Active'),
(2, 'HH-2026-0002', NULL, '45 Rosal St.', 2, '4Ps Beneficiary', 'Below 10,000', 'Rented', 'Yes', 'Piped Water', 'Water-sealed', 'Active'),
(3, 'HH-2026-0003', NULL, '7 Ilang-Ilang Ave.', 3, 'Senior-headed', 'Below 10,000', 'Owned', 'Yes', 'Deep Well', 'Water-sealed', 'Active'),
(4, 'HH-2026-0004', NULL, '88 Camia Lane', 4, 'Indigent', 'Below 10,000', 'Informal Settler', 'No', 'Spring', 'Pit Latrine', 'Active'),
(5, 'HH-2026-0005', NULL, '3 Dahlia Rd.', 5, 'Regular', '20,001 - 40,000', 'Owned', 'Yes', 'Piped Water', 'Water-sealed', 'Active');

INSERT INTO residents (id, resident_no, first_name, middle_name, last_name, birthdate, sex, civil_status, contact_no, email, address, purok_id, household_id, occupation, residency_status, is_senior, is_pwd, is_solo_parent, is_4ps, status) VALUES
(1, 'RES-2026-0001', 'Juan', 'Santos', 'Dela Cruz', '1985-03-14', 'Male', 'Married', '09171230001', 'juan.delacruz@example.com', '12 Sampaguita St.', 1, 1, 'Electrician', 'Permanent', 0, 0, 0, 0, 'Active'),
(2, 'RES-2026-0002', 'Maria', 'Lopez', 'Dela Cruz', '1987-07-22', 'Female', 'Married', '09171230002', 'maria.delacruz@example.com', '12 Sampaguita St.', 1, 1, 'Teacher', 'Permanent', 0, 0, 0, 0, 'Active'),
(3, 'RES-2026-0003', 'Pedro', NULL, 'Dela Cruz', '2012-11-02', 'Male', 'Single', NULL, NULL, '12 Sampaguita St.', 1, 1, 'Student', 'Permanent', 0, 0, 0, 0, 'Active'),
(4, 'RES-2026-0004', 'Ana', 'Cruz', 'Santos', '1992-01-30', 'Female', 'Single', '09171230004', 'ana.santos@example.com', '45 Rosal St.', 2, 2, 'Vendor', 'Permanent', 0, 0, 1, 1, 'Active'),
(5, 'RES-2026-0005', 'Liza', 'Ramos', 'Santos', '2016-05-18', 'Female', 'Single', NULL, NULL, '45 Rosal St.', 2, 2, 'Student', 'Permanent', 0, 0, 0, 1, 'Active'),
(6, 'RES-2026-0006', 'Lolo', 'Mendoza', 'Reyes', '1953-09-09', 'Male', 'Widowed', '09171230006', NULL, '7 Ilang-Ilang Ave.', 3, 3, 'Retired', 'Permanent', 1, 0, 0, 0, 'Active'),
(7, 'RES-2026-0007', 'Rosa', 'Aquino', 'Reyes', '1978-12-05', 'Female', 'Married', '09171230007', 'rosa.reyes@example.com', '7 Ilang-Ilang Ave.', 3, 3, 'Store Owner', 'Permanent', 0, 0, 0, 0, 'Active'),
(8, 'RES-2026-0008', 'Mario', NULL, 'Garcia', '1990-04-11', 'Male', 'Single', '09171230008', NULL, '88 Camia Lane', 4, 4, 'Construction Worker', 'Temporary', 0, 1, 0, 0, 'Active'),
(9, 'RES-2026-0009', 'Carla', 'Villanueva', 'Bautista', '1995-08-25', 'Female', 'Single', '09171230009', 'carla.bautista@example.com', '3 Dahlia Rd.', 5, 5, 'Nurse', 'Permanent', 0, 0, 0, 0, 'Active'),
(10, 'RES-2026-0010', 'Jose', 'Tan', 'Bautista', '1960-02-02', 'Male', 'Married', '09171230010', NULL, '3 Dahlia Rd.', 5, 5, 'Farmer', 'Permanent', 1, 0, 0, 0, 'Active'),
(11, 'RES-2026-0011', 'Kevin', NULL, 'Ramirez', '1999-06-06', 'Male', 'Single', '09171230011', 'kevin.ramirez@example.com', '21 Rosal St.', 2, NULL, 'Student', 'Permanent', 0, 0, 0, 0, 'Pending Verification');

UPDATE households SET head_resident_id = 1 WHERE id = 1;
UPDATE households SET head_resident_id = 4 WHERE id = 2;
UPDATE households SET head_resident_id = 6 WHERE id = 3;
UPDATE households SET head_resident_id = 8 WHERE id = 4;
UPDATE households SET head_resident_id = 10 WHERE id = 5;

INSERT INTO users (id, username, password_hash, full_name, email, contact_no, role, resident_id, assigned_modules, status) VALUES
(1, 'admin', '$2y$10$MiPw/fL6DQGYFFGcwJcfX..kWojVCB14v2zSdBBgG/7KI1tjX1g6i', 'System Administrator', 'admin@example.com', NULL, 'admin', NULL, NULL, 'Active'),
(2, 'secretary', '$2y$10$ewnZpDsjnrzn8wwJssUFl.Jis47LaCMsRa5hHi4b.rTE45x87ji.a', 'Elena Marquez', 'secretary@example.com', '09180000002', 'secretary', NULL, NULL, 'Active'),
(3, 'treasurer', '$2y$10$tCfhU7CxlLJJmYqX.uY6SuFmIFpnm.SSUrlU47BIQuV4oNiqsQLQG', 'Ricardo Flores', 'treasurer@example.com', '09180000003', 'treasurer', NULL, NULL, 'Active'),
(4, 'captain', '$2y$10$2Sc81x7AWWSukvzOVchCieDo0GivqXQ8Pnns4vqw/52n0eM/wG0rS', 'Hon. Antonio Villareal', 'captain@example.com', '09180000004', 'captain', NULL, NULL, 'Active'),
(5, 'staff', '$2y$10$cwUbk4fAFYmC97jbgilMl.Lp1FNiEfS1QiwQrub/yXrJs60jhIxdS', 'Nina Castillo', 'staff@example.com', '09180000005', 'staff', NULL, 'peace_order,environment,assets', 'Active'),
(6, 'juan', '$2y$10$aLTD18q.0n/S6IrttFqNjed7BjefjU29x04EsWK0TFLJRRakPH2Je', 'Juan Dela Cruz', 'juan.delacruz@example.com', '09171230001', 'resident', 1, NULL, 'Active'),
(7, 'ana', '$2y$10$aLTD18q.0n/S6IrttFqNjed7BjefjU29x04EsWK0TFLJRRakPH2Je', 'Ana Santos', 'ana.santos@example.com', '09171230004', 'resident', 4, NULL, 'Active'),
(8, 'kevin', '$2y$10$aLTD18q.0n/S6IrttFqNjed7BjefjU29x04EsWK0TFLJRRakPH2Je', 'Kevin Ramirez', 'kevin.ramirez@example.com', '09171230011', 'resident', 11, NULL, 'Active');

INSERT INTO documents (id, name, description, requirements, fee, processing_days, body_text, status) VALUES
(1, 'Barangay Clearance', 'General clearance for employment, school, and other purposes', 'Valid ID (photocopy)\nProof of residency', 50.00, 1, 'This is to certify that {name}, {age} years old, {civil_status}, is a bonafide resident of {address}, {purok}, and has no derogatory record on file in this barangay as of this date. This clearance is issued upon request for {purpose}.', 'Active'),
(2, 'Certificate of Residency', 'Proof that the person lives in the barangay', 'Valid ID (photocopy)', 30.00, 1, 'This is to certify that {name}, {age} years old, {civil_status}, is a resident of {address}, {purok}. This certification is issued upon request for {purpose}.', 'Active'),
(3, 'Certificate of Indigency', 'For residents with low income who need assistance', 'Valid ID (photocopy)\nProof of income or letter of request', 0.00, 1, 'This is to certify that {name}, {age} years old, {civil_status}, residing at {address}, {purok}, belongs to an indigent family in this barangay. Issued upon request for {purpose}.', 'Active'),
(4, 'Certificate of Good Moral Character', 'Character certification', 'Valid ID (photocopy)', 50.00, 2, 'This is to certify that {name}, {age} years old, of {address}, {purok}, is a person of good moral character and a law-abiding resident. Issued for {purpose}.', 'Active'),
(5, 'Certificate of Low Income', 'Certifies household income is low', 'Valid ID (photocopy)\nProof of income (if any)', 0.00, 2, 'This is to certify that {name} of {address}, {purok}, belongs to a low-income household. Issued for {purpose}.', 'Active'),
(6, 'Certificate of No Property', 'Certifies no registered property in the barangay', 'Valid ID (photocopy)', 50.00, 2, 'This is to certify that {name} of {address}, {purok}, has no real property registered in the records of this barangay. Issued for {purpose}.', 'Active');

INSERT INTO services (id, name, category, description, requirements, status) VALUES
(1, 'Barangay Assistance', 'Assistance', 'Request for medical, burial, or emergency assistance', 'Valid ID\nSupporting document (medical abstract, death certificate, etc.)', 'Active'),
(2, 'Facility Request', 'Facility', 'Request for the use of barangay facilities (see Facilities > Reservations for scheduled bookings)', 'Letter of request', 'Active'),
(3, 'Vehicle Request', 'Vehicle', 'Request to use the barangay vehicle for emergencies or official use', 'Letter of request\nDriver details', 'Active'),
(4, 'Community Program Registration', 'Community Program', 'Register for barangay programs and trainings', 'Valid ID', 'Active'),
(5, 'Other Barangay Service', 'Other', 'Any other service not listed', 'Letter of request', 'Active');

INSERT INTO fees (id, fee_type, purpose, amount, status) VALUES
(1, 'Barangay Clearance Fee', 'Clearance for employment/school', 50.00, 'Active'),
(2, 'Certification Fee', 'Residency / good moral / no property', 30.00, 'Active'),
(3, 'Business Clearance Fee', 'Barangay business clearance', 300.00, 'Active'),
(4, 'Facility Rental - Covered Court', 'Per use of the covered court', 500.00, 'Active');

INSERT INTO officials (id, full_name, position, contact_no, term_start, term_end, status) VALUES
(1, 'Hon. Antonio Villareal', 'Punong Barangay', '09180000004', '2023-11-01', '2026-10-31', 'Active'),
(2, 'Hon. Gloria Mendez', 'Barangay Kagawad', '09180000011', '2023-11-01', '2026-10-31', 'Active'),
(3, 'Hon. Ernesto Alvarez', 'Barangay Kagawad', '09180000012', '2023-11-01', '2026-10-31', 'Active'),
(4, 'Hon. Teresita Cruz', 'Barangay Kagawad', '09180000013', '2023-11-01', '2026-10-31', 'Active'),
(5, 'Elena Marquez', 'Barangay Secretary', '09180000002', '2023-11-01', '2026-10-31', 'Active'),
(6, 'Ricardo Flores', 'Barangay Treasurer', '09180000003', '2023-11-01', '2026-10-31', 'Active');

INSERT INTO tanods (id, name, contact_no, position, assigned_area, status) VALUES
(1, 'Bernardo Salazar', '09190000001', 'Chief Tanod', 'Purok 1 and 2', 'Active'),
(2, 'Ramil Torres', '09190000002', 'Tanod', 'Purok 3', 'Active'),
(3, 'Dante Navarro', '09190000003', 'Tanod', 'Purok 4 and 5', 'Active');

INSERT INTO message_templates (id, name, channel, subject, body, status) VALUES
(1, 'Request Approved', 'Both', 'Request Approved', 'Your request has been approved. Please check your account for details.', 'Active'),
(2, 'Payment Confirmation', 'Both', 'Payment Confirmation', 'Your payment was received. Thank you.', 'Active'),
(3, 'Important Announcement', 'Both', 'Barangay Announcement', 'Please read the latest barangay announcement on the portal.', 'Active');

INSERT INTO announcements (id, title, content, audience, status, date_posted, created_by) VALUES
(1, 'Barangay Clean-up Drive', 'All residents are invited to join the monthly clean-up drive this Saturday, 7:00 AM at the Barangay Hall. Bring gloves and trash bags.', 'Public', 'Published', CURDATE(), 2),
(2, 'Office Hours Reminder', 'The barangay hall is open Monday to Friday, 8:00 AM to 5:00 PM. Online requests are processed during office hours.', 'Public', 'Published', CURDATE(), 2),
(3, 'Draft: Vaccination Schedule', 'Schedule will be announced soon.', 'Residents Only', 'Draft', NULL, 2);

INSERT INTO events (id, name, event_date, event_time, location, description, organizer, allow_registration, status) VALUES
(1, 'Barangay Clean-up Drive', DATE_ADD(CURDATE(), INTERVAL 5 DAY), '07:00:00', 'Barangay Hall', 'Monthly clean-up of the barangay streets.', 'Barangay Council', 'Yes', 'Published'),
(2, 'Free Medical Mission', DATE_ADD(CURDATE(), INTERVAL 14 DAY), '08:00:00', 'Covered Court', 'Free check-ups for residents.', 'Barangay Health Volunteers', 'Yes', 'Published');

INSERT INTO facilities (id, name, facility_type, capacity, description, status) VALUES
(1, 'Covered Court', 'Court', 300, 'Basketball and multi-purpose court', 'Available'),
(2, 'Barangay Hall Function Room', 'Hall', 60, 'Air-conditioned function room', 'Available'),
(3, 'Chairs and Tables Set', 'Equipment', 100, 'Monobloc chairs and folding tables', 'Available');

INSERT INTO assets (id, asset_code, name, category, quantity, condition_status, location, assigned_to, acquisition_date, status) VALUES
(1, 'AST-0001', 'Desktop Computer', 'Computer', 2, 'Good', 'Secretary Office', 'Elena Marquez', '2024-02-10', 'Active'),
(2, 'AST-0002', 'Printer', 'Printer', 1, 'Fair', 'Secretary Office', 'Elena Marquez', '2023-06-15', 'Active'),
(3, 'AST-0003', 'Barangay Service Vehicle', 'Vehicle', 1, 'Good', 'Motor Pool', 'Bernardo Salazar', '2022-01-20', 'Active');

INSERT INTO projects (id, name, description, proposal, budget, beneficiaries, start_date, end_date, status, progress) VALUES
(1, 'Drainage Improvement - Purok 4', 'Concrete canal along Camia Lane to prevent flooding.', 'Approved by the council.', 250000.00, 'Purok 4 residents', DATE_SUB(CURDATE(), INTERVAL 20 DAY), DATE_ADD(CURDATE(), INTERVAL 40 DAY), 'Ongoing', 45),
(2, 'Solar Street Lights', 'Install 10 solar street lights.', 'Waiting for budget approval.', 180000.00, 'All puroks', NULL, NULL, 'Proposed', 0);

INSERT INTO assistance_programs (id, program_name, assistance_type, eligibility, amount_item, start_date, end_date, status) VALUES
(1, 'Food Pack Distribution', 'Food Assistance', 'Indigent and 4Ps households', '1 food pack per household', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), 'Active');

INSERT INTO ordinances (id, doc_type, doc_number, title, doc_date, description, is_public, status, created_by) VALUES
(1, 'Ordinance', 'ORD-2026-001', 'Barangay Ordinance on Proper Waste Segregation', '2026-02-01', 'Requires households to segregate waste into biodegradable and non-biodegradable.', 'Yes', 'Active', 2),
(2, 'Resolution', 'RES-2026-001', 'Resolution Approving the 2026 Annual Budget', '2026-01-15', 'Approves the annual budget of the barangay.', 'Yes', 'Active', 2);

INSERT INTO budgets (id, budget_year, category, allocation, amount, status) VALUES
(1, YEAR(CURDATE()), 'Infrastructure', 'Drainage and street lights', 500000.00, 'Approved'),
(2, YEAR(CURDATE()), 'Social Services', 'Assistance programs', 200000.00, 'Approved'),
(3, YEAR(CURDATE()), 'Administration', 'Office supplies and utilities', 150000.00, 'Approved');

-- A few real transactions so the dashboard and reports are not empty
INSERT INTO document_requests (id, request_no, resident_id, document_id, purpose, status, fee_amount, payment_status, remarks, document_no, verification_code, issued_date) VALUES
(1, CONCAT('DR-', YEAR(CURDATE()), '-0001'), 1, 1, 'Employment', 'Completed', 50.00, 'Paid', NULL, CONCAT('CERT-', YEAR(CURDATE()), '-0001'), 'A1B2C3D4E5F6', CURDATE()),
(2, CONCAT('DR-', YEAR(CURDATE()), '-0002'), 4, 2, 'School requirement', 'For Payment', 30.00, 'Unpaid', NULL, NULL, NULL, NULL),
(3, CONCAT('DR-', YEAR(CURDATE()), '-0003'), 7, 3, 'Medical assistance', 'Pending', 0.00, 'Not Required', NULL, NULL, NULL, NULL);
INSERT INTO status_history (ref_table, ref_id, status, remarks, user_id) VALUES
('document_requests', 1, 'Pending', 'Record created', 6), ('document_requests', 1, 'Completed', 'Release / Mark Completed', 2),
('document_requests', 2, 'Pending', 'Record created', 7), ('document_requests', 2, 'For Payment', 'Approve', 2),
('document_requests', 3, 'Pending', 'Record created', 2);
INSERT INTO payments (id, transaction_id, resident_id, fee_id, purpose, amount, payment_date, payment_method, ref_type, ref_id, status, received_by) VALUES
(1, CONCAT('TXN-', YEAR(CURDATE()), '-0001'), 1, 1, CONCAT('Document fee - DR-', YEAR(CURDATE()), '-0001'), 50.00, CURDATE(), 'Cash', 'document_request', 1, 'Paid', 3);
INSERT INTO official_receipts (or_number, payment_id, resident_id, purpose, amount, issue_date, payment_method, treasurer_id, status) VALUES
(CONCAT('OR-', YEAR(CURDATE()), '-0001'), 1, 1, CONCAT('Document fee - DR-', YEAR(CURDATE()), '-0001'), 50.00, CURDATE(), 'Cash', 3, 'Issued');

SET FOREIGN_KEY_CHECKS = 1;
