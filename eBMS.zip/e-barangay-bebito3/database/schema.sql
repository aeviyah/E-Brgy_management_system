-- E-BARANGAY MANAGEMENT SYSTEM - DATABASE SCHEMA
-- Step 1: import this file in phpMyAdmin (Import tab). Step 2: import seed.sql
CREATE DATABASE IF NOT EXISTS e_barangay CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE e_barangay;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(120) NULL,
  contact_no VARCHAR(30) NULL,
  role VARCHAR(20) NOT NULL,                -- admin, secretary, treasurer, captain, staff, resident
  resident_id INT NULL,
  assigned_modules VARCHAR(255) NULL,       -- for staff: comma-separated module keys
  status VARCHAR(20) NOT NULL DEFAULT 'Active',
  last_login DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(60) NOT NULL UNIQUE,
  setting_value TEXT NULL
) ENGINE=InnoDB;

CREATE TABLE puroks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL UNIQUE,
  leader VARCHAR(120) NULL,
  assigned_area VARCHAR(150) NULL,
  description TEXT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB;

CREATE TABLE households (
  id INT AUTO_INCREMENT PRIMARY KEY,
  household_no VARCHAR(30) NOT NULL UNIQUE,
  head_resident_id INT NULL,
  address VARCHAR(200) NOT NULL,
  purok_id INT NOT NULL,
  classification VARCHAR(40) NULL,
  income_bracket VARCHAR(40) NULL,
  housing_type VARCHAR(30) NULL,
  has_electricity VARCHAR(5) NULL,
  water_source VARCHAR(40) NULL,
  toilet_facility VARCHAR(40) NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (purok_id) REFERENCES puroks(id)
) ENGINE=InnoDB;

CREATE TABLE residents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  resident_no VARCHAR(30) NOT NULL UNIQUE,
  first_name VARCHAR(60) NOT NULL,
  middle_name VARCHAR(60) NULL,
  last_name VARCHAR(60) NOT NULL,
  birthdate DATE NOT NULL,
  sex VARCHAR(10) NOT NULL,
  civil_status VARCHAR(20) NOT NULL,
  contact_no VARCHAR(30) NULL,
  email VARCHAR(120) NULL,
  address VARCHAR(200) NOT NULL,
  purok_id INT NOT NULL,
  household_id INT NULL,
  occupation VARCHAR(80) NULL,
  residency_status VARCHAR(20) NOT NULL DEFAULT 'Permanent',
  is_senior TINYINT(1) NOT NULL DEFAULT 0,
  is_pwd TINYINT(1) NOT NULL DEFAULT 0,
  is_solo_parent TINYINT(1) NOT NULL DEFAULT 0,
  is_4ps TINYINT(1) NOT NULL DEFAULT 0,
  status VARCHAR(30) NOT NULL DEFAULT 'Pending Verification',
  remarks VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (purok_id) REFERENCES puroks(id),
  FOREIGN KEY (household_id) REFERENCES households(id)
) ENGINE=InnoDB;

ALTER TABLE households ADD FOREIGN KEY (head_resident_id) REFERENCES residents(id);
ALTER TABLE users ADD FOREIGN KEY (resident_id) REFERENCES residents(id);

CREATE TABLE status_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ref_table VARCHAR(40) NOT NULL,
  ref_id INT NOT NULL,
  status VARCHAR(40) NOT NULL,
  remarks VARCHAR(255) NULL,
  user_id INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (ref_table, ref_id)
) ENGINE=InnoDB;

CREATE TABLE documents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  description VARCHAR(255) NULL,
  requirements TEXT NULL,
  fee DECIMAL(10,2) NOT NULL DEFAULT 0,
  processing_days INT NOT NULL DEFAULT 1,
  body_text TEXT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB;

CREATE TABLE document_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  request_no VARCHAR(30) NOT NULL UNIQUE,
  resident_id INT NOT NULL,
  document_id INT NOT NULL,
  purpose VARCHAR(255) NOT NULL,
  requirements_file VARCHAR(255) NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'Pending',
  fee_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  payment_status VARCHAR(20) NOT NULL DEFAULT 'Not Required',
  remarks VARCHAR(255) NULL,
  document_no VARCHAR(40) NULL,
  verification_code VARCHAR(40) NULL UNIQUE,
  issued_date DATE NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (resident_id) REFERENCES residents(id),
  FOREIGN KEY (document_id) REFERENCES documents(id)
) ENGINE=InnoDB;

CREATE TABLE permits (
  id INT AUTO_INCREMENT PRIMARY KEY,
  permit_no VARCHAR(30) NOT NULL UNIQUE,
  resident_id INT NOT NULL,
  business_name VARCHAR(120) NOT NULL,
  business_type VARCHAR(80) NOT NULL,
  business_address VARCHAR(200) NOT NULL,
  date_applied DATE NOT NULL,
  requirements_file VARCHAR(255) NULL,
  fee DECIMAL(10,2) NOT NULL DEFAULT 0,
  status VARCHAR(30) NOT NULL DEFAULT 'Applied',
  remarks VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (resident_id) REFERENCES residents(id)
) ENGINE=InnoDB;

CREATE TABLE services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  category VARCHAR(60) NULL,
  description VARCHAR(255) NULL,
  requirements TEXT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB;

CREATE TABLE service_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  request_no VARCHAR(30) NOT NULL UNIQUE,
  resident_id INT NOT NULL,
  service_id INT NOT NULL,
  details TEXT NOT NULL,
  attachment VARCHAR(255) NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'Pending',
  remarks VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (resident_id) REFERENCES residents(id),
  FOREIGN KEY (service_id) REFERENCES services(id)
) ENGINE=InnoDB;

CREATE TABLE fees (
  id INT AUTO_INCREMENT PRIMARY KEY,
  fee_type VARCHAR(80) NOT NULL UNIQUE,
  purpose VARCHAR(200) NULL,
  amount DECIMAL(10,2) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB;

CREATE TABLE payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  transaction_id VARCHAR(30) NOT NULL UNIQUE,
  resident_id INT NOT NULL,
  fee_id INT NULL,
  purpose VARCHAR(200) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  payment_date DATE NOT NULL,
  payment_method VARCHAR(20) NOT NULL DEFAULT 'Cash',
  ref_type VARCHAR(30) NULL,
  ref_id INT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Paid',
  received_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (resident_id) REFERENCES residents(id),
  FOREIGN KEY (fee_id) REFERENCES fees(id)
) ENGINE=InnoDB;

CREATE TABLE official_receipts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  or_number VARCHAR(30) NOT NULL UNIQUE,
  payment_id INT NOT NULL UNIQUE,
  resident_id INT NOT NULL,
  purpose VARCHAR(200) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  issue_date DATE NOT NULL,
  payment_method VARCHAR(20) NOT NULL,
  treasurer_id INT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Issued',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (payment_id) REFERENCES payments(id),
  FOREIGN KEY (resident_id) REFERENCES residents(id)
) ENGINE=InnoDB;

CREATE TABLE complaints (
  id INT AUTO_INCREMENT PRIMARY KEY,
  case_no VARCHAR(30) NOT NULL UNIQUE,
  complainant_id INT NULL,
  complainant_name VARCHAR(120) NULL,
  respondent_name VARCHAR(120) NOT NULL,
  incident_type VARCHAR(60) NOT NULL,
  incident_date DATE NOT NULL,
  incident_time TIME NULL,
  location VARCHAR(150) NOT NULL,
  description TEXT NOT NULL,
  assigned_to INT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'Filed',
  remarks VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (complainant_id) REFERENCES residents(id),
  FOREIGN KEY (assigned_to) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE katarungan_cases (
  id INT AUTO_INCREMENT PRIMARY KEY,
  case_no VARCHAR(30) NOT NULL UNIQUE,
  complaint_id INT NULL,
  complainant_name VARCHAR(120) NOT NULL,
  respondent_name VARCHAR(120) NOT NULL,
  case_type VARCHAR(30) NOT NULL,
  filing_date DATE NOT NULL,
  lupon_member VARCHAR(120) NULL,
  hearing_date DATE NULL,
  mediation_status VARCHAR(20) NOT NULL DEFAULT 'Not Started',
  agreement TEXT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'Filed',
  remarks VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (complaint_id) REFERENCES complaints(id)
) ENGINE=InnoDB;

CREATE TABLE tanods (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  contact_no VARCHAR(30) NULL,
  position VARCHAR(60) NOT NULL,
  assigned_area VARCHAR(100) NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB;

CREATE TABLE tanod_duty (
  id INT AUTO_INCREMENT PRIMARY KEY,
  duty_date DATE NOT NULL,
  shift_start TIME NOT NULL,
  shift_end TIME NOT NULL,
  tanod_id INT NOT NULL,
  area VARCHAR(100) NOT NULL,
  attendance VARCHAR(20) NOT NULL DEFAULT 'Scheduled',
  remarks VARCHAR(255) NULL,
  FOREIGN KEY (tanod_id) REFERENCES tanods(id)
) ENGINE=InnoDB;

CREATE TABLE patrol_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  log_date DATE NOT NULL,
  log_time TIME NOT NULL,
  location VARCHAR(150) NOT NULL,
  incident VARCHAR(255) NOT NULL,
  tanod_id INT NOT NULL,
  remarks VARCHAR(255) NULL,
  FOREIGN KEY (tanod_id) REFERENCES tanods(id)
) ENGINE=InnoDB;

CREATE TABLE bcpc_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  record_no VARCHAR(30) NOT NULL UNIQUE,
  child_resident_id INT NOT NULL,
  record_type VARCHAR(40) NOT NULL,
  program VARCHAR(120) NULL,
  record_date DATE NOT NULL,
  intervention VARCHAR(255) NULL,
  referral VARCHAR(150) NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Open',
  remarks TEXT NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (child_resident_id) REFERENCES residents(id)
) ENGINE=InnoDB;

CREATE TABLE vawc_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  incident_no VARCHAR(30) NOT NULL UNIQUE,
  incident_date DATE NOT NULL,
  location VARCHAR(150) NOT NULL,
  persons_involved TEXT NOT NULL,
  incident_type VARCHAR(60) NOT NULL,
  assistance VARCHAR(255) NULL,
  referral VARCHAR(150) NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Open',
  remarks TEXT NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE officials (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  position VARCHAR(60) NOT NULL,
  contact_no VARCHAR(30) NULL,
  term_start DATE NULL,
  term_end DATE NULL,
  photo VARCHAR(255) NULL,
  signature VARCHAR(255) NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB;

CREATE TABLE budgets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  budget_year INT NOT NULL,
  category VARCHAR(80) NOT NULL,
  allocation VARCHAR(200) NULL,
  amount DECIMAL(12,2) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Draft'
) ENGINE=InnoDB;

CREATE TABLE expenses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  expense_name VARCHAR(150) NOT NULL,
  category VARCHAR(80) NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  expense_date DATE NOT NULL,
  description VARCHAR(255) NULL
) ENGINE=InnoDB;

CREATE TABLE disbursements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  voucher_no VARCHAR(30) NOT NULL UNIQUE,
  payee VARCHAR(120) NOT NULL,
  purpose VARCHAR(200) NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  disbursement_date DATE NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB;

CREATE TABLE notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  title VARCHAR(150) NOT NULL,
  message TEXT NOT NULL,
  link VARCHAR(200) NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE message_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  resident_id INT NULL,
  channel VARCHAR(10) NOT NULL,             -- Email or SMS
  recipient VARCHAR(120) NOT NULL,
  subject VARCHAR(150) NULL,
  message TEXT NOT NULL,
  status VARCHAR(30) NOT NULL,              -- Sent, Sent (Test Mode), Failed
  error_message VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE message_templates (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL UNIQUE,
  channel VARCHAR(10) NOT NULL,
  subject VARCHAR(150) NULL,
  body TEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB;

CREATE TABLE announcements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  content TEXT NOT NULL,
  audience VARCHAR(20) NOT NULL DEFAULT 'Public',
  status VARCHAR(20) NOT NULL DEFAULT 'Draft',
  date_posted DATE NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE events (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  event_date DATE NOT NULL,
  event_time TIME NULL,
  location VARCHAR(150) NOT NULL,
  description TEXT NULL,
  organizer VARCHAR(100) NULL,
  allow_registration VARCHAR(5) NOT NULL DEFAULT 'Yes',
  status VARCHAR(20) NOT NULL DEFAULT 'Draft'
) ENGINE=InnoDB;

CREATE TABLE event_participants (
  id INT AUTO_INCREMENT PRIMARY KEY,
  event_id INT NOT NULL,
  resident_id INT NOT NULL,
  attended TINYINT(1) NOT NULL DEFAULT 0,
  registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_event_res (event_id, resident_id),
  FOREIGN KEY (event_id) REFERENCES events(id),
  FOREIGN KEY (resident_id) REFERENCES residents(id)
) ENGINE=InnoDB;

CREATE TABLE assemblies (
  id INT AUTO_INCREMENT PRIMARY KEY,
  assembly_date DATE NOT NULL,
  location VARCHAR(150) NOT NULL,
  agenda TEXT NOT NULL,
  attendees TEXT NULL,
  minutes TEXT NULL,
  concerns TEXT NULL,
  resolutions TEXT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Scheduled'
) ENGINE=InnoDB;

CREATE TABLE meetings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  meeting_date DATE NOT NULL,
  meeting_time TIME NULL,
  location VARCHAR(150) NOT NULL,
  agenda TEXT NOT NULL,
  attendees TEXT NULL,
  minutes TEXT NULL,
  decisions TEXT NULL,
  action_items TEXT NULL,
  related_resolution VARCHAR(80) NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Scheduled'
) ENGINE=InnoDB;

CREATE TABLE ordinances (
  id INT AUTO_INCREMENT PRIMARY KEY,
  doc_type VARCHAR(30) NOT NULL,
  doc_number VARCHAR(40) NOT NULL UNIQUE,
  title VARCHAR(200) NOT NULL,
  doc_date DATE NOT NULL,
  description TEXT NULL,
  attachment VARCHAR(255) NULL,
  is_public VARCHAR(5) NOT NULL DEFAULT 'Yes',
  status VARCHAR(20) NOT NULL DEFAULT 'Active',
  created_by INT NULL
) ENGINE=InnoDB;

CREATE TABLE projects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  description TEXT NULL,
  proposal TEXT NULL,
  budget DECIMAL(12,2) NOT NULL DEFAULT 0,
  beneficiaries VARCHAR(150) NULL,
  start_date DATE NULL,
  end_date DATE NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Proposed',
  progress INT NOT NULL DEFAULT 0,
  accomplishment TEXT NULL
) ENGINE=InnoDB;

CREATE TABLE facilities (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  facility_type VARCHAR(30) NOT NULL,
  capacity INT NULL,
  description VARCHAR(255) NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'Available'
) ENGINE=InnoDB;

CREATE TABLE reservations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  reservation_no VARCHAR(30) NOT NULL UNIQUE,
  facility_id INT NOT NULL,
  resident_id INT NOT NULL,
  purpose VARCHAR(200) NOT NULL,
  reserve_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Pending',
  remarks VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (facility_id) REFERENCES facilities(id),
  FOREIGN KEY (resident_id) REFERENCES residents(id)
) ENGINE=InnoDB;

CREATE TABLE assets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  asset_code VARCHAR(30) NOT NULL UNIQUE,
  name VARCHAR(120) NOT NULL,
  category VARCHAR(40) NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  condition_status VARCHAR(20) NOT NULL DEFAULT 'Good',
  location VARCHAR(100) NULL,
  assigned_to VARCHAR(120) NULL,
  acquisition_date DATE NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB;

CREATE TABLE environment_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  record_type VARCHAR(40) NOT NULL,
  title VARCHAR(150) NOT NULL,
  location VARCHAR(150) NULL,
  record_date DATE NOT NULL,
  description TEXT NULL,
  reported_by VARCHAR(100) NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Open'
) ENGINE=InnoDB;

CREATE TABLE assistance_programs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  program_name VARCHAR(120) NOT NULL,
  assistance_type VARCHAR(30) NOT NULL,
  eligibility VARCHAR(255) NULL,
  amount_item VARCHAR(100) NULL,
  start_date DATE NULL,
  end_date DATE NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Planned'
) ENGINE=InnoDB;

CREATE TABLE beneficiaries (
  id INT AUTO_INCREMENT PRIMARY KEY,
  program_id INT NOT NULL,
  resident_id INT NOT NULL,
  eligibility_notes VARCHAR(255) NULL,
  assistance_given VARCHAR(100) NULL,
  distribution_date DATE NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Applied',
  remarks VARCHAR(255) NULL,
  UNIQUE KEY uq_prog_res (program_id, resident_id),
  FOREIGN KEY (program_id) REFERENCES assistance_programs(id),
  FOREIGN KEY (resident_id) REFERENCES residents(id)
) ENGINE=InnoDB;

CREATE TABLE activity_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  username VARCHAR(50) NULL,
  action VARCHAR(40) NOT NULL,
  description VARCHAR(255) NOT NULL,
  record_ref VARCHAR(80) NULL,
  ip_address VARCHAR(45) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (action), INDEX (created_at)
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;
