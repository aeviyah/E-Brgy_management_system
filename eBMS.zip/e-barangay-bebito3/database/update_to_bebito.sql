-- Run this in phpMyAdmin (SQL tab) ONLY if you already imported the old seed.sql.
-- It renames the sample barangay to Barangay Bebito, Lopez, Quezon.
-- The phone numbers / email below are SAMPLE placeholders: replace them in Settings > Barangay Settings.
USE e_barangay;
UPDATE settings SET setting_value = 'Barangay Bebito' WHERE setting_key = 'barangay_name';
UPDATE settings SET setting_value = 'Lopez' WHERE setting_key = 'municipality';
UPDATE settings SET setting_value = 'Quezon' WHERE setting_key = 'province';
UPDATE settings SET setting_value = 'Barangay Hall, Barangay Bebito, Lopez, Quezon' WHERE setting_key = 'address';
UPDATE settings SET setting_value = 'barangay.bebito@example.com' WHERE setting_key = 'email';
UPDATE settings SET setting_value = 'Barangay Bebito is a community in the Municipality of Lopez, Province of Quezon. This system helps residents request documents and services online and helps barangay officials manage records.' WHERE setting_key = 'about';
