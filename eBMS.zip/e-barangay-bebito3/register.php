<?php
// RESIDENT SELF-REGISTRATION: Register > Pending Verification > Secretary approves > Active Resident
define('PUBLIC_PAGE', true);
require_once 'auth.php';
if (is_logged_in()) redirect(BASE_URL . 'dashboard.php');

$errors = [];
$v = $_POST;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $get = function ($k) use ($v) { return trim($v[$k] ?? ''); };
    foreach (['first_name' => 'First name', 'last_name' => 'Last name', 'birthdate' => 'Birthdate', 'sex' => 'Sex', 'civil_status' => 'Civil status', 'address' => 'Address', 'purok_id' => 'Purok/Sitio', 'username' => 'Username', 'password' => 'Password'] as $k => $label) {
        if ($get($k) === '') $errors[$k] = $label . ' is required.';
    }
    $d = DateTime::createFromFormat('Y-m-d', $get('birthdate'));
    if ($get('birthdate') !== '' && (!$d || $d->format('Y-m-d') !== $get('birthdate') || $get('birthdate') > date('Y-m-d'))) $errors['birthdate'] = 'Enter a valid birthdate.';
    if (!in_array($get('sex'), ['Male', 'Female'])) $errors['sex'] = 'Choose a valid sex.';
    if (!in_array($get('civil_status'), ['Single', 'Married', 'Widowed', 'Separated'])) $errors['civil_status'] = 'Choose a valid civil status.';
    if ($get('email') === '') $errors['email'] = 'Email is required (for confirmation messages).';
    elseif (!filter_var($get('email'), FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Enter a valid email address.';
    if ($get('contact_no') !== '' && !valid_phone($get('contact_no'))) $errors['contact_no'] = 'Enter a valid contact number.';
    if (!preg_match('/^[A-Za-z0-9_.]{4,30}$/', $get('username'))) $errors['username'] = 'Username must be 4-30 letters, numbers, dot or underscore.';
    elseif (db_val("SELECT COUNT(*) FROM users WHERE username = ?", [$get('username')]) > 0) $errors['username'] = 'This username is already taken.';
    if (strlen($v['password'] ?? '') < 8) $errors['password'] = 'Password must be at least 8 characters.';
    if (($v['password'] ?? '') !== ($v['password2'] ?? '')) $errors['password2'] = 'Passwords do not match.';
    if (!db_val("SELECT COUNT(*) FROM puroks WHERE id = ? AND status = 'Active'", [(int)$get('purok_id')])) $errors['purok_id'] = 'Choose a valid Purok/Sitio.';

    if (!$errors) {
        $resNo = next_number('RES', 'residents', 'resident_no');
        $rid = db_exec("INSERT INTO residents (resident_no, first_name, middle_name, last_name, birthdate, sex, civil_status, contact_no, email, address, purok_id, status) VALUES (?,?,?,?,?,?,?,?,?,?,?, 'Pending Verification')",
            [$resNo, $get('first_name'), $get('middle_name') ?: null, $get('last_name'), $get('birthdate'), $get('sex'), $get('civil_status'), $get('contact_no') ?: null, $get('email'), $get('address'), (int)$get('purok_id')]);
        $uid = db_exec("INSERT INTO users (username, password_hash, full_name, email, contact_no, role, resident_id, status) VALUES (?,?,?,?,?, 'resident', ?, 'Active')",
            [$get('username'), password_hash($v['password'], PASSWORD_DEFAULT), $get('first_name') . ' ' . $get('last_name'), $get('email'), $get('contact_no') ?: null, $rid]);
        add_history('residents', $rid, 'Pending Verification', 'Self-registration submitted');
        db_exec("INSERT INTO activity_logs (user_id, username, action, description, record_ref, ip_address) VALUES (?,?,?,?,?,?)", [$uid, $get('username'), 'Register', 'New resident registration ' . $resNo, 'residents#' . $rid, $_SERVER['REMOTE_ADDR'] ?? '']);
        notify_roles(['secretary'], 'New Resident Registration', $get('first_name') . ' ' . $get('last_name') . ' is waiting for verification.', BASE_URL . 'residents/index.php?action=view&id=' . $rid);
        notify_resident($rid, 'Registration Received', 'Thank you for registering. Your account is pending verification by the Barangay Secretary.', ['inapp', 'email']);
        flash('success', 'Registration submitted! You can log in now. Your account will be fully active after the Secretary verifies you.');
        redirect(BASE_URL . 'login.php');
    }
}
$puroks = db_pairs("SELECT id, name FROM puroks WHERE status = 'Active' ORDER BY name");
function rf($errors, $k) { return isset($errors[$k]) ? '<div class="field-error">' . e($errors[$k]) . '</div>' : ''; }
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Register | E-Barangay <?= e(brgy_short()) ?></title>
<link rel="icon" type="image/svg+xml" href="<?= BASE_URL ?>img/logo.svg">
<link rel="stylesheet" href="<?= BASE_URL ?>css/style.css"><?= scene_css() ?></head>
<body class="reg-page">
<div class="reg-wrap"><div class="reg-card">
    <div class="reg-head"><?= brand_logo('', 'Barangay seal') ?><div><h2>Resident Registration</h2>
    <p class="help" style="margin:2px 0 0"><?= e(setting('barangay_name', 'Barangay')) ?> &middot; The Barangay Secretary will verify your registration.</p></div></div>
    <?php if ($errors): ?><div class="alert alert-error">Please fix the errors below.</div><?php endif; ?>
    <form method="post"><?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>First Name *</label><input type="text" name="first_name" value="<?= e($v['first_name'] ?? '') ?>"><?= rf($errors, 'first_name') ?></div>
        <div class="form-group"><label>Middle Name</label><input type="text" name="middle_name" value="<?= e($v['middle_name'] ?? '') ?>"></div>
        <div class="form-group"><label>Last Name *</label><input type="text" name="last_name" value="<?= e($v['last_name'] ?? '') ?>"><?= rf($errors, 'last_name') ?></div>
        <div class="form-group"><label>Birthdate *</label><input type="date" name="birthdate" value="<?= e($v['birthdate'] ?? '') ?>"><?= rf($errors, 'birthdate') ?></div>
        <div class="form-group"><label>Sex *</label><select name="sex"><option value="">--</option><?php foreach (['Male', 'Female'] as $o) echo '<option' . (($v['sex'] ?? '') === $o ? ' selected' : '') . '>' . $o . '</option>'; ?></select><?= rf($errors, 'sex') ?></div>
        <div class="form-group"><label>Civil Status *</label><select name="civil_status"><option value="">--</option><?php foreach (['Single', 'Married', 'Widowed', 'Separated'] as $o) echo '<option' . (($v['civil_status'] ?? '') === $o ? ' selected' : '') . '>' . $o . '</option>'; ?></select><?= rf($errors, 'civil_status') ?></div>
        <div class="form-group"><label>Contact Number</label><input type="text" name="contact_no" value="<?= e($v['contact_no'] ?? '') ?>" placeholder="09XXXXXXXXX"><?= rf($errors, 'contact_no') ?></div>
        <div class="form-group"><label>Email *</label><input type="email" name="email" value="<?= e($v['email'] ?? '') ?>"><?= rf($errors, 'email') ?></div>
        <div class="form-group full"><label>Address *</label><input type="text" name="address" value="<?= e($v['address'] ?? '') ?>"><?= rf($errors, 'address') ?></div>
        <div class="form-group"><label>Purok/Sitio *</label><select name="purok_id"><option value="">--</option><?php foreach ($puroks as $id => $n) echo '<option value="' . $id . '"' . (($v['purok_id'] ?? '') == $id ? ' selected' : '') . '>' . e($n) . '</option>'; ?></select><?= rf($errors, 'purok_id') ?></div>
        <div class="form-group"><label>Username *</label><input type="text" name="username" value="<?= e($v['username'] ?? '') ?>"><?= rf($errors, 'username') ?></div>
        <div class="form-group"><label>Password * (min 8)</label><input type="password" name="password"><?= rf($errors, 'password') ?></div>
        <div class="form-group"><label>Confirm Password *</label><input type="password" name="password2"><?= rf($errors, 'password2') ?></div>
    </div>
    <p><button class="btn" type="submit">Submit Registration</button> <a class="btn btn-outline" href="login.php">Back to Login</a></p>
    </form>
</div></div>
<script src="<?= BASE_URL ?>js/script.js"></script>
</body></html>
