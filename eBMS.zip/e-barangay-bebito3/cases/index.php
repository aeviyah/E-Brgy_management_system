<?php
// CASES OVERVIEW - one place to see which case modules you are allowed to open
require_once '../auth.php';
if (is_resident()) redirect(BASE_URL . 'complaints/index.php');
$page_title = 'Cases Overview';
$breadcrumb = ['Cases'];
require '../includes/header.php';
$cards = [
    ['complaints', 'Complaints & Blotter', 'complaints/index.php', "SELECT COUNT(*) FROM complaints WHERE status NOT IN ('Resolved','Closed','Referred')", 'open'],
    ['katarungan', 'Katarungang Pambarangay', 'katarungang/index.php', "SELECT COUNT(*) FROM katarungan_cases WHERE status NOT IN ('Settled','Closed')", 'open'],
    ['peace_order', 'Peace & Order / Tanod', 'peace_order/index.php', "SELECT COUNT(*) FROM tanods WHERE status = 'Active'", 'active tanod'],
    ['bcpc', 'BCPC / Child Protection (restricted)', 'bcpc/index.php', "SELECT COUNT(*) FROM bcpc_records WHERE status NOT IN ('Closed','Archived')", 'open'],
    ['vawc', 'VAWC (restricted)', 'vawc/index.php', "SELECT COUNT(*) FROM vawc_records WHERE status NOT IN ('Closed','Archived')", 'open'],
];
echo '<div class="kpis">';
foreach ($cards as $c) {
    if (!user_can($c[0])) continue;
    echo '<a class="kpi" href="' . BASE_URL . $c[2] . '"><div class="num">' . (int)db_val($c[3]) . '</div><div class="lbl">' . e($c[1]) . ' &middot; ' . $c[4] . '</div></a>';
}
echo '</div><div class="card"><p class="help">Only the case modules your role is authorized to use are shown. Sensitive records (BCPC, VAWC) are visible to authorized roles only, and every view is written in the Audit Trail.</p></div>';
require '../includes/footer.php';
