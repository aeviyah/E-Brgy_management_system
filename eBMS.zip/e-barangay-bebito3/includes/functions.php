<?php
// GENERAL HELPER FUNCTIONS

// ---------- Output ----------
function e($text) {
    return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8');
}
function redirect($url) {
    header('Location: ' . $url);
    exit;
}
function money($n) {
    return '&#8369;' . number_format((float)$n, 2);
}
function fdate($d) {
    if (!$d || $d == '0000-00-00') return '';
    return date('M d, Y', strtotime($d));
}
function ftime($t) {
    if (!$t) return '';
    return date('h:i A', strtotime($t));
}
function age_of($birthdate) {
    if (!$birthdate) return '';
    return (new DateTime($birthdate))->diff(new DateTime())->y;
}

// ---------- Database helpers (prepared statements) ----------
function db_query($sql, $params = []) {
    global $conn;
    $stmt = $conn->prepare($sql);
    if (count($params) > 0) {
        $types = '';
        foreach ($params as $p) {
            if (is_int($p)) $types .= 'i';
            elseif (is_float($p)) $types .= 'd';
            else $types .= 's';
        }
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return $stmt;
}
function db_all($sql, $params = []) {
    $stmt = db_query($sql, $params);
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}
function db_one($sql, $params = []) {
    $rows = db_all($sql, $params);
    return count($rows) > 0 ? $rows[0] : null;
}
function db_val($sql, $params = []) {
    $row = db_one($sql, $params);
    if (!$row) return null;
    return array_values($row)[0];
}
function db_exec($sql, $params = []) {
    global $conn;
    $stmt = db_query($sql, $params);
    $stmt->close();
    return $conn->insert_id;
}
// Make a lookup list [id => label] from a SELECT id, label query
function db_pairs($sql, $params = []) {
    $stmt = db_query($sql, $params);
    $out = [];
    foreach ($stmt->get_result()->fetch_all(MYSQLI_NUM) as $r) $out[$r[0]] = $r[1];
    $stmt->close();
    return $out;
}

// ---------- Flash messages ----------
function flash($type, $msg) {
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $msg];
}
function show_flash() {
    if (empty($_SESSION['flash'])) return;
    foreach ($_SESSION['flash'] as $f) {
        echo '<div class="alert alert-' . e($f['type']) . '">' . e($f['msg']) . '</div>';
    }
    unset($_SESSION['flash']);
}

// ---------- CSRF protection ----------
function csrf_token() {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}
function csrf_field() {
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}
function csrf_verify() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $sent = $_POST['csrf'] ?? '';
        if (!hash_equals($_SESSION['csrf'] ?? '', $sent)) {
            http_response_code(400);
            die('Invalid form token. Please go back, refresh the page and try again.');
        }
    }
}

// ---------- Status badges ----------
function badge($status) {
    $green  = ['Active','Approved','Completed','Paid','Published','Released','Resolved','Settled','Present','Available','Issued','Ready for Release','Distributed','Good','Eligible','Successful','Yes'];
    $yellow = ['Pending','Pending Verification','Draft','Proposed','Applied','Filed','Scheduled','Open','For Payment','Unpaid','Fair','Planned','Not Started'];
    $blue   = ['Under Review','Processing','Ongoing','In Progress','Hearing','Mediation','Assigned','Assessed','Referred','Late'];
    $red    = ['Rejected','Cancelled','Failed','Absent','Damaged','Void','Needs Repair','Returned for Correction','Failed'];
    $class = 'grey';
    if (in_array($status, $green)) $class = 'green';
    elseif (in_array($status, $yellow)) $class = 'yellow';
    elseif (in_array($status, $blue)) $class = 'blue';
    elseif (in_array($status, $red)) $class = 'red';
    if (strpos((string)$status, 'Sent') === 0) $class = 'green';
    return '<span class="badge badge-' . $class . '">' . e($status) . '</span>';
}

// ---------- Audit trail ----------
function log_activity($action, $description, $record = '') {
    global $CURRENT_USER;
    $uid = $CURRENT_USER['id'] ?? null;
    $uname = $CURRENT_USER['username'] ?? null;
    db_exec("INSERT INTO activity_logs (user_id, username, action, description, record_ref, ip_address) VALUES (?,?,?,?,?,?)",
        [$uid, $uname, $action, $description, $record, $_SERVER['REMOTE_ADDR'] ?? '']);
}

// ---------- Status history (timeline) ----------
function add_history($table, $id, $status, $remarks = '') {
    global $CURRENT_USER;
    db_exec("INSERT INTO status_history (ref_table, ref_id, status, remarks, user_id) VALUES (?,?,?,?,?)",
        [$table, (int)$id, $status, $remarks, $CURRENT_USER['id'] ?? null]);
}

// ---------- Settings ----------
function setting($key, $default = '') {
    static $cache = null;
    if ($cache === null) $cache = db_pairs("SELECT setting_key, setting_value FROM settings");
    return $cache[$key] ?? $default;
}

// ---------- Auto numbers (e.g. DR-2026-0001) ----------
function next_number($prefix, $table, $column) {
    $year = date('Y');
    $like = $prefix . '-' . $year . '-%';
    $count = (int)db_val("SELECT COUNT(*) FROM $table WHERE $column LIKE ?", [$like]);
    do {
        $count++;
        $num = $prefix . '-' . $year . '-' . str_pad($count, 4, '0', STR_PAD_LEFT);
        $exists = (int)db_val("SELECT COUNT(*) FROM $table WHERE $column = ?", [$num]);
    } while ($exists > 0);
    return $num;
}

// ---------- File upload (type + size check, unique name) ----------
function save_upload($input, $allowed = ['pdf', 'jpg', 'jpeg', 'png'], $maxMB = 2) {
    if (!isset($_FILES[$input]) || $_FILES[$input]['error'] === UPLOAD_ERR_NO_FILE) return [null, null];
    $f = $_FILES[$input];
    if ($f['error'] !== UPLOAD_ERR_OK) return [null, 'File upload failed.'];
    if ($f['size'] > $maxMB * 1024 * 1024) return [null, 'File is too large (max ' . $maxMB . ' MB).'];
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) return [null, 'Invalid file type. Allowed: ' . implode(', ', $allowed) . '.'];
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $okMimes = ['application/pdf', 'image/jpeg', 'image/png'];
    if (!in_array($mime, $okMimes)) return [null, 'Invalid file content.'];
    $name = date('YmdHis') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dir = ROOT_PATH . '/uploads/';
    if (!is_dir($dir)) mkdir($dir, 0777, true);
    if (!move_uploaded_file($f['tmp_name'], $dir . $name)) return [null, 'Could not save the uploaded file.'];
    return [$name, null];
}
function file_link($name) {
    if (!$name) return '';
    return '<a href="' . BASE_URL . 'uploads/' . e($name) . '" target="_blank">View file</a>';
}

// ---------- Small option lists used by many forms ----------
function opts($list) {
    $out = [];
    foreach ($list as $v) $out[$v] = $v;
    return $out;
}
function resident_label_sql() {
    return "SELECT id, CONCAT(last_name, ', ', first_name, ' (', resident_no, ')') FROM residents WHERE status <> 'Archived' ORDER BY last_name, first_name";
}
function resident_name($id) {
    $r = db_one("SELECT first_name, middle_name, last_name FROM residents WHERE id = ?", [(int)$id]);
    if (!$r) return '';
    return trim($r['first_name'] . ' ' . ($r['middle_name'] ? $r['middle_name'][0] . '. ' : '') . $r['last_name']);
}

function valid_phone($s) {
    return preg_match('/^[0-9+\-\s()]{7,20}$/', $s) === 1;
}

// Simple horizontal bar chart in pure HTML/CSS. $data = [label => number]
function render_bars($data, $isMoney = false) {
    $max = $data ? max($data) : 0;
    echo '<div class="bars">';
    foreach ($data as $label => $val) {
        $w = $max > 0 ? round(($val / $max) * 100) : 0;
        echo '<div class="row"><div class="name">' . e($label) . '</div><div class="bar"><div class="fill" style="width:' . $w . '%"></div></div><div class="val">' . ($isMoney ? money($val) : e($val)) . '</div></div>';
    }
    if (!$data) echo '<p class="help">No data yet.</p>';
    echo '</div>';
}


// ---------- Look & feel helpers (UI only) ----------
// Small line-icon set (24x24, stroke). Usage: echo icon('home');
function icon($name, $class = 'ico') {
    static $paths = [
        'home'     => '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
        'users'    => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><circle cx="17.5" cy="9" r="2.5"/><path d="M17 14.2c2.6.2 4.5 2 4.5 5.3"/>',
        'house'    => '<path d="M4 21V9l8-6 8 6v12z"/><path d="M9 21v-7h6v7"/>',
        'map'      => '<path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2z"/><path d="M9 4v14M15 6v14"/>',
        'file'     => '<path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
        'briefcase'=> '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a2 2 0 012-2h2a2 2 0 012 2v2M3 13h18"/>',
        'hand'     => '<path d="M12 21s-7-4.4-7-10a4 4 0 017-2.6A4 4 0 0119 11c0 5.6-7 10-7 10z"/>',
        'scale'    => '<path d="M12 3v18M6 21h12M5 7h14"/><path d="M5 7l-3 7a3 3 0 006 0zM19 7l-3 7a3 3 0 006 0z"/>',
        'shield'   => '<path d="M12 3l8 3v6c0 4.5-3.2 7.8-8 9-4.8-1.2-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
        'landmark' => '<path d="M3 10l9-6 9 6M5 10v8M9.5 10v8M14.5 10v8M19 10v8M3 21h18M3 10h18"/>',
        'wallet'   => '<path d="M3 7a2 2 0 012-2h13v4"/><path d="M3 7v11a2 2 0 002 2h15V9H5a2 2 0 01-2-2z"/><circle cx="16.5" cy="14.5" r="1.2"/>',
        'megaphone'=> '<path d="M3 11v3a1 1 0 001 1h3l8 4V6L7 10H4a1 1 0 00-1 1z"/><path d="M19 9a4 4 0 010 6"/>',
        'calendar' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
        'building' => '<rect x="5" y="3" width="14" height="18" rx="1"/><path d="M9 7h2M13 7h2M9 11h2M13 11h2M9 15h2M13 15h2M10 21v-3h4v3"/>',
        'box'      => '<path d="M21 8l-9-5-9 5 9 5z"/><path d="M3 8v8l9 5 9-5V8M12 13v8"/>',
        'hammer'   => '<path d="M14 6l4 4M5 19l9-9M12 4l3-1 6 6-1 3-3-1-3 3-5-5 3-3z"/>',
        'leaf'     => '<path d="M5 19C5 9 11 4 20 4c0 9-5 15-15 15z"/><path d="M5 19c3-5 6-8 11-10"/>',
        'heart'    => '<path d="M12 20s-8-4.6-8-10.5A4.5 4.5 0 0112 7a4.5 4.5 0 018 2.5C20 15.4 12 20 12 20z"/>',
        'chart'    => '<path d="M4 20V4M4 20h16"/><path d="M8 16v-4M12 16V8M16 16v-6"/>',
        'search'   => '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
        'clipboard'=> '<rect x="6" y="4" width="12" height="17" rx="2"/><path d="M9 4V3h6v1M9 11h6M9 15h4"/>',
        'settings' => '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
        'lock'     => '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
        'bell'     => '<path d="M6 16V11a6 6 0 0112 0v5l2 2H4z"/><path d="M10 21h4"/>',
        'logout'   => '<path d="M9 4H5a2 2 0 00-2 2v12a2 2 0 002 2h4M16 8l4 4-4 4M20 12H9"/>',
        'plus'     => '<path d="M12 5v14M5 12h14"/>',
        'chev'     => '<path d="M9 6l6 6-6 6"/>',
        'menu'     => '<path d="M4 6h16M4 12h16M4 18h16"/>',
        'receipt'  => '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
        'siren'    => '<path d="M7 18v-6a5 5 0 0110 0v6M5 21h14M12 3v2M4.5 7l1.5 1.5M19.5 7L18 8.5"/>',
        'id'       => '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2.2"/><path d="M5.8 16c.6-1.7 1.9-2.5 3.2-2.5s2.6.8 3.2 2.5M15 10h4M15 14h3"/>',
    ];
    $p = $paths[$name] ?? $paths['file'];
    return '<svg class="' . $class . '" viewBox="0 0 24 24" aria-hidden="true">' . $p . '</svg>';
}

// Barangay seal (swap img/logo.svg with the official seal at any time).
function brand_logo($class = 'seal', $alt = '') {
    return '<img class="' . e($class) . '" src="' . BASE_URL . 'img/logo.svg" alt="' . e($alt) . '">';
}
// Optional real photo of the barangay: put img/brgy-photo.jpg and it replaces the illustrated scene.
function scene_url() {
    return BASE_URL . (is_file(ROOT_PATH . '/img/brgy-photo.jpg') ? 'img/brgy-photo.jpg' : 'img/scene.svg');
}
function scene_css() {
    // Overrides every place that uses the illustrated scene when a real photo exists.
    if (!is_file(ROOT_PATH . '/img/brgy-photo.jpg')) return '';
    $u = BASE_URL . 'img/brgy-photo.jpg';
    return '<style>.page-head,.welcome{background-image:linear-gradient(100deg,rgba(12,42,31,.88),rgba(18,57,42,.5) 55%,rgba(18,57,42,.1)),url("' . $u . '")!important;background-size:cover!important;background-position:center!important}'
         . '.login-hero,.reg-page{background-image:url("' . $u . '")!important}'
         . '.hero{background-image:linear-gradient(0deg,rgba(8,34,24,.78),rgba(8,34,24,.1) 70%),url("' . $u . '")!important}'
         . '.main::after{background-image:url("' . $u . '")!important}</style>';
}
function brgy_short() {
    return preg_replace('/^Barangay\s+/i', '', setting('barangay_name', 'Barangay'));
}
function greeting() {
    $h = (int)date('G');
    return $h < 12 ? 'Magandang umaga' : ($h < 18 ? 'Magandang hapon' : 'Magandang gabi');
}
