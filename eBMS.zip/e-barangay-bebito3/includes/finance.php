<?php
// PAYMENT -> OFFICIAL RECEIPT -> REQUEST UPDATE
// Used by payments/index.php whenever a payment becomes "Paid".

function create_receipt($pay) {
    global $CURRENT_USER;
    if (db_one("SELECT id FROM official_receipts WHERE payment_id = ?", [$pay['id']])) return;
    $orNo = next_number('OR', 'official_receipts', 'or_number');
    db_exec("INSERT INTO official_receipts (or_number, payment_id, resident_id, purpose, amount, issue_date, payment_method, treasurer_id) VALUES (?,?,?,?,?,?,?,?)",
        [$orNo, $pay['id'], $pay['resident_id'], $pay['purpose'], $pay['amount'], $pay['payment_date'], $pay['payment_method'], $CURRENT_USER['id']]);
    log_activity('Create', 'Issued Official Receipt ' . $orNo . ' for ' . $pay['transaction_id'], 'official_receipts');
}

function payment_finalize($paymentId) {
    $pay = db_one("SELECT * FROM payments WHERE id = ?", [(int)$paymentId]);
    if (!$pay || $pay['status'] !== 'Paid') return;
    create_receipt($pay);
    $or = db_one("SELECT or_number FROM official_receipts WHERE payment_id = ?", [$pay['id']]);
    $msg = 'Payment of PHP ' . number_format($pay['amount'], 2) . ' for ' . $pay['purpose'] . ' was received. OR No. ' . ($or['or_number'] ?? '') . '. Thank you.';

    // If this payment is for a document request, move the request forward
    if ($pay['ref_type'] === 'document_request' && $pay['ref_id']) {
        $req = db_one("SELECT * FROM document_requests WHERE id = ?", [(int)$pay['ref_id']]);
        if ($req) {
            db_exec("UPDATE document_requests SET payment_status = 'Paid' WHERE id = ?", [$req['id']]);
            if ($req['status'] === 'For Payment') {
                db_exec("UPDATE document_requests SET status = 'Processing' WHERE id = ?", [$req['id']]);
                add_history('document_requests', $req['id'], 'Processing', 'Payment received (' . $pay['transaction_id'] . '). Request is now being processed.');
                $msg .= ' Your document request ' . $req['request_no'] . ' is now being processed.';
            }
        }
    }
    notify_resident($pay['resident_id'], 'Payment Confirmation', $msg, ['inapp', 'email', 'sms'], BASE_URL . 'receipts/index.php');
}

function payment_void_effects($pay) {
    db_exec("UPDATE official_receipts SET status = 'Void' WHERE payment_id = ?", [$pay['id']]);
    if ($pay['ref_type'] === 'document_request' && $pay['ref_id']) {
        $req = db_one("SELECT * FROM document_requests WHERE id = ?", [(int)$pay['ref_id']]);
        if ($req && in_array($req['status'], ['Processing', 'For Payment'])) {
            db_exec("UPDATE document_requests SET payment_status = 'Unpaid', status = 'For Payment' WHERE id = ?", [$req['id']]);
            add_history('document_requests', $req['id'], 'For Payment', 'Payment ' . $pay['transaction_id'] . ' was cancelled. Payment is required again.');
        }
    }
}
