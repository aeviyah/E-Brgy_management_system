<?php
// NOTIFICATION WORKFLOW
//   System event -> in-app notification -> email -> SMS -> saved in message_logs
// If email/SMS cannot be sent, the failure is only recorded. The system keeps working.
require_once __DIR__ . '/../config/mail_sms.php';

function log_message($residentId, $channel, $recipient, $subject, $message, $status, $error = '') {
    db_exec("INSERT INTO message_logs (resident_id, channel, recipient, subject, message, status, error_message) VALUES (?,?,?,?,?,?,?)",
        [$residentId, $channel, $recipient, $subject, $message, $status, $error]);
}

function send_email($residentId, $to, $subject, $message) {
    try {
        if (NOTIFY_MODE !== 'live') {
            log_message($residentId, 'Email', $to, $subject, $message, 'Sent (Test Mode)');
            return true;
        }
        $headers = 'From: ' . MAIL_FROM_NAME . ' <' . MAIL_FROM . ">\r\nContent-Type: text/plain; charset=UTF-8";
        $ok = @mail($to, $subject, $message, $headers);
        log_message($residentId, 'Email', $to, $subject, $message, $ok ? 'Sent' : 'Failed', $ok ? '' : 'mail() failed - check sendmail settings');
        return $ok;
    } catch (Throwable $t) {
        log_message($residentId, 'Email', $to, $subject, $message, 'Failed', $t->getMessage());
        return false;
    }
}

function send_sms($residentId, $number, $message) {
    try {
        if (NOTIFY_MODE !== 'live') {
            log_message($residentId, 'SMS', $number, null, $message, 'Sent (Test Mode)');
            return true;
        }
        if (SMS_API_KEY === '') {
            log_message($residentId, 'SMS', $number, null, $message, 'Failed', 'SMS API key is not set in config/mail_sms.php');
            return false;
        }
        $ch = curl_init(SMS_API_URL);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(['apikey' => SMS_API_KEY, 'number' => $number, 'message' => $message, 'sendername' => SMS_SENDER]));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $ok = ($code >= 200 && $code < 300);
        log_message($residentId, 'SMS', $number, null, $message, $ok ? 'Sent' : 'Failed', $ok ? '' : 'Gateway returned HTTP ' . $code);
        return $ok;
    } catch (Throwable $t) {
        log_message($residentId, 'SMS', $number, null, $message, 'Failed', $t->getMessage());
        return false;
    }
}

// Notify one resident. $channels can contain 'inapp', 'email', 'sms'
function notify_resident($residentId, $title, $message, $channels = ['inapp', 'email', 'sms'], $link = '') {
    try {
        $res = db_one("SELECT id, email, contact_no FROM residents WHERE id = ?", [(int)$residentId]);
        if (!$res) return;
        if (in_array('inapp', $channels)) {
            $user = db_one("SELECT id FROM users WHERE resident_id = ?", [(int)$residentId]);
            if ($user) {
                db_exec("INSERT INTO notifications (user_id, title, message, link) VALUES (?,?,?,?)", [$user['id'], $title, $message, $link]);
            }
        }
        if (in_array('email', $channels) && $res['email'] && filter_var($res['email'], FILTER_VALIDATE_EMAIL)) {
            send_email($res['id'], $res['email'], $title, $message);
        }
        if (in_array('sms', $channels) && $res['contact_no']) {
            send_sms($res['id'], $res['contact_no'], $message);
        }
    } catch (Throwable $t) {
        // Never stop the main workflow because of a notification problem
    }
}

// Notify every staff account that has one of the given roles (in-app only)
function notify_roles($roles, $title, $message, $link = '') {
    try {
        $marks = implode(',', array_fill(0, count($roles), '?'));
        foreach (db_all("SELECT id FROM users WHERE status='Active' AND role IN ($marks)", $roles) as $u) {
            db_exec("INSERT INTO notifications (user_id, title, message, link) VALUES (?,?,?,?)", [$u['id'], $title, $message, $link]);
        }
    } catch (Throwable $t) {
    }
}
