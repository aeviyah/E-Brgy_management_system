<?php
// Page layout start. Set $page_title and $breadcrumb (array of strings) before including.
global $CURRENT_USER, $ROLE_LABELS;
$page_title = $page_title ?? 'E-Barangay';
$breadcrumb = $breadcrumb ?? [];
$body_class = $body_class ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#12392a">
<title><?= e($page_title) ?> | E-Barangay <?= e(brgy_short()) ?></title>
<link rel="icon" type="image/svg+xml" href="<?= BASE_URL ?>img/logo.svg">
<link rel="stylesheet" href="<?= BASE_URL ?>css/style.css">
<?= scene_css() ?>
</head>
<body class="<?= e($body_class) ?>">
<div class="layout">
    <?php require __DIR__ . '/sidebar.php'; ?>
    <div class="scrim" id="scrim" onclick="toggleSidebar()"></div>
    <div class="main">
        <?php require __DIR__ . '/navbar.php'; ?>
        <div class="content">
            <?php if (empty($hide_banner)): ?>
            <div class="page-head">
                <?= brand_logo('seal') ?>
                <div>
                    <h1><?= e($page_title) ?></h1>
                    <div class="breadcrumb">
                        <a href="<?= BASE_URL ?>dashboard.php">Home</a>
                        <?php foreach ($breadcrumb as $b): ?> &rsaquo; <span><?= e($b) ?></span><?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php show_flash(); ?>
