<?php
global $CURRENT_USER, $ROLE_LABELS;
$unread = (int)db_val("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0", [$CURRENT_USER['id']]);
$initial = strtoupper(mb_substr(trim($CURRENT_USER['full_name']), 0, 1));
?>
<header class="topbar">
    <button class="menu-btn" type="button" onclick="toggleSidebar()" aria-label="Open menu"><?= icon('menu') ?></button>
    <form class="global-search" action="<?= BASE_URL ?>search/index.php" method="get">
        <?= icon('search') ?>
        <input type="text" name="q" placeholder="Search residents, households, requests, payments...  ( / )" value="<?= e($_GET['q'] ?? '') ?>">
        <button type="submit">Search</button>
    </form>
    <div class="top-actions">
        <div class="today"><strong><?= e(date('l')) ?></strong><?= e(date('F j, Y')) ?></div>
        <?php if (!is_resident() && user_can('residents', 'manage')): ?>
            <a class="btn btn-small btn-gold" href="<?= BASE_URL ?>residents/index.php?action=add"><?= icon('plus') ?> Quick Add Resident</a>
        <?php elseif (is_resident()): ?>
            <a class="btn btn-small btn-gold" href="<?= BASE_URL ?>documents/index.php"><?= icon('plus') ?> Request Document</a>
        <?php endif; ?>
        <a class="notif <?= $unread > 0 ? 'has' : '' ?>" href="<?= BASE_URL ?>notifications/index.php" title="Notifications">
            <?= icon('bell') ?><?php if ($unread > 0): ?><span class="notif-count"><?= $unread ?></span><?php endif; ?>
        </a>
        <div class="user-box">
            <span class="avatar"><?= e($initial) ?></span>
            <div class="who"><a href="<?= BASE_URL ?>profile.php"><strong><?= e($CURRENT_USER['full_name']) ?></strong></a>
            <span class="role-tag"><?= e($ROLE_LABELS[$CURRENT_USER['role']] ?? $CURRENT_USER['role']) ?></span></div>
        </div>
        <a class="btn btn-small btn-outline" href="<?= BASE_URL ?>logout.php" title="Log out"><?= icon('logout') ?></a>
    </div>
</header>
