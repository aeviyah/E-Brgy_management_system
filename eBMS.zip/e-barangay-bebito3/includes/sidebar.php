<?php
// Sidebar. Links that the user cannot use are hidden (not just blocked).
global $CURRENT_USER;
function nav_link($label, $path, $module = null, $ability = 'view') {
    $self = $_SERVER['PHP_SELF'];
    if ($module !== null && !user_can($module, $ability)) return;
    // highlight the link that matches the current file
    $active = (substr($self, -strlen($path)) === $path) ? 'active' : '';
    echo '<a class="' . $active . '" href="' . BASE_URL . $path . '">' . e($label) . '</a>';
}
// Icon for each sidebar group title (kept inside the function so it works from any include scope)
function nav_group($title, $callback) {
    static $NAV_ICONS = [
    'My Account' => 'id', 'Requests' => 'file', 'Payments & Cases' => 'wallet', 'Community' => 'megaphone',
    'Records' => 'users', 'Documents & Permits' => 'file', 'Barangay Services' => 'hand',
    'Cases & Protection' => 'scale', 'Governance' => 'landmark', 'Treasury' => 'wallet',
    'Communication' => 'megaphone', 'Community & Operations' => 'building', 'Control' => 'settings',
    ];
    ob_start();
    $callback();
    $html = ob_get_clean();
    if (trim($html) === '') return;
    $key = preg_replace('/[^a-z]/', '', strtolower($title));
    echo '<div class="nav-group" data-key="' . $key . '"><button type="button" class="nav-title">' . icon($NAV_ICONS[$title] ?? 'file')
        . '<span>' . e($title) . '</span>' . icon('chev', 'ico chev') . '</button>'
        . '<div class="nav-items"><div>' . $html . '</div></div></div>';
}
function nav_locked($label) {
    echo '<a class="locked" href="' . BASE_URL . 'locked.php?m=' . urlencode($label) . '">' . icon('lock') . e($label) . '<small>Future Module</small></a>';
}
?>
<aside class="sidebar" id="sidebar">
    <a class="brand" href="<?= BASE_URL ?>dashboard.php">
        <?= brand_logo('brand-logo') ?>
        <div><strong>E-Barangay</strong><small><?= e(setting('barangay_name', 'Barangay')) ?></small><small style="color:#9fbfae"><?= e(setting('municipality')) ?>, <?= e(setting('province')) ?></small></div>
    </a>
    <nav>
        <?php $dash_active = (substr($_SERVER['PHP_SELF'], -13) === 'dashboard.php') ? 'active' : ''; ?>
        <a class="nav-single <?= $dash_active ?>" href="<?= BASE_URL ?>dashboard.php"><?= icon('home') ?> Dashboard</a>

        <?php if (is_resident()): ?>
            <?php nav_group('My Account', function () {
                nav_link('My Profile', 'profile.php');
                nav_link('Notifications', 'notifications/index.php');
            }); ?>
            <?php nav_group('Requests', function () {
                nav_link('Document Requests', 'documents/requests.php');
                nav_link('Business Clearance', 'permits/index.php');
                nav_link('Service Requests', 'services/requests.php');
                nav_link('Facility Reservations', 'facilities/reservations.php');
            }); ?>
            <?php nav_group('Payments & Cases', function () {
                nav_link('My Payments', 'payments/index.php');
                nav_link('My Receipts', 'receipts/index.php');
                nav_link('My Complaints', 'complaints/index.php');
            }); ?>
            <?php nav_group('Community', function () {
                nav_link('Announcements', 'announcements/index.php');
                nav_link('Events', 'events/index.php');
                nav_link('Public Portal', 'public/index.php');
            }); ?>
        <?php else: ?>
            <?php nav_group('Records', function () {
                nav_link('Residents', 'residents/index.php', 'residents');
                nav_link('Households', 'households/index.php', 'households');
                nav_link('Purok / Sitio', 'puroks/index.php', 'puroks');
            }); ?>
            <?php nav_group('Documents & Permits', function () {
                nav_link('Document Requests', 'documents/requests.php', 'doc_requests');
                nav_link('Document Catalog', 'documents/index.php', 'documents');
                nav_link('Business Clearance', 'permits/index.php', 'permits');
            }); ?>
            <?php nav_group('Barangay Services', function () {
                nav_link('Service Requests', 'services/requests.php', 'service_requests');
                nav_link('Service Catalog', 'services/index.php', 'services');
            }); ?>
            <?php nav_group('Cases & Protection', function () {
                nav_link('Cases Overview', 'cases/index.php', 'complaints');
                nav_link('Complaints & Blotter', 'complaints/index.php', 'complaints');
                nav_link('Katarungang Pambarangay', 'katarungang/index.php', 'katarungan');
                nav_link('Tanod Roster', 'peace_order/index.php', 'peace_order');
                nav_link('Tanod Duty', 'peace_order/duty.php', 'peace_order');
                nav_link('Patrol / Incident Log', 'peace_order/patrol.php', 'peace_order');
                nav_link('BCPC / Child Protection', 'bcpc/index.php', 'bcpc');
                nav_link('VAWC (Restricted)', 'vawc/index.php', 'vawc');
            }); ?>
            <?php nav_group('Governance', function () {
                nav_link('Officials & Personnel', 'officials/index.php', 'officials');
                nav_link('Barangay Assembly', 'assembly/index.php', 'assembly');
                nav_link('Meetings & Minutes', 'meetings/index.php', 'meetings');
                nav_link('Ordinances & Resolutions', 'ordinances/index.php', 'ordinances');
            }); ?>
            <?php nav_group('Treasury', function () {
                nav_link('Treasury Dashboard', 'treasury/index.php', 'treasury');
                nav_link('Fees', 'treasury/fees.php', 'treasury');
                nav_link('Payments', 'payments/index.php', 'payments');
                nav_link('Official Receipts', 'receipts/index.php', 'receipts');
                nav_link('Budget', 'budget/index.php', 'budget');
                nav_link('Expenses', 'budget/expenses.php', 'budget');
                nav_link('Disbursements', 'budget/disbursements.php', 'budget');
            }); ?>
            <?php nav_group('Communication', function () {
                nav_link('Message Center', 'communication/index.php', 'communication');
                nav_link('Send Message', 'communication/send.php', 'communication', 'manage');
                nav_link('Templates', 'communication/templates.php', 'communication');
                nav_link('Announcements', 'announcements/index.php', 'announcements');
            }); ?>
            <?php nav_group('Community & Operations', function () {
                nav_link('Events', 'events/index.php', 'events');
                nav_link('Facilities', 'facilities/index.php', 'facilities');
                nav_link('Reservations', 'facilities/reservations.php', 'reservations');
                nav_link('Assets & Inventory', 'assets/index.php', 'assets');
                nav_link('Projects', 'projects/index.php', 'projects');
                nav_link('Environment & Sanitation', 'environment/index.php', 'environment');
                nav_link('Assistance Programs', 'assistance/index.php', 'assistance');
                nav_link('Beneficiaries', 'assistance/beneficiaries.php', 'assistance');
            }); ?>
            <?php nav_group('Control', function () {
                nav_link('Reports & Analytics', 'reports/index.php', 'reports');
                nav_link('Global Search', 'search/index.php');
                nav_link('Audit Trail', 'audit/index.php', 'audit');
                nav_link('Users', 'settings/users.php', 'settings');
                nav_link('Barangay Settings', 'settings/index.php', 'settings');
                nav_link('Roles & Permissions', 'settings/roles.php', 'settings');
                nav_link('Backup & Data', 'backup/index.php', 'backup');
                nav_link('My Profile', 'profile.php');
                nav_link('Public Portal', 'public/index.php');
            }); ?>
        <?php endif; ?>

        <div class="nav-locked-title">LOCKED / FUTURE MODULES</div>
        <?php nav_locked('SK Management'); nav_locked('Health Center'); nav_locked('Emergency & Disaster'); ?>
    </nav>
</aside>
