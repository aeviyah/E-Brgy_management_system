<?php
// =====================================================================
// CRUD ENGINE
// Every module page (residents/index.php, households/index.php, ...) only describes
// its table, fields and workflow in an array ($cfg). This file does the common work:
//   list + search + filter  |  add  |  edit  |  view  |  archive  |  workflow buttons
// Validation is done in PHP. All queries use prepared statements.
// =====================================================================

function crud_defaults($cfg) {
    $cfg += [
        'pk' => 'id', 'alias' => 't', 'order' => 't.id DESC', 'per_page' => 15,
        'archive' => null,        // e.g. ['value' => 'Archived', 'restore' => 'Active']
        'delete' => false,        // true = allow permanent delete (only for simple log-type tables)
        'no_edit' => false,
        'actions' => [], 'columns' => null, 'search' => [], 'joins' => '',
        'computed' => [], 'resident' => null, 'history' => false, 'export' => true,
        'status_field' => 'status', 'status_chips' => true, 'ref' => null,
        'singular' => $cfg['title'], 'after_save' => 'list', 'where' => '',
        'links' => [], 'log_view' => false, 'remarks_field' => null, 'date_filter' => null,
    ];
    if ($cfg['columns'] === null) {
        $cfg['columns'] = [];
        foreach ($cfg['fields'] as $n => $d) {
            if (!empty($d['list'])) $cfg['columns'][] = $n;
        }
    }
    return $cfg;
}

// ---------------------------------------------------------------- permissions
function crud_role_in_manage($cfg) {
    global $CURRENT_USER, $MODULES;
    return in_array($CURRENT_USER['role'], $MODULES[$cfg['module']]['acl']['manage']);
}
function crud_can($cfg, $ability) {
    if (is_resident()) {
        $r = $cfg['resident'];
        if (!$r) return false;
        if ($ability === 'view') return true;
        if ($ability === 'add') return !empty($r['add']);
        return false;
    }
    if ($ability === 'add' && !empty($cfg['no_add'])) return false;
    switch ($ability) {
        case 'view':    return user_can($cfg['module'], 'view');
        case 'add':
        case 'edit':    return user_can($cfg['module'], 'manage');
        case 'archive': return crud_role_in_manage($cfg);   // staff cannot archive
    }
    return false;
}

// ---------------------------------------------------------------- field helpers
function crud_col($name, $def) {
    return $def['column'] ?? $name;
}
function crud_options($def) {
    static $cache = [];
    if (isset($def['options'])) return $def['options'];
    if (isset($def['sql'])) {
        $key = md5($def['sql']);
        if (!isset($cache[$key])) $cache[$key] = db_pairs($def['sql']);
        return $cache[$key];
    }
    return [];
}
function crud_form_fields($cfg, $isEdit) {
    $out = [];
    foreach ($cfg['fields'] as $name => $def) {
        $type = $def['type'] ?? 'text';
        if ($type === 'auto' || ($def['form'] ?? true) === false) continue;
        if (is_resident() && !empty($def['staff_only'])) continue;
        if ($isEdit && !empty($def['add_only'])) continue;
        if (!$isEdit && !empty($def['edit_only'])) continue;
        if (is_resident() && !empty($cfg['resident']['column']) && $name === $cfg['resident']['column']) continue;
        $out[$name] = $def;
    }
    return $out;
}
function crud_get($cfg, $id) {
    $sel = 't.*';
    foreach ($cfg['computed'] as $k => $c) $sel .= ', (' . $c['sql'] . ') AS ' . $k;
    $row = db_one("SELECT $sel FROM {$cfg['table']} t {$cfg['joins']} WHERE t.{$cfg['pk']} = ? LIMIT 1", [(int)$id]);
    if (!$row) return null;
    // Residents may only see their own rows
    if (is_resident()) {
        $r = $cfg['resident'];
        if (!empty($r['column']) && $row[$r['column']] != $GLOBALS['CURRENT_USER']['resident_id']) return null;
        if (!empty($r['where']) && !db_one("SELECT 1 FROM {$cfg['table']} t WHERE t.{$cfg['pk']} = ? AND ({$r['where']})", [(int)$id])) return null;
    }
    return $row;
}
function crud_ref($cfg, $row) {
    if ($cfg['ref'] && isset($row[$cfg['ref']])) return $row[$cfg['ref']];
    return '#' . $row[$cfg['pk']];
}
function crud_is_archived($cfg, $row) {
    return $cfg['archive'] && ($row[$cfg['status_field']] ?? '') === $cfg['archive']['value'];
}

// ---------------------------------------------------------------- display of one value
function crud_display($cfg, $name, $row) {
    if (isset($cfg['computed'][$name])) {
        $c = $cfg['computed'][$name];
        $v = $row[$name] ?? '';
        if (!empty($c['money'])) return money($v);
        if (!empty($c['badge'])) return badge($v);
        if (!empty($c['date'])) return e(fdate($v));
        if (!empty($c['html'])) return $v;
        return e($v);
    }
    $def = $cfg['fields'][$name] ?? [];
    $type = $def['type'] ?? 'text';
    $v = $row[crud_col($name, $def)] ?? null;
    if ($v === null || $v === '') return '';
    if ($type === 'password') return '********';
    if ($type === 'select') {
        $o = crud_options($def);
        $label = $o[$v] ?? $v;
        return (!empty($def['badge']) || $name === $cfg['status_field']) ? badge($label) : e($label);
    }
    if ($type === 'checkbox') return $v ? badge('Yes') : '<span class="badge badge-grey">No</span>';
    if ($type === 'checkboxes') {
        $o = crud_options($def);
        $labels = [];
        foreach (explode(',', $v) as $k) $labels[] = $o[trim($k)] ?? trim($k);
        return e(implode(', ', $labels));
    }
    if ($type === 'date') return e(fdate($v));
    if ($type === 'time') return e(ftime($v));
    if ($type === 'file') return file_link($v);
    if (!empty($def['money'])) return money($v);
    if (!empty($def['badge']) || $name === $cfg['status_field']) return badge($v);
    if ($type === 'textarea') return e(mb_strimwidth($v, 0, 90, '...'));
    return e($v);
}
function crud_plain($cfg, $name, $row) {   // for CSV export
    return trim(html_entity_decode(strip_tags(crud_display($cfg, $name, $row)), ENT_QUOTES, 'UTF-8'));
}
function crud_label($cfg, $name) {
    if (isset($cfg['computed'][$name])) return $cfg['computed'][$name]['label'];
    return $cfg['fields'][$name]['label'] ?? $name;
}

// ---------------------------------------------------------------- validation
function crud_validate($cfg, $post, $id, $existing) {
    $isEdit = $id > 0;
    $data = [];
    $errors = [];
    foreach (crud_form_fields($cfg, $isEdit) as $name => $def) {
        $type = $def['type'] ?? 'text';
        $label = $def['label'] ?? $name;
        $col = crud_col($name, $def);
        $raw = $post[$name] ?? '';

        if ($type === 'file') {
            list($file, $err) = save_upload($name, $def['allowed'] ?? ['pdf', 'jpg', 'jpeg', 'png'], $def['max_mb'] ?? 2);
            if ($err) { $errors[$name] = $label . ': ' . $err; continue; }
            if ($file) $data[$col] = $file;
            elseif (!$isEdit && !empty($def['required'])) $errors[$name] = $label . ' is required.';
            continue;
        }
        if ($type === 'checkbox') { $data[$col] = isset($post[$name]) ? 1 : 0; continue; }
        if ($type === 'checkboxes') {
            $allowed = array_keys(crud_options($def));
            $picked = array_values(array_intersect((array)($post[$name] ?? []), array_map('strval', $allowed)));
            if (!empty($def['required']) && !$picked) $errors[$name] = $label . ' is required.';
            $data[$col] = $picked ? implode(',', $picked) : null;
            continue;
        }
        if ($type === 'password') {
            $pw = (string)$raw;
            if ($pw === '') {
                if (!$isEdit) $errors[$name] = $label . ' is required.';
                continue;                            // keep old password on edit
            }
            if (strlen($pw) < 8) { $errors[$name] = $label . ' must be at least 8 characters.'; continue; }
            $data[$col] = password_hash($pw, PASSWORD_DEFAULT);
            continue;
        }

        $val = is_array($raw) ? '' : trim((string)$raw);
        if ($val === '') {
            if (!empty($def['required'])) $errors[$name] = $label . ' is required.';
            $data[$col] = null;
            continue;
        }
        if (!empty($def['max']) && mb_strlen($val) > $def['max']) $errors[$name] = $label . ' must not exceed ' . $def['max'] . ' characters.';

        switch ($type) {
            case 'email':
                if (!filter_var($val, FILTER_VALIDATE_EMAIL)) $errors[$name] = 'Enter a valid email address.';
                break;
            case 'number':
                if (!preg_match('/^-?\d+$/', $val)) { $errors[$name] = $label . ' must be a whole number.'; break; }
                if (isset($def['min']) && $val < $def['min']) $errors[$name] = $label . ' must be at least ' . $def['min'] . '.';
                if (isset($def['max_value']) && $val > $def['max_value']) $errors[$name] = $label . ' must not be more than ' . $def['max_value'] . '.';
                $val = (int)$val;
                break;
            case 'decimal':
                if (!is_numeric($val)) { $errors[$name] = $label . ' must be a number.'; break; }
                if ($val < ($def['min'] ?? 0)) $errors[$name] = $label . ' must be at least ' . ($def['min'] ?? 0) . '.';
                $val = round((float)$val, 2);
                break;
            case 'date':
                $d = DateTime::createFromFormat('Y-m-d', $val);
                if (!$d || $d->format('Y-m-d') !== $val) { $errors[$name] = $label . ' must be a valid date.'; break; }
                if (!empty($def['not_future']) && $val > date('Y-m-d')) $errors[$name] = $label . ' cannot be in the future.';
                if (!empty($def['not_past']) && $val < date('Y-m-d') && !($isEdit && $existing && $existing[$col] == $val)) $errors[$name] = $label . ' cannot be in the past.';
                break;
            case 'time':
                if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/', $val)) $errors[$name] = $label . ' must be a valid time.';
                break;
            case 'select':
                if (!array_key_exists($val, crud_options($def))) $errors[$name] = 'Please choose a valid ' . strtolower($label) . '.';
                break;
        }
        if (!empty($def['unique']) && !isset($errors[$name])) {
            $dup = (int)db_val("SELECT COUNT(*) FROM {$cfg['table']} WHERE $col = ? AND {$cfg['pk']} <> ?", [$val, $id]);
            if ($dup > 0) $errors[$name] = $label . ' "' . $val . '" already exists.';
        }
        $data[$col] = $val;
    }
    // Resident accounts: force the owner column
    if (is_resident() && !empty($cfg['resident']['column'])) {
        $data[$cfg['resident']['column']] = (int)$GLOBALS['CURRENT_USER']['resident_id'];
    }
    return [$data, $errors];
}

// ---------------------------------------------------------------- saving
function crud_save($cfg) {
    global $conn;
    $id = (int)($_POST['id'] ?? 0);
    $isEdit = $id > 0;
    $existing = null;
    if ($isEdit) {
        $existing = crud_get($cfg, $id);
        if (!$existing || $cfg['no_edit'] || !crud_can($cfg, 'edit')) forbidden();
        if (crud_is_archived($cfg, $existing)) forbidden('Archived records cannot be edited. Restore the record first.');
        if (!empty($cfg['edit_locked']) && in_array($existing[$cfg['status_field']] ?? '', $cfg['edit_locked'])) forbidden('This record can no longer be edited.');
    } elseif (!crud_can($cfg, 'add')) {
        forbidden();
    }

    list($data, $errors) = crud_validate($cfg, $_POST, $id, $existing);
    if (!empty($cfg['validate'])) {
        $more = call_user_func($cfg['validate'], $data, $id, $existing);
        if (is_array($more)) $errors = array_merge($errors, $more);
    }
    if ($errors) {
        crud_form($cfg, $id, $_POST, $errors);
        return;
    }

    if (!$isEdit) {
        // automatic fields (record numbers, created_by, default status ...)
        foreach ($cfg['fields'] as $name => $def) {
            if (($def['type'] ?? '') !== 'auto') continue;
            $col = crud_col($name, $def);
            $data[$col] = isset($def['auto']) ? call_user_func($def['auto'], $data) : ($def['value'] ?? null);
        }
    }
    if (!empty($cfg['before_save'])) call_user_func_array($cfg['before_save'], [&$data, $id, $existing]);

    try {
        if ($isEdit) {
            $sets = [];
            $params = [];
            foreach ($data as $c => $v) { $sets[] = "$c = ?"; $params[] = $v; }
            $params[] = $id;
            if ($sets) db_exec("UPDATE {$cfg['table']} SET " . implode(', ', $sets) . " WHERE {$cfg['pk']} = ?", $params);
            $newId = $id;
        } else {
            $cols = array_keys($data);
            $marks = implode(',', array_fill(0, count($cols), '?'));
            $newId = db_exec("INSERT INTO {$cfg['table']} (" . implode(',', $cols) . ") VALUES ($marks)", array_values($data));
        }
    } catch (Exception $ex) {
        $errors['_'] = 'The record could not be saved: ' . $ex->getMessage();
        crud_form($cfg, $id, $_POST, $errors);
        return;
    }

    $row = crud_get($cfg, $newId);
    $ref = $row ? crud_ref($cfg, $row) : '#' . $newId;
    if ($isEdit) {
        log_activity('Update', 'Updated ' . $cfg['singular'] . ' ' . $ref, $cfg['table'] . '#' . $newId);
        if (!empty($cfg['after_update'])) call_user_func($cfg['after_update'], $newId, $data, $existing);
        flash('success', $cfg['singular'] . ' updated successfully.');
    } else {
        log_activity('Create', 'Created ' . $cfg['singular'] . ' ' . $ref, $cfg['table'] . '#' . $newId);
        if ($cfg['history'] && $row) add_history($cfg['table'], $newId, $row[$cfg['status_field']] ?? 'Created', 'Record created');
        if (!empty($cfg['after_create'])) call_user_func($cfg['after_create'], $newId, $data);
        flash('success', $cfg['singular'] . ' saved successfully.');
    }
    if ($cfg['after_save'] === 'view') redirect('?action=view&id=' . $newId);
    redirect('?');
}

// ---------------------------------------------------------------- archive / delete / workflow
function crud_archive($cfg, $restore) {
    $id = (int)($_POST['id'] ?? 0);
    $row = crud_get($cfg, $id);
    if (!$row || !$cfg['archive'] || !crud_can($cfg, 'archive')) forbidden();
    $new = $restore ? $cfg['archive']['restore'] : $cfg['archive']['value'];
    db_exec("UPDATE {$cfg['table']} SET {$cfg['status_field']} = ? WHERE {$cfg['pk']} = ?", [$new, $id]);
    if ($cfg['history']) add_history($cfg['table'], $id, $new, $restore ? 'Restored' : 'Archived');
    log_activity($restore ? 'Restore' : 'Archive', ($restore ? 'Restored ' : 'Archived ') . $cfg['singular'] . ' ' . crud_ref($cfg, $row), $cfg['table'] . '#' . $id);
    flash('success', $cfg['singular'] . ($restore ? ' restored.' : ' archived.'));
    redirect('?');
}
function crud_delete($cfg) {
    $id = (int)($_POST['id'] ?? 0);
    $row = crud_get($cfg, $id);
    if (!$row || !$cfg['delete'] || !crud_can($cfg, 'archive')) forbidden();
    try {
        db_exec("DELETE FROM {$cfg['table']} WHERE {$cfg['pk']} = ?", [$id]);
        log_activity('Delete', 'Deleted ' . $cfg['singular'] . ' ' . crud_ref($cfg, $row), $cfg['table'] . '#' . $id);
        flash('success', $cfg['singular'] . ' deleted.');
    } catch (Exception $ex) {
        flash('error', 'This record is used by other records and cannot be deleted.');
    }
    redirect('?');
}
// Is this workflow action available for this row and user?
function crud_action_ok($cfg, $act, $row) {
    global $CURRENT_USER;
    if (!in_array($row[$cfg['status_field']] ?? '', $act['from'])) return false;
    if (crud_is_archived($cfg, $row)) return false;
    if (is_resident()) {
        if (empty($act['resident'])) return false;
        if (empty($cfg['resident']['column']) || $row[$cfg['resident']['column']] != $CURRENT_USER['resident_id']) return false;
    } else {
        $roles = $act['roles'] ?? [];
        if (!in_array($CURRENT_USER['role'], $roles)) return false;
    }
    if (!empty($act['guard_show']) && !call_user_func($act['guard_show'], $row)) return false;
    return true;
}
function crud_act($cfg) {
    $id = (int)($_POST['id'] ?? 0);
    $key = $_POST['key'] ?? '';
    $remarks = trim($_POST['remarks'] ?? '');
    $row = crud_get($cfg, $id);
    if (!$row) forbidden();
    $act = null;
    foreach ($cfg['actions'] as $a) if ($a['key'] === $key) $act = $a;
    if (!$act || !crud_action_ok($cfg, $act, $row)) forbidden('This action is not available for this record.');
    if (($act['remarks'] ?? false) === 'required' && $remarks === '') {
        flash('error', 'Remarks are required for this action.');
        redirect('?action=view&id=' . $id);
    }
    if (!empty($act['guard'])) {
        $err = call_user_func($act['guard'], $row);
        if ($err) { flash('error', $err); redirect('?action=view&id=' . $id); }
    }
    $to = isset($act['to_fn']) ? call_user_func($act['to_fn'], $row) : $act['to'];
    $sets = [$cfg['status_field'] => $to];
    foreach (($act['set'] ?? []) as $col => $val) $sets[$col] = is_callable($val) ? call_user_func($val, $row) : $val;
    if ($cfg['remarks_field'] && $remarks !== '') $sets[$cfg['remarks_field']] = $remarks;

    $cols = [];
    $params = [];
    foreach ($sets as $c => $v) { $cols[] = "$c = ?"; $params[] = $v; }
    $params[] = $id;
    db_exec("UPDATE {$cfg['table']} SET " . implode(', ', $cols) . " WHERE {$cfg['pk']} = ?", $params);

    if ($cfg['history']) add_history($cfg['table'], $id, $to, $act['label'] . ($remarks ? ': ' . $remarks : ''));
    log_activity($act['label'], $act['label'] . ' - ' . $cfg['singular'] . ' ' . crud_ref($cfg, $row) . ' (now ' . $to . ')', $cfg['table'] . '#' . $id);

    $newRow = crud_get($cfg, $id);
    if (!empty($act['after'])) call_user_func($act['after'], $newRow, $remarks, $row);
    if (!empty($cfg['notify']) && ($act['notify'] ?? true)) {
        $n = call_user_func($cfg['notify'], $newRow, $to, $remarks, $act);
        if ($n) notify_resident($n['resident_id'], $n['title'], $n['message'], $n['channels'] ?? ['inapp', 'email', 'sms'], $n['link'] ?? '');
    }
    flash('success', $cfg['singular'] . ' ' . crud_ref($cfg, $row) . ': status is now "' . $to . '".');
    redirect($act['redirect'] ?? ('?action=view&id=' . $id));
}

// ---------------------------------------------------------------- list query
function crud_query_parts($cfg) {
    global $CURRENT_USER;
    $where = [];
    $params = [];
    if (is_resident()) {
        $r = $cfg['resident'];
        if (!empty($r['column'])) { $where[] = "t.{$r['column']} = ?"; $params[] = (int)$CURRENT_USER['resident_id']; }
        if (!empty($r['where'])) $where[] = '(' . $r['where'] . ')';
    }
    if ($cfg['where']) $where[] = '(' . $cfg['where'] . ')';

    $q = trim($_GET['q'] ?? '');
    if ($q !== '' && $cfg['search']) {
        $parts = [];
        foreach ($cfg['search'] as $col) { $parts[] = "$col LIKE ?"; $params[] = '%' . $q . '%'; }
        $where[] = '(' . implode(' OR ', $parts) . ')';
    }
    foreach ($cfg['fields'] as $name => $def) {
        if (empty($def['filter'])) continue;
        $v = $_GET[$name] ?? '';
        if ($v !== '') { $where[] = 't.' . crud_col($name, $def) . ' = ?'; $params[] = $v; }
    }
    if (!empty($cfg['date_filter'])) {
        if (!empty($_GET['from'])) { $where[] = "t.{$cfg['date_filter']} >= ?"; $params[] = $_GET['from']; }
        if (!empty($_GET['to']))   { $where[] = "t.{$cfg['date_filter']} <= ?"; $params[] = $_GET['to'] . ' 23:59:59'; }
    }
    // hide archived records unless the user filters by that status
    if ($cfg['archive'] && ($_GET[$cfg['status_field']] ?? '') === '') {
        $where[] = "t.{$cfg['status_field']} <> ?";
        $params[] = $cfg['archive']['value'];
    }
    return [$where ? ' WHERE ' . implode(' AND ', $where) : '', $params];
}
function crud_select($cfg) {
    $sel = 't.*';
    foreach ($cfg['computed'] as $k => $c) $sel .= ', (' . $c['sql'] . ') AS ' . $k;
    return $sel;
}

// ---------------------------------------------------------------- pages
function crud_page_start($cfg, $title, $crumbs = []) {
    $page_title = $title;
    $breadcrumb = array_merge([$cfg['title']], $crumbs);
    require __DIR__ . '/header.php';
}
function crud_page_end() {
    require __DIR__ . '/footer.php';
}

function crud_list($cfg) {
    list($whereSql, $params) = crud_query_parts($cfg);
    $from = "{$cfg['table']} t {$cfg['joins']}";
    $total = (int)db_val("SELECT COUNT(*) FROM $from $whereSql", $params);
    $perPage = $cfg['per_page'];
    $pages = max(1, (int)ceil($total / $perPage));
    $page = min(max(1, (int)($_GET['page'] ?? 1)), $pages);
    $rows = db_all("SELECT " . crud_select($cfg) . " FROM $from $whereSql ORDER BY {$cfg['order']} LIMIT $perPage OFFSET " . (($page - 1) * $perPage), $params);

    crud_page_start($cfg, $cfg['title']);
    if (!empty($cfg['intro'])) echo '<p class="help" style="font-size:13px">' . e($cfg['intro']) . '</p>';
    if (!empty($cfg['list_top'])) call_user_func($cfg['list_top']);

    // status chips with counts
    $sf = $cfg['status_field'];
    if ($cfg['status_chips'] && isset($cfg['fields'][$sf])) {
        list($wSql, $wParams) = crud_query_parts(array_merge($cfg, ['search' => [], 'archive' => null, 'fields' => [], 'date_filter' => null]));
        $counts = db_pairs("SELECT t.$sf, COUNT(*) FROM $from $wSql GROUP BY t.$sf", $wParams);
        $cur = $_GET[$sf] ?? '';
        echo '<div class="chips"><a class="' . ($cur === '' ? 'on' : '') . '" href="?">All</a>';
        $chipOpts = crud_options($cfg['fields'][$sf]);
        if ($cfg['archive'] && !isset($chipOpts[$cfg['archive']['value']])) $chipOpts[$cfg['archive']['value']] = $cfg['archive']['value'];
        foreach ($chipOpts as $val => $label) {
            $n = $counts[$val] ?? 0;
            if ($n == 0 && $cur !== (string)$val) continue;
            echo '<a class="' . ($cur === (string)$val ? 'on' : '') . '" href="?' . $sf . '=' . urlencode($val) . '">' . e($label) . ' (' . $n . ')</a>';
        }
        echo '</div>';
    }

    // toolbar: search + filters + add button
    echo '<div class="card"><form method="get" class="filters">';
    if ($cfg['search']) echo '<input type="text" name="q" placeholder="Search..." value="' . e($_GET['q'] ?? '') . '">';
    foreach ($cfg['fields'] as $name => $def) {
        if (empty($def['filter'])) continue;
        echo '<select name="' . e($name) . '"><option value="">All ' . e($def['label']) . '</option>';
        foreach (crud_options($def) as $v => $l) echo '<option value="' . e($v) . '"' . (($_GET[$name] ?? '') === (string)$v ? ' selected' : '') . '>' . e($l) . '</option>';
        echo '</select>';
    }
    if (!empty($cfg['date_filter'])) {
        echo '<input type="date" name="from" value="' . e($_GET['from'] ?? '') . '" title="From"><input type="date" name="to" value="' . e($_GET['to'] ?? '') . '" title="To">';
    }
    echo '<button class="btn btn-small" type="submit">Search / Filter</button><a class="btn btn-small btn-outline" href="?">Reset</a>';
    echo '</form>';
    echo '<div class="toolbar"><span class="help">' . $total . ' record(s)</span><span>';
    if ($cfg['export'] && !is_resident()) echo '<a class="btn btn-small btn-outline" href="?action=export&' . e($_SERVER['QUERY_STRING'] ?? '') . '">Export CSV</a> ';
    if (crud_can($cfg, 'add')) echo '<a class="btn btn-small" href="?action=add">+ Add ' . e($cfg['singular']) . '</a>';
    echo '</span></div>';

    // table
    echo '<div class="table-wrap"><table><thead><tr>';
    foreach ($cfg['columns'] as $c) echo '<th>' . e(crud_label($cfg, $c)) . '</th>';
    echo '<th>Actions</th></tr></thead><tbody>';
    if (!$rows) echo '<tr><td class="empty" colspan="' . (count($cfg['columns']) + 1) . '">No records found.</td></tr>';
    foreach ($rows as $row) {
        $id = $row[$cfg['pk']];
        echo '<tr>';
        foreach ($cfg['columns'] as $i => $c) {
            $html = crud_display($cfg, $c, $row);
            echo '<td>' . ($i === 0 ? '<a href="?action=view&id=' . $id . '"><strong>' . $html . '</strong></a>' : $html) . '</td>';
        }
        echo '<td class="actions"><a class="btn btn-small btn-outline" href="?action=view&id=' . $id . '">View</a> ';
        $archived = crud_is_archived($cfg, $row);
        if (crud_can($cfg, 'edit') && !$cfg['no_edit'] && !$archived && !(!empty($cfg['edit_locked']) && in_array($row[$sf] ?? '', $cfg['edit_locked'])))
            echo '<a class="btn btn-small btn-outline" href="?action=edit&id=' . $id . '">Edit</a> ';
        crud_post_button($cfg, $id, 'archive', 'Archive', $archived);
        crud_post_button($cfg, $id, 'restore', 'Restore', !$archived);
        echo crud_link_buttons($cfg, $row, 'btn btn-small btn-outline');
        echo '</td></tr>';
    }
    echo '</tbody></table></div>';

    // pager
    if ($pages > 1) {
        echo '<div class="pager">';
        for ($p = 1; $p <= $pages; $p++) {
            $qs = http_build_query(array_merge($_GET, ['page' => $p]));
            echo $p == $page ? '<span>' . $p . '</span>' : '<a href="?' . e($qs) . '">' . $p . '</a>';
        }
        echo '</div>';
    }
    echo '</div>';
    crud_page_end();
}

// extra link buttons (Print, Record Payment ...). Each link: label, url(fn row => url|null), roles (optional), resident (optional)
function crud_link_buttons($cfg, $row, $class) {
    global $CURRENT_USER;
    $html = '';
    foreach ($cfg['links'] as $lk) {
        if (is_resident()) { if (empty($lk['resident'])) continue; }
        elseif (isset($lk['roles']) && !in_array($CURRENT_USER['role'], $lk['roles'])) continue;
        $url = call_user_func($lk['url'], $row);
        if ($url) $html .= '<a class="' . $class . '" href="' . e($url) . '"' . (!empty($lk['blank']) ? ' target="_blank"' : '') . '>' . e($lk['label']) . '</a> ';
    }
    return $html;
}

// small POST button for archive / restore / delete
function crud_post_button($cfg, $id, $kind, $label, $hide) {
    if ($hide) return;
    if ($kind === 'archive' || $kind === 'restore') {
        if (!$cfg['archive'] || !crud_can($cfg, 'archive')) return;
    }
    if ($kind === 'delete' && (!$cfg['delete'] || !crud_can($cfg, 'archive'))) return;
    $msg = $kind === 'restore' ? 'Restore this record?' : ($kind === 'delete' ? 'Permanently delete this record? This cannot be undone.' : 'Archive this record? It will be hidden from the normal list.');
    echo '<form method="post" class="inline-form" onsubmit="return confirmAction(\'' . e($msg) . '\', this)">' . csrf_field()
        . '<input type="hidden" name="do" value="' . $kind . '"><input type="hidden" name="id" value="' . (int)$id . '">'
        . '<button class="btn btn-small ' . ($kind === 'restore' ? 'btn-green' : 'btn-red') . '" type="submit">' . e($label) . '</button></form> ';
}

function crud_form($cfg, $id = 0, $old = null, $errors = []) {
    $isEdit = $id > 0;
    $row = null;
    if ($isEdit) {
        $row = crud_get($cfg, $id);
        if (!$row || $cfg['no_edit'] || !crud_can($cfg, 'edit')) forbidden();
        if (crud_is_archived($cfg, $row)) forbidden('Archived records cannot be edited. Restore the record first.');
        if (!empty($cfg['edit_locked']) && in_array($row[$cfg['status_field']] ?? '', $cfg['edit_locked'])) forbidden('This record can no longer be edited.');
    } elseif (!crud_can($cfg, 'add')) {
        forbidden();
    }
    $values = $old ?? ($row ?? []);
    crud_page_start($cfg, ($isEdit ? 'Edit ' : 'Add ') . $cfg['singular'], [$isEdit ? 'Edit' : 'Add']);
    if (!empty($cfg['form_top'])) call_user_func($cfg['form_top']);
    if ($errors) {
        echo '<div class="alert alert-error"><strong>Please fix the following:</strong><ul style="margin:6px 0 0 18px">';
        foreach ($errors as $m) echo '<li>' . e($m) . '</li>';
        echo '</ul></div>';
    }
    echo '<div class="card"><form method="post" enctype="multipart/form-data" autocomplete="off">' . csrf_field();
    echo '<input type="hidden" name="do" value="save"><input type="hidden" name="id" value="' . (int)$id . '">';
    echo '<div class="form-grid">';
    foreach (crud_form_fields($cfg, $isEdit) as $name => $def) {
        $type = $def['type'] ?? 'text';
        $col = crud_col($name, $def);
        if ($old !== null) $val = $old[$name] ?? '';
        elseif ($row) $val = $row[$col] ?? '';
        else $val = $_GET[$name] ?? ($def['default'] ?? '');
        if ($type === 'hidden') {
            echo '<input type="hidden" name="' . e($name) . '" value="' . e($val) . '">';
            continue;
        }
        $full = in_array($type, ['textarea', 'checkboxes']) || !empty($def['full']);
        echo '<div class="form-group' . ($full ? ' full' : '') . (isset($errors[$name]) ? ' has-error' : '') . '">';
        echo '<label>' . e($def['label']) . (!empty($def['required']) ? ' <span class="req">*</span>' : '') . '</label>';
        $req = '';
        $ph = !empty($def['placeholder']) ? ' placeholder="' . e($def['placeholder']) . '"' : '';
        $ml = !empty($def['max']) ? ' maxlength="' . (int)$def['max'] . '"' : '';
        switch ($type) {
            case 'textarea':
                echo '<textarea name="' . e($name) . '"' . $ph . '>' . e($val) . '</textarea>';
                break;
            case 'select':
                echo '<select name="' . e($name) . '"><option value="">-- Select --</option>';
                foreach (crud_options($def) as $v => $l) echo '<option value="' . e($v) . '"' . ((string)$val === (string)$v ? ' selected' : '') . '>' . e($l) . '</option>';
                echo '</select>';
                break;
            case 'checkbox':
                echo '<label class="checks"><input type="checkbox" name="' . e($name) . '" value="1"' . ($val ? ' checked' : '') . '> Yes</label>';
                break;
            case 'checkboxes':
                $picked = $old !== null ? (array)($old[$name] ?? []) : explode(',', (string)$val);
                echo '<div class="checks">';
                foreach (crud_options($def) as $v => $l) echo '<label><input type="checkbox" name="' . e($name) . '[]" value="' . e($v) . '"' . (in_array((string)$v, $picked) ? ' checked' : '') . '> ' . e($l) . '</label>';
                echo '</div>';
                break;
            case 'file':
                echo '<input type="file" name="' . e($name) . '">';
                if ($isEdit && $val) echo '<div class="help">Current file: ' . file_link($val) . ' (upload a new one to replace it)</div>';
                break;
            case 'password':
                echo '<input type="password" name="' . e($name) . '" autocomplete="new-password">';
                break;
            case 'decimal':
                echo '<input type="number" step="0.01" min="' . e($def['min'] ?? 0) . '" name="' . e($name) . '" value="' . e($val) . '">';
                break;
            case 'number':
                echo '<input type="number" name="' . e($name) . '" value="' . e($val) . '"' . (isset($def['min']) ? ' min="' . (int)$def['min'] . '"' : '') . (isset($def['max_value']) ? ' max="' . (int)$def['max_value'] . '"' : '') . '>';
                break;
            case 'date':
            case 'time':
            case 'email':
                echo '<input type="' . $type . '" name="' . e($name) . '" value="' . e($val) . '"' . $ph . '>';
                break;
            default:
                echo '<input type="text" name="' . e($name) . '" value="' . e($val) . '"' . $ph . $ml . '>';
        }
        if (!empty($def['help'])) echo '<div class="help">' . e($def['help']) . '</div>';
        if (isset($errors[$name])) echo '<div class="field-error">' . e($errors[$name]) . '</div>';
        echo '</div>';
    }
    echo '</div><p style="margin-top:16px"><button class="btn" type="submit">Save ' . e($cfg['singular']) . '</button> <a class="btn btn-outline" href="?">Cancel</a></p>';
    echo '</form></div>';
    crud_page_end();
}

function crud_view($cfg, $id) {
    $row = crud_get($cfg, $id);
    if (!$row) forbidden('Record not found or you are not allowed to see it.');
    if ($cfg['log_view']) log_activity('View', 'Viewed ' . $cfg['singular'] . ' ' . crud_ref($cfg, $row), $cfg['table'] . '#' . $id);
    $sf = $cfg['status_field'];
    crud_page_start($cfg, $cfg['singular'] . ' ' . crud_ref($cfg, $row), ['Details']);

    echo '<div class="card"><div class="action-bar">';
    echo '<a class="btn btn-outline" href="?">&laquo; Back to list</a>';
    $archived = crud_is_archived($cfg, $row);
    if (crud_can($cfg, 'edit') && !$cfg['no_edit'] && !$archived && !(!empty($cfg['edit_locked']) && in_array($row[$sf] ?? '', $cfg['edit_locked'])))
        echo '<a class="btn" href="?action=edit&id=' . $id . '">Edit</a>';
    echo crud_link_buttons($cfg, $row, 'btn btn-outline');
    crud_post_button($cfg, $id, 'archive', 'Archive', $archived);
    crud_post_button($cfg, $id, 'restore', 'Restore', !$archived);
    crud_post_button($cfg, $id, 'delete', 'Delete', false);
    echo '</div>';

    // workflow buttons (only the ones this user may press right now)
    $buttons = '';
    foreach ($cfg['actions'] as $act) {
        if (!crud_action_ok($cfg, $act, $row)) continue;
        $rem = $act['remarks'] ?? false;
        $buttons .= '<form method="post" class="inline-form" ' . (!$rem ? 'onsubmit="return confirmAction(\'' . e($act['label']) . '?\', this)"' : '') . '>' . csrf_field()
            . '<input type="hidden" name="do" value="act"><input type="hidden" name="id" value="' . (int)$id . '"><input type="hidden" name="key" value="' . e($act['key']) . '"><input type="hidden" name="remarks" value="">'
            . '<button class="btn ' . e($act['class'] ?? '') . '" type="submit" data-label="' . e($act['label']) . '"' . ($rem ? ' onclick="return askRemarks(this, ' . ($rem === 'required' ? 'true' : 'false') . ')"' : '') . '>' . e($act['label']) . '</button></form> ';
    }
    if ($buttons) echo '<div class="action-bar"><strong>Process:</strong> ' . $buttons . '</div>';

    echo '<dl class="detail">';
    foreach ($cfg['fields'] as $name => $def) {
        if (($def['type'] ?? '') === 'password' || ($def['view'] ?? true) === false) continue;
        $html = crud_display($cfg, $name, $row);
        echo '<dt>' . e($def['label']) . '</dt><dd>' . ($html === '' ? '<span class="help">&mdash;</span>' : $html) . '</dd>';
    }
    $shown = array_column($cfg['fields'], 'label');
    foreach ($cfg['computed'] as $k => $c) {
        if (!empty($c['hide_in_view']) || in_array($c['label'], $shown)) continue;   // skip duplicates of fields already shown
        echo '<dt>' . e($c['label']) . '</dt><dd>' . crud_display($cfg, $k, $row) . '</dd>';
    }
    echo '</dl></div>';

    if ($cfg['history']) {
        $hist = db_all("SELECT h.*, u.full_name FROM status_history h LEFT JOIN users u ON u.id = h.user_id WHERE h.ref_table = ? AND h.ref_id = ? ORDER BY h.id DESC", [$cfg['table'], $id]);
        echo '<div class="card"><h3>Status Timeline</h3><ul class="timeline">';
        foreach ($hist as $h) {
            echo '<li>' . badge($h['status']) . ' ' . e($h['remarks']) . '<small>' . e(date('M d, Y h:i A', strtotime($h['created_at']))) . ' &middot; ' . e($h['full_name'] ?? 'System') . '</small></li>';
        }
        if (!$hist) echo '<li>No history yet.</li>';
        echo '</ul></div>';
    }
    if (!empty($cfg['view_extra'])) call_user_func($cfg['view_extra'], $row);
    crud_page_end();
}

function crud_export($cfg) {
    if (!$cfg['export'] || is_resident()) forbidden();
    list($whereSql, $params) = crud_query_parts($cfg);
    $rows = db_all("SELECT " . crud_select($cfg) . " FROM {$cfg['table']} t {$cfg['joins']} $whereSql ORDER BY {$cfg['order']}", $params);
    log_activity('Export', 'Exported ' . $cfg['title'] . ' to CSV (' . count($rows) . ' rows)', $cfg['table']);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $cfg['table'] . '_' . date('Ymd') . '.csv"');
    $out = fopen('php://output', 'w');
    $head = [];
    foreach ($cfg['columns'] as $c) $head[] = crud_label($cfg, $c);
    fputcsv($out, $head);
    foreach ($rows as $row) {
        $line = [];
        foreach ($cfg['columns'] as $c) $line[] = crud_plain($cfg, $c, $row);
        fputcsv($out, $line);
    }
    exit;
}

// ---------------------------------------------------------------- entry point
function crud_run($cfg) {
    $cfg = crud_defaults($cfg);
    if (!crud_can($cfg, 'view')) forbidden();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        switch ($_POST['do'] ?? '') {
            case 'save':    crud_save($cfg); return;
            case 'archive': crud_archive($cfg, false); return;
            case 'restore': crud_archive($cfg, true); return;
            case 'delete':  crud_delete($cfg); return;
            case 'act':     crud_act($cfg); return;
        }
        forbidden('Unknown request.');
    }
    $action = $_GET['action'] ?? 'list';
    switch ($action) {
        case 'add':    crud_form($cfg, 0); break;
        case 'edit':   crud_form($cfg, (int)($_GET['id'] ?? 0)); break;
        case 'view':   crud_view($cfg, (int)($_GET['id'] ?? 0)); break;
        case 'export': crud_export($cfg); break;
        default:       crud_list($cfg);
    }
}
