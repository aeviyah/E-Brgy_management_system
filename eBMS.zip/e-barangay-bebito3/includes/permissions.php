<?php
// ROLES AND PERMISSIONS
$ROLE_LABELS = [
    'admin'     => 'System Administrator',
    'secretary' => 'Barangay Secretary',
    'treasurer' => 'Barangay Treasurer',
    'captain'   => 'Punong Barangay',
    'staff'     => 'Barangay Staff',
    'resident'  => 'Resident',
];

// $manage = roles that can add/edit/archive. $view = roles that can only look.
function acl($manage, $view = []) {
    return ['manage' => $manage, 'view' => array_merge($manage, $view)];
}

// Every module and who can use it. (Barangay Staff only gets modules assigned to them in Settings > Users.)
$MODULES = [
    'residents'        => ['label' => 'Residents',                 'acl' => acl(['admin','secretary'], ['captain'])],
    'households'       => ['label' => 'Households',                'acl' => acl(['admin','secretary'], ['captain'])],
    'puroks'           => ['label' => 'Purok/Sitio',               'acl' => acl(['admin','secretary'], ['captain'])],
    'documents'        => ['label' => 'Document Catalog',          'acl' => acl(['admin','secretary'], ['captain','treasurer'])],
    'doc_requests'     => ['label' => 'Document Requests',         'acl' => acl(['admin','secretary'], ['captain','treasurer'])],
    'permits'          => ['label' => 'Business Clearance',        'acl' => acl(['admin','secretary'], ['captain','treasurer'])],
    'services'         => ['label' => 'Service Catalog',           'acl' => acl(['admin','secretary'], ['captain'])],
    'service_requests' => ['label' => 'Service Requests',          'acl' => acl(['admin','secretary'], ['captain'])],
    'complaints'       => ['label' => 'Complaints & Blotter',      'acl' => acl(['admin','secretary','captain'])],
    'katarungan'       => ['label' => 'Katarungang Pambarangay',   'acl' => acl(['admin','secretary','captain'])],
    'peace_order'      => ['label' => 'Peace & Order / Tanod',     'acl' => acl(['admin','secretary'], ['captain'])],
    'bcpc'             => ['label' => 'BCPC / Child Protection',   'acl' => acl(['secretary','captain'])],
    'vawc'             => ['label' => 'VAWC (Restricted)',         'acl' => acl(['secretary','captain'])],
    'officials'        => ['label' => 'Officials & Personnel',     'acl' => acl(['admin','secretary'], ['captain','treasurer'])],
    'treasury'         => ['label' => 'Treasury & Fees',           'acl' => acl(['admin','treasurer'], ['secretary','captain'])],
    'payments'         => ['label' => 'Payments',                  'acl' => acl(['admin','treasurer'], ['secretary','captain'])],
    'receipts'         => ['label' => 'Official Receipts',         'acl' => acl(['admin','treasurer'], ['secretary','captain'])],
    'budget'           => ['label' => 'Budget & Disbursement',     'acl' => acl(['admin','treasurer'], ['secretary','captain'])],
    'communication'    => ['label' => 'Communication Center',      'acl' => acl(['admin','secretary'], ['captain'])],
    'announcements'    => ['label' => 'Announcements',             'acl' => acl(['admin','secretary'], ['captain','treasurer'])],
    'events'           => ['label' => 'Events & Activities',       'acl' => acl(['admin','secretary'], ['captain','treasurer'])],
    'assembly'         => ['label' => 'Barangay Assembly',         'acl' => acl(['admin','secretary'], ['captain','treasurer'])],
    'meetings'         => ['label' => 'Meetings & Minutes',        'acl' => acl(['admin','secretary'], ['captain','treasurer'])],
    'ordinances'       => ['label' => 'Ordinances & Resolutions',  'acl' => acl(['admin','secretary'], ['captain','treasurer'])],
    'projects'         => ['label' => 'Development & Projects',    'acl' => acl(['admin','captain'], ['secretary','treasurer'])],
    'facilities'       => ['label' => 'Facilities',                'acl' => acl(['admin','secretary'], ['captain'])],
    'reservations'     => ['label' => 'Reservations',              'acl' => acl(['admin','secretary'], ['captain'])],
    'assets'           => ['label' => 'Assets & Inventory',        'acl' => acl(['admin','secretary'], ['captain','treasurer'])],
    'environment'      => ['label' => 'Environment & Sanitation',  'acl' => acl(['admin','secretary'], ['captain'])],
    'assistance'       => ['label' => 'Community Assistance',      'acl' => acl(['admin','secretary'], ['captain'])],
    'reports'          => ['label' => 'Reports & Analytics',       'acl' => acl([], ['admin','secretary','treasurer','captain'])],
    'audit'            => ['label' => 'Audit Trail',               'acl' => acl([], ['admin','captain'])],
    'backup'           => ['label' => 'Backup & Data',             'acl' => acl(['admin'])],
    'settings'         => ['label' => 'Settings & Users',          'acl' => acl(['admin'])],
];

// Can the logged-in user use this module?  $ability = 'view' or 'manage'
function user_can($module, $ability = 'view') {
    global $CURRENT_USER, $MODULES;
    if (!$CURRENT_USER || !isset($MODULES[$module])) return false;
    $role = $CURRENT_USER['role'];
    if ($role === 'resident') return false;      // residents use their own pages
    $acl = $MODULES[$module]['acl'];
    if (in_array($role, $acl['manage'])) return true;
    if ($ability === 'view' && in_array($role, $acl['view'])) return true;
    // Staff: only assigned modules (they can view and add/edit, but not archive)
    if ($role === 'staff') {
        $assigned = array_map('trim', explode(',', (string)$CURRENT_USER['assigned_modules']));
        if (in_array($module, $assigned)) return true;
    }
    return false;
}

// Modules that can be assigned to Barangay Staff (shown as checkboxes in the user form)
function staff_module_options() {
    global $MODULES;
    $out = [];
    foreach ($MODULES as $key => $m) {
        if (in_array($key, ['settings', 'backup', 'audit', 'reports'])) continue;
        $out[$key] = $m['label'];
    }
    return $out;
}
