<?php
// AUDIT TRAIL - who did what and when
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'audit', 'title' => 'Audit Trail', 'singular' => 'Log Entry', 'table' => 'activity_logs',
    'ref' => 'id', 'order' => 't.id DESC', 'no_add' => true, 'no_edit' => true, 'per_page' => 25, 'date_filter' => 'created_at', 'status_chips' => false,
    'search' => ['t.username', 't.action', 't.description', 't.record_ref'],
    'fields' => [
        'created_at'  => ['label' => 'Date / Time'],
        'username'    => ['label' => 'User', 'filter' => true, 'type' => 'select', 'options' => db_pairs("SELECT DISTINCT username, username FROM activity_logs WHERE username IS NOT NULL ORDER BY username")],
        'action'      => ['label' => 'Action', 'type' => 'select', 'filter' => true, 'badge' => true, 'options' => db_pairs("SELECT DISTINCT action, action FROM activity_logs ORDER BY action")],
        'description' => ['label' => 'Description'],
        'record_ref'  => ['label' => 'Affected Record'],
        'ip_address'  => ['label' => 'IP Address'],
    ],
    'columns' => ['created_at', 'username', 'action', 'description', 'record_ref'],
    'intro' => 'Read-only. Logins, creates, updates, approvals, payments, archives, exports and views of restricted records are recorded here.',
];
crud_run($cfg);
