<?php
// EVENTS & ACTIVITIES: Create (Draft) > Publish > Registration > Attendance > Completed (history)
require_once '../auth.php';
require_once '../includes/crud.php';

$a = ['admin', 'secretary'];
$cfg = [
    'module' => 'events', 'title' => 'Events & Activities', 'singular' => 'Event', 'table' => 'events',
    'ref' => 'name', 'order' => 't.event_date DESC', 'after_save' => 'view', 'date_filter' => 'event_date',
    'archive' => ['value' => 'Archived', 'restore' => 'Draft'],
    'search' => ['t.name', 't.location', 't.organizer'],
    'resident' => ['column' => null, 'where' => "t.status IN ('Published','Completed')"],
    'fields' => [
        'name'               => ['label' => 'Event Name', 'required' => true, 'max' => 150, 'full' => true],
        'event_date'         => ['label' => 'Date', 'type' => 'date', 'required' => true],
        'event_time'         => ['label' => 'Time', 'type' => 'time'],
        'location'           => ['label' => 'Location', 'required' => true, 'max' => 150],
        'organizer'          => ['label' => 'Organizer', 'max' => 100],
        'allow_registration' => ['label' => 'Allow Registration', 'type' => 'select', 'required' => true, 'default' => 'Yes', 'options' => opts(['Yes', 'No'])],
        'description'        => ['label' => 'Description', 'type' => 'textarea'],
        'status'             => ['label' => 'Status', 'type' => 'auto', 'value' => 'Draft', 'options' => opts(['Draft', 'Published', 'Completed', 'Cancelled', 'Archived'])],
    ],
    'columns' => ['name', 'event_date', 'event_time', 'location', 'organizer', 'status'],
    'actions' => [
        ['key' => 'publish', 'label' => 'Publish', 'from' => ['Draft'], 'to' => 'Published', 'roles' => $a, 'class' => 'btn-green'],
        ['key' => 'complete', 'label' => 'Mark Completed', 'from' => ['Published'], 'to' => 'Completed', 'roles' => $a, 'class' => 'btn-green'],
        ['key' => 'cancel', 'label' => 'Cancel Event', 'from' => ['Draft', 'Published'], 'to' => 'Cancelled', 'roles' => $a, 'class' => 'btn-red', 'remarks' => 'optional'],
    ],
    'view_extra' => function ($ev) {
        global $CURRENT_USER;
        $parts = db_all("SELECT p.*, r.resident_no, r.first_name, r.last_name FROM event_participants p JOIN residents r ON r.id = p.resident_id WHERE p.event_id = ? ORDER BY r.last_name", [$ev['id']]);
        echo '<div class="card"><h3>Registration &amp; Attendance (' . count($parts) . ')</h3>';
        if (is_resident()) {
            $mine = db_one("SELECT id FROM event_participants WHERE event_id = ? AND resident_id = ?", [$ev['id'], $CURRENT_USER['resident_id']]);
            if ($ev['status'] === 'Published' && $ev['allow_registration'] === 'Yes') {
                echo '<form method="post" action="participants.php">' . csrf_field() . '<input type="hidden" name="event_id" value="' . $ev['id'] . '"><input type="hidden" name="do" value="' . ($mine ? 'unregister' : 'register') . '">'
                   . '<button class="btn ' . ($mine ? 'btn-red' : 'btn-green') . '">' . ($mine ? 'Cancel my registration' : 'Register for this event') . '</button></form>';
            } else echo '<p class="help">Registration is closed for this event.</p>';
            echo '<p>' . ($mine ? badge('Registered') : '') . '</p></div>';
            return;
        }
        echo '<div class="table-wrap"><table><tr><th>Resident</th><th>Registered</th><th>Attended</th><th></th></tr>';
        foreach ($parts as $p) {
            echo '<tr><td>' . e($p['last_name'] . ', ' . $p['first_name']) . ' (' . e($p['resident_no']) . ')</td><td>' . e(fdate($p['registered_at'])) . '</td><td>' . ($p['attended'] ? badge('Present') : badge('Pending')) . '</td><td>';
            if (user_can('events', 'manage')) echo '<form method="post" action="participants.php" class="inline-form">' . csrf_field() . '<input type="hidden" name="event_id" value="' . $ev['id'] . '"><input type="hidden" name="participant_id" value="' . $p['id'] . '"><input type="hidden" name="do" value="attend"><button class="btn btn-small btn-outline">' . ($p['attended'] ? 'Undo attendance' : 'Mark present') . '</button></form>';
            echo '</td></tr>';
        }
        if (!$parts) echo '<tr><td colspan="4" class="empty">No registrations yet.</td></tr>';
        echo '</table></div>';
        if (user_can('events', 'manage') && $ev['status'] === 'Published') {
            echo '<form method="post" action="participants.php" class="filters" style="margin-top:10px">' . csrf_field() . '<input type="hidden" name="event_id" value="' . $ev['id'] . '"><input type="hidden" name="do" value="add_resident">'
               . '<select name="resident_id">';
            foreach (db_pairs(resident_label_sql()) as $id => $l) echo '<option value="' . $id . '">' . e($l) . '</option>';
            echo '</select><button class="btn btn-small">Add participant (walk-in)</button></form>';
        }
        echo '</div>';
    },
];
crud_run($cfg);
