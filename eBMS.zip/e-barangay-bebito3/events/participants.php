<?php
// Small handler for event registration and attendance buttons
require_once '../auth.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('index.php');
$eid = (int)($_POST['event_id'] ?? 0);
$ev = db_one("SELECT * FROM events WHERE id = ?", [$eid]);
if (!$ev) forbidden('Event not found.');
$do = $_POST['do'] ?? '';
$back = 'index.php?action=view&id=' . $eid;

if (is_resident()) {
    $rid = (int)$CURRENT_USER['resident_id'];
    if ($ev['status'] !== 'Published' || $ev['allow_registration'] !== 'Yes') forbidden('Registration is closed.');
    if ($do === 'register') {
        if (!db_one("SELECT id FROM event_participants WHERE event_id = ? AND resident_id = ?", [$eid, $rid])) {
            if (($CURRENT_RESIDENT['status'] ?? '') !== 'Active') { flash('error', 'Only verified residents can register.'); redirect($back); }
            db_exec("INSERT INTO event_participants (event_id, resident_id) VALUES (?,?)", [$eid, $rid]);
            log_activity('Create', 'Registered for event ' . $ev['name'], 'events#' . $eid);
            flash('success', 'You are registered for ' . $ev['name'] . '.');
        }
    } elseif ($do === 'unregister') {
        db_exec("DELETE FROM event_participants WHERE event_id = ? AND resident_id = ? AND attended = 0", [$eid, $rid]);
        flash('success', 'Registration cancelled.');
    }
    redirect($back);
}
require_module('events', 'manage');
if ($do === 'attend') {
    db_exec("UPDATE event_participants SET attended = 1 - attended WHERE id = ? AND event_id = ?", [(int)$_POST['participant_id'], $eid]);
    log_activity('Update', 'Updated attendance for event ' . $ev['name'], 'events#' . $eid);
    flash('success', 'Attendance updated.');
} elseif ($do === 'add_resident') {
    $rid = (int)($_POST['resident_id'] ?? 0);
    if ($rid && !db_one("SELECT id FROM event_participants WHERE event_id = ? AND resident_id = ?", [$eid, $rid])) {
        db_exec("INSERT INTO event_participants (event_id, resident_id) VALUES (?,?)", [$eid, $rid]);
        flash('success', 'Participant added.');
    } else flash('error', 'Resident is already registered.');
}
redirect($back);
