<?php
// ROLES & PERMISSIONS - read-only table of who can use each module
require_once '../auth.php';
require_module('settings');
$page_title = 'Roles & Permissions';
$breadcrumb = ['Settings', 'Roles & Permissions'];
require '../includes/header.php';
$roles = ['admin', 'secretary', 'treasurer', 'captain'];
?>
<div class="card"><p class="help">M = manage (add/edit/archive/process), V = view only. Barangay Staff only get the modules assigned to them in <a href="users.php">Users</a> (view/add/edit, no archive). Residents only use their own pages (profile, requests, payments, announcements...).</p>
<div class="table-wrap"><table><tr><th>Module</th><?php foreach ($roles as $r) echo '<th>' . e($ROLE_LABELS[$r]) . '</th>'; ?><th>Staff (assigned)</th></tr>
<?php foreach ($MODULES as $key => $m): ?>
    <tr><td><?= e($m['label']) ?></td>
    <?php foreach ($roles as $r) echo '<td>' . (in_array($r, $m['acl']['manage']) ? '<strong>M</strong>' : (in_array($r, $m['acl']['view']) ? 'V' : '-')) . '</td>'; ?>
    <td><?= isset(staff_module_options()[$key]) ? 'if assigned' : '-' ?></td></tr>
<?php endforeach; ?>
</table></div></div>
<?php require '../includes/footer.php'; ?>
