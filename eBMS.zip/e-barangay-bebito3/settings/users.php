<?php
// USERS & ROLES (System Administrator only)
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'settings', 'title' => 'Users', 'singular' => 'User', 'table' => 'users',
    'ref' => 'username', 'order' => 't.role, t.username', 'export' => false,
    'search' => ['t.username', 't.full_name', 't.email'],
    'intro' => 'Create accounts and choose roles. For Barangay Staff, tick the modules they may use. For Resident accounts, link the resident record.',
    'fields' => [
        'username'  => ['label' => 'Username', 'required' => true, 'unique' => true, 'max' => 50],
        'password'  => ['label' => 'Password', 'type' => 'password', 'column' => 'password_hash', 'help' => 'Min 8 characters. When editing, leave blank to keep the old password.'],
        'full_name' => ['label' => 'Full Name', 'required' => true, 'max' => 120],
        'email'     => ['label' => 'Email', 'type' => 'email', 'max' => 120],
        'contact_no' => ['label' => 'Contact No.', 'max' => 20],
        'role'      => ['label' => 'Role', 'type' => 'select', 'required' => true, 'filter' => true, 'options' => $ROLE_LABELS],
        'resident_id' => ['label' => 'Linked Resident (for Resident role)', 'type' => 'select', 'sql' => resident_label_sql()],
        'assigned_modules' => ['label' => 'Assigned Modules (for Barangay Staff)', 'type' => 'checkboxes', 'options' => staff_module_options(), 'list' => false],
        'status'    => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Active', 'options' => opts(['Active', 'Inactive']), 'filter' => true],
    ],
    'computed' => [
        'last' => ['label' => 'Last Login', 'sql' => 't.last_login'],
    ],
    'columns' => ['username', 'full_name', 'role', 'email', 'last', 'status'],
    'validate' => function ($d, $id) {
        global $CURRENT_USER;
        $err = [];
        if (($d['role'] ?? '') === 'resident' && empty($d['resident_id'])) $err['resident_id'] = 'Choose the resident record for a Resident account.';
        if (($d['role'] ?? '') !== 'resident' && !empty($d['resident_id'])) $err['resident_id'] = 'Only Resident accounts should be linked to a resident.';
        if ($id == $CURRENT_USER['id'] && (($d['status'] ?? '') !== 'Active' || ($d['role'] ?? '') !== 'admin')) $err['_'] = 'You cannot deactivate or demote your own account.';
        if (!empty($d['contact_no']) && !valid_phone($d['contact_no'])) $err['contact_no'] = 'Enter a valid contact number.';
        return $err;
    },
    'before_save' => function (&$data) {
        if (($data['role'] ?? '') !== 'staff') $data['assigned_modules'] = null;
    },
];
crud_run($cfg);
