<?php
// BARANGAY SETTINGS (profile shown on the public portal and printed documents)
require_once '../auth.php';
require_module('settings', 'manage');

$keys = ['barangay_name' => 'Barangay Name', 'municipality' => 'Municipality / City', 'province' => 'Province', 'address' => 'Office Address',
         'contact_no' => 'Contact Number', 'email' => 'Email', 'office_hours' => 'Office Hours'];
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vals = [];
    foreach (array_merge(array_keys($keys), ['about', 'emergency_contacts']) as $k) $vals[$k] = trim($_POST[$k] ?? '');
    if ($vals['barangay_name'] === '') $errors[] = 'Barangay name is required.';
    if ($vals['email'] !== '' && !filter_var($vals['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email.';
    if (!$errors) {
        foreach ($vals as $k => $v) db_exec("INSERT INTO settings (setting_key, setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)", [$k, $v]);
        log_activity('Update', 'Updated barangay settings', 'settings');
        flash('success', 'Settings saved.');
        redirect('index.php');
    }
}
$page_title = 'Barangay Settings';
$breadcrumb = ['Settings'];
require '../includes/header.php';
if ($errors) echo '<div class="alert alert-error">' . implode('<br>', array_map('e', $errors)) . '</div>';
?>
<div class="card"><form method="post"><?= csrf_field() ?><div class="form-grid">
<?php foreach ($keys as $k => $label): ?>
    <div class="form-group"><label><?= e($label) ?></label><input type="text" name="<?= $k ?>" value="<?= e($_POST[$k] ?? setting($k)) ?>"></div>
<?php endforeach; ?>
    <div class="form-group full"><label>About the Barangay</label><textarea name="about"><?= e($_POST['about'] ?? setting('about')) ?></textarea></div>
    <div class="form-group full"><label>Emergency Contacts (one per line, e.g. "Police - 911")</label><textarea name="emergency_contacts"><?= e($_POST['emergency_contacts'] ?? setting('emergency_contacts')) ?></textarea></div>
</div><p><button class="btn">Save Settings</button></p></form></div>
<?php require '../includes/footer.php'; ?>
