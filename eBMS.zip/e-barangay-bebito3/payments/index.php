<?php
// PAYMENTS - Fee Assessment > Payment > Transaction > Official Receipt > Collection Report
require_once '../auth.php';
require_once '../includes/crud.php';
require_once '../includes/finance.php';

$cfg = [
    'module' => 'payments', 'title' => 'Payments', 'singular' => 'Payment', 'table' => 'payments',
    'ref' => 'transaction_id', 'order' => 't.payment_date DESC, t.id DESC', 'after_save' => 'view',
    'no_edit' => true, 'date_filter' => 'payment_date',
    'joins' => 'LEFT JOIN residents rr ON rr.id = t.resident_id',
    'search' => ['t.transaction_id', 'rr.first_name', 'rr.last_name', 't.purpose'],
    'resident' => ['column' => 'resident_id', 'add' => false],
    'fields' => [
        'transaction_id' => ['label' => 'Transaction ID', 'type' => 'auto', 'auto' => function () { return next_number('TXN', 'payments', 'transaction_id'); }],
        'resident_id'    => ['label' => 'Resident', 'type' => 'select', 'required' => true, 'sql' => resident_label_sql()],
        'fee_id'         => ['label' => 'Fee Type (optional)', 'type' => 'select', 'sql' => "SELECT id, CONCAT(fee_type, ' - PHP ', FORMAT(amount, 2)) FROM fees WHERE status = 'Active' ORDER BY fee_type", 'help' => 'Just a reference; type the amount below.'],
        'purpose'        => ['label' => 'Purpose', 'required' => true, 'max' => 200, 'full' => true],
        'amount'         => ['label' => 'Amount (PHP)', 'type' => 'decimal', 'required' => true, 'min' => 0.01, 'money' => true],
        'payment_date'   => ['label' => 'Payment Date', 'type' => 'date', 'required' => true, 'not_future' => true, 'default' => date('Y-m-d')],
        'payment_method' => ['label' => 'Payment Method', 'type' => 'select', 'required' => true, 'options' => opts(['Cash', 'GCash', 'Bank Transfer', 'Other']), 'default' => 'Cash', 'filter' => true],
        'status'         => ['label' => 'Status', 'type' => 'select', 'required' => true, 'options' => opts(['Paid', 'Pending', 'Cancelled']), 'default' => 'Paid', 'filter' => true],
        'ref_type'       => ['label' => 'Ref Type', 'type' => 'hidden', 'view' => false],
        'ref_id'         => ['label' => 'Ref ID', 'type' => 'hidden', 'view' => false],
        'received_by'    => ['label' => 'Received By', 'type' => 'auto', 'auto' => function () { return $GLOBALS['CURRENT_USER']['id']; }, 'view' => false],
    ],
    'computed' => [
        'resident_name' => ['label' => 'Resident', 'sql' => "SELECT CONCAT(r.last_name, ', ', r.first_name) FROM residents r WHERE r.id = t.resident_id"],
        'or_number'     => ['label' => 'OR No.', 'sql' => "SELECT o.or_number FROM official_receipts o WHERE o.payment_id = t.id"],
        'treasurer'     => ['label' => 'Received By', 'sql' => "SELECT u.full_name FROM users u WHERE u.id = t.received_by"],
    ],
    'columns' => ['transaction_id', 'resident_name', 'purpose', 'amount', 'payment_date', 'payment_method', 'or_number', 'status'],
    'validate' => function ($data) {
        $err = [];
        if (!empty($data['ref_type']) && !in_array($data['ref_type'], ['document_request', 'permit', 'other'])) $err['_'] = 'Invalid reference.';
        return $err;
    },
    'after_create' => function ($id, $data) { payment_finalize($id); },
    'actions' => [
        ['key' => 'markpaid', 'label' => 'Mark as Paid (Issue OR)', 'from' => ['Pending'], 'to' => 'Paid', 'roles' => ['admin', 'treasurer'], 'class' => 'btn-green',
         'after' => function ($row) { payment_finalize($row['id']); }],
        ['key' => 'void', 'label' => 'Cancel Payment', 'from' => ['Paid', 'Pending'], 'to' => 'Cancelled', 'roles' => ['admin', 'treasurer'], 'class' => 'btn-red', 'remarks' => 'required',
         'after' => function ($row) { payment_void_effects($row); }],
    ],
    'links' => [
        ['label' => 'View Receipt', 'resident' => true, 'url' => function ($row) {
            $id = db_val("SELECT id FROM official_receipts WHERE payment_id = ?", [$row['id']]);
            return $id ? BASE_URL . 'receipts/index.php?action=view&id=' . $id : null; }],
    ],
];
crud_run($cfg);
