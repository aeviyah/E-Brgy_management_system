<?php
// REPORTS & BASIC ANALYTICS - COUNT(), SUM(), GROUP BY only. No AI/prediction.
require_once '../auth.php';
require_module('reports');
$r = $_GET['r'] ?? 'overview';

// ---------- Collection report (with CSV export) ----------
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
if ($r === 'collections') {
    require_module('payments');
    $rows = db_all("SELECT p.*, r.first_name, r.last_name, o.or_number FROM payments p JOIN residents r ON r.id = p.resident_id LEFT JOIN official_receipts o ON o.payment_id = p.id
                    WHERE p.status = 'Paid' AND p.payment_date BETWEEN ? AND ? ORDER BY p.payment_date, p.id", [$from, $to]);
    if (isset($_GET['export'])) {
        log_activity('Export', "Exported collection report $from to $to", 'reports');
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="collections_' . $from . '_' . $to . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Date', 'Transaction', 'OR No.', 'Resident', 'Purpose', 'Method', 'Amount']);
        foreach ($rows as $x) fputcsv($out, [$x['payment_date'], $x['transaction_id'], $x['or_number'], $x['last_name'] . ', ' . $x['first_name'], $x['purpose'], $x['payment_method'], $x['amount']]);
        exit;
    }
}

$page_title = 'Reports & Analytics';
$breadcrumb = ['Reports'];
require '../includes/header.php';
echo '<div class="chips no-print"><a class="' . ($r === 'overview' ? 'on' : '') . '" href="?r=overview">Overview</a>';
if (user_can('payments')) echo '<a class="' . ($r === 'collections' ? 'on' : '') . '" href="?r=collections">Collection Report</a>';
echo '</div>';

if ($r === 'collections') {
    $total = array_sum(array_column($rows, 'amount'));
    $daily = [];
    $method = [];
    foreach ($rows as $x) { $daily[fdate($x['payment_date'])] = ($daily[fdate($x['payment_date'])] ?? 0) + $x['amount']; $method[$x['payment_method']] = ($method[$x['payment_method']] ?? 0) + $x['amount']; }
    ?>
    <div class="card"><form method="get" class="filters no-print"><input type="hidden" name="r" value="collections">
        From <input type="date" name="from" value="<?= e($from) ?>"> To <input type="date" name="to" value="<?= e($to) ?>">
        <button class="btn btn-small">Show</button>
        <a class="btn btn-small btn-outline" href="?r=collections&from=<?= e($from) ?>&to=<?= e($to) ?>&export=1">Export CSV</a>
        <button type="button" class="btn btn-small btn-outline" onclick="window.print()">Print</button></form>
        <div class="kpis"><div class="kpi"><div class="num"><?= money($total) ?></div><div class="lbl">Total Collected</div></div><div class="kpi"><div class="num"><?= count($rows) ?></div><div class="lbl">Transactions</div></div></div>
        <div class="grid grid-2"><div><h3>Daily Collection</h3><?php render_bars($daily, true); ?></div><div><h3>By Payment Method</h3><?php render_bars($method, true); ?></div></div>
        <h3>Transactions</h3><div class="table-wrap"><table><tr><th>Date</th><th>Transaction</th><th>OR No.</th><th>Resident</th><th>Purpose</th><th>Method</th><th>Amount</th></tr>
        <?php foreach ($rows as $x) echo '<tr><td>' . e(fdate($x['payment_date'])) . '</td><td>' . e($x['transaction_id']) . '</td><td>' . e($x['or_number']) . '</td><td>' . e($x['last_name'] . ', ' . $x['first_name']) . '</td><td>' . e($x['purpose']) . '</td><td>' . e($x['payment_method']) . '</td><td>' . money($x['amount']) . '</td></tr>';
        if (!$rows) echo '<tr><td colspan="7" class="empty">No collections in this period.</td></tr>'; ?>
        </table></div></div>
    <?php
    require '../includes/footer.php';
    exit;
}

// ---------- Overview ----------
echo '<div class="grid grid-2">';
if (user_can('residents')) {
    echo '<div class="card"><h3>Residents per Purok</h3>';
    render_bars(db_pairs("SELECT p.name, COUNT(r.id) FROM puroks p LEFT JOIN residents r ON r.purok_id = p.id AND r.status = 'Active' GROUP BY p.id, p.name ORDER BY p.name"));
    echo '</div><div class="card"><h3>Male / Female</h3>';
    render_bars(db_pairs("SELECT sex, COUNT(*) FROM residents WHERE status = 'Active' GROUP BY sex"));
    echo '</div><div class="card"><h3>Age Groups</h3>';
    render_bars(db_pairs("SELECT g, COUNT(*) FROM (SELECT CASE WHEN TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) < 18 THEN '0-17 (Minor)' WHEN TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) < 35 THEN '18-34' WHEN TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) < 60 THEN '35-59' ELSE '60+ (Senior)' END AS g FROM residents WHERE status = 'Active') x GROUP BY g ORDER BY g"));
    echo '</div><div class="card"><h3>Sector Counts</h3>';
    render_bars([
        'Senior Citizens' => (int)db_val("SELECT COUNT(*) FROM residents WHERE status = 'Active' AND (is_senior = 1 OR TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) >= 60)"),
        'PWD' => (int)db_val("SELECT COUNT(*) FROM residents WHERE status = 'Active' AND is_pwd = 1"),
        'Solo Parents' => (int)db_val("SELECT COUNT(*) FROM residents WHERE status = 'Active' AND is_solo_parent = 1"),
        '4Ps' => (int)db_val("SELECT COUNT(*) FROM residents WHERE status = 'Active' AND is_4ps = 1"),
    ]);
    echo '</div>';
}
if (user_can('doc_requests')) {
    echo '<div class="card"><h3>Document Requests by Status</h3>';
    render_bars(db_pairs("SELECT status, COUNT(*) FROM document_requests GROUP BY status"));
    echo '</div><div class="card"><h3>Most Requested Documents</h3>';
    render_bars(db_pairs("SELECT d.name, COUNT(*) FROM document_requests dr JOIN documents d ON d.id = dr.document_id GROUP BY d.id, d.name ORDER BY COUNT(*) DESC LIMIT 6"));
    echo '</div>';
}
if (user_can('service_requests')) {
    echo '<div class="card"><h3>Service Requests by Status</h3>';
    render_bars(db_pairs("SELECT status, COUNT(*) FROM service_requests GROUP BY status"));
    echo '</div>';
}
if (user_can('complaints')) {
    echo '<div class="card"><h3>Complaints by Status</h3>';
    render_bars(db_pairs("SELECT status, COUNT(*) FROM complaints GROUP BY status"));
    echo '</div>';
}
if (user_can('payments')) {
    echo '<div class="card"><h3>Collections per Month (this year)</h3>';
    render_bars(db_pairs("SELECT DATE_FORMAT(payment_date, '%b') m, COALESCE(SUM(amount),0) FROM payments WHERE status = 'Paid' AND YEAR(payment_date) = YEAR(CURDATE()) GROUP BY MONTH(payment_date), m ORDER BY MONTH(payment_date)"), true);
    echo '<p><a class="btn btn-small btn-outline" href="?r=collections">Open Collection Report</a></p></div>';
}
if (user_can('projects')) {
    echo '<div class="card"><h3>Projects by Status</h3>';
    render_bars(db_pairs("SELECT status, COUNT(*) FROM projects GROUP BY status"));
    echo '</div>';
}
echo '</div>';
require '../includes/footer.php';
