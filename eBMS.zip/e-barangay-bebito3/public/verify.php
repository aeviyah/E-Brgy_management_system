<?php
// DOCUMENT VERIFICATION - shows only whether a document is genuine. No private details (name is masked).
require_once 'inc.php';
public_header('Verify a Barangay Document');
$code = strtoupper(trim($_GET['code'] ?? ''));
function mask($s) { return mb_substr($s, 0, 1) . str_repeat('*', max(2, mb_strlen($s) - 1)); }
?>
<div class="card"><form method="get" class="filters"><input type="text" name="code" placeholder="Verification code" value="<?= e($code) ?>"><button class="btn btn-small">Verify</button></form>
<?php
if ($code !== '') {
    $d = db_one("SELECT dr.document_no, dr.issued_date, dr.status, d.name, r.first_name, r.last_name FROM document_requests dr JOIN documents d ON d.id = dr.document_id JOIN residents r ON r.id = dr.resident_id WHERE dr.verification_code = ?", [$code]);
    if ($d && in_array($d['status'], ['Ready for Release', 'Completed'])) {
        echo '<div class="alert alert-success"><strong>VALID DOCUMENT</strong><br>Document: ' . e($d['name']) . '<br>Document No.: ' . e($d['document_no']) . '<br>Date issued: ' . e(fdate($d['issued_date'])) . '<br>Issued to: ' . e(mask($d['first_name']) . ' ' . mask($d['last_name'])) . '</div>';
    } else echo '<div class="alert alert-error"><strong>NOT FOUND.</strong> This code does not match any issued document.</div>';
}
?>
<p class="help">For privacy, only the document type, number and date are shown.</p></div>
<?php public_footer(); ?>
