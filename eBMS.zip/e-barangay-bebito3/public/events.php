<?php
require_once 'inc.php';
public_header('Events & Activities');
foreach (db_all("SELECT * FROM events WHERE status IN ('Published','Completed') ORDER BY event_date DESC LIMIT 30") as $x)
    echo '<div class="card"><h3>' . e($x['name']) . ' ' . badge($x['status']) . '</h3><p><strong>' . e(fdate($x['event_date'])) . ' ' . e(ftime($x['event_time'])) . '</strong> &middot; ' . e($x['location']) . '<br>Organizer: ' . e($x['organizer']) . '</p><p>' . nl2br(e($x['description'])) . '</p></div>';
public_footer();
