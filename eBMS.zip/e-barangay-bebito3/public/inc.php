<?php
// Shared layout for the PUBLIC portal. Never show private resident information here.
define('PUBLIC_PAGE', true);
require_once __DIR__ . '/../auth.php';

function public_header($title) {
    ?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> | <?= e(setting('barangay_name', 'Barangay')) ?></title>
<link rel="icon" type="image/svg+xml" href="<?= BASE_URL ?>img/logo.svg">
<link rel="stylesheet" href="<?= BASE_URL ?>css/style.css"><?= scene_css() ?></head>
<body>
<div class="public-top">
    <a class="pbrand" href="index.php"><?= brand_logo('', 'Barangay seal') ?><span><?= e(setting('barangay_name', 'Barangay')) ?></span></a>
    <span>
        <a href="index.php">Home</a><a href="services.php">Services &amp; Fees</a><a href="announcements.php">Announcements</a><a href="events.php">Events</a>
        <a href="officials.php">Officials</a><a href="ordinances.php">Ordinances</a><a href="verify.php">Verify Document</a>
    </span>
    <span style="margin-left:auto">
        <?php if (is_logged_in()): ?><a href="<?= BASE_URL ?>dashboard.php">My Dashboard</a><?php else: ?><a href="<?= BASE_URL ?>login.php">Login</a><a href="<?= BASE_URL ?>register.php">Register</a><?php endif; ?>
    </span>
</div>
<div class="public-wrap"><?php if ($title !== 'Welcome'): ?><h1><?= e($title) ?></h1><?php endif; ?>
<?php
}
function public_footer() {
    echo '</div><p style="text-align:center;color:#64756c;font-size:12px;padding:20px 20px 40px">' . e(setting('barangay_name')) . ' &middot; ' . e(setting('address')) . ' &middot; ' . e(setting('contact_no')) . '</p></body></html>';
}
