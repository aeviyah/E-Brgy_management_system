<?php
require_once 'inc.php';
public_header('Announcements');
foreach (db_all("SELECT * FROM announcements WHERE status = 'Published' AND audience = 'Public' ORDER BY date_posted DESC, id DESC LIMIT 30") as $a)
    echo '<div class="card"><h3>' . e($a['title']) . '</h3><small class="help">Posted ' . e(fdate($a['date_posted'])) . '</small><p>' . nl2br(e($a['content'])) . '</p></div>';
public_footer();
