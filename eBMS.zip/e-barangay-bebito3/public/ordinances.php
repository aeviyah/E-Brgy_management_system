<?php
require_once 'inc.php';
public_header('Ordinances & Resolutions');
echo '<div class="card"><div class="table-wrap"><table><tr><th>Number</th><th>Type</th><th>Title</th><th>Date</th><th>File</th></tr>';
foreach (db_all("SELECT * FROM ordinances WHERE is_public = 'Yes' AND status = 'Active' ORDER BY doc_date DESC") as $o)
    echo '<tr><td>' . e($o['doc_number']) . '</td><td>' . e($o['doc_type']) . '</td><td><strong>' . e($o['title']) . '</strong><br><small class="help">' . e($o['description']) . '</small></td><td>' . e(fdate($o['doc_date'])) . '</td><td>' . file_link($o['attachment']) . '</td></tr>';
echo '</table></div></div>';
public_footer();
