<?php
require_once 'inc.php';
public_header('Welcome');
?>
<div class="hero">
    <?= brand_logo('seal', 'Barangay seal') ?>
    <h1><?= e(setting('barangay_name')) ?></h1>
    <p><?= e(setting('municipality')) ?>, <?= e(setting('province')) ?></p>
    <p><?= nl2br(e(setting('about'))) ?></p>
    <div class="action-bar"><a class="btn btn-outline" href="<?= BASE_URL ?>login.php">Login to request documents</a> <a class="btn btn-outline" href="<?= BASE_URL ?>register.php">Register as resident</a> <a class="btn btn-outline" href="verify.php">Verify a document</a></div>
</div>
<div class="quick" style="margin-bottom:18px">
    <a href="services.php"><span class="qi"><?= icon('file') ?></span>Services &amp; Fees</a>
    <a href="announcements.php"><span class="qi"><?= icon('megaphone') ?></span>Announcements</a>
    <a href="events.php"><span class="qi"><?= icon('calendar') ?></span>Events</a>
    <a href="officials.php"><span class="qi"><?= icon('landmark') ?></span>Barangay Officials</a>
    <a href="ordinances.php"><span class="qi"><?= icon('scale') ?></span>Ordinances</a>
    <a href="verify.php"><span class="qi"><?= icon('shield') ?></span>Verify Document</a>
</div>
<div class="grid grid-2">
    <div class="card"><h3>Contact &amp; Office Hours</h3>
        <p><strong>Address:</strong> <?= e(setting('address')) ?><br><strong>Phone:</strong> <?= e(setting('contact_no')) ?><br><strong>Email:</strong> <?= e(setting('email')) ?><br><strong>Office hours:</strong> <?= e(setting('office_hours')) ?></p></div>
    <div class="card"><h3>Emergency Contacts</h3>
        <?php foreach (preg_split('/\r?\n/', setting('emergency_contacts')) as $l) if (trim($l) !== '') echo '<p style="margin:4px 0">' . e($l) . '</p>'; ?></div>
</div>
<div class="grid grid-2">
    <div class="card"><h3>Latest Announcements</h3>
        <?php $an = db_all("SELECT id, title, content, date_posted FROM announcements WHERE status = 'Published' AND audience = 'Public' ORDER BY date_posted DESC, id DESC LIMIT 4");
        foreach ($an as $a) echo '<p><strong>' . e($a['title']) . '</strong> <small class="help">' . e(fdate($a['date_posted'])) . '</small><br>' . e(mb_strimwidth($a['content'], 0, 140, '...')) . '</p>';
        if (!$an) echo '<p class="help">No announcements.</p>'; ?>
        <a href="announcements.php">All announcements &raquo;</a></div>
    <div class="card"><h3>Upcoming Events</h3>
        <?php $ev = db_all("SELECT name, event_date, event_time, location FROM events WHERE status = 'Published' AND event_date >= CURDATE() ORDER BY event_date LIMIT 4");
        foreach ($ev as $x) echo '<p><strong>' . e($x['name']) . '</strong><br>' . e(fdate($x['event_date'])) . ' ' . e(ftime($x['event_time'])) . ' &middot; ' . e($x['location']) . '</p>';
        if (!$ev) echo '<p class="help">No upcoming events.</p>'; ?>
        <a href="events.php">All events &raquo;</a></div>
</div>
<?php public_footer(); ?>
