<?php
require_once 'inc.php';
public_header('Services, Requirements & Fees');
echo '<div class="card"><h3>Documents &amp; Certificates</h3><div class="table-wrap"><table><tr><th>Document</th><th>Requirements</th><th>Fee</th><th>Processing</th></tr>';
foreach (db_all("SELECT * FROM documents WHERE status = 'Active' ORDER BY name") as $d)
    echo '<tr><td><strong>' . e($d['name']) . '</strong><br><small class="help">' . e($d['description']) . '</small></td><td>' . nl2br(e($d['requirements'])) . '</td><td>' . ($d['fee'] > 0 ? money($d['fee']) : 'Free') . '</td><td>' . (int)$d['processing_days'] . ' day(s)</td></tr>';
echo '</table></div></div><div class="card"><h3>Barangay Services</h3><div class="table-wrap"><table><tr><th>Service</th><th>Requirements</th></tr>';
foreach (db_all("SELECT * FROM services WHERE status = 'Active' ORDER BY name") as $s)
    echo '<tr><td><strong>' . e($s['name']) . '</strong><br><small class="help">' . e($s['description']) . '</small></td><td>' . nl2br(e($s['requirements'])) . '</td></tr>';
echo '</table></div></div><div class="card"><h3>Fee Schedule</h3><div class="table-wrap"><table><tr><th>Fee</th><th>Purpose</th><th>Amount</th></tr>';
foreach (db_all("SELECT * FROM fees WHERE status = 'Active' ORDER BY fee_type") as $f) echo '<tr><td>' . e($f['fee_type']) . '</td><td>' . e($f['purpose']) . '</td><td>' . money($f['amount']) . '</td></tr>';
echo '</table></div></div>';
public_footer();
