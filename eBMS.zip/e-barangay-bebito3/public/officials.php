<?php
require_once 'inc.php';
public_header('Barangay Officials');
echo '<div class="grid grid-3">';
foreach (db_all("SELECT full_name, position, photo FROM officials WHERE status = 'Active' ORDER BY FIELD(position, 'Punong Barangay', 'Barangay Kagawad', 'Barangay Secretary', 'Barangay Treasurer'), id") as $o) {
    echo '<div class="card official">' . ($o['photo'] ? '<img src="' . BASE_URL . 'uploads/' . e($o['photo']) . '" alt="">' : '<div class="ph"></div>') . '<strong>' . e($o['full_name']) . '</strong><br><small class="help">' . e($o['position']) . '</small></div>';
}
echo '</div>';
public_footer();
