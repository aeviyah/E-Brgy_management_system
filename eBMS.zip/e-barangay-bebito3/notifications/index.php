<?php
// IN-APP NOTIFICATIONS for the logged-in user
require_once '../auth.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['do'] ?? '') === 'readall') db_exec("UPDATE notifications SET is_read = 1 WHERE user_id = ?", [$CURRENT_USER['id']]);
    if (($_POST['do'] ?? '') === 'read') db_exec("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?", [(int)$_POST['id'], $CURRENT_USER['id']]);
    redirect('index.php');
}
$list = db_all("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 50", [$CURRENT_USER['id']]);
$page_title = 'Notifications';
$breadcrumb = ['Notifications'];
require '../includes/header.php';
?>
<div class="card">
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="readall"><button class="btn btn-small btn-outline">Mark all as read</button></form><br>
    <?php foreach ($list as $n): ?>
        <div style="padding:10px 0;border-bottom:1px solid #eee;<?= $n['is_read'] ? 'opacity:.65' : 'font-weight:600' ?>">
            <?= e($n['title']) ?> <small class="help"><?= e(date('M d, Y h:i A', strtotime($n['created_at']))) ?></small><br>
            <span style="font-weight:normal"><?= e($n['message']) ?></span>
            <?php if ($n['link']): ?> <a href="<?= e($n['link']) ?>" style="font-weight:normal">Open</a><?php endif; ?>
            <?php if (!$n['is_read']): ?>
                <form method="post" class="inline-form"><?= csrf_field() ?><input type="hidden" name="do" value="read"><input type="hidden" name="id" value="<?= $n['id'] ?>"><button class="btn btn-small btn-outline">Mark read</button></form>
            <?php endif; ?>
        </div>
    <?php endforeach; if (!$list) echo '<p class="help">No notifications yet.</p>'; ?>
</div>
<?php require '../includes/footer.php'; ?>
