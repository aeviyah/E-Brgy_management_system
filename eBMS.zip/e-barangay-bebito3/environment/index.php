<?php
// ENVIRONMENT & SANITATION: schedules, clean-ups, concerns, dumping reports, monitoring
require_once '../auth.php';
require_once '../includes/crud.php';

$a = ['admin', 'secretary', 'staff'];
$cfg = [
    'module' => 'environment', 'title' => 'Environment & Sanitation', 'singular' => 'Environment Record', 'table' => 'environment_records',
    'ref' => 'title', 'order' => 't.record_date DESC', 'archive' => ['value' => 'Archived', 'restore' => 'Open'], 'history' => true, 'date_filter' => 'record_date',
    'search' => ['t.title', 't.location', 't.description'],
    'fields' => [
        'record_type' => ['label' => 'Record Type', 'type' => 'select', 'required' => true, 'filter' => true,
                          'options' => opts(['Waste Collection Schedule', 'Clean-up Activity', 'Sanitation Concern', 'Environmental Complaint', 'Illegal Dumping Report', 'Monitoring Record'])],
        'title'       => ['label' => 'Title', 'required' => true, 'max' => 150, 'full' => true],
        'location'    => ['label' => 'Location', 'max' => 150],
        'record_date' => ['label' => 'Date', 'type' => 'date', 'required' => true, 'default' => date('Y-m-d')],
        'reported_by' => ['label' => 'Reported By', 'max' => 100],
        'description' => ['label' => 'Description', 'type' => 'textarea'],
        'status'      => ['label' => 'Status', 'type' => 'auto', 'value' => 'Open', 'options' => opts(['Open', 'In Progress', 'Resolved', 'Closed'])],
    ],
    'columns' => ['record_date', 'record_type', 'title', 'location', 'status'],
    'actions' => [
        ['key' => 'start', 'label' => 'Start Action', 'from' => ['Open'], 'to' => 'In Progress', 'roles' => $a, 'class' => 'btn-blue'],
        ['key' => 'resolve', 'label' => 'Mark Resolved', 'from' => ['Open', 'In Progress'], 'to' => 'Resolved', 'roles' => $a, 'class' => 'btn-green', 'remarks' => 'optional'],
        ['key' => 'close', 'label' => 'Close', 'from' => ['Resolved'], 'to' => 'Closed', 'roles' => $a],
    ],
];
crud_run($cfg);
