<?php
// MEETINGS & MINUTES
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'meetings', 'title' => 'Meetings & Minutes', 'singular' => 'Meeting', 'table' => 'meetings',
    'ref' => 'meeting_date', 'order' => 't.meeting_date DESC', 'archive' => ['value' => 'Archived', 'restore' => 'Scheduled'],
    'search' => ['t.agenda', 't.location', 't.related_resolution'],
    'fields' => [
        'meeting_date' => ['label' => 'Meeting Date', 'type' => 'date', 'required' => true],
        'meeting_time' => ['label' => 'Time', 'type' => 'time'],
        'location'     => ['label' => 'Location', 'required' => true, 'max' => 150],
        'agenda'       => ['label' => 'Agenda', 'type' => 'textarea', 'required' => true],
        'attendees'    => ['label' => 'Attendees', 'type' => 'textarea'],
        'minutes'      => ['label' => 'Minutes', 'type' => 'textarea'],
        'decisions'    => ['label' => 'Decisions', 'type' => 'textarea'],
        'action_items' => ['label' => 'Action Items', 'type' => 'textarea'],
        'related_resolution' => ['label' => 'Related Resolution No.', 'max' => 80],
        'status'       => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Scheduled', 'options' => opts(['Scheduled', 'Completed', 'Cancelled'])],
    ],
    'columns' => ['meeting_date', 'meeting_time', 'location', 'agenda', 'status'],
];
crud_run($cfg);
