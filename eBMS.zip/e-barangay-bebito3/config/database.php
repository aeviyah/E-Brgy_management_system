<?php
// DATABASE CONNECTION (XAMPP default settings)
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'e_barangay');

// If your project folder is not named "e-barangay", change this.
define('BASE_URL', '/e-barangay/');
define('ROOT_PATH', dirname(__DIR__));

// Shows the clickable demo-account chips on the login page. Set to false before real use.
define('DEMO_MODE', true);
date_default_timezone_set('Asia/Manila');

// Show database errors as exceptions (easier to catch)
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $conn->set_charset('utf8mb4');
    $conn->query("SET time_zone = '+08:00'");   // Philippine time
} catch (Exception $ex) {
    die('Database connection failed. Start MySQL in XAMPP and import database/schema.sql and database/seed.sql. '
        . 'Details: ' . htmlspecialchars($ex->getMessage()));
}
