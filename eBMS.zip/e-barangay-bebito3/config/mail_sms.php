<?php
// NOTIFICATION SETTINGS (Email + SMS)
// 'test' = nothing is really sent; messages are saved in the Message History as "Sent (Test Mode)".
// 'live' = Email uses PHP mail() (configure sendmail in XAMPP); SMS calls the gateway below.
define('NOTIFY_MODE', 'test');

define('MAIL_FROM', 'no-reply@barangay.local');
define('MAIL_FROM_NAME', 'E-Barangay');

// SMS gateway (example: Semaphore, a Philippine SMS provider). Put your own API key.
define('SMS_API_URL', 'https://api.semaphore.co/api/v4/messages');
define('SMS_API_KEY', '');
define('SMS_SENDER', 'BARANGAY');
