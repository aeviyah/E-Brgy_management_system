<?php
// DEVELOPMENT & PROJECTS: Proposed > Approved > Ongoing > Completed (or Cancelled)
require_once '../auth.php';
require_once '../includes/crud.php';

$a = ['admin', 'captain'];
$cfg = [
    'module' => 'projects', 'title' => 'Development & Projects', 'singular' => 'Project', 'table' => 'projects',
    'ref' => 'name', 'order' => 't.id DESC', 'after_save' => 'view', 'history' => true,
    'search' => ['t.name', 't.description', 't.beneficiaries'],
    'edit_locked' => ['Completed', 'Cancelled'],
    'fields' => [
        'name'           => ['label' => 'Project Name', 'required' => true, 'max' => 150, 'full' => true],
        'description'    => ['label' => 'Description', 'type' => 'textarea'],
        'proposal'       => ['label' => 'Proposal', 'type' => 'textarea'],
        'budget'         => ['label' => 'Budget (PHP)', 'type' => 'decimal', 'required' => true, 'money' => true],
        'beneficiaries'  => ['label' => 'Target Beneficiaries', 'max' => 150],
        'start_date'     => ['label' => 'Start Date', 'type' => 'date'],
        'end_date'       => ['label' => 'End Date', 'type' => 'date'],
        'progress'       => ['label' => 'Progress (%)', 'type' => 'number', 'min' => 0, 'max_value' => 100, 'default' => '0'],
        'accomplishment' => ['label' => 'Accomplishment', 'type' => 'textarea'],
        'status'         => ['label' => 'Status', 'type' => 'auto', 'value' => 'Proposed', 'options' => opts(['Proposed', 'Approved', 'Ongoing', 'Completed', 'Cancelled'])],
    ],
    'computed' => [
        'bar' => ['label' => 'Progress', 'html' => true, 'hide_in_view' => true,
                  'sql' => "CONCAT('<div class=\"bar\" style=\"background:#e5e7eb;border-radius:3px;width:110px\"><div style=\"background:#111;height:12px;border-radius:3px;width:', t.progress, '%\"></div></div><small>', t.progress, '%</small>')"],
    ],
    'columns' => ['name', 'budget', 'start_date', 'end_date', 'bar', 'status'],
    'validate' => function ($d) {
        return (!empty($d['start_date']) && !empty($d['end_date']) && $d['end_date'] < $d['start_date']) ? ['end_date' => 'End date must be after the start date.'] : [];
    },
    'actions' => [
        ['key' => 'approve', 'label' => 'Approve Project', 'from' => ['Proposed'], 'to' => 'Approved', 'roles' => $a, 'class' => 'btn-green', 'remarks' => 'optional'],
        ['key' => 'start', 'label' => 'Start Project', 'from' => ['Approved'], 'to' => 'Ongoing', 'roles' => $a, 'class' => 'btn-blue'],
        ['key' => 'complete', 'label' => 'Mark Completed', 'from' => ['Ongoing'], 'to' => 'Completed', 'roles' => $a, 'class' => 'btn-green', 'set' => ['progress' => 100], 'remarks' => 'optional'],
        ['key' => 'cancel', 'label' => 'Cancel Project', 'from' => ['Proposed', 'Approved', 'Ongoing'], 'to' => 'Cancelled', 'roles' => $a, 'class' => 'btn-red', 'remarks' => 'required'],
    ],
];
crud_run($cfg);
