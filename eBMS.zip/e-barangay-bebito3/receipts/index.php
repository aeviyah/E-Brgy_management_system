<?php
// OFFICIAL RECEIPTS - created automatically when a payment is Paid
require_once '../auth.php';
require_once '../includes/crud.php';
require_once '../includes/finance.php';

$cfg = [
    'module' => 'receipts', 'title' => 'Official Receipts', 'singular' => 'Official Receipt', 'table' => 'official_receipts',
    'ref' => 'or_number', 'order' => 't.id DESC', 'no_add' => true, 'no_edit' => true, 'date_filter' => 'issue_date',
    'joins' => 'LEFT JOIN residents rr ON rr.id = t.resident_id',
    'search' => ['t.or_number', 'rr.first_name', 'rr.last_name', 't.purpose'],
    'resident' => ['column' => 'resident_id', 'add' => false],
    'fields' => [
        'or_number'      => ['label' => 'OR Number', 'unique' => true],
        'payment_id'     => ['label' => 'Transaction', 'type' => 'select', 'sql' => "SELECT id, transaction_id FROM payments"],
        'resident_id'    => ['label' => 'Resident', 'type' => 'select', 'sql' => "SELECT id, CONCAT(last_name, ', ', first_name) FROM residents"],
        'purpose'        => ['label' => 'Purpose'],
        'amount'         => ['label' => 'Amount', 'type' => 'decimal', 'money' => true],
        'issue_date'     => ['label' => 'Date', 'type' => 'date'],
        'payment_method' => ['label' => 'Payment Method'],
        'treasurer_id'   => ['label' => 'Treasurer', 'type' => 'select', 'sql' => "SELECT id, full_name FROM users"],
        'status'         => ['label' => 'Status', 'type' => 'select', 'options' => opts(['Issued', 'Void']), 'filter' => true],
    ],
    'columns' => ['or_number', 'payment_id', 'resident_id', 'purpose', 'amount', 'issue_date', 'status'],
    'links' => [
        ['label' => 'Print Receipt', 'resident' => true, 'blank' => true, 'url' => function ($row) { return BASE_URL . 'receipts/print.php?id=' . $row['id']; }],
    ],
];
crud_run($cfg);
