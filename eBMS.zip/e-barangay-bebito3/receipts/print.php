<?php
// PRINTABLE OFFICIAL RECEIPT
require_once '../auth.php';
$id = (int)($_GET['id'] ?? 0);
$or = db_one("SELECT o.*, p.transaction_id, r.first_name, r.last_name, r.address, u.full_name AS treasurer FROM official_receipts o
              JOIN payments p ON p.id = o.payment_id JOIN residents r ON r.id = o.resident_id LEFT JOIN users u ON u.id = o.treasurer_id WHERE o.id = ?", [$id]);
if (!$or) forbidden('Receipt not found.');
if (is_resident()) { if ($or['resident_id'] != $CURRENT_USER['resident_id']) forbidden(); }
elseif (!user_can('receipts')) forbidden();
?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Receipt <?= e($or['or_number']) ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>css/style.css"></head>
<body style="background:#dfe8e2">
<div class="no-print" style="text-align:center;padding:10px"><button class="btn" onclick="window.print()">Print</button> <a class="btn btn-outline" href="javascript:history.back()">Back</a></div>
<div class="certificate" style="max-width:520px;padding:30px;font-family:Arial,sans-serif"><div class="cert-mark"></div>
    <div class="cert-head"><?= brand_logo('', 'Barangay seal') ?></div>
    <h2><?= e(strtoupper(setting('barangay_name', 'Barangay'))) ?></h2>
    <p class="center" style="margin:0"><?= e(setting('municipality')) ?>, <?= e(setting('province')) ?></p>
    <h2 style="margin-top:14px">OFFICIAL RECEIPT <?= $or['status'] === 'Void' ? '(VOID)' : '' ?></h2>
    <table style="margin-top:10px">
        <tr><td><strong>OR No.</strong></td><td><?= e($or['or_number']) ?></td></tr>
        <tr><td><strong>Date</strong></td><td><?= e(fdate($or['issue_date'])) ?></td></tr>
        <tr><td><strong>Transaction ID</strong></td><td><?= e($or['transaction_id']) ?></td></tr>
        <tr><td><strong>Received from</strong></td><td><?= e($or['first_name'] . ' ' . $or['last_name']) ?></td></tr>
        <tr><td><strong>Address</strong></td><td><?= e($or['address']) ?></td></tr>
        <tr><td><strong>Purpose</strong></td><td><?= e($or['purpose']) ?></td></tr>
        <tr><td><strong>Payment Method</strong></td><td><?= e($or['payment_method']) ?></td></tr>
        <tr><td><strong>Amount</strong></td><td style="font-size:18px"><strong><?= money($or['amount']) ?></strong></td></tr>
    </table>
    <p style="margin-top:36px;text-align:right">______________________<br><?= e($or['treasurer']) ?><br>Barangay Treasurer</p>
</div>
</body></html>
