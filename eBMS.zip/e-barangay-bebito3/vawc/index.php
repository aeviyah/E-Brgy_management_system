<?php
// VAWC / WOMEN'S PROTECTION - basic RESTRICTED records. Highly confidential.
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'vawc', 'title' => 'VAWC Records (Restricted)', 'singular' => 'VAWC Record', 'table' => 'vawc_records',
    'ref' => 'incident_no', 'after_save' => 'view', 'log_view' => true, 'export' => false,
    'archive' => ['value' => 'Archived', 'restore' => 'Open'],
    'intro' => 'HIGHLY CONFIDENTIAL: authorized officials only. Every view is recorded in the Audit Trail. This module is never shown on the public portal or in global search.',
    'search' => ['t.incident_no', 't.location', 't.incident_type'],
    'fields' => [
        'incident_no'      => ['label' => 'Incident No.', 'type' => 'auto', 'auto' => function () { return next_number('VAWC', 'vawc_records', 'incident_no'); }],
        'incident_date'    => ['label' => 'Date', 'type' => 'date', 'required' => true, 'not_future' => true],
        'location'         => ['label' => 'Location', 'required' => true, 'max' => 150],
        'persons_involved' => ['label' => 'Persons Involved', 'type' => 'textarea', 'required' => true],
        'incident_type'    => ['label' => 'Incident Type', 'type' => 'select', 'required' => true, 'filter' => true, 'options' => opts(['Physical', 'Psychological', 'Sexual', 'Economic', 'Other'])],
        'assistance'       => ['label' => 'Assistance Given', 'max' => 255, 'full' => true],
        'referral'         => ['label' => 'Referral', 'max' => 150, 'placeholder' => 'e.g. PNP Women and Children Desk, DSWD'],
        'status'           => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Open', 'options' => opts(['Open', 'Ongoing', 'Referred', 'Closed']), 'filter' => true],
        'remarks'          => ['label' => 'Remarks', 'type' => 'textarea'],
        'created_by'       => ['label' => 'Created By', 'type' => 'auto', 'view' => false, 'auto' => function () { return $GLOBALS['CURRENT_USER']['id']; }],
    ],
    'columns' => ['incident_no', 'incident_date', 'incident_type', 'location', 'referral', 'status'],
];
crud_run($cfg);
