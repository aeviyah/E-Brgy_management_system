<?php
// SERVICE CATALOG
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'services', 'title' => 'Service Catalog', 'singular' => 'Service', 'table' => 'services',
    'ref' => 'name', 'order' => 't.name',
    'archive' => ['value' => 'Archived', 'restore' => 'Active'],
    'search' => ['t.name', 't.category', 't.description'],
    'resident' => ['column' => null, 'where' => "t.status = 'Active'"],
    'fields' => [
        'name'         => ['label' => 'Service Name', 'required' => true, 'unique' => true, 'max' => 100],
        'category'     => ['label' => 'Category', 'type' => 'select', 'options' => opts(['Assistance', 'Facility', 'Vehicle', 'Community Program', 'Other']), 'filter' => true],
        'description'  => ['label' => 'Description', 'max' => 255, 'full' => true],
        'requirements' => ['label' => 'Requirements', 'type' => 'textarea', 'help' => 'One requirement per line.'],
        'status'       => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Active', 'options' => opts(['Active', 'Inactive']), 'staff_only' => true],
    ],
    'columns' => ['name', 'category', 'description', 'status'],
    'links' => [
        ['label' => 'Request This Service', 'resident' => true, 'roles' => ['admin', 'secretary'],
         'url' => function ($row) { return $row['status'] === 'Active' ? BASE_URL . 'services/requests.php?action=add&service_id=' . $row['id'] : null; }],
    ],
    'view_extra' => function ($row) {
        echo '<div class="card"><h3>Requirements</h3><ul>';
        foreach (preg_split('/\r?\n/', (string)$row['requirements']) as $l) if (trim($l) !== '') echo '<li>' . e($l) . '</li>';
        echo '</ul></div>';
    },
];
crud_run($cfg);
