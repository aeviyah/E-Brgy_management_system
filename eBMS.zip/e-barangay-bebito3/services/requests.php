<?php
// SERVICE REQUESTS: Pending > Under Review > Approved > Processing > Completed (or Rejected / Cancelled)
require_once '../auth.php';
require_once '../includes/crud.php';

$staff = ['admin', 'secretary'];
$cfg = [
    'module' => 'service_requests', 'title' => 'Service Requests', 'singular' => 'Service Request', 'table' => 'service_requests',
    'ref' => 'request_no', 'after_save' => 'view', 'history' => true, 'remarks_field' => 'remarks',
    'joins' => 'LEFT JOIN residents rr ON rr.id = t.resident_id LEFT JOIN services ss ON ss.id = t.service_id',
    'search' => ['t.request_no', 'rr.first_name', 'rr.last_name', 'ss.name'],
    'resident' => ['column' => 'resident_id', 'add' => true],
    'edit_locked' => ['Approved', 'Processing', 'Completed', 'Cancelled', 'Rejected'],
    'fields' => [
        'request_no'  => ['label' => 'Request No.', 'type' => 'auto', 'auto' => function () { return next_number('SR', 'service_requests', 'request_no'); }],
        'resident_id' => ['label' => 'Resident', 'type' => 'select', 'required' => true, 'sql' => resident_label_sql(), 'add_only' => true],
        'service_id'  => ['label' => 'Service', 'type' => 'select', 'required' => true, 'sql' => "SELECT id, name FROM services WHERE status = 'Active' ORDER BY name", 'filter' => true],
        'details'     => ['label' => 'Request Details', 'type' => 'textarea', 'required' => true, 'help' => 'Explain what you need, date needed, number of people, etc.'],
        'attachment'  => ['label' => 'Attachment (PDF/JPG/PNG)', 'type' => 'file'],
        'status'      => ['label' => 'Status', 'type' => 'select', 'options' => opts(['Pending', 'Under Review', 'Approved', 'Processing', 'Completed', 'Rejected', 'Cancelled']), 'form' => false],
        'remarks'     => ['label' => 'Latest Remarks', 'form' => false],
    ],
    'computed' => [
        'resident_name' => ['label' => 'Resident', 'sql' => "SELECT CONCAT(r.last_name, ', ', r.first_name) FROM residents r WHERE r.id = t.resident_id"],
        'service_name'  => ['label' => 'Service', 'sql' => "SELECT s.name FROM services s WHERE s.id = t.service_id"],
        'requested'     => ['label' => 'Date Requested', 'sql' => 't.created_at', 'date' => true],
    ],
    'columns' => ['request_no', 'resident_name', 'service_name', 'requested', 'status'],
    'validate' => function ($data, $id) {
        global $CURRENT_RESIDENT;
        if ($id) return [];
        $rid = is_resident() ? ($CURRENT_RESIDENT['id'] ?? 0) : ($data['resident_id'] ?? 0);
        if (db_val("SELECT status FROM residents WHERE id = ?", [(int)$rid]) !== 'Active') return ['_' => 'Only verified (Active) residents can request services.'];
        return [];
    },
    'after_create' => function ($id, $data) {
        $row = db_one("SELECT * FROM service_requests WHERE id = ?", [$id]);
        notify_roles(['secretary'], 'New Service Request', $row['request_no'] . ' needs review.', BASE_URL . 'services/requests.php?action=view&id=' . $id);
        notify_resident($row['resident_id'], 'Service Request Received', 'Your service request ' . $row['request_no'] . ' was received and is pending review.', ['inapp', 'email']);
    },
    'actions' => [
        ['key' => 'review', 'label' => 'Start Review', 'from' => ['Pending'], 'to' => 'Under Review', 'roles' => $staff, 'class' => 'btn-blue'],
        ['key' => 'approve', 'label' => 'Approve', 'from' => ['Under Review'], 'to' => 'Approved', 'roles' => ['admin', 'secretary', 'captain'], 'class' => 'btn-green', 'remarks' => 'optional'],
        ['key' => 'reject', 'label' => 'Reject', 'from' => ['Pending', 'Under Review'], 'to' => 'Rejected', 'roles' => ['admin', 'secretary', 'captain'], 'remarks' => 'required', 'class' => 'btn-red'],
        ['key' => 'process', 'label' => 'Start Processing', 'from' => ['Approved'], 'to' => 'Processing', 'roles' => $staff, 'class' => 'btn-blue'],
        ['key' => 'complete', 'label' => 'Mark Completed', 'from' => ['Processing'], 'to' => 'Completed', 'roles' => $staff, 'class' => 'btn-green', 'remarks' => 'optional'],
        ['key' => 'cancel', 'label' => 'Cancel Request', 'from' => ['Pending', 'Under Review'], 'to' => 'Cancelled', 'resident' => true, 'roles' => $staff, 'class' => 'btn-red'],
    ],
    'notify' => function ($row, $to, $remarks) {
        $svc = db_val("SELECT name FROM services WHERE id = ?", [$row['service_id']]);
        $t = 'Your ' . $svc . ' request (' . $row['request_no'] . ') is now "' . $to . '".';
        if ($remarks !== '') $t .= ' Remarks: ' . $remarks;
        return ['resident_id' => $row['resident_id'], 'title' => 'Service Request Update', 'message' => $t, 'channels' => ['inapp', 'email', 'sms'], 'link' => BASE_URL . 'services/requests.php?action=view&id=' . $row['id']];
    },
];
crud_run($cfg);
