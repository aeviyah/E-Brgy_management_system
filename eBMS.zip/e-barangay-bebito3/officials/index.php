<?php
// OFFICIALS & PERSONNEL
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'officials', 'title' => 'Officials & Personnel', 'singular' => 'Official', 'table' => 'officials',
    'ref' => 'full_name', 'order' => 't.id', 'archive' => ['value' => 'Archived', 'restore' => 'Active'],
    'search' => ['t.full_name', 't.position'],
    'fields' => [
        'full_name'  => ['label' => 'Full Name', 'required' => true, 'max' => 120],
        'position'   => ['label' => 'Position', 'type' => 'select', 'required' => true, 'filter' => true,
                         'options' => opts(['Punong Barangay', 'Barangay Kagawad', 'Barangay Secretary', 'Barangay Treasurer', 'Barangay Staff', 'Barangay Tanod', 'Lupon Member'])],
        'contact_no' => ['label' => 'Contact', 'max' => 20],
        'term_start' => ['label' => 'Term Start', 'type' => 'date'],
        'term_end'   => ['label' => 'Term End', 'type' => 'date'],
        'photo'      => ['label' => 'Photo (JPG/PNG)', 'type' => 'file', 'allowed' => ['jpg', 'jpeg', 'png'], 'list' => false],
        'signature'  => ['label' => 'Signature image (JPG/PNG)', 'type' => 'file', 'allowed' => ['jpg', 'jpeg', 'png'], 'help' => 'Used on printed certificates.'],
        'status'     => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Active', 'options' => opts(['Active', 'Inactive'])],
    ],
    'columns' => ['full_name', 'position', 'contact_no', 'term_start', 'term_end', 'status'],
    'validate' => function ($d) {
        $err = [];
        if (!empty($d['term_start']) && !empty($d['term_end']) && $d['term_end'] < $d['term_start']) $err['term_end'] = 'Term end must be after term start.';
        if (!empty($d['contact_no']) && !valid_phone($d['contact_no'])) $err['contact_no'] = 'Enter a valid contact number.';
        return $err;
    },
];
crud_run($cfg);
