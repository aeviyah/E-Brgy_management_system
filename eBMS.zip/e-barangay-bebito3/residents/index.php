<?php
// RESIDENT MANAGEMENT - list, add, edit, view, archive, verification queue
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'residents', 'title' => 'Residents', 'singular' => 'Resident', 'table' => 'residents',
    'ref' => 'resident_no', 'order' => 't.last_name, t.first_name', 'after_save' => 'view',
    'archive' => ['value' => 'Archived', 'restore' => 'Active'],
    'history' => true, 'remarks_field' => 'remarks',
    'search' => ['t.resident_no', 't.first_name', 't.last_name', "CONCAT(t.first_name,' ',t.last_name)", 't.contact_no'],
    'intro' => 'Residents with the status "Pending Verification" are waiting for the Secretary to verify them (click the chip below).',
    'fields' => [
        'resident_no'   => ['label' => 'Resident ID', 'required' => true, 'unique' => true, 'max' => 30, 'default' => next_number('RES', 'residents', 'resident_no'), 'help' => 'Auto-suggested. Must be unique.'],
        'first_name'    => ['label' => 'First Name', 'required' => true, 'max' => 60],
        'middle_name'   => ['label' => 'Middle Name', 'max' => 60],
        'last_name'     => ['label' => 'Last Name', 'required' => true, 'max' => 60],
        'birthdate'     => ['label' => 'Birthdate', 'type' => 'date', 'required' => true, 'not_future' => true],
        'sex'           => ['label' => 'Sex', 'type' => 'select', 'required' => true, 'options' => opts(['Male', 'Female']), 'filter' => true],
        'civil_status'  => ['label' => 'Civil Status', 'type' => 'select', 'required' => true, 'options' => opts(['Single', 'Married', 'Widowed', 'Separated'])],
        'contact_no'    => ['label' => 'Contact Number', 'max' => 20, 'placeholder' => '09XXXXXXXXX'],
        'email'         => ['label' => 'Email', 'type' => 'email', 'max' => 120],
        'address'       => ['label' => 'Address', 'required' => true, 'max' => 200, 'full' => true],
        'purok_id'      => ['label' => 'Purok/Sitio', 'type' => 'select', 'required' => true, 'sql' => "SELECT id, name FROM puroks WHERE status <> 'Archived' ORDER BY name", 'filter' => true],
        'household_id'  => ['label' => 'Household', 'type' => 'select', 'sql' => "SELECT id, CONCAT(household_no, ' - ', address) FROM households WHERE status <> 'Archived' ORDER BY household_no", 'help' => 'Optional. Link the resident to a household.'],
        'occupation'    => ['label' => 'Occupation', 'max' => 80],
        'residency_status' => ['label' => 'Residency Status', 'type' => 'select', 'required' => true, 'default' => 'Permanent', 'options' => opts(['Permanent', 'Temporary', 'Transient'])],
        'is_senior'     => ['label' => 'Senior Citizen', 'type' => 'checkbox'],
        'is_pwd'        => ['label' => 'PWD', 'type' => 'checkbox'],
        'is_solo_parent' => ['label' => 'Solo Parent', 'type' => 'checkbox'],
        'is_4ps'        => ['label' => '4Ps Beneficiary', 'type' => 'checkbox'],
        'status'        => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Active',
                            'options' => opts(['Pending Verification', 'Active', 'Rejected', 'Inactive']), 'filter' => true],
        'remarks'       => ['label' => 'Remarks', 'max' => 255, 'full' => true],
    ],
    'computed' => [
        'full_name' => ['label' => 'Name', 'sql' => "CONCAT(t.last_name, ', ', t.first_name, ' ', COALESCE(t.middle_name, ''))"],
        'age'       => ['label' => 'Age', 'sql' => 'TIMESTAMPDIFF(YEAR, t.birthdate, CURDATE())'],
    ],
    'columns' => ['resident_no', 'full_name', 'age', 'sex', 'purok_id', 'contact_no', 'status'],
    'validate' => function ($data) {
        $err = [];
        if (!empty($data['contact_no']) && !valid_phone($data['contact_no'])) $err['contact_no'] = 'Enter a valid contact number.';
        return $err;
    },
    'actions' => [
        ['key' => 'approve', 'label' => 'Verify & Approve', 'from' => ['Pending Verification', 'Rejected'], 'to' => 'Active', 'roles' => ['admin', 'secretary'], 'class' => 'btn-green', 'remarks' => 'optional'],
        ['key' => 'reject', 'label' => 'Reject', 'from' => ['Pending Verification'], 'to' => 'Rejected', 'roles' => ['admin', 'secretary'], 'class' => 'btn-red', 'remarks' => 'required'],
        ['key' => 'deactivate', 'label' => 'Deactivate', 'from' => ['Active'], 'to' => 'Inactive', 'roles' => ['admin', 'secretary'], 'class' => 'btn-outline', 'remarks' => 'optional'],
        ['key' => 'activate', 'label' => 'Re-activate', 'from' => ['Inactive'], 'to' => 'Active', 'roles' => ['admin', 'secretary'], 'class' => 'btn-green'],
    ],
    // Notify the resident when the registration is approved/rejected
    'notify' => function ($row, $to, $remarks, $act) {
        if ($act['key'] === 'approve') return ['resident_id' => $row['id'], 'title' => 'Registration Approved', 'message' => 'Your barangay resident registration has been approved. You can now request documents and services online.'];
        if ($act['key'] === 'reject') return ['resident_id' => $row['id'], 'title' => 'Registration Not Approved', 'message' => 'Your barangay resident registration was not approved. Reason: ' . $remarks . '. Please visit the barangay hall.'];
        return null;
    },
    'view_extra' => function ($row) {
        echo '<div class="grid grid-2">';
        echo '<div class="card"><h3>Household</h3>';
        if ($row['household_id']) {
            $hh = db_one("SELECT * FROM households WHERE id = ?", [$row['household_id']]);
            echo '<p><strong>' . e($hh['household_no']) . '</strong> - ' . e($hh['address']) . '</p>';
            if (user_can('households')) echo '<p><a href="' . BASE_URL . 'households/index.php?action=view&id=' . (int)$hh['id'] . '">Open household &raquo;</a></p>';
        } else echo '<p class="help">Not linked to any household.</p>';
        echo '</div>';
        echo '<div class="card"><h3>Recent Document Requests</h3>';
        $docs = db_all("SELECT dr.request_no, dr.status, d.name FROM document_requests dr JOIN documents d ON d.id = dr.document_id WHERE dr.resident_id = ? ORDER BY dr.id DESC LIMIT 5", [$row['id']]);
        foreach ($docs as $d) echo '<p>' . e($d['request_no']) . ' - ' . e($d['name']) . ' ' . badge($d['status']) . '</p>';
        if (!$docs) echo '<p class="help">No document requests.</p>';
        echo '</div></div>';
        if (user_can('payments')) {
            echo '<div class="card"><h3>Recent Payments</h3>';
            $pays = db_all("SELECT transaction_id, purpose, amount, payment_date, status FROM payments WHERE resident_id = ? ORDER BY id DESC LIMIT 5", [$row['id']]);
            foreach ($pays as $p) echo '<p>' . e($p['transaction_id']) . ' - ' . e($p['purpose']) . ' - ' . money($p['amount']) . ' ' . badge($p['status']) . '</p>';
            if (!$pays) echo '<p class="help">No payments.</p>';
            echo '</div>';
        }
    },
];
crud_run($cfg);
