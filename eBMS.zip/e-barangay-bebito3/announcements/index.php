<?php
// ANNOUNCEMENTS: Draft > Published > Archived. "Publish & Notify" also sends in-app + email + SMS to residents.
require_once '../auth.php';
require_once '../includes/crud.php';

$a = ['admin', 'secretary'];
function notify_all_residents($row) {
    $title = 'New Announcement: ' . $row['title'];
    $msg = mb_strimwidth($row['title'] . ' - ' . $row['content'], 0, 150, '...');
    foreach (db_all("SELECT id FROM residents WHERE status = 'Active'") as $r) notify_resident($r['id'], $title, $msg, ['inapp', 'email', 'sms'], BASE_URL . 'announcements/index.php?action=view&id=' . $row['id']);
    log_activity('Notify', 'Announcement "' . $row['title'] . '" sent to all active residents', 'announcements#' . $row['id']);
}
$cfg = [
    'module' => 'announcements', 'title' => 'Announcements', 'singular' => 'Announcement', 'table' => 'announcements',
    'ref' => 'title', 'order' => 't.id DESC', 'archive' => ['value' => 'Archived', 'restore' => 'Draft'], 'after_save' => 'view',
    'search' => ['t.title', 't.content'],
    'resident' => ['column' => null, 'where' => "t.status = 'Published' AND t.audience IN ('Public','Residents Only')"],
    'fields' => [
        'title'       => ['label' => 'Title', 'required' => true, 'max' => 150, 'full' => true],
        'content'     => ['label' => 'Content', 'type' => 'textarea', 'required' => true],
        'audience'    => ['label' => 'Audience', 'type' => 'select', 'required' => true, 'default' => 'Public', 'options' => opts(['Public', 'Residents Only']), 'filter' => true, 'help' => '"Public" shows on the public portal too.'],
        'status'      => ['label' => 'Status', 'type' => 'auto', 'value' => 'Draft', 'options' => opts(['Draft', 'Published', 'Archived'])],
        'date_posted' => ['label' => 'Date Posted', 'type' => 'date', 'form' => false],
        'created_by'  => ['label' => 'Created By', 'type' => 'select', 'sql' => "SELECT id, full_name FROM users", 'form' => false],
    ],
    'before_save' => function (&$data, $id, $existing) { if (!$id) $data['created_by'] = $GLOBALS['CURRENT_USER']['id']; },
    'columns' => ['title', 'audience', 'date_posted', 'created_by', 'status'],
    'actions' => [
        ['key' => 'publish', 'label' => 'Publish', 'from' => ['Draft'], 'to' => 'Published', 'roles' => $a, 'class' => 'btn-green', 'set' => ['date_posted' => function () { return date('Y-m-d'); }], 'notify' => false],
        ['key' => 'publish_notify', 'label' => 'Publish & Notify Residents (Email/SMS)', 'from' => ['Draft'], 'to' => 'Published', 'roles' => $a, 'class' => 'btn-green', 'set' => ['date_posted' => function () { return date('Y-m-d'); }], 'notify' => false,
         'after' => function ($row) { notify_all_residents($row); }],
        ['key' => 'notify_again', 'label' => 'Send Email/SMS to Residents', 'from' => ['Published'], 'to' => 'Published', 'roles' => $a, 'class' => 'btn-outline', 'notify' => false,
         'after' => function ($row) { notify_all_residents($row); }],
        ['key' => 'unpublish', 'label' => 'Unpublish (back to Draft)', 'from' => ['Published'], 'to' => 'Draft', 'roles' => $a, 'class' => 'btn-outline', 'notify' => false],
    ],
];
crud_run($cfg);
