<?php
// SEND MESSAGE - Trigger > Create notification > Send SMS/Email > Record status
require_once '../auth.php';
require_module('communication', 'manage');

$errors = [];
$sent = 0;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $target = $_POST['target'] ?? '';
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $channels = array_values(array_intersect((array)($_POST['channels'] ?? []), ['inapp', 'email', 'sms']));
    if ($subject === '') $errors[] = 'Subject is required.';
    if ($message === '') $errors[] = 'Message is required.';
    if (mb_strlen($message) > 480) $errors[] = 'Message is too long (max 480 characters).';
    if (!$channels) $errors[] = 'Choose at least one channel.';
    $ids = [];
    if ($target === 'all') $ids = array_column(db_all("SELECT id FROM residents WHERE status = 'Active'"), 'id');
    elseif ($target === 'purok') {
        if (!(int)($_POST['purok_id'] ?? 0)) $errors[] = 'Choose a Purok.';
        else $ids = array_column(db_all("SELECT id FROM residents WHERE status = 'Active' AND purok_id = ?", [(int)$_POST['purok_id']]), 'id');
    } elseif ($target === 'resident') {
        if (!(int)($_POST['resident_id'] ?? 0)) $errors[] = 'Choose a resident.';
        else $ids = [(int)$_POST['resident_id']];
    } else $errors[] = 'Choose who will receive the message.';
    if (!$errors && !$ids) $errors[] = 'No active residents found for that selection.';
    if (!$errors) {
        foreach ($ids as $rid) { notify_resident($rid, $subject, $message, $channels); $sent++; }
        log_activity('Send', 'Sent message "' . $subject . '" to ' . $sent . ' resident(s) via ' . implode('/', $channels), 'message_logs');
        flash('success', 'Message sent to ' . $sent . ' resident(s). See the delivery status in the Message Center.');
        redirect('index.php');
    }
}
$templates = db_all("SELECT * FROM message_templates WHERE status = 'Active' ORDER BY name");
$page_title = 'Send Message';
$breadcrumb = ['Communication', 'Send Message'];
require '../includes/header.php';
if ($errors) echo '<div class="alert alert-error">' . implode('<br>', array_map('e', $errors)) . '</div>';
?>
<div class="card">
<p class="help">Mode: <strong><?= e(NOTIFY_MODE) ?></strong> (change in config/mail_sms.php). If email/SMS fails, it is only recorded as "Failed"; the system keeps working.</p>
<form method="post"><?= csrf_field() ?>
<div class="form-grid">
    <div class="form-group"><label>Send to *</label>
        <select name="target" id="target" onchange="document.getElementById('purokbox').style.display=this.value=='purok'?'block':'none';document.getElementById('resbox').style.display=this.value=='resident'?'block':'none';">
            <option value="">-- Select --</option>
            <option value="all" <?= ($_POST['target'] ?? '') === 'all' ? 'selected' : '' ?>>All active residents</option>
            <option value="purok" <?= ($_POST['target'] ?? '') === 'purok' ? 'selected' : '' ?>>One Purok</option>
            <option value="resident" <?= ($_POST['target'] ?? '') === 'resident' ? 'selected' : '' ?>>One resident</option>
        </select></div>
    <div class="form-group" id="purokbox" style="display:none"><label>Purok</label><select name="purok_id"><?php foreach (db_pairs("SELECT id, name FROM puroks WHERE status = 'Active' ORDER BY name") as $id => $n) echo '<option value="' . $id . '">' . e($n) . '</option>'; ?></select></div>
    <div class="form-group" id="resbox" style="display:none"><label>Resident</label><select name="resident_id"><?php foreach (db_pairs(resident_label_sql()) as $id => $n) echo '<option value="' . $id . '">' . e($n) . '</option>'; ?></select></div>
    <div class="form-group full"><label>Use a template (optional)</label>
        <select onchange="var o=this.options[this.selectedIndex]; if(o.value!==''){document.getElementById('subject').value=o.getAttribute('data-s');document.getElementById('message').value=o.getAttribute('data-b');}">
            <option value="">-- none --</option>
            <?php foreach ($templates as $t) echo '<option value="1" data-s="' . e($t['subject']) . '" data-b="' . e($t['body']) . '">' . e($t['name']) . '</option>'; ?>
        </select></div>
    <div class="form-group full"><label>Subject *</label><input type="text" id="subject" name="subject" maxlength="150" value="<?= e($_POST['subject'] ?? '') ?>"></div>
    <div class="form-group full"><label>Message * (max 480 characters)</label><textarea id="message" name="message" maxlength="480"><?= e($_POST['message'] ?? '') ?></textarea></div>
    <div class="form-group full checks"><label>Channels *</label>
        <label><input type="checkbox" name="channels[]" value="inapp" checked> In-app</label>
        <label><input type="checkbox" name="channels[]" value="email" checked> Email</label>
        <label><input type="checkbox" name="channels[]" value="sms" checked> SMS</label></div>
</div>
<p><button class="btn" onclick="return confirm('Send this message now?')">Send Message</button> <a class="btn btn-outline" href="index.php">Cancel</a></p>
</form></div>
<script>document.getElementById('target').dispatchEvent(new Event('change'));</script>
<?php require '../includes/footer.php'; ?>
