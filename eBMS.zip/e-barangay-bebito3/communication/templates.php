<?php
// MESSAGE TEMPLATES
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'communication', 'title' => 'Message Templates', 'singular' => 'Template', 'table' => 'message_templates',
    'ref' => 'name', 'order' => 't.name', 'archive' => ['value' => 'Archived', 'restore' => 'Active'],
    'search' => ['t.name', 't.body'],
    'fields' => [
        'name'    => ['label' => 'Template Name', 'required' => true, 'unique' => true, 'max' => 80],
        'channel' => ['label' => 'Channel', 'type' => 'select', 'required' => true, 'options' => opts(['Email', 'SMS', 'Both'])],
        'subject' => ['label' => 'Subject (email)', 'max' => 150],
        'body'    => ['label' => 'Message Body', 'type' => 'textarea', 'required' => true],
        'status'  => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Active', 'options' => opts(['Active', 'Inactive'])],
    ],
    'columns' => ['name', 'channel', 'subject', 'status'],
];
crud_run($cfg);
