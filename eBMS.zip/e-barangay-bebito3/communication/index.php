<?php
// COMMUNICATION CENTER - message history (email + SMS) with delivery status
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'communication', 'title' => 'Message Center (History)', 'singular' => 'Message', 'table' => 'message_logs',
    'ref' => 'id', 'order' => 't.id DESC', 'no_add' => true, 'no_edit' => true,
    'search' => ['t.recipient', 't.subject', 't.message'],
    'intro' => 'Every Email and SMS the system sends is recorded here. In "test mode" nothing leaves the computer; messages are saved as "Sent (Test Mode)". See config/mail_sms.php.',
    'fields' => [
        'created_at' => ['label' => 'Date / Time'],
        'channel'    => ['label' => 'Channel', 'type' => 'select', 'options' => opts(['Email', 'SMS']), 'filter' => true],
        'recipient'  => ['label' => 'Recipient'],
        'subject'    => ['label' => 'Subject'],
        'message'    => ['label' => 'Message', 'type' => 'textarea'],
        'status'     => ['label' => 'Delivery Status', 'type' => 'select', 'options' => opts(['Sent', 'Sent (Test Mode)', 'Failed']), 'filter' => true],
        'error_message' => ['label' => 'Error'],
    ],
    'columns' => ['created_at', 'channel', 'recipient', 'subject', 'message', 'status'],
    'list_top' => function () {
        if (user_can('communication', 'manage')) echo '<p><a class="btn btn-small" href="send.php">+ Send a Message</a> <a class="btn btn-small btn-outline" href="templates.php">Message Templates</a> <span class="help">Mode: <strong>' . e(NOTIFY_MODE) . '</strong></span></p>';
    },
];
crud_run($cfg);
