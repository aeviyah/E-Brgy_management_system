<?php
// PUROK / SITIO MANAGEMENT
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'puroks', 'title' => 'Purok / Sitio', 'singular' => 'Purok/Sitio', 'table' => 'puroks',
    'ref' => 'name', 'order' => 't.name',
    'archive' => ['value' => 'Archived', 'restore' => 'Active'],
    'search' => ['t.name', 't.leader', 't.assigned_area'],
    'fields' => [
        'name'          => ['label' => 'Purok/Sitio Name', 'required' => true, 'unique' => true, 'max' => 80],
        'leader'        => ['label' => 'Leader', 'max' => 120],
        'assigned_area' => ['label' => 'Assigned Area', 'max' => 150],
        'status'        => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Active', 'options' => opts(['Active', 'Inactive'])],
        'description'   => ['label' => 'Description', 'type' => 'textarea'],
    ],
    'computed' => [
        'residents'  => ['label' => 'Residents', 'sql' => "SELECT COUNT(*) FROM residents r WHERE r.purok_id = t.id AND r.status = 'Active'"],
        'households' => ['label' => 'Households', 'sql' => "SELECT COUNT(*) FROM households h WHERE h.purok_id = t.id AND h.status <> 'Archived'"],
    ],
    'columns' => ['name', 'leader', 'assigned_area', 'residents', 'households', 'status'],
];
crud_run($cfg);
