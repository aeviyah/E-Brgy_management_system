<?php
// AUTHENTICATION - include this file at the top of every protected page.
// Public pages (login, public portal) do:  define('PUBLIC_PAGE', true);  before including.
if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/permissions.php';
require_once __DIR__ . '/includes/notify.php';

// Load the logged-in user from the database on every request (so role/status changes apply immediately)
$CURRENT_USER = null;
if (!empty($_SESSION['user_id'])) {
    $CURRENT_USER = db_one("SELECT * FROM users WHERE id = ? AND status = 'Active'", [(int)$_SESSION['user_id']]);
    if (!$CURRENT_USER) {
        session_unset();
        session_destroy();
        session_start();
    }
}

$CURRENT_RESIDENT = null;
if ($CURRENT_USER && $CURRENT_USER['role'] === 'resident' && $CURRENT_USER['resident_id']) {
    $CURRENT_RESIDENT = db_one("SELECT * FROM residents WHERE id = ?", [(int)$CURRENT_USER['resident_id']]);
}

function is_logged_in() {
    global $CURRENT_USER;
    return $CURRENT_USER !== null;
}
function is_resident() {
    global $CURRENT_USER;
    return $CURRENT_USER && $CURRENT_USER['role'] === 'resident';
}
function has_role($roles) {
    global $CURRENT_USER;
    return $CURRENT_USER && in_array($CURRENT_USER['role'], (array)$roles);
}
function forbidden($msg = 'You do not have permission to open this page.') {
    http_response_code(403);
    $page_title = 'Access Denied';
    $breadcrumb = ['Access Denied'];
    require __DIR__ . '/includes/header.php';
    echo '<div class="card"><h3>Access Denied</h3><p>' . e($msg) . '</p><p><a class="btn" href="' . BASE_URL . 'dashboard.php">Back to Dashboard</a></p></div>';
    require __DIR__ . '/includes/footer.php';
    exit;
}
function require_login() {
    if (!is_logged_in()) redirect(BASE_URL . 'login.php');
}
function require_module($module, $ability = 'view') {
    if (!user_can($module, $ability)) forbidden();
}
function require_roles($roles) {
    if (!has_role($roles)) forbidden();
}

// Check username/password. Returns the user row or an error message string.
function login_attempt($username, $password) {
    $user = db_one("SELECT * FROM users WHERE username = ?", [$username]);
    if (!$user || !password_verify($password, $user['password_hash'])) {
        return 'Invalid username or password.';
    }
    if ($user['status'] !== 'Active') {
        return 'This account is not active. Please contact the barangay office.';
    }
    return $user;
}

// Page protection: everything is protected unless the page says PUBLIC_PAGE
if (!defined('PUBLIC_PAGE')) {
    require_login();
    csrf_verify();
}
