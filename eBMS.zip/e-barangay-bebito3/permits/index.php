<?php
// PERMITS - Barangay Business Clearance
// Applied > Under Review > Assessed > Approved > Released  (or Rejected / Cancelled)
require_once '../auth.php';
require_once '../includes/crud.php';

$staff = ['admin', 'secretary'];
$cfg = [
    'module' => 'permits', 'title' => 'Business Clearance', 'singular' => 'Business Clearance', 'table' => 'permits',
    'ref' => 'permit_no', 'after_save' => 'view', 'history' => true, 'remarks_field' => 'remarks',
    'joins' => 'LEFT JOIN residents rr ON rr.id = t.resident_id',
    'search' => ['t.permit_no', 't.business_name', 'rr.first_name', 'rr.last_name'],
    'resident' => ['column' => 'resident_id', 'add' => true],
    'edit_locked' => ['Approved', 'Released', 'Cancelled', 'Rejected'],
    'fields' => [
        'permit_no'        => ['label' => 'Permit No.', 'type' => 'auto', 'auto' => function () { return next_number('BC', 'permits', 'permit_no'); }],
        'resident_id'      => ['label' => 'Applicant', 'type' => 'select', 'required' => true, 'sql' => resident_label_sql(), 'add_only' => true],
        'business_name'    => ['label' => 'Business Name', 'required' => true, 'max' => 120],
        'business_type'    => ['label' => 'Business Type', 'type' => 'select', 'required' => true, 'options' => opts(['Sari-sari Store', 'Food / Carinderia', 'Retail', 'Services', 'Online Business', 'Manufacturing', 'Other']), 'filter' => true],
        'business_address' => ['label' => 'Business Address', 'required' => true, 'max' => 200, 'full' => true],
        'date_applied'     => ['label' => 'Date Applied', 'type' => 'date', 'required' => true, 'not_future' => true, 'default' => date('Y-m-d')],
        'requirements_file' => ['label' => 'Requirements (PDF/JPG/PNG)', 'type' => 'file'],
        'fee'              => ['label' => 'Assessed Fee (PHP)', 'type' => 'decimal', 'money' => true, 'staff_only' => true, 'default' => '0', 'help' => 'Staff: set the fee here (Edit) before pressing "Assess Fee".'],
        'status'           => ['label' => 'Status', 'type' => 'select', 'options' => opts(['Applied', 'Under Review', 'Assessed', 'Approved', 'Released', 'Rejected', 'Cancelled']), 'form' => false],
        'remarks'          => ['label' => 'Latest Remarks', 'form' => false],
    ],
    'computed' => [
        'applicant' => ['label' => 'Applicant', 'sql' => "SELECT CONCAT(r.last_name, ', ', r.first_name) FROM residents r WHERE r.id = t.resident_id"],
    ],
    'columns' => ['permit_no', 'business_name', 'applicant', 'business_type', 'date_applied', 'fee', 'status'],
    'validate' => function ($data, $id) {
        global $CURRENT_RESIDENT;
        if ($id) return [];
        $rid = is_resident() ? ($CURRENT_RESIDENT['id'] ?? 0) : ($data['resident_id'] ?? 0);
        if (db_val("SELECT status FROM residents WHERE id = ?", [(int)$rid]) !== 'Active') return ['_' => 'Only verified (Active) residents can apply.'];
        return [];
    },
    'actions' => [
        ['key' => 'review', 'label' => 'Start Review', 'from' => ['Applied'], 'to' => 'Under Review', 'roles' => $staff, 'class' => 'btn-blue'],
        ['key' => 'assess', 'label' => 'Assess Fee', 'from' => ['Under Review'], 'to' => 'Assessed', 'roles' => ['admin', 'secretary', 'treasurer'], 'remarks' => 'optional',
         'guard' => function ($row) { return $row['fee'] > 0 ? null : 'Set the fee first: click Edit and enter the assessed fee.'; }],
        ['key' => 'approve', 'label' => 'Approve', 'from' => ['Assessed'], 'to' => 'Approved', 'roles' => ['admin', 'secretary', 'captain'], 'class' => 'btn-green',
         'guard' => function ($row) {
             $paid = (float)db_val("SELECT COALESCE(SUM(amount),0) FROM payments WHERE ref_type = 'permit' AND ref_id = ? AND status = 'Paid'", [$row['id']]);
             return $paid >= $row['fee'] ? null : 'The assessed fee has not been fully paid yet. Treasurer: use "Record Payment".'; }],
        ['key' => 'reject', 'label' => 'Reject', 'from' => ['Applied', 'Under Review', 'Assessed'], 'to' => 'Rejected', 'roles' => ['admin', 'secretary', 'captain'], 'remarks' => 'required', 'class' => 'btn-red'],
        ['key' => 'release', 'label' => 'Release Clearance', 'from' => ['Approved'], 'to' => 'Released', 'roles' => $staff, 'class' => 'btn-green'],
        ['key' => 'cancel', 'label' => 'Cancel Application', 'from' => ['Applied'], 'to' => 'Cancelled', 'resident' => true, 'roles' => $staff, 'class' => 'btn-red'],
    ],
    'notify' => function ($row, $to, $remarks, $act) {
        $t = 'Your Business Clearance application ' . $row['permit_no'] . ' (' . $row['business_name'] . ') is now "' . $to . '".';
        if ($to === 'Assessed') $t .= ' Fee: PHP ' . number_format($row['fee'], 2) . '. Please pay at the Treasurer.';
        if ($remarks !== '') $t .= ' Remarks: ' . $remarks;
        return ['resident_id' => $row['resident_id'], 'title' => 'Business Clearance Update', 'message' => $t, 'channels' => in_array($to, ['Assessed', 'Approved', 'Released', 'Rejected']) ? ['inapp', 'email', 'sms'] : ['inapp'], 'link' => BASE_URL . 'permits/index.php?action=view&id=' . $row['id']];
    },
    'links' => [
        ['label' => 'Record Payment', 'roles' => ['admin', 'treasurer'],
         'url' => function ($row) { return $row['status'] === 'Assessed' && $row['fee'] > 0 ? BASE_URL . 'payments/index.php?action=add&resident_id=' . $row['resident_id'] . '&amount=' . $row['fee'] . '&purpose=' . urlencode('Business clearance fee - ' . $row['permit_no']) . '&ref_type=permit&ref_id=' . $row['id'] : null; }],
    ],
];
crud_run($cfg);
