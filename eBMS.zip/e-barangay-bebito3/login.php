<?php
// LOGIN: check username/password > verify account > create session > check role > open dashboard
define('PUBLIC_PAGE', true);
require_once 'auth.php';
if (is_logged_in()) redirect(BASE_URL . 'dashboard.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($username === '' || $password === '') {
        $error = 'Please enter your username and password.';
    } else {
        $result = login_attempt($username, $password);
        if (is_array($result)) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $result['id'];
            db_exec("UPDATE users SET last_login = NOW() WHERE id = ?", [$result['id']]);
            $CURRENT_USER = $result;
            log_activity('Login', $result['username'] . ' logged in', 'users#' . $result['id']);
            redirect(BASE_URL . 'dashboard.php');
        }
        $error = $result;
        $CURRENT_USER = null;
        db_exec("INSERT INTO activity_logs (username, action, description, ip_address) VALUES (?,?,?,?)",
            [$username, 'Failed Login', 'Failed login attempt for "' . $username . '"', $_SERVER['REMOTE_ADDR'] ?? '']);
    }
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login | E-Barangay <?= e(brgy_short()) ?></title>
<link rel="icon" type="image/svg+xml" href="<?= BASE_URL ?>img/logo.svg">
<link rel="stylesheet" href="<?= BASE_URL ?>css/style.css"><?= scene_css() ?></head>
<body class="login-page">
<section class="login-hero">
    <?= brand_logo('seal', 'Barangay seal') ?>
    <h1><?= e(setting('barangay_name', 'Barangay')) ?></h1>
    <p class="tag"><?= e(setting('municipality')) ?>, <?= e(setting('province')) ?> &mdash; request certificates, pay fees, report concerns and follow your request online.</p>
    <div class="pills">
        <a class="pill" href="public/index.php">Public Barangay Portal</a>
        <a class="pill" href="public/verify.php">Verify a document</a>
        <a class="pill" href="public/announcements.php">Announcements</a>
    </div>
</section>
<section class="login-side">
    <div class="login-box">
        <h2>Welcome back</h2>
        <p class="help" style="margin-bottom:18px">Log in to the E-Barangay Management System.</p>
        <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
        <?php show_flash(); ?>
        <form method="post"><?= csrf_field() ?>
            <div class="form-group"><label for="u">Username</label><input id="u" type="text" name="username" value="<?= e($_POST['username'] ?? '') ?>" autocomplete="username" autofocus></div>
            <div class="form-group"><label for="p">Password</label>
                <div class="pw-wrap"><input id="p" type="password" name="password" autocomplete="current-password"><button type="button" data-toggle-pw="#p">Show</button></div></div>
            <button class="btn" type="submit">Log in</button>
        </form>
        <div class="login-links"><a href="register.php">New resident? Register here</a><br><a href="public/index.php">Visit the public portal</a></div>
        <?php if (defined('DEMO_MODE') && DEMO_MODE): ?>
        <details class="demo"><summary>Demo accounts (for defense / testing)</summary>
            <div class="chips">
                <button type="button" data-fill-user="admin" data-fill-pass="Admin@123">Administrator</button>
                <button type="button" data-fill-user="secretary" data-fill-pass="Secretary@123">Secretary</button>
                <button type="button" data-fill-user="treasurer" data-fill-pass="Treasurer@123">Treasurer</button>
                <button type="button" data-fill-user="captain" data-fill-pass="Captain@123">Punong Barangay</button>
                <button type="button" data-fill-user="staff" data-fill-pass="Staff@123">Staff</button>
                <button type="button" data-fill-user="juan" data-fill-pass="Resident@123">Resident (Juan)</button>
            </div>
            <p class="help">Click a role to fill the form, then press Log in.</p>
        </details>
        <?php endif; ?>
    </div>
</section>
<script src="<?= BASE_URL ?>js/script.js"></script>
</body></html>
