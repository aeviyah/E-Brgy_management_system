<?php
// BUDGET (basic) - yearly allocations
require_once '../auth.php';
require_once '../includes/crud.php';

$year = (int)($_GET['budget_year'] ?? date('Y'));
$cfg = [
    'module' => 'budget', 'title' => 'Budget', 'singular' => 'Budget', 'table' => 'budgets',
    'ref' => 'category', 'order' => 't.budget_year DESC, t.category', 'archive' => ['value' => 'Archived', 'restore' => 'Draft'],
    'search' => ['t.category', 't.allocation'],
    'fields' => [
        'budget_year' => ['label' => 'Budget Year', 'type' => 'number', 'required' => true, 'min' => 2000, 'max_value' => 2100, 'default' => date('Y'), 'filter' => true, 'options' => db_pairs('SELECT DISTINCT budget_year, budget_year FROM budgets ORDER BY 1 DESC')],
        'category'    => ['label' => 'Category', 'required' => true, 'max' => 80],
        'allocation'  => ['label' => 'Allocation (description)', 'max' => 200, 'full' => true],
        'amount'      => ['label' => 'Amount (PHP)', 'type' => 'decimal', 'required' => true, 'money' => true, 'min' => 0.01],
        'status'      => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Draft', 'options' => opts(['Draft', 'Approved'])],
    ],
    'columns' => ['budget_year', 'category', 'allocation', 'amount', 'status'],
    'list_top' => function () use ($year) {
        $budget = (float)db_val("SELECT COALESCE(SUM(amount),0) FROM budgets WHERE budget_year = ? AND status = 'Approved'", [$year]);
        $exp = (float)db_val("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE YEAR(expense_date) = ?", [$year]);
        $dis = (float)db_val("SELECT COALESCE(SUM(amount),0) FROM disbursements WHERE YEAR(disbursement_date) = ? AND status = 'Released'", [$year]);
        $col = (float)db_val("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status = 'Paid' AND YEAR(payment_date) = ?", [$year]);
        echo '<div class="kpis"><div class="kpi"><div class="num">' . money($budget) . '</div><div class="lbl">Approved Budget ' . $year . '</div></div>'
           . '<div class="kpi"><div class="num">' . money($exp) . '</div><div class="lbl">Expenses</div></div>'
           . '<div class="kpi"><div class="num">' . money($dis) . '</div><div class="lbl">Released Disbursements</div></div>'
           . '<div class="kpi"><div class="num">' . money($budget - $exp) . '</div><div class="lbl">Remaining (Budget - Expenses)</div></div>'
           . '<div class="kpi"><div class="num">' . money($col) . '</div><div class="lbl">Collections ' . $year . '</div></div></div>';
    },
];
crud_run($cfg);
