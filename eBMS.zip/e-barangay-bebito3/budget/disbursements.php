<?php
// DISBURSEMENTS: Pending > Approved (Punong Barangay) > Released (Treasurer)
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'budget', 'title' => 'Disbursements', 'singular' => 'Disbursement', 'table' => 'disbursements',
    'ref' => 'voucher_no', 'order' => 't.id DESC', 'history' => true, 'after_save' => 'view', 'date_filter' => 'disbursement_date',
    'search' => ['t.voucher_no', 't.payee', 't.purpose'],
    'edit_locked' => ['Approved', 'Released', 'Cancelled'],
    'fields' => [
        'voucher_no'        => ['label' => 'Voucher No.', 'type' => 'auto', 'auto' => function () { return next_number('DV', 'disbursements', 'voucher_no'); }],
        'payee'             => ['label' => 'Payee', 'required' => true, 'max' => 120],
        'purpose'           => ['label' => 'Purpose', 'required' => true, 'max' => 200, 'full' => true],
        'amount'            => ['label' => 'Amount (PHP)', 'type' => 'decimal', 'required' => true, 'money' => true, 'min' => 0.01],
        'disbursement_date' => ['label' => 'Date', 'type' => 'date', 'required' => true, 'default' => date('Y-m-d')],
        'status'            => ['label' => 'Status', 'type' => 'select', 'options' => opts(['Pending', 'Approved', 'Released', 'Cancelled']), 'form' => false],
    ],
    'columns' => ['voucher_no', 'payee', 'purpose', 'amount', 'disbursement_date', 'status'],
    'actions' => [
        ['key' => 'approve', 'label' => 'Approve', 'from' => ['Pending'], 'to' => 'Approved', 'roles' => ['admin', 'captain'], 'class' => 'btn-green'],
        ['key' => 'release', 'label' => 'Release Payment', 'from' => ['Approved'], 'to' => 'Released', 'roles' => ['admin', 'treasurer'], 'class' => 'btn-green',
         'after' => function ($row) {
             // a released disbursement is recorded as an expense
             db_exec("INSERT INTO expenses (expense_name, category, amount, expense_date, description) VALUES (?,?,?,?,?)",
                 ['Disbursement ' . $row['voucher_no'] . ' - ' . $row['payee'], 'Disbursement', $row['amount'], date('Y-m-d'), $row['purpose']]);
         }],
        ['key' => 'cancel', 'label' => 'Cancel', 'from' => ['Pending', 'Approved'], 'to' => 'Cancelled', 'roles' => ['admin', 'treasurer', 'captain'], 'remarks' => 'required', 'class' => 'btn-red'],
    ],
];
crud_run($cfg);
