<?php
// EXPENSES
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'budget', 'title' => 'Expenses', 'singular' => 'Expense', 'table' => 'expenses',
    'ref' => 'expense_name', 'order' => 't.expense_date DESC, t.id DESC', 'delete' => true, 'status_chips' => false, 'date_filter' => 'expense_date',
    'search' => ['t.expense_name', 't.category', 't.description'],
    'fields' => [
        'expense_name' => ['label' => 'Expense', 'required' => true, 'max' => 150],
        'category'     => ['label' => 'Category', 'required' => true, 'max' => 80],
        'amount'       => ['label' => 'Amount (PHP)', 'type' => 'decimal', 'required' => true, 'money' => true, 'min' => 0.01],
        'expense_date' => ['label' => 'Date', 'type' => 'date', 'required' => true, 'not_future' => true, 'default' => date('Y-m-d')],
        'description'  => ['label' => 'Description', 'max' => 255, 'full' => true],
    ],
    'columns' => ['expense_name', 'category', 'amount', 'expense_date', 'description'],
];
crud_run($cfg);
