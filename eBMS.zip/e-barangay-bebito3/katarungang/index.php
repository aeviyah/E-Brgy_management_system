<?php
// KATARUNGANG PAMBARANGAY (basic)
// Filed > Under Review > Hearing > Mediation > Settled > Closed
require_once '../auth.php';
require_once '../includes/crud.php';

$a = ['admin', 'secretary', 'captain'];
$cfg = [
    'module' => 'katarungan', 'title' => 'Katarungang Pambarangay', 'singular' => 'KP Case', 'table' => 'katarungan_cases',
    'ref' => 'case_no', 'after_save' => 'view', 'history' => true, 'remarks_field' => 'remarks',
    'search' => ['t.case_no', 't.complainant_name', 't.respondent_name', 't.lupon_member'],
    'edit_locked' => ['Settled', 'Closed'],
    'fields' => [
        'case_no'          => ['label' => 'Case No.', 'type' => 'auto', 'auto' => function () { return next_number('KP', 'katarungan_cases', 'case_no'); }],
        'complaint_id'     => ['label' => 'Linked Complaint (optional)', 'type' => 'select', 'sql' => "SELECT id, CONCAT(case_no, ' - ', respondent_name) FROM complaints ORDER BY id DESC"],
        'complainant_name' => ['label' => 'Complainant', 'required' => true, 'max' => 120],
        'respondent_name'  => ['label' => 'Respondent', 'required' => true, 'max' => 120],
        'case_type'        => ['label' => 'Case Type', 'type' => 'select', 'required' => true, 'options' => opts(['Civil', 'Criminal', 'Other']), 'filter' => true],
        'filing_date'      => ['label' => 'Filing Date', 'type' => 'date', 'required' => true, 'not_future' => true, 'default' => date('Y-m-d')],
        'lupon_member'     => ['label' => 'Lupon Member / Pangkat', 'max' => 120],
        'hearing_date'     => ['label' => 'Hearing Date', 'type' => 'date'],
        'mediation_status' => ['label' => 'Mediation Status', 'type' => 'select', 'required' => true, 'default' => 'Not Started', 'options' => opts(['Not Started', 'Ongoing', 'Successful', 'Failed'])],
        'agreement'        => ['label' => 'Agreement / Settlement', 'type' => 'textarea'],
        'status'           => ['label' => 'Status', 'type' => 'select', 'options' => opts(['Filed', 'Under Review', 'Hearing', 'Mediation', 'Settled', 'Closed']), 'form' => false],
        'remarks'          => ['label' => 'Latest Remarks', 'form' => false],
    ],
    'columns' => ['case_no', 'complainant_name', 'respondent_name', 'case_type', 'hearing_date', 'mediation_status', 'status'],
    'actions' => [
        ['key' => 'review', 'label' => 'Start Review', 'from' => ['Filed'], 'to' => 'Under Review', 'roles' => $a, 'class' => 'btn-blue'],
        ['key' => 'hearing', 'label' => 'Set to Hearing', 'from' => ['Under Review'], 'to' => 'Hearing', 'roles' => $a, 'class' => 'btn-blue',
         'guard' => function ($row) { return $row['hearing_date'] ? null : 'Set the Hearing Date first (click Edit).'; }],
        ['key' => 'mediation', 'label' => 'Start Mediation', 'from' => ['Hearing'], 'to' => 'Mediation', 'roles' => $a, 'set' => ['mediation_status' => 'Ongoing'], 'class' => 'btn-blue'],
        ['key' => 'settle', 'label' => 'Settled (Agreement Reached)', 'from' => ['Mediation'], 'to' => 'Settled', 'roles' => $a, 'remarks' => 'required', 'set' => ['mediation_status' => 'Successful'], 'class' => 'btn-green',
         'guard' => function ($row) { return trim((string)$row['agreement']) !== '' ? null : 'Write the Agreement/Settlement first (click Edit).'; }],
        ['key' => 'failed', 'label' => 'Mediation Failed - Close', 'from' => ['Mediation'], 'to' => 'Closed', 'roles' => $a, 'remarks' => 'required', 'set' => ['mediation_status' => 'Failed'], 'class' => 'btn-red'],
        ['key' => 'close', 'label' => 'Close Case', 'from' => ['Settled', 'Filed', 'Under Review'], 'to' => 'Closed', 'roles' => $a, 'remarks' => 'optional', 'class' => 'btn-outline'],
    ],
];
crud_run($cfg);
