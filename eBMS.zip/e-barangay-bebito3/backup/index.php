<?php
// BACKUP & DATA MANAGEMENT (basic): database export + archive summary + recovery instructions
require_once '../auth.php';
require_module('backup', 'manage');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'export') {
    global $conn;
    $name = 'e_barangay_backup_' . date('Ymd_His') . '.sql';
    log_activity('Backup', 'Exported database backup ' . $name, 'backup');
    header('Content-Type: application/sql');
    header('Content-Disposition: attachment; filename="' . $name . '"');
    echo "-- E-Barangay database backup, " . date('Y-m-d H:i:s') . "\nSET FOREIGN_KEY_CHECKS=0;\n\n";
    $tables = array_column(db_all("SHOW TABLES"), 'Tables_in_' . DB_NAME);
    foreach ($tables as $t) {
        $create = $conn->query("SHOW CREATE TABLE `$t`")->fetch_row()[1];
        echo "DROP TABLE IF EXISTS `$t`;\n$create;\n";
        $res = $conn->query("SELECT * FROM `$t`");
        while ($row = $res->fetch_assoc()) {
            $vals = array_map(function ($v) use ($conn) { return $v === null ? 'NULL' : "'" . $conn->real_escape_string($v) . "'"; }, array_values($row));
            echo "INSERT INTO `$t` VALUES (" . implode(',', $vals) . ");\n";
        }
        echo "\n";
    }
    echo "SET FOREIGN_KEY_CHECKS=1;\n";
    exit;
}
$archived = [
    'Residents' => "SELECT COUNT(*) FROM residents WHERE status = 'Archived'", 'Households' => "SELECT COUNT(*) FROM households WHERE status = 'Archived'",
    'Documents' => "SELECT COUNT(*) FROM documents WHERE status = 'Archived'", 'Announcements' => "SELECT COUNT(*) FROM announcements WHERE status = 'Archived'",
    'Ordinances' => "SELECT COUNT(*) FROM ordinances WHERE status = 'Archived'", 'Assets' => "SELECT COUNT(*) FROM assets WHERE status = 'Archived'",
];
$page_title = 'Backup & Data Management';
$breadcrumb = ['Backup'];
require '../includes/header.php';
?>
<div class="grid grid-2">
<div class="card"><h3>Database Export</h3><p>Download a full SQL copy of the database (all tables and records).</p>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="export"><button class="btn">Download SQL Backup</button></form>
    <p class="help">Also copy the <code>uploads/</code> folder to keep uploaded files.</p></div>
<div class="card"><h3>Archived Records</h3><p class="help">Records are archived instead of deleted. Open the module and click the "Archived" chip to restore.</p>
    <table><?php foreach ($archived as $label => $sql) echo '<tr><td>' . e($label) . '</td><td>' . (int)db_val($sql) . '</td></tr>'; ?></table></div>
</div>
<div class="card"><h3>Basic Recovery Instructions</h3><ol>
    <li>Open phpMyAdmin (<code>http://localhost/phpmyadmin</code>).</li>
    <li>Select the <code>e_barangay</code> database (create it first if it does not exist).</li>
    <li>Click <strong>Import</strong>, choose the downloaded .sql file, and press <strong>Go</strong>.</li>
    <li>Copy the saved <code>uploads/</code> folder back into the project folder.</li>
</ol></div>
<?php require '../includes/footer.php'; ?>
