<?php
// Home page = Public Barangay Portal
header('Location: public/index.php');
exit;
