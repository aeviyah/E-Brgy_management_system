<?php
// COMMUNITY ASSISTANCE & LIVELIHOOD - programs
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'assistance', 'title' => 'Assistance Programs', 'singular' => 'Program', 'table' => 'assistance_programs',
    'ref' => 'program_name', 'order' => 't.id DESC', 'archive' => ['value' => 'Archived', 'restore' => 'Planned'],
    'search' => ['t.program_name', 't.eligibility'],
    'fields' => [
        'program_name'    => ['label' => 'Program Name', 'required' => true, 'max' => 120],
        'assistance_type' => ['label' => 'Assistance Type', 'type' => 'select', 'required' => true, 'filter' => true, 'options' => opts(['Food Assistance', 'Financial Assistance', 'Educational Assistance', 'Livelihood Program'])],
        'eligibility'     => ['label' => 'Eligibility', 'max' => 255, 'full' => true],
        'amount_item'     => ['label' => 'Amount / Item', 'max' => 100],
        'start_date'      => ['label' => 'Start Date', 'type' => 'date'],
        'end_date'        => ['label' => 'End Date', 'type' => 'date'],
        'status'          => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Planned', 'options' => opts(['Planned', 'Active', 'Completed'])],
    ],
    'computed' => [
        'beneficiaries' => ['label' => 'Beneficiaries', 'sql' => "SELECT COUNT(*) FROM beneficiaries b WHERE b.program_id = t.id AND b.status <> 'Rejected'"],
    ],
    'columns' => ['program_name', 'assistance_type', 'amount_item', 'start_date', 'end_date', 'beneficiaries', 'status'],
    'validate' => function ($d) { return (!empty($d['start_date']) && !empty($d['end_date']) && $d['end_date'] < $d['start_date']) ? ['end_date' => 'End date must be after the start date.'] : []; },
];
crud_run($cfg);
