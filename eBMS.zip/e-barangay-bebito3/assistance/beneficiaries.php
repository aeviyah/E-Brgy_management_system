<?php
// BENEFICIARIES / DISTRIBUTION: Applied > Eligible > Approved > Distributed (or Rejected)
require_once '../auth.php';
require_once '../includes/crud.php';

$a = ['admin', 'secretary'];
$cfg = [
    'module' => 'assistance', 'title' => 'Beneficiaries & Distribution', 'singular' => 'Beneficiary', 'table' => 'beneficiaries',
    'ref' => 'id', 'order' => 't.id DESC', 'history' => true, 'remarks_field' => 'remarks',
    'joins' => 'LEFT JOIN residents rr ON rr.id = t.resident_id LEFT JOIN assistance_programs pp ON pp.id = t.program_id',
    'search' => ['rr.first_name', 'rr.last_name', 'pp.program_name'],
    'edit_locked' => ['Distributed', 'Rejected'],
    'fields' => [
        'program_id'        => ['label' => 'Program', 'type' => 'select', 'required' => true, 'filter' => true, 'sql' => "SELECT id, program_name FROM assistance_programs WHERE status IN ('Planned','Active') ORDER BY program_name"],
        'resident_id'       => ['label' => 'Beneficiary (Resident)', 'type' => 'select', 'required' => true, 'sql' => resident_label_sql()],
        'eligibility_notes' => ['label' => 'Eligibility Notes', 'max' => 255, 'full' => true],
        'assistance_given'  => ['label' => 'Amount / Item Given', 'max' => 100],
        'distribution_date' => ['label' => 'Distribution Date', 'type' => 'date'],
        'status'            => ['label' => 'Status', 'type' => 'select', 'options' => opts(['Applied', 'Eligible', 'Approved', 'Distributed', 'Rejected']), 'form' => false],
        'remarks'           => ['label' => 'Latest Remarks', 'form' => false],
    ],
    'computed' => [
        'program'  => ['label' => 'Program', 'sql' => "SELECT p.program_name FROM assistance_programs p WHERE p.id = t.program_id"],
        'resident' => ['label' => 'Beneficiary', 'sql' => "SELECT CONCAT(r.last_name, ', ', r.first_name) FROM residents r WHERE r.id = t.resident_id"],
    ],
    'columns' => ['program', 'resident', 'assistance_given', 'distribution_date', 'status'],
    'validate' => function ($d, $id) {
        if (!empty($d['program_id']) && !empty($d['resident_id']) && db_val("SELECT COUNT(*) FROM beneficiaries WHERE program_id = ? AND resident_id = ? AND id <> ?", [$d['program_id'], $d['resident_id'], $id]) > 0)
            return ['resident_id' => 'This resident is already listed in this program.'];
        return [];
    },
    'actions' => [
        ['key' => 'eligible', 'label' => 'Mark Eligible', 'from' => ['Applied'], 'to' => 'Eligible', 'roles' => $a, 'class' => 'btn-blue'],
        ['key' => 'approve', 'label' => 'Approve', 'from' => ['Eligible'], 'to' => 'Approved', 'roles' => ['admin', 'secretary', 'captain'], 'class' => 'btn-green'],
        ['key' => 'distribute', 'label' => 'Record Distribution', 'from' => ['Approved'], 'to' => 'Distributed', 'roles' => $a, 'class' => 'btn-green', 'set' => ['distribution_date' => function () { return date('Y-m-d'); }]],
        ['key' => 'reject', 'label' => 'Reject', 'from' => ['Applied', 'Eligible'], 'to' => 'Rejected', 'roles' => $a, 'remarks' => 'required', 'class' => 'btn-red'],
    ],
    'notify' => function ($row, $to, $remarks) {
        $p = db_val("SELECT program_name FROM assistance_programs WHERE id = ?", [$row['program_id']]);
        return ['resident_id' => $row['resident_id'], 'title' => 'Assistance Program Update', 'message' => 'Your application to "' . $p . '" is now "' . $to . '".' . ($remarks ? ' Remarks: ' . $remarks : ''), 'channels' => in_array($to, ['Approved', 'Distributed', 'Rejected']) ? ['inapp', 'sms'] : ['inapp']];
    },
];
crud_run($cfg);
