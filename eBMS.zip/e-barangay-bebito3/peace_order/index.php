<?php
// PEACE & ORDER - Tanod roster
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'peace_order', 'title' => 'Tanod Roster', 'singular' => 'Tanod', 'table' => 'tanods',
    'ref' => 'name', 'order' => 't.name', 'archive' => ['value' => 'Archived', 'restore' => 'Active'],
    'search' => ['t.name', 't.assigned_area', 't.position'],
    'fields' => [
        'name'          => ['label' => 'Name', 'required' => true, 'max' => 120],
        'contact_no'    => ['label' => 'Contact', 'max' => 20],
        'position'      => ['label' => 'Position', 'type' => 'select', 'required' => true, 'options' => opts(['Chief Tanod', 'Tanod', 'Peace Volunteer'])],
        'assigned_area' => ['label' => 'Assigned Area', 'max' => 100],
        'status'        => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Active', 'options' => opts(['Active', 'Inactive'])],
    ],
    'columns' => ['name', 'contact_no', 'position', 'assigned_area', 'status'],
    'validate' => function ($d) { return (!empty($d['contact_no']) && !valid_phone($d['contact_no'])) ? ['contact_no' => 'Enter a valid contact number.'] : []; },
];
crud_run($cfg);
