<?php
// PATROL / INCIDENT LOG
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'peace_order', 'title' => 'Patrol / Incident Log', 'singular' => 'Patrol Log', 'table' => 'patrol_logs',
    'status_chips' => false, 'delete' => true, 'order' => 't.log_date DESC, t.log_time DESC', 'date_filter' => 'log_date',
    'joins' => 'LEFT JOIN tanods tn ON tn.id = t.tanod_id', 'search' => ['tn.name', 't.location', 't.incident'],
    'fields' => [
        'log_date' => ['label' => 'Date', 'type' => 'date', 'required' => true, 'not_future' => true, 'default' => date('Y-m-d')],
        'log_time' => ['label' => 'Time', 'type' => 'time', 'required' => true],
        'location' => ['label' => 'Location', 'required' => true, 'max' => 150],
        'incident' => ['label' => 'Incident / Observation', 'required' => true, 'max' => 255, 'full' => true],
        'tanod_id' => ['label' => 'Assigned Tanod', 'type' => 'select', 'required' => true, 'sql' => "SELECT id, name FROM tanods WHERE status = 'Active' ORDER BY name", 'filter' => true],
        'remarks'  => ['label' => 'Remarks', 'max' => 255],
    ],
    'columns' => ['log_date', 'log_time', 'location', 'incident', 'tanod_id'],
];
crud_run($cfg);
