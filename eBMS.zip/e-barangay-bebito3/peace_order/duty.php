<?php
// TANOD DUTY SCHEDULE + ATTENDANCE
require_once '../auth.php';
require_once '../includes/crud.php';

$a = ['admin', 'secretary'];
$cfg = [
    'module' => 'peace_order', 'title' => 'Tanod Duty', 'singular' => 'Duty', 'table' => 'tanod_duty',
    'status_field' => 'attendance', 'order' => 't.duty_date DESC, t.shift_start', 'delete' => true, 'date_filter' => 'duty_date',
    'joins' => 'LEFT JOIN tanods tn ON tn.id = t.tanod_id', 'search' => ['tn.name', 't.area'],
    'fields' => [
        'duty_date'   => ['label' => 'Date', 'type' => 'date', 'required' => true, 'default' => date('Y-m-d')],
        'shift_start' => ['label' => 'Time From', 'type' => 'time', 'required' => true],
        'shift_end'   => ['label' => 'Time To', 'type' => 'time', 'required' => true],
        'tanod_id'    => ['label' => 'Assigned Tanod', 'type' => 'select', 'required' => true, 'sql' => "SELECT id, name FROM tanods WHERE status = 'Active' ORDER BY name", 'filter' => true],
        'area'        => ['label' => 'Area', 'required' => true, 'max' => 100],
        'attendance'  => ['label' => 'Attendance', 'type' => 'select', 'options' => opts(['Scheduled', 'Present', 'Late', 'Absent']), 'form' => false],
        'remarks'     => ['label' => 'Remarks', 'max' => 255],
    ],
    'columns' => ['duty_date', 'shift_start', 'shift_end', 'tanod_id', 'area', 'attendance'],
    'validate' => function ($d) { return (!empty($d['shift_start']) && !empty($d['shift_end']) && $d['shift_end'] <= $d['shift_start']) ? ['shift_end' => 'Overnight shifts: split into two entries. End time must be after start time.'] : []; },
    'actions' => [
        ['key' => 'present', 'label' => 'Mark Present', 'from' => ['Scheduled', 'Late', 'Absent'], 'to' => 'Present', 'roles' => $a, 'class' => 'btn-green'],
        ['key' => 'late', 'label' => 'Mark Late', 'from' => ['Scheduled'], 'to' => 'Late', 'roles' => $a, 'class' => 'btn-blue'],
        ['key' => 'absent', 'label' => 'Mark Absent', 'from' => ['Scheduled', 'Late'], 'to' => 'Absent', 'roles' => $a, 'class' => 'btn-red'],
    ],
];
crud_run($cfg);
