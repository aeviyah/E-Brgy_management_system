// Basic JavaScript for E-Barangay (Barangay Bebito, Lopez, Quezon)
// Everything here is progressive: if this file fails, the PHP pages still work.

// ---------- Sidebar (mobile open/close + scrim) ----------
function toggleSidebar() {
    var sb = document.getElementById('sidebar');
    var scrim = document.getElementById('scrim');
    if (!sb) return;
    var open = sb.classList.toggle('open');
    if (scrim) scrim.classList.toggle('show', open);
}

// ---------- Modal dialogs (replace the plain browser prompt / confirm) ----------
function openModal(opts) {
    var back = document.createElement('div');
    back.className = 'modal-back';
    var box = document.createElement('div');
    box.className = 'modal' + (opts.danger ? ' danger' : '');
    box.setAttribute('role', 'dialog');
    box.setAttribute('aria-modal', 'true');

    var h = document.createElement('h4'); h.textContent = opts.title || 'Please confirm';
    var p = document.createElement('p'); p.textContent = opts.message || '';
    box.appendChild(h); box.appendChild(p);

    var ta = null, err = null;
    if (opts.input) {
        ta = document.createElement('textarea');
        ta.placeholder = opts.required ? 'Remarks (required)' : 'Remarks (optional)';
        err = document.createElement('div'); err.className = 'm-err';
        box.appendChild(ta); box.appendChild(err);
    }
    var row = document.createElement('div'); row.className = 'm-actions';
    var no = document.createElement('button'); no.type = 'button'; no.className = 'btn btn-outline'; no.textContent = 'Cancel';
    var yes = document.createElement('button'); yes.type = 'button';
    yes.className = 'btn ' + (opts.danger ? 'btn-red' : ''); yes.textContent = opts.okText || 'Confirm';
    row.appendChild(no); row.appendChild(yes); box.appendChild(row);
    back.appendChild(box); document.body.appendChild(back);
    (ta || yes).focus();

    function close() {
        document.removeEventListener('keydown', onKey);
        back.classList.add('out');
        setTimeout(function () { if (back.parentNode) back.parentNode.removeChild(back); }, 180);
    }
    function submit() {
        if (ta && opts.required && ta.value.trim() === '') { err.textContent = 'Remarks are required for this action.'; ta.focus(); return; }
        var v = ta ? ta.value : '';
        close();
        opts.onOk(v);
    }
    function onKey(e) { if (e.key === 'Escape') close(); }
    no.onclick = close; yes.onclick = submit;
    back.addEventListener('mousedown', function (e) { if (e.target === back) close(); });
    document.addEventListener('keydown', onKey);
}

// Ask for remarks before submitting an action form (Approve, Reject, ...)
function askRemarks(button, required) {
    var form = button.closest('form');
    var label = button.getAttribute('data-label') || button.innerText;
    openModal({
        title: label, message: 'Add remarks for this action. They are saved in the record history.',
        input: true, required: required, okText: label,
        danger: /reject|cancel|return|void/i.test(label),
        onOk: function (text) { form.querySelector('input[name=remarks]').value = text; form.submit(); }
    });
    return false;   // the modal submits the form after the person confirms
}

// Generic confirmation for dangerous actions (Archive, Delete) - used as onsubmit="return confirmAction(..)"
function confirmAction(message, form) {
    if (!form || !form.submit) { return confirm(message || 'Are you sure?'); }
    var danger = /archive|delete|void|cancel|reject/i.test(message || '');
    openModal({
        title: danger ? 'Please confirm' : 'Continue?', message: message || 'Are you sure?', danger: danger,
        okText: 'Yes, continue', onOk: function () { form.submit(); }
    });
    return false;
}

document.addEventListener('DOMContentLoaded', function () {

    // ---------- Sidebar groups: open the one holding the current page, remember the rest ----------
    var groups = document.querySelectorAll('.nav-group');
    var saved = {};
    try { saved = JSON.parse(localStorage.getItem('ebNav') || '{}'); } catch (e) {}
    groups.forEach(function (g) {
        var key = g.getAttribute('data-key');
        if (g.querySelector('a.active') || saved[key]) g.classList.add('open');
        g.querySelector('.nav-title').addEventListener('click', function () {
            g.classList.toggle('open');
            saved[key] = g.classList.contains('open');
            try { localStorage.setItem('ebNav', JSON.stringify(saved)); } catch (e) {}
        });
    });
    var act = document.querySelector('.sidebar a.active');
    if (act && act.scrollIntoView) { setTimeout(function () { act.scrollIntoView({ block: 'center' }); }, 350); }

    // ---------- Dashboard numbers count up once on load ----------
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    document.querySelectorAll('.kpi .num').forEach(function (el) {
        var m = el.textContent.match(/^(\D*)([\d,]+(?:\.\d+)?)(.*)$/);
        if (!m || reduce) return;
        var target = parseFloat(m[2].replace(/,/g, '')), dec = (m[2].split('.')[1] || '').length;
        if (!isFinite(target) || target === 0) return;
        var start = null, dur = 900;
        function fmt(v) { return v.toLocaleString('en-US', { minimumFractionDigits: dec, maximumFractionDigits: dec }); }
        el.textContent = m[1] + fmt(0) + m[3];
        function tick(ts) {
            if (start === null) start = ts;
            var t = Math.min(1, (ts - start) / dur), eased = 1 - Math.pow(1 - t, 3);
            el.textContent = m[1] + fmt(target * eased) + m[3];
            if (t < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
    });

    // ---------- Alerts: dismiss button, success messages fade after a few seconds ----------
    document.querySelectorAll('.alert').forEach(function (a) {
        var x = document.createElement('button'); x.type = 'button'; x.className = 'x'; x.setAttribute('aria-label', 'Dismiss'); x.innerHTML = '&times;';
        x.onclick = function () { a.classList.add('gone'); setTimeout(function () { a.style.display = 'none'; }, 400); };
        a.appendChild(x);
        if (a.classList.contains('alert-success')) setTimeout(function () { x.onclick(); }, 6000);
    });

    // ---------- Password show/hide ----------
    document.querySelectorAll('[data-toggle-pw]').forEach(function (b) {
        b.addEventListener('click', function () {
            var i = document.querySelector(b.getAttribute('data-toggle-pw'));
            if (!i) return;
            i.type = i.type === 'password' ? 'text' : 'password';
            b.textContent = i.type === 'password' ? 'Show' : 'Hide';
        });
    });

    // ---------- Demo account chips fill the login form ----------
    document.querySelectorAll('[data-fill-user]').forEach(function (b) {
        b.addEventListener('click', function () {
            var u = document.querySelector('input[name=username]'), p = document.querySelector('input[name=password]');
            if (u && p) { u.value = b.getAttribute('data-fill-user'); p.value = b.getAttribute('data-fill-pass'); p.focus(); }
        });
    });

    // ---------- Press "/" to jump to search ----------
    document.addEventListener('keydown', function (e) {
        var tag = (e.target.tagName || '').toLowerCase();
        if (e.key === '/' && tag !== 'input' && tag !== 'textarea' && tag !== 'select') {
            var s = document.querySelector('.global-search input'); if (s) { e.preventDefault(); s.focus(); }
        }
    });
});
