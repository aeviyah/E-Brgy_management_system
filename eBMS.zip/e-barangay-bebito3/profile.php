<?php
// MY PROFILE - account info, change password, and (for residents) update contact details
require_once 'auth.php';
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = $_POST['do'] ?? '';
    if ($do === 'password') {
        $old = $_POST['old_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        if (!password_verify($old, $CURRENT_USER['password_hash'])) $errors[] = 'Current password is incorrect.';
        if (strlen($new) < 8) $errors[] = 'New password must be at least 8 characters.';
        if ($new !== ($_POST['new_password2'] ?? '')) $errors[] = 'New passwords do not match.';
        if (!$errors) {
            db_exec("UPDATE users SET password_hash = ? WHERE id = ?", [password_hash($new, PASSWORD_DEFAULT), $CURRENT_USER['id']]);
            log_activity('Update', 'Changed own password', 'users#' . $CURRENT_USER['id']);
            flash('success', 'Password changed.');
            redirect('profile.php');
        }
    }
    if ($do === 'contact' && is_resident() && $CURRENT_RESIDENT) {
        $email = trim($_POST['email'] ?? '');
        $contact = trim($_POST['contact_no'] ?? '');
        $address = trim($_POST['address'] ?? '');
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email.';
        if ($contact !== '' && !valid_phone($contact)) $errors[] = 'Enter a valid contact number.';
        if ($address === '') $errors[] = 'Address is required.';
        if (!$errors) {
            db_exec("UPDATE residents SET email = ?, contact_no = ?, address = ? WHERE id = ?", [$email ?: null, $contact ?: null, $address, $CURRENT_RESIDENT['id']]);
            db_exec("UPDATE users SET email = ?, contact_no = ? WHERE id = ?", [$email ?: null, $contact ?: null, $CURRENT_USER['id']]);
            log_activity('Update', 'Resident updated own contact details', 'residents#' . $CURRENT_RESIDENT['id']);
            flash('success', 'Contact details updated.');
            redirect('profile.php');
        }
    }
}
$page_title = 'My Profile';
$breadcrumb = ['My Profile'];
require 'includes/header.php';
if ($errors) echo '<div class="alert alert-error">' . implode('<br>', array_map('e', $errors)) . '</div>';
$r = $CURRENT_RESIDENT;
?>
<div class="grid grid-2">
<div class="card"><h3>Account</h3>
    <dl class="detail"><dt>Name</dt><dd><?= e($CURRENT_USER['full_name']) ?></dd><dt>Username</dt><dd><?= e($CURRENT_USER['username']) ?></dd>
    <dt>Role</dt><dd><?= e($ROLE_LABELS[$CURRENT_USER['role']]) ?></dd><dt>Last login</dt><dd><?= e($CURRENT_USER['last_login']) ?></dd></dl>
    <?php if ($r): ?>
    <h3>Resident Record</h3>
    <dl class="detail"><dt>Resident ID</dt><dd><?= e($r['resident_no']) ?></dd><dt>Status</dt><dd><?= badge($r['status']) ?></dd>
    <dt>Birthdate</dt><dd><?= e(fdate($r['birthdate'])) ?></dd><dt>Purok</dt><dd><?= e(db_val("SELECT name FROM puroks WHERE id = ?", [$r['purok_id']])) ?></dd></dl>
    <?php endif; ?>
</div>
<div>
    <?php if ($r): ?>
    <div class="card"><h3>Update Contact Details</h3><form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="contact">
        <div class="form-group"><label>Email</label><input type="email" name="email" value="<?= e($r['email']) ?>"></div>
        <div class="form-group"><label>Contact Number</label><input type="text" name="contact_no" value="<?= e($r['contact_no']) ?>"></div>
        <div class="form-group"><label>Address</label><input type="text" name="address" value="<?= e($r['address']) ?>"></div>
        <p><button class="btn">Save</button></p></form></div>
    <?php endif; ?>
    <div class="card"><h3>Change Password</h3><form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="password">
        <div class="form-group"><label>Current Password</label><input type="password" name="old_password"></div>
        <div class="form-group"><label>New Password (min 8)</label><input type="password" name="new_password"></div>
        <div class="form-group"><label>Confirm New Password</label><input type="password" name="new_password2"></div>
        <p><button class="btn">Change Password</button></p></form></div>
</div></div>
<?php require 'includes/footer.php'; ?>
