<?php
// DASHBOARD - what needs attention now? (changes with the user's role)
require_once 'auth.php';
$page_title = 'Dashboard';
$breadcrumb = [];
$hide_banner = true;   // the dashboard has its own welcome banner

function welcome_banner($subtitle, $badgeHtml = '') {
    global $CURRENT_USER, $ROLE_LABELS;
    $first = explode(' ', trim($CURRENT_USER['full_name']))[0];
    echo '<div class="welcome">' . brand_logo('seal', 'Barangay seal') . '<div>'
       . '<div class="when">' . e(date('l, F j, Y')) . '</div>'
       . '<h2>' . e(greeting()) . ', ' . e($first) . '!</h2>'
       . '<p>' . e($subtitle) . '</p>'
       . '<p>' . e($ROLE_LABELS[$CURRENT_USER['role']] ?? '') . ' &middot; ' . e(setting('barangay_name', 'Barangay')) . ' ' . $badgeHtml . '</p>'
       . '</div></div>';
}

// ======================= RESIDENT DASHBOARD =======================
if (is_resident()) {
    $rid = (int)$CURRENT_USER['resident_id'];
    $my = $CURRENT_RESIDENT;
    require 'includes/header.php';
    welcome_banner('Request documents, pay fees and track everything from one place.', $my ? badge($my['status']) : '');
    if ($my && $my['status'] === 'Pending Verification') echo '<div class="alert alert-warning"><strong>Registration pending.</strong> The Barangay Secretary is still verifying your registration. You can request documents once you are Active.</div>';
    if ($my && $my['status'] === 'Rejected') echo '<div class="alert alert-error"><strong>Registration not approved.</strong> ' . e($my['remarks']) . ' Please visit the barangay hall.</div>';
    $q = function ($sql) use ($rid) { return (int)db_val($sql, [$rid]); };
    ?>
    <div class="card"><h3>What would you like to do?</h3>
        <p class="help" style="margin:-4px 0 12px">Resident ID: <strong><?= e($my['resident_no'] ?? '') ?></strong></p>
        <div class="quick">
            <a href="documents/index.php"><span class="qi"><?= icon('file') ?></span>Request a Document</a>
            <a href="services/index.php"><span class="qi"><?= icon('hand') ?></span>Request a Service</a>
            <a href="permits/index.php?action=add"><span class="qi"><?= icon('briefcase') ?></span>Business Clearance</a>
            <a href="complaints/index.php?action=add"><span class="qi"><?= icon('scale') ?></span>File a Complaint</a>
            <a href="facilities/reservations.php?action=add"><span class="qi"><?= icon('building') ?></span>Reserve a Facility</a>
        </div></div>
    <div class="kpis">
        <a class="kpi " style="--i:0" href="documents/requests.php"><span class="kico"><?= icon('file') ?></span><div class="num"><?= $q("SELECT COUNT(*) FROM document_requests WHERE resident_id = ? AND status NOT IN ('Completed','Rejected','Cancelled')") ?></div><div class="lbl">Active Document Requests</div></a>
        <a class="kpi k-bay" style="--i:1" href="services/requests.php"><span class="kico"><?= icon('hand') ?></span><div class="num"><?= $q("SELECT COUNT(*) FROM service_requests WHERE resident_id = ? AND status NOT IN ('Completed','Rejected','Cancelled')") ?></div><div class="lbl">Active Service Requests</div></a>
        <a class="kpi k-gold" style="--i:2" href="documents/requests.php?status=For+Payment"><span class="kico"><?= icon('wallet') ?></span><div class="num"><?= $q("SELECT COUNT(*) FROM document_requests WHERE resident_id = ? AND status = 'For Payment'") ?></div><div class="lbl">Fees to Pay</div></a>
        <a class="kpi k-coral" style="--i:3" href="notifications/index.php"><span class="kico"><?= icon('bell') ?></span><div class="num"><?= (int)db_val("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0", [$CURRENT_USER['id']]) ?></div><div class="lbl">Unread Notifications</div></a>
    </div>
    <div class="grid grid-2">
        <div class="card"><h3>My Recent Requests</h3>
            <div class="table-wrap"><table><tr><th>No.</th><th>Request</th><th>Status</th></tr>
            <?php foreach (db_all("SELECT dr.id, dr.request_no, d.name, dr.status FROM document_requests dr JOIN documents d ON d.id = dr.document_id WHERE dr.resident_id = ? ORDER BY dr.id DESC LIMIT 6", [$rid]) as $r): ?>
                <tr><td><a href="documents/requests.php?action=view&id=<?= $r['id'] ?>"><?= e($r['request_no']) ?></a></td><td><?= e($r['name']) ?></td><td><?= badge($r['status']) ?></td></tr>
            <?php endforeach; ?>
            <?php foreach (db_all("SELECT sr.id, sr.request_no, s.name, sr.status FROM service_requests sr JOIN services s ON s.id = sr.service_id WHERE sr.resident_id = ? ORDER BY sr.id DESC LIMIT 4", [$rid]) as $r): ?>
                <tr><td><a href="services/requests.php?action=view&id=<?= $r['id'] ?>"><?= e($r['request_no']) ?></a></td><td><?= e($r['name']) ?></td><td><?= badge($r['status']) ?></td></tr>
            <?php endforeach; ?>
            </table></div></div>
        <div class="card"><h3>Announcements</h3>
            <?php $an = db_all("SELECT id, title, date_posted FROM announcements WHERE status = 'Published' ORDER BY date_posted DESC, id DESC LIMIT 5");
            foreach ($an as $a) echo '<p><a href="announcements/index.php?action=view&id=' . $a['id'] . '"><strong>' . e($a['title']) . '</strong></a><br><small class="help">' . e(fdate($a['date_posted'])) . '</small></p>';
            if (!$an) echo '<p class="help">No announcements.</p>'; ?>
            <h3>Upcoming Events</h3>
            <?php $ev = db_all("SELECT id, name, event_date, location FROM events WHERE status = 'Published' AND event_date >= CURDATE() ORDER BY event_date LIMIT 4");
            foreach ($ev as $x) echo '<p><a href="events/index.php?action=view&id=' . $x['id'] . '"><strong>' . e($x['name']) . '</strong></a><br><small class="help">' . e(fdate($x['event_date'])) . ' &middot; ' . e($x['location']) . '</small></p>';
            if (!$ev) echo '<p class="help">No upcoming events.</p>'; ?>
        </div>
    </div>
    <?php
    require 'includes/footer.php';
    exit;
}

// ======================= STAFF / OFFICIAL DASHBOARD =======================
function kpi($label, $value, $link = '') {
    static $n = 0;
    // icon + colour picked from the label so every card is easy to recognise
    $map = [
        'Total Residents' => ['users', ''], 'Pending Verification' => ['id', 'k-gold'], 'Total Households' => ['house', 'k-bay'],
        'Pending Document Requests' => ['file', 'k-gold'], 'Pending Service Requests' => ['hand', 'k-gold'], 'Open Cases' => ['scale', 'k-coral'],
        'Upcoming Events' => ['calendar', 'k-bay'], "Today's Collection" => ['wallet', ''], 'Collection This Month' => ['chart', 'k-bay'], 'Active Projects' => ['hammer', 'k-gold'],
    ];
    [$ic, $cls] = $map[$label] ?? ['file', ''];
    $tag = $link ? 'a href="' . BASE_URL . $link . '"' : 'div';
    $end = $link ? 'a' : 'div';
    echo "<$tag class=\"kpi $cls\" style=\"--i:" . ($n++) . "\"><span class=\"kico\">" . icon($ic) . "</span><div class=\"num\">" . $value . "</div><div class=\"lbl\">" . e($label) . "</div></$end>";
}
require 'includes/header.php';
welcome_banner('Here is what needs attention in the barangay today.');

echo '<div class="kpis">';
if (user_can('residents')) {
    kpi('Total Residents', (int)db_val("SELECT COUNT(*) FROM residents WHERE status = 'Active'"), 'residents/index.php?status=Active');
    $pv = (int)db_val("SELECT COUNT(*) FROM residents WHERE status = 'Pending Verification'");
    kpi('Pending Verification', $pv, 'residents/index.php?status=Pending+Verification');
}
if (user_can('households')) kpi('Total Households', (int)db_val("SELECT COUNT(*) FROM households WHERE status <> 'Archived'"), 'households/index.php');
if (user_can('doc_requests')) kpi('Pending Document Requests', (int)db_val("SELECT COUNT(*) FROM document_requests WHERE status IN ('Pending','Under Review')"), 'documents/requests.php?status=Pending');
if (user_can('service_requests')) kpi('Pending Service Requests', (int)db_val("SELECT COUNT(*) FROM service_requests WHERE status IN ('Pending','Under Review')"), 'services/requests.php?status=Pending');
if (user_can('complaints')) kpi('Open Cases', (int)db_val("SELECT COUNT(*) FROM complaints WHERE status NOT IN ('Resolved','Closed')") + (int)db_val("SELECT COUNT(*) FROM katarungan_cases WHERE status NOT IN ('Settled','Closed')"), 'cases/index.php');
if (user_can('events')) kpi('Upcoming Events', (int)db_val("SELECT COUNT(*) FROM events WHERE status = 'Published' AND event_date >= CURDATE()"), 'events/index.php');
if (user_can('payments')) {
    kpi("Today's Collection", money(db_val("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='Paid' AND payment_date = CURDATE()")), 'treasury/index.php');
    kpi('Collection This Month', money(db_val("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='Paid' AND DATE_FORMAT(payment_date,'%Y-%m') = DATE_FORMAT(CURDATE(),'%Y-%m')")), 'payments/index.php');
}
if (user_can('projects')) kpi('Active Projects', (int)db_val("SELECT COUNT(*) FROM projects WHERE status = 'Ongoing'"), 'projects/index.php?status=Ongoing');
echo '</div>';

// Quick actions (only the ones this role can use)
echo '<div class="card"><h3>Quick Actions</h3><div class="quick">';
$qa = [
    ['Register Resident', 'residents/index.php?action=add', 'residents', 'manage', 'users'],
    ['Process Documents', 'documents/requests.php', 'doc_requests', 'manage', 'file'],
    ['Review Service Requests', 'services/requests.php', 'service_requests', 'manage', 'hand'],
    ['Record Payment', 'payments/index.php?action=add', 'payments', 'manage', 'wallet'],
    ['File Complaint', 'complaints/index.php?action=add', 'complaints', 'manage', 'scale'],
    ['Create Announcement', 'announcements/index.php?action=add', 'announcements', 'manage', 'megaphone'],
    ['Add Project', 'projects/index.php?action=add', 'projects', 'manage', 'hammer'],
];
foreach ($qa as $a) if (user_can($a[2], $a[3])) echo '<a href="' . BASE_URL . $a[1] . '"><span class="qi">' . icon($a[4]) . '</span>' . e($a[0]) . '</a>';
echo '</div></div>';

echo '<div class="grid grid-2">';
// Requests panel
if (user_can('doc_requests')) {
    $reqs = db_all("SELECT dr.id, dr.request_no, dr.status, d.name, r.first_name, r.last_name, dr.created_at FROM document_requests dr
                    JOIN documents d ON d.id = dr.document_id JOIN residents r ON r.id = dr.resident_id
                    WHERE dr.status IN ('Pending','Under Review','For Payment','Processing','Ready for Release') ORDER BY dr.id DESC LIMIT 8");
    echo '<div class="card"><h3>Pending Document Requests</h3><div class="table-wrap"><table><tr><th>No.</th><th>Resident</th><th>Document</th><th>Status</th></tr>';
    foreach ($reqs as $r) echo '<tr><td><a href="' . BASE_URL . 'documents/requests.php?action=view&id=' . $r['id'] . '">' . e($r['request_no']) . '</a></td><td>' . e($r['last_name'] . ', ' . $r['first_name']) . '</td><td>' . e($r['name']) . '</td><td>' . badge($r['status']) . '</td></tr>';
    if (!$reqs) echo '<tr><td colspan="4" class="empty">Nothing waiting. Good job!</td></tr>';
    echo '</table></div></div>';
}
// Cases panel (permission aware)
if (user_can('complaints')) {
    $cs = db_all("SELECT id, case_no, incident_type, status FROM complaints WHERE status NOT IN ('Resolved','Closed') ORDER BY id DESC LIMIT 6");
    echo '<div class="card"><h3>Open Complaints / Blotter</h3><div class="table-wrap"><table><tr><th>Case No.</th><th>Type</th><th>Status</th></tr>';
    foreach ($cs as $c) echo '<tr><td><a href="' . BASE_URL . 'complaints/index.php?action=view&id=' . $c['id'] . '">' . e($c['case_no']) . '</a></td><td>' . e($c['incident_type']) . '</td><td>' . badge($c['status']) . '</td></tr>';
    if (!$cs) echo '<tr><td colspan="3" class="empty">No open complaints.</td></tr>';
    echo '</table></div></div>';
}
// Analytics
if (user_can('residents')) {
    echo '<div class="card"><h3>Residents per Purok</h3>';
    render_bars(db_pairs("SELECT p.name, COUNT(r.id) FROM puroks p LEFT JOIN residents r ON r.purok_id = p.id AND r.status = 'Active' WHERE p.status <> 'Archived' GROUP BY p.id, p.name ORDER BY p.name"));
    echo '</div>';
}
if (user_can('doc_requests')) {
    echo '<div class="card"><h3>Document Requests by Status</h3>';
    render_bars(db_pairs("SELECT status, COUNT(*) FROM document_requests GROUP BY status ORDER BY COUNT(*) DESC"));
    echo '</div>';
}
// Calendar: upcoming things in the next 30 days
$cal = [];
if (user_can('events')) foreach (db_all("SELECT event_date d, name FROM events WHERE status = 'Published' AND event_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)") as $x) $cal[] = [$x['d'], 'Event', $x['name']];
if (user_can('katarungan')) foreach (db_all("SELECT hearing_date d, case_no FROM katarungan_cases WHERE hearing_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY) AND status IN ('Under Review','Hearing','Mediation')") as $x) $cal[] = [$x['d'], 'Hearing', $x['case_no']];
if (user_can('meetings')) foreach (db_all("SELECT meeting_date d, agenda FROM meetings WHERE status = 'Scheduled' AND meeting_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)") as $x) $cal[] = [$x['d'], 'Meeting', mb_strimwidth($x['agenda'], 0, 40, '...')];
if (user_can('assembly')) foreach (db_all("SELECT assembly_date d FROM assemblies WHERE status = 'Scheduled' AND assembly_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)") as $x) $cal[] = [$x['d'], 'Assembly', 'Barangay Assembly'];
if (user_can('reservations')) foreach (db_all("SELECT r.reserve_date d, f.name FROM reservations r JOIN facilities f ON f.id = r.facility_id WHERE r.status = 'Approved' AND r.reserve_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)") as $x) $cal[] = [$x['d'], 'Reservation', $x['name']];
usort($cal, function ($a, $b) { return strcmp($a[0], $b[0]); });
echo '<div class="card"><h3>Upcoming (next 30 days)</h3>';
foreach (array_slice($cal, 0, 8) as $c) echo '<div class="cal-item"><div class="cal-date"><b>' . e(strtoupper(date('M', strtotime($c[0])))) . '</b><span>' . e(date('j', strtotime($c[0]))) . '</span></div><div><strong>' . e($c[2]) . '</strong><br><span class="badge badge-grey">' . e($c[1]) . '</span></div></div>';
if (!$cal) echo '<p class="help">Nothing scheduled.</p>';
echo '</div>';
// Recent activity
$own = user_can('audit') ? '' : ' WHERE user_id = ' . (int)$CURRENT_USER['id'];
echo '<div class="card"><h3>Recent Activity</h3>';
foreach (db_all("SELECT username, action, description, created_at FROM activity_logs $own ORDER BY id DESC LIMIT 8") as $l)
    echo '<div class="feed-item"><div><strong>' . e($l['username']) . '</strong>: ' . e($l['description']) . '<br><small class="help">' . e(date('M d h:i A', strtotime($l['created_at']))) . '</small></div></div>';
echo '</div>';
// Announcements
echo '<div class="card"><h3>Recent Announcements</h3>';
$an = db_all("SELECT id, title, status, date_posted FROM announcements WHERE status = 'Published' ORDER BY date_posted DESC, id DESC LIMIT 4");
foreach ($an as $a) echo '<p><a href="' . BASE_URL . 'announcements/index.php?action=view&id=' . $a['id'] . '"><strong>' . e($a['title']) . '</strong></a> <small class="help">' . e(fdate($a['date_posted'])) . '</small></p>';
if (!$an) echo '<p class="help">No published announcements.</p>';
echo '</div></div>';
require 'includes/footer.php';
