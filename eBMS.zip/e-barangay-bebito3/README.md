# E-Barangay Management System (Programming 3)

PHP + MySQL + HTML/CSS/basic JavaScript. No framework. Runs on XAMPP.

## 1. Setup (XAMPP)
1. Copy this folder to `C:\xampp\htdocs\e-barangay`  (folder name must be `e-barangay`; otherwise change `BASE_URL` in `config/database.php`).
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin` > **Import** > choose `database/schema.sql` > Go.
4. Import `database/seed.sql` the same way (sample data and demo accounts).
5. Open `http://localhost/e-barangay/`.

If your MySQL root has a password, edit `config/database.php`.

## 2. Demo accounts
| Role | Username | Password |
|---|---|---|
| System Administrator | admin | Admin@123 |
| Barangay Secretary | secretary | Secretary@123 |
| Barangay Treasurer | treasurer | Treasurer@123 |
| Punong Barangay | captain | Captain@123 |
| Barangay Staff (Peace & Order, Environment, Assets) | staff | Staff@123 |
| Resident (Juan Dela Cruz) | juan | Resident@123 |
| Resident (Ana Santos) | ana | Resident@123 |
| Resident, pending verification (Kevin Ramirez) | kevin | Resident@123 |

Residents can also register themselves at `register.php` (status "Pending Verification" until the Secretary approves).

## 3. Defense demo (matches section 53 of the instructions)
1. Login as **admin** > Dashboard.
2. Residents > **+ Add Resident** > save > see it in the list > **Edit** > **Archive** (database status changes to Archived; use the "Archived" chip to restore).
3. Logout. Login as **juan** > Document Catalog > "Request This Document" > submit (status **Pending**).
4. Login as **secretary** > Document Requests > open the request > **Start Review** > **Approve** (status **For Payment**, resident gets in-app + email + SMS).
5. Login as **treasurer** > Treasury Dashboard > **Record Payment** > save. The system creates the **Transaction**, the **Official Receipt** (Official Receipts > Print Receipt) and moves the request to **Processing**.
6. Login as **secretary** > open the request > **Generate Document** > **Release / Mark Completed**. Use **Print / View Document**.
7. Login as **juan** > the request shows **Completed**; open the printable certificate. Public verification: `public/verify.php`.
8. Secretary > Announcements > Add > **Publish & Notify Residents** > see it on the Public Portal (`public/announcements.php`).
9. Communication > Message Center shows every Email/SMS and its delivery status.
10. Treasurer/Secretary > Reports & Analytics > Collection Report.
11. Admin or Captain > Audit Trail shows every action.

## 4. Email / SMS
`config/mail_sms.php` has `NOTIFY_MODE`:
* `'test'` (default): nothing is sent; messages are saved in the Message Center as "Sent (Test Mode)".
* `'live'`: email uses PHP `mail()` (needs sendmail set up in XAMPP); SMS uses an HTTP gateway (Semaphore format, put your API key). If sending fails it is recorded as "Failed" and the system keeps working.

## 5. How the code is organized
* `auth.php` - session, login check, CSRF check on every POST (include it first on every protected page).
* `includes/permissions.php` - roles and the module access table (shown in Settings > Roles & Permissions).
* `includes/crud.php` - the one reusable engine for list / search / filter / add / edit / view / archive / workflow buttons / validation / CSV export. Each module page (e.g. `residents/index.php`) is only a short array describing its table, fields and workflow, so every button is the same tested code.
* `includes/finance.php` - payment > official receipt > request update.
* `includes/notify.php` - in-app, email and SMS notifications.
* `documents/print.php`, `receipts/print.php`, `public/verify.php` - printable certificate, receipt, verification page.

## 6. Notes and decisions
* **Document request flow:** Pending > Under Review > (For Payment, only if the fee > 0) > Processing > Ready for Release > Completed. Exceptions: Rejected, Returned for Correction, Cancelled.
* **Business clearance:** Applied > Under Review > Assessed (fee set via Edit first) > Approved (only after the fee is paid) > Released.
* **Restricted modules:** BCPC and VAWC are limited to Secretary and Punong Barangay (and Staff only if assigned). The System Administrator is intentionally NOT given access. Residents cannot open them, they are excluded from global search, and every view is written to the Audit Trail.
* **Archive instead of delete:** most records are archived. Only simple logs (patrol log, duty, expenses) can be deleted.
* **Locked modules** (SK, Health Center, Emergency & Disaster) only show a "Future Module" page. Agriculture and dedicated Senior Citizen/PWD systems are not built (senior/PWD are only simple resident tags and report counts).
* Instead of separate `resolutions` and `reports` tables, resolutions are stored in `ordinances` (type column) and reports are generated live from SQL.
* Charts are plain HTML/CSS bars, so the project works without internet.

## 7. Tested
Every page was opened with every role (no PHP errors; permission-denied pages return 403). End-to-end flows were run: registration > approval, document request > payment > receipt > completion, payment cancel, permits, complaints, reservations (double-booking blocked), announcements + notifications, event registration, user creation, backup export, CSV export, CSRF rejection, SQL-injection/XSS probes, file-upload type checks.


## 8. Barangay Bebito, Lopez, Quezon theme (UI/UX layer)

* **Seal / logo:** `img/logo.svg` (placeholder seal). Replace the file with your official barangay seal (same file name, SVG or change the extension in `includes/functions.php > brand_logo()`).
* **Background / "face of the barangay":** `img/scene.svg` is an animated illustrated scene (Sierra Madre hills, rice terraces, coconut palms, bahay kubo). To use a real photo, add `img/brgy-photo.jpg` (hall, plaza, aerial shot) and every banner, login and portal page switches to it automatically.
* **Name / address:** `database/seed.sql` now uses Barangay Bebito, Lopez, Quezon. If you already imported the old seed, run `database/update_to_bebito.sql` once. Phone numbers and email are SAMPLE values: edit them in Settings > Barangay Settings.
* **Demo chips on login:** set `DEMO_MODE` to `false` in `config/database.php` before real use.
* **Animations:** login seal drop, drifting clouds/swaying palms, KPI count-up, growing bar charts, sidebar accordion, status timeline, modal dialogs for Approve/Reject/Archive (replace the plain browser prompts). All respect "reduce motion".
* No PHP logic or database structure was changed. Only the shell (`includes/header|navbar|sidebar|footer`), `css/style.css`, `js/script.js`, login/register, dashboard markup, public portal, printable certificate/receipt and seed text.
