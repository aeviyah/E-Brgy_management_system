<?php
// TREASURY DASHBOARD - daily/monthly collections, pending payments, recent transactions
require_once '../auth.php';
require_module('treasury');

$today = date('Y-m-d');
$month = date('Y-m');
$dayTotal = (float)db_val("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='Paid' AND payment_date = ?", [$today]);
$dayCount = (int)db_val("SELECT COUNT(*) FROM payments WHERE status='Paid' AND payment_date = ?", [$today]);
$monthTotal = (float)db_val("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='Paid' AND DATE_FORMAT(payment_date,'%Y-%m') = ?", [$month]);
$monthCount = (int)db_val("SELECT COUNT(*) FROM payments WHERE status='Paid' AND DATE_FORMAT(payment_date,'%Y-%m') = ?", [$month]);
$unpaid = db_all("SELECT dr.id, dr.request_no, dr.fee_amount, dr.resident_id, d.name, r.first_name, r.last_name FROM document_requests dr
                  JOIN documents d ON d.id = dr.document_id JOIN residents r ON r.id = dr.resident_id WHERE dr.status = 'For Payment' ORDER BY dr.id");
$recent = db_all("SELECT p.*, r.first_name, r.last_name FROM payments p JOIN residents r ON r.id = p.resident_id ORDER BY p.id DESC LIMIT 8");

$page_title = 'Treasury Dashboard';
$breadcrumb = ['Treasury'];
require '../includes/header.php';
?>
<div class="kpis">
    <div class="kpi"><div class="num"><?= money($dayTotal) ?></div><div class="lbl">Today's Collection</div></div>
    <div class="kpi"><div class="num"><?= $dayCount ?></div><div class="lbl">Transactions Today</div></div>
    <div class="kpi"><div class="num"><?= money($monthTotal) ?></div><div class="lbl">This Month's Collection</div></div>
    <div class="kpi"><div class="num"><?= $monthCount ?></div><div class="lbl">Transactions This Month</div></div>
    <a class="kpi" href="<?= BASE_URL ?>documents/requests.php?status=For+Payment"><div class="num"><?= count($unpaid) ?></div><div class="lbl">Waiting for Payment</div></a>
</div>
<div class="card">
    <h3>Pending Payments (Document Requests)</h3>
    <div class="table-wrap"><table><tr><th>Request</th><th>Resident</th><th>Document</th><th>Fee</th><th></th></tr>
    <?php foreach ($unpaid as $u): ?>
        <tr><td><?= e($u['request_no']) ?></td><td><?= e($u['last_name'] . ', ' . $u['first_name']) ?></td><td><?= e($u['name']) ?></td><td><?= money($u['fee_amount']) ?></td>
        <td><?php if (user_can('payments', 'manage')): ?><a class="btn btn-small" href="<?= BASE_URL ?>payments/index.php?action=add&resident_id=<?= $u['resident_id'] ?>&amount=<?= $u['fee_amount'] ?>&purpose=<?= urlencode('Document fee - ' . $u['request_no']) ?>&ref_type=document_request&ref_id=<?= $u['id'] ?>">Record Payment</a><?php endif; ?></td></tr>
    <?php endforeach; if (!$unpaid) echo '<tr><td colspan="5" class="empty">No pending payments.</td></tr>'; ?>
    </table></div>
</div>
<div class="card">
    <h3>Recent Transactions</h3>
    <div class="table-wrap"><table><tr><th>Transaction</th><th>Resident</th><th>Purpose</th><th>Amount</th><th>Date</th><th>Status</th></tr>
    <?php foreach ($recent as $p): ?>
        <tr><td><a href="<?= BASE_URL ?>payments/index.php?action=view&id=<?= $p['id'] ?>"><?= e($p['transaction_id']) ?></a></td><td><?= e($p['last_name'] . ', ' . $p['first_name']) ?></td><td><?= e($p['purpose']) ?></td><td><?= money($p['amount']) ?></td><td><?= e(fdate($p['payment_date'])) ?></td><td><?= badge($p['status']) ?></td></tr>
    <?php endforeach; if (!$recent) echo '<tr><td colspan="6" class="empty">No transactions yet.</td></tr>'; ?>
    </table></div>
    <p><a class="btn btn-outline btn-small" href="<?= BASE_URL ?>reports/index.php?r=collections">Collection Report</a></p>
</div>
<?php require '../includes/footer.php'; ?>
