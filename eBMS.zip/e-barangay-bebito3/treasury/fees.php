<?php
// FEES - fee types and amounts
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'treasury', 'title' => 'Fees', 'singular' => 'Fee', 'table' => 'fees',
    'ref' => 'fee_type', 'order' => 't.fee_type',
    'archive' => ['value' => 'Archived', 'restore' => 'Active'],
    'search' => ['t.fee_type', 't.purpose'],
    'fields' => [
        'fee_type' => ['label' => 'Fee Type', 'required' => true, 'unique' => true, 'max' => 80],
        'purpose'  => ['label' => 'Purpose', 'max' => 200, 'full' => true],
        'amount'   => ['label' => 'Amount (PHP)', 'type' => 'decimal', 'required' => true, 'money' => true],
        'status'   => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Active', 'options' => opts(['Active', 'Inactive'])],
    ],
    'columns' => ['fee_type', 'purpose', 'amount', 'status'],
];
crud_run($cfg);
