<?php
// GLOBAL SEARCH - results depend on the user's permissions.
// BCPC and VAWC records are NEVER included in global search.
require_once '../auth.php';
$q = trim($_GET['q'] ?? '');
$like = '%' . $q . '%';
$sections = [];

if ($q !== '' && mb_strlen($q) >= 2) {
    if (is_resident()) {
        $rid = (int)$CURRENT_USER['resident_id'];
        $sections['My Document Requests'] = ['documents/requests.php', db_all("SELECT dr.id, dr.request_no a, d.name b, dr.status c FROM document_requests dr JOIN documents d ON d.id = dr.document_id WHERE dr.resident_id = ? AND (dr.request_no LIKE ? OR d.name LIKE ? OR dr.purpose LIKE ?) LIMIT 10", [$rid, $like, $like, $like])];
        $sections['My Payments'] = ['payments/index.php', db_all("SELECT id, transaction_id a, purpose b, status c FROM payments WHERE resident_id = ? AND (transaction_id LIKE ? OR purpose LIKE ?) LIMIT 10", [$rid, $like, $like])];
        $sections['Announcements'] = ['announcements/index.php', db_all("SELECT id, title a, DATE_FORMAT(date_posted, '%b %d, %Y') b, status c FROM announcements WHERE status = 'Published' AND (title LIKE ? OR content LIKE ?) LIMIT 10", [$like, $like])];
    } else {
        if (user_can('residents')) $sections['Residents'] = ['residents/index.php', db_all("SELECT id, resident_no a, CONCAT(last_name, ', ', first_name) b, status c FROM residents WHERE resident_no LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR CONCAT(first_name, ' ', last_name) LIKE ? OR contact_no LIKE ? LIMIT 10", [$like, $like, $like, $like, $like])];
        if (user_can('households')) $sections['Households'] = ['households/index.php', db_all("SELECT id, household_no a, address b, status c FROM households WHERE household_no LIKE ? OR address LIKE ? LIMIT 10", [$like, $like])];
        if (user_can('doc_requests')) $sections['Document Requests'] = ['documents/requests.php', db_all("SELECT dr.id, dr.request_no a, CONCAT(r.last_name, ', ', r.first_name, ' - ', d.name) b, dr.status c FROM document_requests dr JOIN residents r ON r.id = dr.resident_id JOIN documents d ON d.id = dr.document_id WHERE dr.request_no LIKE ? OR dr.document_no LIKE ? OR r.last_name LIKE ? OR r.first_name LIKE ? LIMIT 10", [$like, $like, $like, $like])];
        if (user_can('service_requests')) $sections['Service Requests'] = ['services/requests.php', db_all("SELECT sr.id, sr.request_no a, CONCAT(r.last_name, ', ', r.first_name) b, sr.status c FROM service_requests sr JOIN residents r ON r.id = sr.resident_id WHERE sr.request_no LIKE ? OR r.last_name LIKE ? OR r.first_name LIKE ? LIMIT 10", [$like, $like, $like])];
        if (user_can('payments')) $sections['Payments'] = ['payments/index.php', db_all("SELECT p.id, p.transaction_id a, CONCAT(r.last_name, ', ', r.first_name, ' - ', p.purpose) b, p.status c FROM payments p JOIN residents r ON r.id = p.resident_id WHERE p.transaction_id LIKE ? OR p.purpose LIKE ? OR r.last_name LIKE ? LIMIT 10", [$like, $like, $like])];
        if (user_can('complaints')) $sections['Complaints / Blotter'] = ['complaints/index.php', db_all("SELECT id, case_no a, CONCAT(respondent_name, ' - ', incident_type) b, status c FROM complaints WHERE case_no LIKE ? OR respondent_name LIKE ? OR complainant_name LIKE ? LIMIT 10", [$like, $like, $like])];
        if (user_can('katarungan')) $sections['Katarungang Pambarangay'] = ['katarungang/index.php', db_all("SELECT id, case_no a, CONCAT(complainant_name, ' vs ', respondent_name) b, status c FROM katarungan_cases WHERE case_no LIKE ? OR complainant_name LIKE ? OR respondent_name LIKE ? LIMIT 10", [$like, $like, $like])];
        if (user_can('ordinances')) $sections['Ordinances & Resolutions'] = ['ordinances/index.php', db_all("SELECT id, doc_number a, title b, status c FROM ordinances WHERE doc_number LIKE ? OR title LIKE ? LIMIT 10", [$like, $like])];
        if (user_can('announcements')) $sections['Announcements'] = ['announcements/index.php', db_all("SELECT id, title a, audience b, status c FROM announcements WHERE title LIKE ? OR content LIKE ? LIMIT 10", [$like, $like])];
    }
    log_activity('Search', 'Searched for "' . mb_strimwidth($q, 0, 60, '') . '"', 'search');
}
$page_title = 'Global Search';
$breadcrumb = ['Search'];
require '../includes/header.php';
?>
<div class="card"><form method="get" class="filters"><input type="text" name="q" value="<?= e($q) ?>" placeholder="Type at least 2 letters..." style="min-width:300px"><button class="btn btn-small">Search</button></form>
<p class="help">You only see results from modules you are allowed to open.</p></div>
<?php
$found = 0;
foreach ($sections as $title => $s) {
    if (!$s[1]) continue;
    $found += count($s[1]);
    echo '<div class="card"><h3>' . e($title) . '</h3><div class="table-wrap"><table>';
    foreach ($s[1] as $row) echo '<tr><td><a href="' . BASE_URL . $s[0] . '?action=view&id=' . $row['id'] . '"><strong>' . e($row['a']) . '</strong></a></td><td>' . e($row['b']) . '</td><td>' . badge($row['c']) . '</td></tr>';
    echo '</table></div></div>';
}
if ($q !== '' && !$found) echo '<div class="card"><p class="empty">No results for "' . e($q) . '".</p></div>';
require '../includes/footer.php';
