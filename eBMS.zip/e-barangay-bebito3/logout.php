<?php
define('PUBLIC_PAGE', true);
require_once 'auth.php';
if ($CURRENT_USER) log_activity('Logout', $CURRENT_USER['username'] . ' logged out', 'users#' . $CURRENT_USER['id']);
$_SESSION = [];
session_destroy();
session_start();
flash('success', 'You have been logged out.');
redirect(BASE_URL . 'login.php');
