<?php
// ASSETS & INVENTORY
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'assets', 'title' => 'Assets & Inventory', 'singular' => 'Asset', 'table' => 'assets',
    'ref' => 'asset_code', 'order' => 't.asset_code', 'archive' => ['value' => 'Archived', 'restore' => 'Active'],
    'search' => ['t.asset_code', 't.name', 't.location', 't.assigned_to'],
    'fields' => [
        'asset_code'       => ['label' => 'Asset Code', 'required' => true, 'unique' => true, 'max' => 30, 'default' => 'AST-' . str_pad((int)db_val("SELECT COUNT(*) FROM assets") + 1, 4, '0', STR_PAD_LEFT)],
        'name'             => ['label' => 'Name', 'required' => true, 'max' => 120],
        'category'         => ['label' => 'Category', 'type' => 'select', 'required' => true, 'filter' => true, 'options' => opts(['Computer', 'Printer', 'Furniture', 'Vehicle', 'Supplies', 'Equipment', 'Other'])],
        'quantity'         => ['label' => 'Quantity', 'type' => 'number', 'required' => true, 'min' => 0, 'default' => '1'],
        'condition_status' => ['label' => 'Condition', 'type' => 'select', 'required' => true, 'filter' => true, 'options' => opts(['Good', 'Fair', 'Needs Repair', 'Damaged']), 'badge' => true],
        'location'         => ['label' => 'Location', 'max' => 100],
        'assigned_to'      => ['label' => 'Assigned Personnel', 'max' => 120],
        'acquisition_date' => ['label' => 'Acquisition Date', 'type' => 'date', 'not_future' => true],
        'status'           => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Active', 'options' => opts(['Active', 'Under Repair', 'Disposed'])],
    ],
    'columns' => ['asset_code', 'name', 'category', 'quantity', 'condition_status', 'location', 'assigned_to', 'status'],
];
crud_run($cfg);
