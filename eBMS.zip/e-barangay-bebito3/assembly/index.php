<?php
// BARANGAY ASSEMBLY
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'assembly', 'title' => 'Barangay Assembly', 'singular' => 'Assembly', 'table' => 'assemblies',
    'ref' => 'assembly_date', 'order' => 't.assembly_date DESC', 'archive' => ['value' => 'Archived', 'restore' => 'Scheduled'],
    'search' => ['t.location', 't.agenda', 't.concerns'],
    'fields' => [
        'assembly_date' => ['label' => 'Assembly Date', 'type' => 'date', 'required' => true],
        'location'      => ['label' => 'Location', 'required' => true, 'max' => 150],
        'agenda'        => ['label' => 'Agenda', 'type' => 'textarea', 'required' => true],
        'attendees'     => ['label' => 'Attendees', 'type' => 'textarea', 'help' => 'Names or number of attendees.'],
        'minutes'       => ['label' => 'Minutes', 'type' => 'textarea'],
        'concerns'      => ['label' => 'Community Concerns', 'type' => 'textarea'],
        'resolutions'   => ['label' => 'Actions / Resolutions', 'type' => 'textarea'],
        'status'        => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Scheduled', 'options' => opts(['Scheduled', 'Ongoing', 'Completed', 'Cancelled'])],
    ],
    'columns' => ['assembly_date', 'location', 'agenda', 'status'],
];
crud_run($cfg);
