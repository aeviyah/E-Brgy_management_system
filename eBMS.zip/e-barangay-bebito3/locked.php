<?php
require_once 'auth.php';
$name = $_GET['m'] ?? 'This module';
$page_title = $name;
$breadcrumb = ['Locked Module'];
require 'includes/header.php';
?>
<div class="card locked-card">
    <div class="lock-icon"><?= icon('lock') ?></div>
    <h2><?= e($name) ?></h2>
    <p><span class="badge badge-grey">Future Module</span></p>
    <p>This module is currently locked and reserved for future development.</p>
    <p><a class="btn" href="<?= BASE_URL ?>dashboard.php">Back to Dashboard</a></p>
</div>
<?php require 'includes/footer.php'; ?>
