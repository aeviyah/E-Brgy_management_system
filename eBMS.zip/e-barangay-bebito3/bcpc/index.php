<?php
// BCPC / CHILD PROTECTION - basic RESTRICTED records. Not visible to residents.
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'bcpc', 'title' => 'BCPC / Child Protection', 'singular' => 'BCPC Record', 'table' => 'bcpc_records',
    'ref' => 'record_no', 'after_save' => 'view', 'log_view' => true,
    'archive' => ['value' => 'Archived', 'restore' => 'Open'],
    'intro' => 'RESTRICTED: authorized officials only. Every view is recorded in the Audit Trail.',
    'joins' => 'LEFT JOIN residents rr ON rr.id = t.child_resident_id',
    'search' => ['t.record_no', 'rr.first_name', 'rr.last_name', 't.program'],
    'fields' => [
        'record_no'         => ['label' => 'Record No.', 'type' => 'auto', 'auto' => function () { return next_number('BCPC', 'bcpc_records', 'record_no'); }],
        'child_resident_id' => ['label' => 'Child (Resident)', 'type' => 'select', 'required' => true, 'sql' => "SELECT id, CONCAT(last_name, ', ', first_name, ' (', resident_no, ')') FROM residents WHERE status <> 'Archived' AND birthdate > DATE_SUB(CURDATE(), INTERVAL 18 YEAR) ORDER BY last_name", 'help' => 'Only residents under 18 are listed.'],
        'record_type'       => ['label' => 'Record Type', 'type' => 'select', 'required' => true, 'options' => opts(['Program Participation', 'Child Protection Report', 'Case']), 'filter' => true],
        'program'           => ['label' => 'Program', 'max' => 120],
        'record_date'       => ['label' => 'Date', 'type' => 'date', 'required' => true, 'not_future' => true, 'default' => date('Y-m-d')],
        'intervention'      => ['label' => 'Intervention', 'max' => 255, 'full' => true],
        'referral'          => ['label' => 'Referral', 'max' => 150, 'placeholder' => 'e.g. DSWD, Social Welfare Office'],
        'status'            => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Open', 'options' => opts(['Open', 'Ongoing', 'Referred', 'Closed']), 'filter' => true],
        'remarks'           => ['label' => 'Remarks', 'type' => 'textarea'],
        'created_by'        => ['label' => 'Created By', 'type' => 'auto', 'view' => false, 'auto' => function () { return $GLOBALS['CURRENT_USER']['id']; }],
    ],
    'computed' => [
        'child_name' => ['label' => 'Child', 'sql' => "SELECT CONCAT(r.last_name, ', ', r.first_name) FROM residents r WHERE r.id = t.child_resident_id"],
    ],
    'columns' => ['record_no', 'child_name', 'record_type', 'record_date', 'referral', 'status'],
];
crud_run($cfg);
