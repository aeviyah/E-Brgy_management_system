<?php
// HOUSEHOLD MANAGEMENT - one household has many residents
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'households', 'title' => 'Households', 'singular' => 'Household', 'table' => 'households',
    'ref' => 'household_no', 'order' => 't.household_no', 'after_save' => 'view',
    'archive' => ['value' => 'Archived', 'restore' => 'Active'],
    'search' => ['t.household_no', 't.address', "(SELECT CONCAT(r.first_name,' ',r.last_name) FROM residents r WHERE r.id = t.head_resident_id)"],
    'fields' => [
        'household_no'     => ['label' => 'Household Number', 'required' => true, 'unique' => true, 'max' => 30, 'default' => next_number('HH', 'households', 'household_no')],
        'head_resident_id' => ['label' => 'Household Head', 'type' => 'select', 'sql' => resident_label_sql(), 'help' => 'Choose from registered residents.'],
        'address'          => ['label' => 'Address', 'required' => true, 'max' => 200, 'full' => true],
        'purok_id'         => ['label' => 'Purok/Sitio', 'type' => 'select', 'required' => true, 'sql' => "SELECT id, name FROM puroks WHERE status <> 'Archived' ORDER BY name", 'filter' => true],
        'classification'   => ['label' => 'Household Classification', 'type' => 'select', 'options' => opts(['Regular', '4Ps Beneficiary', 'Indigent', 'Solo Parent Household', 'Senior-headed'])],
        'income_bracket'   => ['label' => 'Income Bracket (monthly)', 'type' => 'select', 'options' => opts(['Below 10,000', '10,000 - 20,000', '20,001 - 40,000', 'Above 40,000'])],
        'housing_type'     => ['label' => 'Housing', 'type' => 'select', 'options' => opts(['Owned', 'Rented', 'Shared', 'Informal Settler'])],
        'has_electricity'  => ['label' => 'Has Electricity', 'type' => 'select', 'options' => opts(['Yes', 'No'])],
        'water_source'     => ['label' => 'Water Source', 'type' => 'select', 'options' => opts(['Piped Water', 'Deep Well', 'Spring', 'Water Vendor'])],
        'toilet_facility'  => ['label' => 'Toilet Facility', 'type' => 'select', 'options' => opts(['Water-sealed', 'Pit Latrine', 'Shared', 'None'])],
        'status'           => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Active', 'options' => opts(['Active', 'Inactive']), 'filter' => true],
    ],
    'computed' => [
        'head_name' => ['label' => 'Household Head', 'sql' => "SELECT CONCAT(r.last_name, ', ', r.first_name) FROM residents r WHERE r.id = t.head_resident_id"],
        'members'   => ['label' => 'Members', 'sql' => "SELECT COUNT(*) FROM residents r WHERE r.household_id = t.id AND r.status <> 'Archived'"],
    ],
    'columns' => ['household_no', 'head_name', 'address', 'purok_id', 'members', 'classification', 'status'],
    'view_extra' => function ($row) {
        $members = db_all("SELECT id, resident_no, first_name, last_name, sex, birthdate, status FROM residents WHERE household_id = ? AND status <> 'Archived' ORDER BY birthdate", [$row['id']]);
        echo '<div class="card"><h3>Household Members (' . count($members) . ')</h3><div class="table-wrap"><table><tr><th>Resident ID</th><th>Name</th><th>Sex</th><th>Age</th><th>Status</th></tr>';
        foreach ($members as $m) {
            $link = user_can('residents') ? '<a href="' . BASE_URL . 'residents/index.php?action=view&id=' . $m['id'] . '">' . e($m['resident_no']) . '</a>' : e($m['resident_no']);
            echo '<tr><td>' . $link . '</td><td>' . e($m['last_name'] . ', ' . $m['first_name']) . '</td><td>' . e($m['sex']) . '</td><td>' . age_of($m['birthdate']) . '</td><td>' . badge($m['status']) . '</td></tr>';
        }
        if (!$members) echo '<tr><td colspan="5" class="empty">No members yet. Link residents to this household from the Resident edit form.</td></tr>';
        echo '</table></div></div>';
    },
];
crud_run($cfg);
