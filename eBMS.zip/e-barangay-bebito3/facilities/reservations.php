<?php
// RESERVATIONS: Check Availability > Request > Review > Approve > Reserve > Complete
// Double-booking is blocked: two APPROVED reservations of the same facility cannot overlap.
require_once '../auth.php';
require_once '../includes/crud.php';

// returns the clashing reservation (or null)
function find_conflict($facilityId, $date, $start, $end, $exceptId = 0) {
    return db_one("SELECT reservation_no, start_time, end_time FROM reservations
                   WHERE facility_id = ? AND reserve_date = ? AND status = 'Approved' AND id <> ? AND start_time < ? AND end_time > ?",
                  [(int)$facilityId, $date, (int)$exceptId, $end, $start]);
}
$a = ['admin', 'secretary'];
$cfg = [
    'module' => 'reservations', 'title' => 'Facility Reservations', 'singular' => 'Reservation', 'table' => 'reservations',
    'ref' => 'reservation_no', 'order' => 't.reserve_date DESC, t.start_time', 'after_save' => 'view', 'history' => true, 'remarks_field' => 'remarks',
    'date_filter' => 'reserve_date',
    'joins' => 'LEFT JOIN facilities ff ON ff.id = t.facility_id LEFT JOIN residents rr ON rr.id = t.resident_id',
    'search' => ['t.reservation_no', 'ff.name', 'rr.last_name', 'rr.first_name', 't.purpose'],
    'resident' => ['column' => 'resident_id', 'add' => true],
    'edit_locked' => ['Approved', 'Rejected', 'Cancelled', 'Completed'],
    'fields' => [
        'reservation_no' => ['label' => 'Reservation No.', 'type' => 'auto', 'auto' => function () { return next_number('RSV', 'reservations', 'reservation_no'); }],
        'facility_id'    => ['label' => 'Facility', 'type' => 'select', 'required' => true, 'filter' => true, 'sql' => "SELECT id, name FROM facilities WHERE status = 'Available' ORDER BY name"],
        'resident_id'    => ['label' => 'Requested By', 'type' => 'select', 'required' => true, 'sql' => resident_label_sql(), 'add_only' => true],
        'purpose'        => ['label' => 'Purpose', 'required' => true, 'max' => 200, 'full' => true],
        'reserve_date'   => ['label' => 'Date', 'type' => 'date', 'required' => true, 'not_past' => true],
        'start_time'     => ['label' => 'Start Time', 'type' => 'time', 'required' => true],
        'end_time'       => ['label' => 'End Time', 'type' => 'time', 'required' => true],
        'status'         => ['label' => 'Status', 'type' => 'select', 'options' => opts(['Pending', 'Approved', 'Rejected', 'Cancelled', 'Completed']), 'form' => false],
        'remarks'        => ['label' => 'Latest Remarks', 'form' => false],
    ],
    'computed' => [
        'facility' => ['label' => 'Facility', 'sql' => "SELECT f.name FROM facilities f WHERE f.id = t.facility_id"],
        'requester' => ['label' => 'Requested By', 'sql' => "SELECT CONCAT(r.last_name, ', ', r.first_name) FROM residents r WHERE r.id = t.resident_id"],
    ],
    'columns' => ['reservation_no', 'facility', 'requester', 'reserve_date', 'start_time', 'end_time', 'status'],
    'list_top' => function () {
        // Availability checker
        $fid = (int)($_GET['av_facility'] ?? 0);
        $date = $_GET['av_date'] ?? '';
        echo '<div class="card"><h3>Check Availability</h3><form method="get" class="filters"><select name="av_facility"><option value="">-- Facility --</option>';
        foreach (db_pairs("SELECT id, name FROM facilities WHERE status = 'Available' ORDER BY name") as $id => $n) echo '<option value="' . $id . '"' . ($fid == $id ? ' selected' : '') . '>' . e($n) . '</option>';
        echo '</select><input type="date" name="av_date" value="' . e($date) . '"><button class="btn btn-small">Check</button></form>';
        if ($fid && $date) {
            $rows = db_all("SELECT reservation_no, start_time, end_time FROM reservations WHERE facility_id = ? AND reserve_date = ? AND status = 'Approved' ORDER BY start_time", [$fid, $date]);
            if (!$rows) echo '<p>' . badge('Available') . ' No approved reservations on ' . e(fdate($date)) . '. The whole day is free.</p>';
            foreach ($rows as $r) echo '<p>' . badge('Approved') . ' Already booked: ' . e(ftime($r['start_time'])) . ' - ' . e(ftime($r['end_time'])) . ' (' . e($r['reservation_no']) . ')</p>';
        }
        echo '</div>';
    },
    'validate' => function ($d, $id) {
        global $CURRENT_RESIDENT;
        $err = [];
        $rid = is_resident() ? ($CURRENT_RESIDENT['id'] ?? 0) : ($d['resident_id'] ?? 0);
        if (!$id && db_val("SELECT status FROM residents WHERE id = ?", [(int)$rid]) !== 'Active') $err['_'] = 'Only verified (Active) residents can reserve facilities.';
        if (!empty($d['start_time']) && !empty($d['end_time'])) {
            if ($d['end_time'] <= $d['start_time']) $err['end_time'] = 'End time must be after the start time.';
            elseif (!empty($d['facility_id']) && !empty($d['reserve_date'])) {
                $c = find_conflict($d['facility_id'], $d['reserve_date'], $d['start_time'], $d['end_time'], $id);
                if ($c) $err['reserve_date'] = 'Not available: already reserved ' . ftime($c['start_time']) . ' - ' . ftime($c['end_time']) . ' (' . $c['reservation_no'] . ').';
            }
        }
        return $err;
    },
    'after_create' => function ($id) {
        $row = db_one("SELECT * FROM reservations WHERE id = ?", [$id]);
        notify_roles(['secretary'], 'New Facility Reservation', $row['reservation_no'] . ' needs review.', BASE_URL . 'facilities/reservations.php?action=view&id=' . $id);
    },
    'actions' => [
        ['key' => 'approve', 'label' => 'Approve (Reserve)', 'from' => ['Pending'], 'to' => 'Approved', 'roles' => ['admin', 'secretary', 'captain'], 'class' => 'btn-green', 'remarks' => 'optional',
         'guard' => function ($row) { $c = find_conflict($row['facility_id'], $row['reserve_date'], $row['start_time'], $row['end_time'], $row['id']); return $c ? 'Cannot approve: overlaps with ' . $c['reservation_no'] . '.' : null; }],
        ['key' => 'reject', 'label' => 'Reject', 'from' => ['Pending'], 'to' => 'Rejected', 'roles' => ['admin', 'secretary', 'captain'], 'remarks' => 'required', 'class' => 'btn-red'],
        ['key' => 'complete', 'label' => 'Mark Completed', 'from' => ['Approved'], 'to' => 'Completed', 'roles' => $a, 'class' => 'btn-green'],
        ['key' => 'cancel', 'label' => 'Cancel Reservation', 'from' => ['Pending', 'Approved'], 'to' => 'Cancelled', 'resident' => true, 'roles' => $a, 'class' => 'btn-red'],
    ],
    'notify' => function ($row, $to, $remarks) {
        $t = 'Your facility reservation ' . $row['reservation_no'] . ' for ' . fdate($row['reserve_date']) . ' is now "' . $to . '".';
        if ($remarks !== '') $t .= ' Remarks: ' . $remarks;
        return ['resident_id' => $row['resident_id'], 'title' => 'Reservation Update', 'message' => $t, 'channels' => ['inapp', 'email', 'sms'], 'link' => BASE_URL . 'facilities/reservations.php?action=view&id=' . $row['id']];
    },
];
crud_run($cfg);
