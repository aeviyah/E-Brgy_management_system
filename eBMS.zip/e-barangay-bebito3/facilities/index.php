<?php
// FACILITIES (Covered Court, Barangay Hall, Function Room, Equipment)
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'facilities', 'title' => 'Facilities', 'singular' => 'Facility', 'table' => 'facilities',
    'ref' => 'name', 'order' => 't.name', 'archive' => ['value' => 'Archived', 'restore' => 'Available'],
    'search' => ['t.name', 't.description'],
    'resident' => ['column' => null, 'where' => "t.status = 'Available'"],
    'fields' => [
        'name'          => ['label' => 'Facility Name', 'required' => true, 'unique' => true, 'max' => 100],
        'facility_type' => ['label' => 'Type', 'type' => 'select', 'required' => true, 'filter' => true, 'options' => opts(['Court', 'Hall', 'Room', 'Equipment', 'Other'])],
        'capacity'      => ['label' => 'Capacity', 'type' => 'number', 'min' => 1],
        'description'   => ['label' => 'Description', 'max' => 255, 'full' => true],
        'status'        => ['label' => 'Availability', 'type' => 'select', 'required' => true, 'default' => 'Available', 'options' => opts(['Available', 'Under Maintenance'])],
    ],
    'columns' => ['name', 'facility_type', 'capacity', 'description', 'status'],
    'links' => [
        ['label' => 'Reserve', 'resident' => true, 'roles' => ['admin', 'secretary'],
         'url' => function ($row) { return $row['status'] === 'Available' ? BASE_URL . 'facilities/reservations.php?action=add&facility_id=' . $row['id'] : null; }],
    ],
];
crud_run($cfg);
