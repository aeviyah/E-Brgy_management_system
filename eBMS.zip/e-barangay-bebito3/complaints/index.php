<?php
// COMPLAINTS & BLOTTER
// Filed > Under Review > Assigned > Processing > Resolved > Closed   (or Referred to Katarungang Pambarangay)
// Residents can file a complaint and see ONLY their own. Staff see cases only if authorized.
require_once '../auth.php';
require_once '../includes/crud.php';

$auth = ['admin', 'secretary', 'captain'];
$cfg = [
    'module' => 'complaints', 'title' => 'Complaints & Blotter', 'singular' => 'Complaint', 'table' => 'complaints',
    'ref' => 'case_no', 'after_save' => 'view', 'history' => true, 'remarks_field' => 'remarks',
    'search' => ['t.case_no', 't.complainant_name', 't.respondent_name', 't.incident_type', 't.location',
                 "(SELECT CONCAT(r.first_name,' ',r.last_name) FROM residents r WHERE r.id = t.complainant_id)"],
    'resident' => ['column' => 'complainant_id', 'add' => true],
    'edit_locked' => ['Resolved', 'Closed', 'Referred'],
    'date_filter' => 'incident_date',
    'fields' => [
        'case_no'          => ['label' => 'Blotter / Case No.', 'type' => 'auto', 'auto' => function () { return next_number('BL', 'complaints', 'case_no'); }],
        'complainant_id'   => ['label' => 'Complainant (Resident)', 'type' => 'select', 'sql' => resident_label_sql(), 'help' => 'Leave blank if the complainant is not a registered resident.'],
        'complainant_name' => ['label' => 'Complainant Name (if not a resident)', 'max' => 120, 'staff_only' => true],
        'respondent_name'  => ['label' => 'Respondent', 'required' => true, 'max' => 120],
        'incident_type'    => ['label' => 'Incident Type', 'type' => 'select', 'required' => true, 'filter' => true,
                               'options' => opts(['Noise Complaint', 'Physical Altercation', 'Theft', 'Property Dispute', 'Neighbor Dispute', 'Vandalism', 'Public Disturbance', 'Other'])],
        'incident_date'    => ['label' => 'Date of Incident', 'type' => 'date', 'required' => true, 'not_future' => true],
        'incident_time'    => ['label' => 'Time', 'type' => 'time'],
        'location'         => ['label' => 'Location', 'required' => true, 'max' => 150],
        'description'      => ['label' => 'Description', 'type' => 'textarea', 'required' => true],
        'assigned_to'      => ['label' => 'Assigned Personnel', 'type' => 'select', 'staff_only' => true, 'sql' => "SELECT id, full_name FROM users WHERE role <> 'resident' AND status = 'Active' ORDER BY full_name"],
        'status'           => ['label' => 'Status', 'type' => 'select', 'options' => opts(['Filed', 'Under Review', 'Assigned', 'Processing', 'Resolved', 'Closed', 'Referred']), 'form' => false],
        'remarks'          => ['label' => 'Latest Remarks', 'form' => false],
    ],
    'computed' => [
        'complainant' => ['label' => 'Complainant', 'sql' => "COALESCE((SELECT CONCAT(r.last_name, ', ', r.first_name) FROM residents r WHERE r.id = t.complainant_id), t.complainant_name)"],
    ],
    'columns' => ['case_no', 'complainant', 'respondent_name', 'incident_type', 'incident_date', 'status'],
    'validate' => function ($data) {
        if (!is_resident() && empty($data['complainant_id']) && empty($data['complainant_name'])) return ['complainant_id' => 'Choose the complainant or type the complainant name.'];
        return [];
    },
    'after_create' => function ($id) {
        $row = db_one("SELECT case_no FROM complaints WHERE id = ?", [$id]);
        notify_roles(['secretary', 'captain'], 'New Complaint Filed', $row['case_no'] . ' was filed.', BASE_URL . 'complaints/index.php?action=view&id=' . $id);
    },
    'actions' => [
        ['key' => 'review', 'label' => 'Start Review', 'from' => ['Filed'], 'to' => 'Under Review', 'roles' => $auth, 'class' => 'btn-blue'],
        ['key' => 'assign', 'label' => 'Mark as Assigned', 'from' => ['Under Review'], 'to' => 'Assigned', 'roles' => $auth,
         'guard' => function ($row) { return $row['assigned_to'] ? null : 'Choose the Assigned Personnel first (click Edit).'; }],
        ['key' => 'process', 'label' => 'Start Processing', 'from' => ['Assigned'], 'to' => 'Processing', 'roles' => $auth, 'class' => 'btn-blue'],
        ['key' => 'resolve', 'label' => 'Resolve', 'from' => ['Processing'], 'to' => 'Resolved', 'roles' => $auth, 'remarks' => 'required', 'class' => 'btn-green'],
        ['key' => 'close', 'label' => 'Close Case', 'from' => ['Resolved', 'Filed', 'Under Review'], 'to' => 'Closed', 'roles' => $auth, 'remarks' => 'optional', 'class' => 'btn-outline'],
        ['key' => 'refer', 'label' => 'Refer to Katarungang Pambarangay', 'from' => ['Under Review', 'Assigned', 'Processing'], 'to' => 'Referred', 'roles' => $auth, 'remarks' => 'optional', 'class' => 'btn-outline'],
    ],
    // The complainant is told about progress (in-app only: case details are private)
    'notify' => function ($row, $to, $remarks) {
        if (!$row['complainant_id']) return null;
        return ['resident_id' => $row['complainant_id'], 'title' => 'Complaint Update', 'message' => 'Your complaint ' . $row['case_no'] . ' is now "' . $to . '".', 'channels' => ['inapp', 'sms'], 'link' => BASE_URL . 'complaints/index.php?action=view&id=' . $row['id']];
    },
    'links' => [
        ['label' => 'Create KP Case', 'roles' => ['admin', 'secretary', 'captain'],
         'url' => function ($row) { return $row['status'] === 'Referred' ? BASE_URL . 'katarungang/index.php?action=add&complaint_id=' . $row['id'] . '&respondent_name=' . urlencode($row['respondent_name']) . '&complainant_name=' . urlencode(resident_name($row['complainant_id']) ?: $row['complainant_name']) : null; }],
    ],
];
crud_run($cfg);
