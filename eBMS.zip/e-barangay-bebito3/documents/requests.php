<?php
// DOCUMENT REQUESTS - the main workflow
// Pending > Under Review > (For Payment) > Processing > Ready for Release > Completed
// Exceptions: Rejected, Returned for Correction, Cancelled
require_once '../auth.php';
require_once '../includes/crud.php';

$staffRoles = ['admin', 'secretary'];
$cfg = [
    'module' => 'doc_requests', 'title' => 'Document Requests', 'singular' => 'Document Request', 'table' => 'document_requests',
    'ref' => 'request_no', 'after_save' => 'view', 'history' => true, 'remarks_field' => 'remarks',
    'joins' => 'LEFT JOIN residents rr ON rr.id = t.resident_id LEFT JOIN documents dd ON dd.id = t.document_id',
    'search' => ['t.request_no', 'rr.first_name', 'rr.last_name', 'dd.name', 't.document_no'],
    'resident' => ['column' => 'resident_id', 'add' => true],
    'edit_locked' => ['Processing', 'Ready for Release', 'Completed', 'Cancelled', 'Rejected'],
    'intro' => is_resident() ? 'Submit a request, then track its status here.' : '',
    'fields' => [
        'request_no'  => ['label' => 'Request No.', 'type' => 'auto', 'auto' => function () { return next_number('DR', 'document_requests', 'request_no'); }],
        'resident_id' => ['label' => 'Resident', 'type' => 'select', 'required' => true, 'sql' => resident_label_sql(), 'add_only' => true],
        'document_id' => ['label' => 'Document', 'type' => 'select', 'required' => true, 'sql' => "SELECT id, CONCAT(name, IF(fee > 0, CONCAT(' - PHP ', FORMAT(fee, 2)), ' - Free')) FROM documents WHERE status = 'Active' ORDER BY name", 'filter' => true],
        'purpose'     => ['label' => 'Purpose', 'required' => true, 'max' => 255, 'full' => true, 'placeholder' => 'e.g. Employment, scholarship, school requirement'],
        'requirements_file' => ['label' => 'Upload Requirements (PDF/JPG/PNG)', 'type' => 'file', 'help' => 'Upload a scan or photo of your requirements (max 2 MB).'],
        'status'      => ['label' => 'Status', 'type' => 'select', 'options' => opts(['Pending', 'Under Review', 'For Payment', 'Processing', 'Ready for Release', 'Completed', 'Rejected', 'Returned for Correction', 'Cancelled']), 'form' => false],
        'fee_amount'  => ['label' => 'Fee', 'type' => 'auto', 'money' => true, 'auto' => function ($d) { return (float)db_val("SELECT fee FROM documents WHERE id = ?", [(int)$d['document_id']]); }],
        'payment_status' => ['label' => 'Payment', 'type' => 'auto', 'badge' => true, 'auto' => function ($d) { return ((float)db_val("SELECT fee FROM documents WHERE id = ?", [(int)$d['document_id']])) > 0 ? 'Unpaid' : 'Not Required'; }],
        'remarks'     => ['label' => 'Latest Remarks', 'form' => false],
        'document_no' => ['label' => 'Document No.', 'form' => false],
        'issued_date' => ['label' => 'Date Issued', 'type' => 'date', 'form' => false],
    ],
    'computed' => [
        'resident_name' => ['label' => 'Resident', 'sql' => "SELECT CONCAT(r.last_name, ', ', r.first_name) FROM residents r WHERE r.id = t.resident_id"],
        'doc_name'      => ['label' => 'Document', 'sql' => "SELECT d.name FROM documents d WHERE d.id = t.document_id"],
        'requested'     => ['label' => 'Date Requested', 'sql' => 't.created_at', 'date' => true],
    ],
    'columns' => ['request_no', 'resident_name', 'doc_name', 'requested', 'payment_status', 'status'],
    'validate' => function ($data, $id) {
        global $CURRENT_RESIDENT;
        $err = [];
        if ($id) return $err;   // only check when a NEW request is created
        $rid = is_resident() ? ($CURRENT_RESIDENT['id'] ?? 0) : ($data['resident_id'] ?? 0);
        $st = db_val("SELECT status FROM residents WHERE id = ?", [(int)$rid]);
        if ($st !== 'Active') $err['_'] = 'Only verified (Active) residents can request documents.';
        return $err;
    },
    'after_create' => function ($id, $data) {
        $row = db_one("SELECT dr.*, d.name AS doc_name FROM document_requests dr JOIN documents d ON d.id = dr.document_id WHERE dr.id = ?", [$id]);
        notify_roles(['secretary'], 'New Document Request', $row['request_no'] . ' - ' . $row['doc_name'] . ' needs review.', BASE_URL . 'documents/requests.php?action=view&id=' . $id);
        notify_resident($row['resident_id'], 'Document Request Received', 'Your ' . $row['doc_name'] . ' request (' . $row['request_no'] . ') was received and is pending review.', ['inapp', 'email'], BASE_URL . 'documents/requests.php?action=view&id=' . $id);
    },
    'actions' => [
        ['key' => 'review', 'label' => 'Start Review', 'from' => ['Pending'], 'to' => 'Under Review', 'roles' => $staffRoles, 'class' => 'btn-blue'],
        ['key' => 'approve', 'label' => 'Approve', 'from' => ['Under Review'], 'roles' => ['admin', 'secretary', 'captain'], 'class' => 'btn-green', 'remarks' => 'optional',
         'to_fn' => function ($row) { return $row['fee_amount'] > 0 ? 'For Payment' : 'Processing'; }],
        ['key' => 'return', 'label' => 'Return for Correction', 'from' => ['Under Review'], 'to' => 'Returned for Correction', 'roles' => $staffRoles, 'remarks' => 'required', 'class' => 'btn-outline'],
        ['key' => 'reject', 'label' => 'Reject', 'from' => ['Pending', 'Under Review'], 'to' => 'Rejected', 'roles' => ['admin', 'secretary', 'captain'], 'remarks' => 'required', 'class' => 'btn-red'],
        ['key' => 'resubmit', 'label' => 'Resubmit Request', 'from' => ['Returned for Correction'], 'to' => 'Pending', 'resident' => true, 'roles' => $staffRoles, 'remarks' => 'optional'],
        ['key' => 'ready', 'label' => 'Generate Document (Ready for Release)', 'from' => ['Processing'], 'to' => 'Ready for Release', 'roles' => ['admin', 'secretary', 'captain'], 'class' => 'btn-green',
         'set' => [
             'document_no'       => function ($row) { return next_number('CERT', 'document_requests', 'document_no'); },
             'verification_code' => function ($row) { return strtoupper(bin2hex(random_bytes(6))); },
             'issued_date'       => function ($row) { return date('Y-m-d'); },
         ]],
        ['key' => 'release', 'label' => 'Release / Mark Completed', 'from' => ['Ready for Release'], 'to' => 'Completed', 'roles' => $staffRoles, 'class' => 'btn-green'],
        ['key' => 'cancel', 'label' => 'Cancel Request', 'from' => ['Pending', 'Under Review', 'Returned for Correction'], 'to' => 'Cancelled', 'resident' => true, 'roles' => $staffRoles, 'class' => 'btn-red'],
    ],
    // Every status change tells the resident (in-app + email, SMS for the important ones)
    'notify' => function ($row, $to, $remarks, $act) {
        $doc = db_val("SELECT name FROM documents WHERE id = ?", [$row['document_id']]);
        $sms = ['For Payment', 'Processing', 'Ready for Release', 'Rejected', 'Returned for Correction', 'Completed'];
        $text = 'Your ' . $doc . ' request (' . $row['request_no'] . ') is now "' . $to . '".';
        if ($to === 'For Payment') $text = 'Your ' . $doc . ' request has been approved. Please pay PHP ' . number_format($row['fee_amount'], 2) . ' at the Treasurer.';
        if ($to === 'Ready for Release') $text = 'Your ' . $doc . ' is ready for release/printing. Please check your account for details.';
        if ($remarks !== '') $text .= ' Remarks: ' . $remarks;
        return ['resident_id' => $row['resident_id'], 'title' => 'Document Request Update', 'message' => $text,
                'channels' => in_array($to, $sms) ? ['inapp', 'email', 'sms'] : ['inapp'], 'link' => BASE_URL . 'documents/requests.php?action=view&id=' . $row['id']];
    },
    'links' => [
        ['label' => 'Record Payment', 'roles' => ['admin', 'treasurer'],
         'url' => function ($row) { return $row['status'] === 'For Payment' ? BASE_URL . 'payments/index.php?action=add&resident_id=' . $row['resident_id'] . '&amount=' . $row['fee_amount'] . '&purpose=' . urlencode('Document fee - ' . $row['request_no']) . '&ref_type=document_request&ref_id=' . $row['id'] : null; }],
        ['label' => 'Print / View Document', 'resident' => true, 'roles' => ['admin', 'secretary', 'captain'], 'blank' => true,
         'url' => function ($row) { return in_array($row['status'], ['Ready for Release', 'Completed']) ? BASE_URL . 'documents/print.php?id=' . $row['id'] : null; }],
    ],
    'view_extra' => function ($row) {
        $docRow = db_one("SELECT requirements FROM documents WHERE id = ?", [$row['document_id']]);
        echo '<div class="card"><h3>Required Documents</h3><ul>';
        foreach (preg_split('/\r?\n/', (string)$docRow['requirements']) as $line) if (trim($line) !== '') echo '<li>' . e($line) . '</li>';
        echo '</ul><p>Uploaded file: ' . ($row['requirements_file'] ? file_link($row['requirements_file']) : '<span class="help">none</span>') . '</p></div>';
    },
];
crud_run($cfg);
