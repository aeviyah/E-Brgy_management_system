<?php
// DOCUMENT CATALOG (Barangay Clearance, Certificate of Residency, ...)
require_once '../auth.php';
require_once '../includes/crud.php';

$cfg = [
    'module' => 'documents', 'title' => 'Document Catalog', 'singular' => 'Document', 'table' => 'documents',
    'ref' => 'name', 'order' => 't.name',
    'archive' => ['value' => 'Archived', 'restore' => 'Active'],
    'search' => ['t.name', 't.description'],
    'resident' => ['column' => null, 'where' => "t.status = 'Active'"],
    'intro' => 'Choose a document, read the requirements, then click "Request This Document".',
    'fields' => [
        'name'            => ['label' => 'Document Name', 'required' => true, 'unique' => true, 'max' => 100],
        'description'     => ['label' => 'Description', 'max' => 255, 'full' => true],
        'requirements'    => ['label' => 'Requirements', 'type' => 'textarea', 'help' => 'One requirement per line.'],
        'fee'             => ['label' => 'Fee (PHP)', 'type' => 'decimal', 'required' => true, 'money' => true, 'default' => '0'],
        'processing_days' => ['label' => 'Processing Days', 'type' => 'number', 'required' => true, 'min' => 1, 'default' => '1'],
        'body_text'       => ['label' => 'Certificate Wording', 'type' => 'textarea', 'staff_only' => true, 'view' => false,
                              'help' => 'Placeholders: {name} {age} {civil_status} {address} {purok} {purpose} {date}'],
        'status'          => ['label' => 'Status', 'type' => 'select', 'required' => true, 'default' => 'Active', 'options' => opts(['Active', 'Inactive']), 'staff_only' => true],
    ],
    'columns' => ['name', 'description', 'fee', 'processing_days', 'status'],
    'links' => [
        ['label' => 'Request This Document', 'resident' => true, 'roles' => ['admin', 'secretary'],
         'url' => function ($row) { return $row['status'] === 'Active' ? BASE_URL . 'documents/requests.php?action=add&document_id=' . $row['id'] : null; }],
    ],
    'view_extra' => function ($row) {
        echo '<div class="card"><h3>Requirements Checklist</h3><ul>';
        foreach (preg_split('/\r?\n/', (string)$row['requirements']) as $line) if (trim($line) !== '') echo '<li>' . e($line) . '</li>';
        echo '</ul></div>';
    },
];
crud_run($cfg);
