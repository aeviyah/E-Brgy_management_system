<?php
// PRINTABLE CERTIFICATE (basic). Only for Ready for Release / Completed requests.
require_once '../auth.php';
$id = (int)($_GET['id'] ?? 0);
$req = db_one("SELECT dr.*, d.name AS doc_name, d.body_text, r.first_name, r.middle_name, r.last_name, r.birthdate, r.civil_status, r.address, p.name AS purok
               FROM document_requests dr JOIN documents d ON d.id = dr.document_id JOIN residents r ON r.id = dr.resident_id JOIN puroks p ON p.id = r.purok_id
               WHERE dr.id = ?", [$id]);
if (!$req) forbidden('Request not found.');
if (is_resident()) {
    if ($req['resident_id'] != $CURRENT_USER['resident_id']) forbidden();
} elseif (!user_can('doc_requests')) forbidden();
if (!in_array($req['status'], ['Ready for Release', 'Completed'])) forbidden('The document is not ready yet.');

$captain = db_one("SELECT * FROM officials WHERE position = 'Punong Barangay' AND status = 'Active' ORDER BY id LIMIT 1");
$fullName = strtoupper(trim($req['first_name'] . ' ' . ($req['middle_name'] ? $req['middle_name'][0] . '. ' : '') . $req['last_name']));
$body = $req['body_text'] ?: 'This is to certify that {name}, {age} years old, {civil_status}, is a resident of {address}, {purok}. This certification is issued upon request for {purpose}.';
$body = strtr($body, [
    '{name}' => '<strong>' . e($fullName) . '</strong>', '{age}' => age_of($req['birthdate']), '{civil_status}' => e(strtolower($req['civil_status'])),
    '{address}' => e($req['address']), '{purok}' => e($req['purok']), '{purpose}' => e($req['purpose']), '{date}' => e(date('F d, Y', strtotime($req['issued_date']))),
]);
$verifyUrl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . BASE_URL . 'public/verify.php?code=' . $req['verification_code'];
if ($req['status'] === 'Ready for Release' || $req['status'] === 'Completed') log_activity('Print', 'Viewed/printed document ' . $req['document_no'], 'document_requests#' . $id);
?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title><?= e($req['doc_name']) ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>css/style.css"></head>
<body style="background:#dfe8e2">
<div class="no-print" style="text-align:center;padding:10px"><button class="btn" onclick="window.print()">Print</button> <a class="btn btn-outline" href="javascript:history.back()">Back</a></div>
<div class="certificate"><div class="cert-mark"></div>
    <div class="cert-head"><?= brand_logo('', 'Barangay seal') ?>
    <div><p>Republic of the Philippines</p>
    <p>Province of <?= e(setting('province')) ?> &middot; Municipality of <?= e(setting('municipality')) ?></p>
    <h2><?= e(strtoupper(setting('barangay_name', 'Barangay'))) ?></h2>
    <p>OFFICE OF THE PUNONG BARANGAY</p></div></div>
    <hr>
    <h1><?= e(strtoupper($req['doc_name'])) ?></h1>
    <p class="center" style="margin:0">Document No: <?= e($req['document_no']) ?></p>
    <br><p><strong>TO WHOM IT MAY CONCERN:</strong></p>
    <p style="text-indent:40px"><?= $body ?></p>
    <p style="text-indent:40px">Issued this <?= e(date('jS \d\a\y \of F, Y', strtotime($req['issued_date']))) ?> at <?= e(setting('barangay_name')) ?>.</p>
    <br><br>
    <div style="display:flex;justify-content:space-between;align-items:flex-end">
        <div id="qrbox" style="width:110px;font-size:10px;text-align:center"></div>
        <div class="center" style="min-width:250px">
            <?php if ($captain && $captain['signature']): ?><img src="<?= BASE_URL ?>uploads/<?= e($captain['signature']) ?>" style="height:50px"><br><?php endif; ?>
            <strong><?= e(strtoupper($captain['full_name'] ?? 'PUNONG BARANGAY')) ?></strong><br>Punong Barangay
        </div>
    </div>
    <p style="font-size:11px;text-align:center;margin-top:30px">Verification code: <strong><?= e($req['verification_code']) ?></strong><br>Verify at: <?= e($verifyUrl) ?></p>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
// QR code is optional (needs internet). If the library does not load, the verification code above is still printed.
if (typeof QRCode !== 'undefined') { new QRCode(document.getElementById('qrbox'), { text: <?= json_encode($verifyUrl) ?>, width: 100, height: 100 }); }
</script>
</body></html>
