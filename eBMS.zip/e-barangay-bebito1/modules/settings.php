<?php

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';

require_module_access('settings');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && is_admin()) {
    require_post();
    $fullName = trim((string) ($_POST['full_name'] ?? ''));
    $email = trim((string) ($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $roleId = (int) ($_POST['role_id'] ?? 0);

    if ($fullName === '' || $email === '' || $password === '' || !$roleId) {
        flash('danger', 'Full name, email, password and role are required.');
    } else {
        run_query(
            'INSERT INTO users (role_id, full_name, email, password, status, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, NOW(), NOW())',
            [$roleId, $fullName, $email, password_hash($password, PASSWORD_DEFAULT), 'Active']
        );
        audit_log('Created user', 'User', (int) db()->lastInsertId(), $fullName);
        flash('success', 'User account created.');
        redirect('modules/settings.php');
    }
}

$roles = fetch_all('SELECT * FROM roles ORDER BY id');
$users = fetch_all(
    'SELECT users.*, roles.name AS role_name
     FROM users
     JOIN roles ON roles.id = users.role_id
     ORDER BY roles.id, users.full_name'
);

render_header('Settings');
page_header('Settings', 'Users, roles, permissions, system readiness and backup reminders.');
?>
<section class="grid grid-2">
    <div class="panel">
        <div class="panel-header"><h2>User Accounts</h2></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>User</th><th>Email</th><th>Role</th><th>Status</th></tr></thead>
                <tbody>
                <?php foreach ($users as $account): ?>
                    <tr>
                        <td><?= e($account['full_name']) ?></td>
                        <td><?= e($account['email']) ?></td>
                        <td><?= e($account['role_name']) ?></td>
                        <td><span class="<?= e(status_class($account['status'])) ?>"><?= e($account['status']) ?></span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="panel">
        <div class="panel-header"><h2>Create Staff Account</h2></div>
        <div class="panel-body">
            <?php if (is_admin()): ?>
            <form method="post" class="form-grid">
                <div class="form-field full"><label>Full name</label><input class="form-control" name="full_name" required></div>
                <div class="form-field full"><label>Email</label><input class="form-control" type="email" name="email" required></div>
                <div class="form-field full"><label>Password</label><input class="form-control" type="password" name="password" required></div>
                <div class="form-field full"><label>Role</label><select class="form-control" name="role_id" required><?php foreach ($roles as $role): ?><option value="<?= (int) $role['id'] ?>"><?= e($role['name']) ?></option><?php endforeach; ?></select></div>
                <div class="form-actions full"><button class="btn" type="submit">Create User</button></div>
            </form>
            <?php else: ?>
                <p class="muted">Only the System Administrator can create new user accounts.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="panel">
    <div class="panel-header"><h2>Role Permissions</h2></div>
    <div class="panel-body grid grid-3">
        <?php foreach ($roles as $role): ?>
            <article class="module-card">
                <h3><?= e($role['name']) ?></h3>
                <p><?= e(implode(', ', role_permissions()[$role['slug']] ?? [])) ?></p>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<section class="panel">
    <div class="panel-header"><h2>Backup & Data Management</h2></div>
    <div class="panel-body">
        <p>For Programming 3 defense, export the MySQL database from phpMyAdmin regularly. Include resident records, workflows, payments, notifications, audit logs and settings.</p>
        <p class="muted">Recommended filename: ebarangay_management_backup_<?= e(date('Ymd')) ?>.sql</p>
    </div>
</section>
<?php render_footer(); ?>

