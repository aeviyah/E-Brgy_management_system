<?php

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';

require_module_access('residents');

$puroks = fetch_all('SELECT id, name FROM puroks ORDER BY name');
$editId = (int) ($_GET['edit'] ?? 0);
$edit = $editId ? fetch_one('SELECT * FROM residents WHERE id = ?', [$editId]) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $action = (string) ($_POST['action'] ?? '');
    $data = [
        trim((string) ($_POST['first_name'] ?? '')),
        trim((string) ($_POST['middle_name'] ?? '')),
        trim((string) ($_POST['last_name'] ?? '')),
        trim((string) ($_POST['suffix'] ?? '')),
        trim((string) ($_POST['gender'] ?? '')),
        $_POST['birth_date'] ?: null,
        trim((string) ($_POST['civil_status'] ?? '')),
        trim((string) ($_POST['contact_no'] ?? '')),
        trim((string) ($_POST['email'] ?? '')),
        trim((string) ($_POST['address'] ?? '')),
        $_POST['purok_id'] ?: null,
        trim((string) ($_POST['occupation'] ?? '')),
        trim((string) ($_POST['education'] ?? '')),
        trim((string) ($_POST['voter_status'] ?? '')),
        trim((string) ($_POST['residency_status'] ?? 'Resident')),
        isset($_POST['is_pwd']) ? 1 : 0,
        isset($_POST['is_senior']) ? 1 : 0,
        isset($_POST['is_solo_parent']) ? 1 : 0,
        isset($_POST['is_4ps']) ? 1 : 0,
        (string) ($_POST['status'] ?? 'Pending Verification'),
        trim((string) ($_POST['notes'] ?? '')),
    ];

    if ($data[0] === '' || $data[2] === '' || $data[9] === '') {
        flash('danger', 'First name, last name, and address are required.');
    } elseif ($action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        if ($id) {
            $data[] = $id;
            run_query(
                'UPDATE residents SET first_name = ?, middle_name = ?, last_name = ?, suffix = ?, gender = ?, birth_date = ?, civil_status = ?, contact_no = ?, email = ?, address = ?, purok_id = ?, occupation = ?, education = ?, voter_status = ?, residency_status = ?, is_pwd = ?, is_senior = ?, is_solo_parent = ?, is_4ps = ?, status = ?, notes = ?, updated_at = NOW() WHERE id = ?',
                $data
            );
            audit_log('Updated resident', 'Resident', $id, $data[0] . ' ' . $data[2]);
            flash('success', 'Resident updated.');
        } else {
            array_unshift($data, generate_reference('RES'));
            run_query(
                'INSERT INTO residents (resident_no, first_name, middle_name, last_name, suffix, gender, birth_date, civil_status, contact_no, email, address, purok_id, occupation, education, voter_status, residency_status, is_pwd, is_senior, is_solo_parent, is_4ps, status, notes, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
                $data
            );
            $id = (int) db()->lastInsertId();
            audit_log('Created resident', 'Resident', $id, $data[1] . ' ' . $data[3]);
            flash('success', 'Resident registered.');
        }

        redirect('modules/residents.php');
    }
}

$search = trim((string) ($_GET['q'] ?? ''));
$status = trim((string) ($_GET['status'] ?? ''));
$params = [];
$where = 'WHERE 1=1';
if ($search !== '') {
    $where .= ' AND (resident_no LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR contact_no LIKE ?)';
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like, $like, $like);
}
if ($status !== '') {
    $where .= ' AND residents.status = ?';
    $params[] = $status;
}

$residents = fetch_all(
    'SELECT residents.*, puroks.name AS purok_name
     FROM residents
     LEFT JOIN puroks ON puroks.id = residents.purok_id
     ' . $where . '
     ORDER BY residents.updated_at DESC
     LIMIT 120',
    $params
);

render_header('Residents');
page_header('Resident Management', 'Registration, verification, classifications, profile information and archive status.');
?>
<section class="panel">
    <div class="panel-header"><h2><?= $edit ? 'Edit Resident' : 'Register Resident' ?></h2></div>
    <div class="panel-body">
        <form method="post" class="form-grid">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= (int) ($edit['id'] ?? 0) ?>">
            <div class="form-field"><label>First name *</label><input class="form-control" name="first_name" value="<?= e($edit['first_name'] ?? '') ?>" required></div>
            <div class="form-field"><label>Last name *</label><input class="form-control" name="last_name" value="<?= e($edit['last_name'] ?? '') ?>" required></div>
            <div class="form-field"><label>Middle name</label><input class="form-control" name="middle_name" value="<?= e($edit['middle_name'] ?? '') ?>"></div>
            <div class="form-field"><label>Suffix</label><input class="form-control" name="suffix" value="<?= e($edit['suffix'] ?? '') ?>"></div>
            <div class="form-field"><label>Gender</label><select class="form-control" name="gender"><option value="">Select</option><option <?= selected($edit['gender'] ?? '', 'Female') ?>>Female</option><option <?= selected($edit['gender'] ?? '', 'Male') ?>>Male</option></select></div>
            <div class="form-field"><label>Birth date</label><input class="form-control" type="date" name="birth_date" value="<?= e($edit['birth_date'] ?? '') ?>"></div>
            <div class="form-field"><label>Civil status</label><input class="form-control" name="civil_status" value="<?= e($edit['civil_status'] ?? '') ?>"></div>
            <div class="form-field"><label>Contact no.</label><input class="form-control" name="contact_no" value="<?= e($edit['contact_no'] ?? '') ?>"></div>
            <div class="form-field"><label>Email</label><input class="form-control" type="email" name="email" value="<?= e($edit['email'] ?? '') ?>"></div>
            <div class="form-field"><label>Purok / Sitio</label><select class="form-control" name="purok_id"><option value="">Select</option><?php foreach ($puroks as $purok): ?><option value="<?= (int) $purok['id'] ?>" <?= selected($edit['purok_id'] ?? '', $purok['id']) ?>><?= e($purok['name']) ?></option><?php endforeach; ?></select></div>
            <div class="form-field full"><label>Address *</label><textarea class="form-control" name="address" rows="2" required><?= e($edit['address'] ?? '') ?></textarea></div>
            <div class="form-field"><label>Occupation</label><input class="form-control" name="occupation" value="<?= e($edit['occupation'] ?? '') ?>"></div>
            <div class="form-field"><label>Education</label><input class="form-control" name="education" value="<?= e($edit['education'] ?? '') ?>"></div>
            <div class="form-field"><label>Voter status</label><input class="form-control" name="voter_status" value="<?= e($edit['voter_status'] ?? '') ?>"></div>
            <div class="form-field"><label>Residency status</label><input class="form-control" name="residency_status" value="<?= e($edit['residency_status'] ?? 'Resident') ?>"></div>
            <div class="form-field"><label>Record status</label><select class="form-control" name="status"><?php foreach (resident_statuses() as $value): ?><option <?= selected($edit['status'] ?? 'Pending Verification', $value) ?>><?= e($value) ?></option><?php endforeach; ?></select></div>
            <div class="form-field full"><label>Classifications</label><div class="split-actions"><label><input type="checkbox" name="is_pwd" <?= checked((bool) ($edit['is_pwd'] ?? false)) ?>> PWD</label><label><input type="checkbox" name="is_senior" <?= checked((bool) ($edit['is_senior'] ?? false)) ?>> Senior Citizen</label><label><input type="checkbox" name="is_solo_parent" <?= checked((bool) ($edit['is_solo_parent'] ?? false)) ?>> Solo Parent</label><label><input type="checkbox" name="is_4ps" <?= checked((bool) ($edit['is_4ps'] ?? false)) ?>> 4Ps</label></div></div>
            <div class="form-field full"><label>Notes</label><textarea class="form-control" name="notes" rows="2"><?= e($edit['notes'] ?? '') ?></textarea></div>
            <div class="form-actions full"><button class="btn" type="submit"><?= $edit ? 'Update Resident' : 'Add Resident' ?></button><?php if ($edit): ?><a class="btn btn-ghost" href="<?= e(app_url('modules/residents.php')) ?>">Cancel</a><?php endif; ?></div>
        </form>
    </div>
</section>

<section class="panel">
    <div class="panel-header"><h2>Resident List</h2></div>
    <form class="filter-bar" method="get">
        <input name="q" placeholder="Search resident no., name, email or contact" value="<?= e($search) ?>">
        <select name="status" data-autosubmit><option value="">All statuses</option><?php foreach (resident_statuses() as $value): ?><option value="<?= e($value) ?>" <?= selected($status, $value) ?>><?= e($value) ?></option><?php endforeach; ?></select>
        <button class="btn" type="submit">Filter</button>
    </form>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Resident</th><th>Contact</th><th>Purok</th><th>Classifications</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>
            <?php foreach ($residents as $resident): ?>
                <tr>
                    <td><span class="record-title"><strong><?= e(resident_full_name($resident)) ?></strong><small><?= e($resident['resident_no']) ?></small></span></td>
                    <td><?= e($resident['contact_no'] ?: 'No contact') ?><br><small><?= e($resident['email']) ?></small></td>
                    <td><?= e($resident['purok_name'] ?: 'Unassigned') ?></td>
                    <td><?= e(trim(($resident['is_senior'] ? 'Senior ' : '') . ($resident['is_pwd'] ? 'PWD ' : '') . ($resident['is_solo_parent'] ? 'Solo Parent ' : '') . ($resident['is_4ps'] ? '4Ps' : '')) ?: 'None') ?></td>
                    <td><span class="<?= e(status_class($resident['status'])) ?>"><?= e($resident['status']) ?></span></td>
                    <td><a class="btn btn-ghost" href="<?= e(app_url('modules/residents.php?edit=' . (int) $resident['id'])) ?>">Edit</a></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$residents): ?><tr><td colspan="6">No residents found.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php render_footer(); ?>

