(function () {
    'use strict';
    var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /* ---------- Toasts ---------- */
    var toastIcons = {
        success: '<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>',
        info: '<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z M12 16v-5 M12 8v.01"/></svg>'
    };

    function showToast(type, message) {
        var stack = document.getElementById('toastStack');
        if (!stack) { return; }
        var toast = document.createElement('div');
        toast.className = 'toast ' + (type === 'info' ? 'info' : 'success');
        toast.setAttribute('role', 'status');
        toast.innerHTML = (toastIcons[type] || toastIcons.success) + '<p></p><button type="button" aria-label="Dismiss">&times;</button>';
        toast.querySelector('p').textContent = message;
        stack.appendChild(toast);

        var timer = setTimeout(dismiss, 5000);
        function dismiss() {
            clearTimeout(timer);
            toast.classList.add('out');
            setTimeout(function () { toast.remove(); }, reduceMotion ? 0 : 300);
        }
        toast.querySelector('button').addEventListener('click', dismiss);
    }
    window.showToast = showToast;

    // Success / info flash messages become toasts. Errors and warnings stay on the page so they are not missed.
    document.querySelectorAll('[data-flash]').forEach(function (alertBox) {
        var type = alertBox.classList.contains('alert-success') ? 'success' : (alertBox.classList.contains('alert-info') ? 'info' : null);
        if (type) {
            showToast(type, alertBox.textContent.trim());
            alertBox.remove();
        }
    });

    /* ---------- Confirm modal ---------- */
    var modal = document.getElementById('confirmModal');
    var pendingForm = null;
    var pendingSubmitter = null;
    var lastFocus = null;

    var destructive = ['Rejected', 'Cancelled', 'Archived', 'Deceased', 'Transferred', 'Inactive'];

    // Explicit data-confirm wins; otherwise ask when a POST form is changing a record to a closing status
    function confirmMessage(form) {
        if (form.dataset.confirm) { return form.dataset.confirm; }
        if (!form.method || form.method.toLowerCase() !== 'post') { return ''; }
        var select = form.querySelector('select[name="status"]');
        if (!select || destructive.indexOf(select.value) === -1) { return ''; }
        var original = Array.prototype.filter.call(select.options, function (o) { return o.defaultSelected; })[0];
        if (original && original.value === select.value) { return ''; }
        return 'Set the status to "' + select.value + '"? The change is saved to the record history and the audit trail.';
    }

    function openConfirm(form, submitter, message) {
        if (!modal) { return window.confirm(message); }
        pendingForm = form;
        pendingSubmitter = submitter || null;
        lastFocus = document.activeElement;
        document.getElementById('confirmText').textContent = message;
        modal.hidden = false;
        modal.querySelector('[data-modal-cancel]').focus();
        return false;
    }
    function closeConfirm() {
        if (!modal) { return; }
        modal.hidden = true;
        pendingForm = null;
        pendingSubmitter = null;
        if (lastFocus && lastFocus.focus) { lastFocus.focus(); }
    }

    /* ---------- Count-up for dashboard numbers ---------- */
    function countUp(el) {
        var original = el.textContent.trim();
        var match = original.match(/^(\D*?)([\d,]*\.?\d+)(\D*)$/);
        if (!match) { return; }
        var prefix = match[1], raw = match[2], suffix = match[3];
        var target = parseFloat(raw.replace(/,/g, ''));
        if (!isFinite(target) || target === 0) { return; }
        var decimals = (raw.split('.')[1] || '').length;
        var useCommas = raw.indexOf(',') !== -1;
        var start = null, duration = 900;

        function format(n) {
            var s = n.toFixed(decimals);
            if (useCommas) { s = s.replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
            return prefix + s + suffix;
        }
        function step(ts) {
            if (start === null) { start = ts; }
            var t = Math.min(1, (ts - start) / duration);
            var eased = 1 - Math.pow(1 - t, 3);
            el.textContent = t < 1 ? format(target * eased) : original;
            if (t < 1) { requestAnimationFrame(step); }
        }
        el.textContent = format(0);
        requestAnimationFrame(step);
    }
    if (!reduceMotion) {
        document.querySelectorAll('.metric-card strong').forEach(countUp);
    }

    /* ---------- Live clock (server time, Manila) ---------- */
    var clock = document.querySelector('[data-clock]');
    if (clock && window.Intl) {
        var serverNow = Date.parse(clock.dataset.serverTime || '');
        var offset = isFinite(serverNow) ? serverNow - Date.now() : 0;
        var fmt = new Intl.DateTimeFormat('en-PH', { timeZone: 'Asia/Manila', weekday: 'short', month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' });
        var tick = function () { clock.textContent = fmt.format(new Date(Date.now() + offset)); };
        tick();
        setInterval(tick, 15000);
    }

    /* ---------- Sidebar: find a module, keep the active one in view ---------- */
    var navFilter = document.getElementById('navFilter');
    var nav = document.querySelector('.sidebar .nav');
    if (nav) {
        var active = nav.querySelector('.nav-link.active');
        if (active && active.scrollIntoView) { active.scrollIntoView({ block: 'center' }); }
    }
    if (navFilter && nav) {
        navFilter.addEventListener('input', function () {
            var q = navFilter.value.trim().toLowerCase();
            var children = Array.prototype.slice.call(nav.children);
            var group = null, groupVisible = 0;
            function closeGroup() { if (group) { group.hidden = groupVisible === 0 && q !== ''; } }
            children.forEach(function (node) {
                if (node.classList.contains('nav-group')) {
                    closeGroup();
                    group = node; groupVisible = 0;
                    return;
                }
                var show = q === '' || node.textContent.toLowerCase().indexOf(q) !== -1;
                node.hidden = !show;
                if (show) { groupVisible++; }
            });
            closeGroup();
        });
    }

    /* ---------- Clicks ---------- */
    document.addEventListener('click', function (event) {
        if (event.target.closest('[data-toggle-sidebar]')) {
            document.body.classList.toggle('sidebar-open');
            return;
        }
        if (document.body.classList.contains('sidebar-open') && !event.target.closest('.sidebar')) {
            document.body.classList.remove('sidebar-open');
        }

        var demo = event.target.closest('[data-demo-email]');
        if (demo) {
            document.getElementById('email').value = demo.dataset.demoEmail;
            document.getElementById('password').value = demo.dataset.demoPassword;
            document.getElementById('password').focus();
            return;
        }

        if (event.target.closest('[data-modal-cancel]') || event.target === modal) {
            closeConfirm();
            return;
        }
        if (event.target.closest('[data-modal-ok]') && pendingForm) {
            var form = pendingForm, submitter = pendingSubmitter;
            form.dataset.confirmed = '1';
            modal.hidden = true;
            if (form.requestSubmit) { form.requestSubmit(submitter || undefined); } else { form.submit(); }
        }
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && modal && !modal.hidden) { closeConfirm(); return; }
        // "/" jumps to global search, like most dashboards
        if (event.key === '/' && !/^(INPUT|TEXTAREA|SELECT)$/.test((document.activeElement || {}).tagName || '')) {
            var search = document.querySelector('.top-search input');
            if (search) { event.preventDefault(); search.focus(); }
        }
    });

    document.addEventListener('change', function (event) {
        var autosubmit = event.target.closest('[data-autosubmit]');
        if (autosubmit && autosubmit.form) { autosubmit.form.submit(); }
    });

    /* ---------- Form submit: confirm first, then show progress ---------- */
    document.addEventListener('submit', function (event) {
        var form = event.target;
        var message = form.dataset.confirmed === '1' ? '' : confirmMessage(form);
        if (message) {
            event.preventDefault();
            if (!modal) {
                if (window.confirm(message)) { form.dataset.confirmed = '1'; form.submit(); }
                return;
            }
            openConfirm(form, event.submitter, message);
            return;
        }
        var button = event.submitter || form.querySelector('button[type=submit], button:not([type])');
        if (button && form.method && form.method.toLowerCase() === 'post') {
            button.classList.add('is-busy');
            setTimeout(function () { button.disabled = true; }, 0);
        }
    });

    // Coming back with the browser's back button should not leave buttons stuck
    window.addEventListener('pageshow', function (event) {
        if (event.persisted) {
            document.querySelectorAll('.btn.is-busy').forEach(function (b) { b.classList.remove('is-busy'); b.disabled = false; });
        }
    });
})();
