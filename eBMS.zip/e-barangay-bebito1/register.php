<?php

require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $required = ['first_name', 'last_name', 'email', 'address', 'password'];
    $missing = [];

    foreach ($required as $field) {
        if (trim((string) ($_POST[$field] ?? '')) === '') {
            $missing[] = $field;
        }
    }

    if ($missing) {
        flash('danger', 'Please complete all required fields.');
    } elseif (strlen((string) $_POST['password']) < 6) {
        flash('danger', 'Password must be at least 6 characters.');
    } else {
        $pdo = null;
        try {
            $pdo = db();
            $pdo->beginTransaction();
            $residentNo = generate_reference('RES');
            run_query(
                'INSERT INTO residents
                 (resident_no, first_name, middle_name, last_name, suffix, gender, birth_date, civil_status, contact_no, email, address, purok_id, occupation, education, voter_status, residency_status, is_pwd, is_senior, is_solo_parent, is_4ps, status, notes, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
                [
                    $residentNo,
                    trim((string) $_POST['first_name']),
                    trim((string) ($_POST['middle_name'] ?? '')),
                    trim((string) $_POST['last_name']),
                    trim((string) ($_POST['suffix'] ?? '')),
                    trim((string) ($_POST['gender'] ?? '')),
                    $_POST['birth_date'] ?: null,
                    trim((string) ($_POST['civil_status'] ?? '')),
                    trim((string) ($_POST['contact_no'] ?? '')),
                    trim((string) $_POST['email']),
                    trim((string) $_POST['address']),
                    $_POST['purok_id'] ?: null,
                    trim((string) ($_POST['occupation'] ?? '')),
                    trim((string) ($_POST['education'] ?? '')),
                    trim((string) ($_POST['voter_status'] ?? '')),
                    'Resident',
                    isset($_POST['is_pwd']) ? 1 : 0,
                    isset($_POST['is_senior']) ? 1 : 0,
                    isset($_POST['is_solo_parent']) ? 1 : 0,
                    isset($_POST['is_4ps']) ? 1 : 0,
                    'Pending Verification',
                    'Registered through resident portal.',
                ]
            );

            $residentId = (int) $pdo->lastInsertId();
            $roleId = (int) fetch_value('SELECT id FROM roles WHERE slug = ?', ['resident']);
            $fullName = trim((string) $_POST['first_name'] . ' ' . (string) $_POST['last_name']);

            run_query(
                'INSERT INTO users (role_id, resident_id, full_name, email, password, status, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())',
                [$roleId, $residentId, $fullName, trim((string) $_POST['email']), password_hash((string) $_POST['password'], PASSWORD_DEFAULT), 'Active']
            );

            $pdo->commit();
            flash('success', 'Registration submitted. You can log in while your resident record is pending verification.');
            redirect('login.php');
        } catch (Throwable $error) {
            if ($pdo instanceof PDO && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            flash('danger', 'Registration failed. The email may already be used or the database is not ready.');
        }
    }
}

$puroks = [];
try {
    $puroks = fetch_all('SELECT id, name FROM puroks ORDER BY name');
} catch (Throwable $error) {
    $puroks = [];
}

render_header('Resident Registration', ['body_class' => 'auth-page']);
?>
<section class="auth-card">
    <p class="eyebrow">Resident Portal</p>
    <h1>Resident Registration</h1>
    <p>Create an account and submit your information for barangay verification.</p>

    <form method="post" class="form-grid">
        <div class="form-field">
            <label>First name *</label>
            <input class="form-control" name="first_name" value="<?= e(old('first_name')) ?>" required>
        </div>
        <div class="form-field">
            <label>Last name *</label>
            <input class="form-control" name="last_name" value="<?= e(old('last_name')) ?>" required>
        </div>
        <div class="form-field">
            <label>Middle name</label>
            <input class="form-control" name="middle_name" value="<?= e(old('middle_name')) ?>">
        </div>
        <div class="form-field">
            <label>Suffix</label>
            <input class="form-control" name="suffix" value="<?= e(old('suffix')) ?>">
        </div>
        <div class="form-field">
            <label>Email *</label>
            <input class="form-control" type="email" name="email" value="<?= e(old('email')) ?>" required>
        </div>
        <div class="form-field">
            <label>Password *</label>
            <input class="form-control" type="password" name="password" required>
        </div>
        <div class="form-field">
            <label>Gender</label>
            <select class="form-control" name="gender">
                <option value="">Select</option>
                <option <?= selected(old('gender'), 'Female') ?>>Female</option>
                <option <?= selected(old('gender'), 'Male') ?>>Male</option>
            </select>
        </div>
        <div class="form-field">
            <label>Birth date</label>
            <input class="form-control" type="date" name="birth_date" value="<?= e(old('birth_date')) ?>">
        </div>
        <div class="form-field">
            <label>Contact no.</label>
            <input class="form-control" name="contact_no" value="<?= e(old('contact_no')) ?>">
        </div>
        <div class="form-field">
            <label>Purok / Sitio</label>
            <select class="form-control" name="purok_id">
                <option value="">Select</option>
                <?php foreach ($puroks as $purok): ?>
                    <option value="<?= (int) $purok['id'] ?>" <?= selected(old('purok_id'), $purok['id']) ?>><?= e($purok['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-field full">
            <label>Address *</label>
            <textarea class="form-control" name="address" rows="3" required><?= e(old('address')) ?></textarea>
        </div>
        <div class="form-field">
            <label>Occupation</label>
            <input class="form-control" name="occupation" value="<?= e(old('occupation')) ?>">
        </div>
        <div class="form-field">
            <label>Education</label>
            <input class="form-control" name="education" value="<?= e(old('education')) ?>">
        </div>
        <div class="form-field full">
            <label>Classifications</label>
            <div class="split-actions">
                <label><input type="checkbox" name="is_pwd" <?= checked(isset($_POST['is_pwd'])) ?>> PWD</label>
                <label><input type="checkbox" name="is_senior" <?= checked(isset($_POST['is_senior'])) ?>> Senior Citizen</label>
                <label><input type="checkbox" name="is_solo_parent" <?= checked(isset($_POST['is_solo_parent'])) ?>> Solo Parent</label>
                <label><input type="checkbox" name="is_4ps" <?= checked(isset($_POST['is_4ps'])) ?>> 4Ps</label>
            </div>
        </div>
        <div class="form-actions full">
            <button class="btn" type="submit">Submit Registration</button>
            <a class="btn btn-ghost" href="<?= e(app_url('login.php')) ?>">Back to Login</a>
        </div>
    </form>
</section>
<?php render_footer(); ?>

