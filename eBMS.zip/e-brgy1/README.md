# E-Barangay Management System

Functional PHP/MySQL web application scaffold for the Programming 3 final project. The implementation follows the attached E-Barangay scope documents as project requirements:

- Core Barangay Management modules are active at a basic, manageable level.
- SK, Barangay Health Center, Emergency and Disaster Response, and other specialized systems are visible as locked future modules.
- Workflows use consistent statuses, queues, role permissions, notifications, reports, and audit logs.
- Stack: HTML5, CSS3, basic JavaScript, PHP, MySQL, phpMyAdmin, XAMPP/Apache.

## Setup

1. Copy this folder into your XAMPP `htdocs` directory.
2. Create the database by importing [database/schema.sql](database/schema.sql) in phpMyAdmin. It creates `e_barangay_app` to avoid colliding with older local databases.
3. Update [config/database.php](config/database.php) if your MySQL username or password differs.
4. Open `http://localhost/e-barangay/` in the browser.

Alternative local test without moving folders:

```powershell
C:\xampp\php\php.exe -S 127.0.0.1:8085 -t .
```

Then open `http://127.0.0.1:8085/`.

Default administrator account:

- Email: `admin@barangay.test`
- Password: `password`

## Main Features

- Login, logout, `auth.php`, resident registration, forgot/reset password, and role-aware dashboards.
- Residents, households, Purok/Sitio, governance, officials, communication, events, facilities, reservations, assets, projects, budget, environment, and assistance CRUD.
- Document, permit, and service request workflows with statuses.
- Complaints, blotter, Katarungang Pambarangay, BCPC, VAWC, and peace/order case tracking.
- Treasury payments, collections, and official receipt generation.
- Public portal, QR/reference verification, global search, reports, settings, notifications, and audit trail.

## Roles

- Resident
- Barangay Secretary
- Barangay Treasurer
- Punong Barangay
- Barangay Staff
- System Administrator

Role permissions are intentionally simple and visible for classroom defense. They can be extended in [includes/auth.php](includes/auth.php).
