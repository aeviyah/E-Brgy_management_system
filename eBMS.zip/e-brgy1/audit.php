<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';

require_roles(['captain', 'admin']);

$q = trim((string) ($_GET['q'] ?? ''));
$where = [];
$params = [];
if ($q !== '') {
    $where[] = '(a.action LIKE ? OR a.table_name LIKE ? OR a.details LIKE ? OR u.full_name LIKE ?)';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
}
$sql = 'SELECT a.*, u.full_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id';
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY a.id DESC LIMIT 300';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$logs = $stmt->fetchAll();

render_header('Audit Trail', 'audit');
page_header('Audit Trail', 'Who, what, when, affected record, login history, approvals, document generation, and archive actions.');
?>
<form class="inline-form" method="get">
    <input type="search" name="q" placeholder="Search audit entries" value="<?= e($q) ?>">
    <button class="button ghost" type="submit">Filter</button>
</form>
<div class="table-wrap">
    <table>
        <thead><tr><th>Date</th><th>User</th><th>Action</th><th>Record</th><th>Details</th><th>IP</th></tr></thead>
        <tbody>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td><?= e($log['created_at']) ?></td>
                    <td><?= e($log['full_name'] ?? 'System / guest') ?></td>
                    <td><?= e($log['action']) ?></td>
                    <td><?= e($log['table_name'] ?? '') ?> #<?= e((string) ($log['record_id'] ?? '')) ?></td>
                    <td><?= e($log['details'] ?? '') ?></td>
                    <td><?= e($log['ip_address'] ?? '') ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$logs): ?><tr><td colspan="6" class="empty-state">No audit logs found.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php render_footer(); ?>
