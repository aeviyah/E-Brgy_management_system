<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';

require_roles(['admin']);

$keys = [
    'barangay_name' => 'Barangay name',
    'office_hours' => 'Office hours',
    'contact_number' => 'Contact number',
    'email_address' => 'Email address',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($keys as $key => $label) {
        $stmt = db()->prepare('INSERT INTO settings (name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value)');
        $stmt->execute([$key, trim((string) ($_POST[$key] ?? ''))]);
    }

    if (!empty($_POST['create_user_email'])) {
        $email = trim((string) $_POST['create_user_email']);
        $fullName = trim((string) ($_POST['create_user_name'] ?? 'New User'));
        $role = (string) ($_POST['create_user_role'] ?? 'staff');
        if (!in_array($role, ['resident', 'secretary', 'treasurer', 'captain', 'staff', 'admin'], true)) {
            $role = 'staff';
        }
        $stmt = db()->prepare('INSERT INTO users (full_name, email, password_hash, role, status) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE role = VALUES(role), full_name = VALUES(full_name)');
        $stmt->execute([$fullName, $email, password_hash('password', PASSWORD_DEFAULT), $role, 'active']);
    }

    audit_log('Update settings', 'settings', null, 'System settings');
    flash('success', 'Settings saved.');
    redirect(app_url('settings.php'));
}

$users = db()->query('SELECT id, full_name, email, role, status, created_at FROM users ORDER BY id DESC LIMIT 100')->fetchAll();

render_header('Settings', 'settings');
page_header('Settings, Users & Backup', 'System identity, role accounts, security settings, backup/export notes, and data management.');
?>
<div class="grid cards-2">
    <form class="card" method="post">
        <h2>Barangay Settings</h2>
        <div class="form-grid">
            <?php foreach ($keys as $key => $label): ?>
                <div class="field">
                    <label><?= e($label) ?></label>
                    <input type="text" name="<?= e($key) ?>" value="<?= e(setting($key)) ?>">
                </div>
            <?php endforeach; ?>
            <div class="field">
                <label>New user name</label>
                <input type="text" name="create_user_name" placeholder="Optional">
            </div>
            <div class="field">
                <label>New user email</label>
                <input type="email" name="create_user_email" placeholder="Optional">
            </div>
            <div class="field">
                <label>New user role</label>
                <select name="create_user_role">
                    <option value="staff">Barangay Staff</option>
                    <option value="secretary">Barangay Secretary</option>
                    <option value="treasurer">Barangay Treasurer</option>
                    <option value="captain">Punong Barangay</option>
                    <option value="admin">System Administrator</option>
                </select>
            </div>
        </div>
        <p class="muted">New staff accounts use the temporary password: password.</p>
        <button class="button" type="submit">Save settings</button>
    </form>
    <section class="card">
        <h2>Backup & Data Management</h2>
        <p>Use phpMyAdmin Export to create database backups. Use phpMyAdmin Import to restore. For defense, demonstrate this with the `e_barangay` database and keep exported `.sql` files outside the web root.</p>
        <div class="actions">
            <a class="button ghost" href="<?= e(app_url('reports.php?export=csv')) ?>">Export overview CSV</a>
            <a class="button ghost" href="<?= e(app_url('audit.php')) ?>">Review audit logs</a>
        </div>
    </section>
</div>

<section class="card" style="margin-top: 14px;">
    <h2>User Accounts</h2>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Created</th></tr></thead>
            <tbody>
                <?php foreach ($users as $account): ?>
                    <tr>
                        <td><?= e($account['full_name']) ?></td>
                        <td><?= e($account['email']) ?></td>
                        <td><?= e(role_label($account['role'])) ?></td>
                        <td><?= status_chip($account['status']) ?></td>
                        <td><?= e($account['created_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
<?php render_footer(); ?>
