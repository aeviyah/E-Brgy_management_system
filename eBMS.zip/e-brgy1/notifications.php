<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';

require_login();
$user = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = db()->prepare("UPDATE notifications SET status = 'Read' WHERE user_id = ? OR user_id IS NULL");
    $stmt->execute([(int) $user['id']]);
    flash('success', 'Notifications marked as read.');
    redirect(app_url('notifications.php'));
}

$stmt = db()->prepare('SELECT * FROM notifications WHERE user_id = ? OR user_id IS NULL ORDER BY id DESC LIMIT 100');
$stmt->execute([(int) $user['id']]);
$notifications = $stmt->fetchAll();

render_header('Notifications', '');
page_header('Notifications', 'Document updates, payment confirmations, case updates, announcements, and system messages.', '<form method="post"><button class="button ghost" type="submit">Mark all read</button></form>');
?>
<div class="table-wrap">
    <table>
        <thead><tr><th>Title</th><th>Message</th><th>Status</th><th>Date</th></tr></thead>
        <tbody>
            <?php foreach ($notifications as $notification): ?>
                <tr>
                    <td><?= e($notification['title']) ?></td>
                    <td><?= e($notification['body']) ?></td>
                    <td><?= status_chip($notification['status']) ?></td>
                    <td><?= e($notification['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$notifications): ?><tr><td colspan="4" class="empty-state">No notifications yet.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php render_footer(); ?>
