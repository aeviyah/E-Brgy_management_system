<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';

require_roles(['resident', 'secretary', 'captain', 'staff', 'admin']);

$user = current_user();
$canProcess = role_allows(['secretary', 'captain', 'staff', 'admin']);
$canViewSensitive = role_allows(['secretary', 'captain', 'admin']);
$caseTypes = [
    'complaint' => 'Complaint',
    'blotter' => 'Blotter',
    'katarungang' => 'Katarungang Pambarangay',
    'peace_order' => 'Peace & Order / Tanod',
    'bcpc' => 'Child Protection / BCPC',
    'vawc' => "VAWC / Women's Protection",
];
$statuses = ['Pending', 'Under Review', 'Mediation', 'Referred', 'Resolved', 'Closed', 'Archived'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['form_action'] ?? '';

    if ($action === 'create') {
        $caseType = (string) ($_POST['case_type'] ?? 'complaint');
        if (!$canProcess && !in_array($caseType, ['complaint', 'blotter'], true)) {
            $caseType = 'complaint';
        }
        $title = trim((string) ($_POST['title'] ?? ''));
        $complainant = trim((string) ($_POST['complainant'] ?? ''));
        if ($title === '' || $complainant === '') {
            flash('error', 'Case title and complainant are required.');
            redirect(app_url('cases.php?action=new'));
        }

        $sensitivity = (string) ($_POST['sensitivity'] ?? 'normal');
        if (!$canProcess) {
            $sensitivity = 'normal';
        }

        $stmt = db()->prepare('INSERT INTO cases (case_type, case_no, title, complainant, respondent, incident_at, location, description, evidence, sensitivity, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            $caseType,
            reference_no('CASE'),
            $title,
            $complainant,
            trim((string) ($_POST['respondent'] ?? '')) ?: null,
            trim((string) ($_POST['incident_at'] ?? '')) ?: null,
            trim((string) ($_POST['location'] ?? '')) ?: null,
            trim((string) ($_POST['description'] ?? '')) ?: null,
            trim((string) ($_POST['evidence'] ?? '')) ?: null,
            $sensitivity,
            'Pending',
        ]);
        $id = (int) db()->lastInsertId();
        audit_log('Create case', 'cases', $id, $caseTypes[$caseType] ?? $caseType);
        notify_user(null, 'New case filed', $title . ' was filed by ' . $complainant . '.');
        flash('success', 'Case filed.');
        redirect(app_url('cases.php'));
    }

    if ($action === 'status' && $canProcess) {
        $id = (int) ($_POST['id'] ?? 0);
        $status = (string) ($_POST['status'] ?? 'Pending');
        if (!in_array($status, $statuses, true)) {
            flash('error', 'Invalid case status.');
            redirect(app_url('cases.php'));
        }
        $stmt = db()->prepare('UPDATE cases SET status = ?, assigned_to = ?, evidence = CONCAT(COALESCE(evidence, ""), ?) WHERE id = ?');
        $note = trim((string) ($_POST['note'] ?? ''));
        $stmt->execute([$status, (int) $user['id'], $note === '' ? '' : "\n\nTimeline note: " . $note, $id]);
        audit_log('Update case status', 'cases', $id, $status);
        flash('success', 'Case updated.');
        redirect(app_url('cases.php'));
    }
}

render_header('Cases', 'cases');

if (($_GET['action'] ?? '') === 'new') {
    page_header('File / Record Case', 'Complaint, blotter, Katarungang Pambarangay, peace and order, BCPC, and VAWC records.', '<a class="button ghost" href="' . e(app_url('cases.php')) . '">Back</a>');
    ?>
    <form class="card" method="post">
        <input type="hidden" name="form_action" value="create">
        <div class="form-grid">
            <div class="field">
                <label>Case type</label>
                <select name="case_type">
                    <?php foreach ($caseTypes as $value => $label): ?>
                        <?php if ($canProcess || in_array($value, ['complaint', 'blotter'], true)): ?>
                            <option value="<?= e($value) ?>"><?= e($label) ?></option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="field">
                <label>Sensitivity</label>
                <select name="sensitivity" <?= $canProcess ? '' : 'disabled' ?>>
                    <option value="normal">Normal</option>
                    <option value="restricted">Restricted</option>
                    <option value="confidential">Confidential</option>
                </select>
            </div>
            <div class="field">
                <label>Case title</label>
                <input type="text" name="title" required>
            </div>
            <div class="field">
                <label>Complainant</label>
                <input type="text" name="complainant" required value="<?= e($user['full_name']) ?>">
            </div>
            <div class="field">
                <label>Respondent</label>
                <input type="text" name="respondent">
            </div>
            <div class="field">
                <label>Incident date/time</label>
                <input type="datetime-local" name="incident_at">
            </div>
            <div class="field full">
                <label>Location</label>
                <input type="text" name="location">
            </div>
            <div class="field full">
                <label>Description</label>
                <textarea name="description"></textarea>
            </div>
            <div class="field full">
                <label>Evidence / witnesses / notes</label>
                <textarea name="evidence"></textarea>
            </div>
        </div>
        <div class="actions" style="margin-top: 16px;">
            <button class="button" type="submit">Save case</button>
        </div>
    </form>
    <?php
    render_footer();
    exit;
}

$where = [];
$params = [];
if (!$canProcess) {
    $where[] = 'complainant = ?';
    $params[] = $user['full_name'];
}
if (!$canViewSensitive) {
    $where[] = "sensitivity = 'normal'";
}
$q = trim((string) ($_GET['q'] ?? ''));
if ($q !== '') {
    $where[] = '(case_no LIKE ? OR title LIKE ? OR complainant LIKE ? OR respondent LIKE ? OR location LIKE ?)';
    for ($i = 0; $i < 5; $i++) {
        $params[] = '%' . $q . '%';
    }
}
$status = trim((string) ($_GET['status'] ?? ''));
if ($status !== '') {
    $where[] = 'status = ?';
    $params[] = $status;
}
$sql = 'SELECT * FROM cases';
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY id DESC LIMIT 200';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$cases = $stmt->fetchAll();

page_header('Complaints, Blotter & Katarungang Pambarangay', 'Permission-controlled case records with timelines, mediation/referral, resolution and closure.', '<a class="button" href="' . e(app_url('cases.php?action=new')) . '">File case</a>');
?>
<form class="inline-form" method="get">
    <input type="search" name="q" placeholder="Search cases" value="<?= e($q) ?>">
    <select name="status">
        <option value="">All statuses</option>
        <?php foreach ($statuses as $option): ?>
            <option value="<?= e($option) ?>" <?= selected($status, $option) ?>><?= e($option) ?></option>
        <?php endforeach; ?>
    </select>
    <button class="button ghost" type="submit">Filter</button>
</form>
<div class="table-wrap">
    <table>
        <thead><tr><th>Case</th><th>Parties</th><th>Incident</th><th>Sensitivity</th><th>Status</th><th>Timeline / Action</th></tr></thead>
        <tbody>
            <?php foreach ($cases as $case): ?>
                <tr>
                    <td><strong><?= e($case['case_no']) ?></strong><br><?= e($caseTypes[$case['case_type']] ?? $case['case_type']) ?><br><?= e($case['title']) ?></td>
                    <td>Complainant: <?= e($case['complainant']) ?><br>Respondent: <?= e($case['respondent'] ?? '') ?></td>
                    <td><?= e($case['incident_at'] ?? '') ?><br><?= e($case['location'] ?? '') ?></td>
                    <td><?= status_chip($case['sensitivity']) ?></td>
                    <td><?= status_chip($case['status']) ?></td>
                    <td>
                        <?php if ($canProcess): ?>
                            <form method="post" class="stacked-form">
                                <input type="hidden" name="form_action" value="status">
                                <input type="hidden" name="id" value="<?= (int) $case['id'] ?>">
                                <select name="status">
                                    <?php foreach ($statuses as $option): ?>
                                        <option value="<?= e($option) ?>" <?= selected($case['status'], $option) ?>><?= e($option) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="text" name="note" placeholder="Timeline note">
                                <button class="button secondary" type="submit">Update</button>
                            </form>
                        <?php else: ?>
                            <span class="muted">Tracking only</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$cases): ?><tr><td colspan="6" class="empty-state">No cases found.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php render_footer(); ?>
