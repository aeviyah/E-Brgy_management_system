document.addEventListener('click', function (event) {
  var toggle = event.target.closest('[data-sidebar-toggle]');
  if (toggle) {
    var sidebar = document.getElementById('sidebar');
    if (sidebar) {
      sidebar.classList.toggle('open');
    }
  }

  var confirmButton = event.target.closest('[data-confirm]');
  if (confirmButton) {
    var message = confirmButton.getAttribute('data-confirm') || 'Continue?';
    if (!window.confirm(message)) {
      event.preventDefault();
    }
  }
});

document.addEventListener('change', function (event) {
  var select = event.target.closest('[data-catalog-select]');
  if (!select) {
    return;
  }

  var option = select.options[select.selectedIndex];
  var form = select.closest('form');
  if (!option || !form) {
    return;
  }

  var fee = form.querySelector('[data-catalog-fee]');
  var requirements = form.querySelector('[data-catalog-requirements]');
  if (fee) {
    fee.value = option.getAttribute('data-fee') || '0';
  }
  if (requirements) {
    requirements.value = option.getAttribute('data-requirements') || '';
  }
});
