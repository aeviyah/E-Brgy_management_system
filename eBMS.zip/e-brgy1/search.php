<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';

require_login();
$user = current_user();
$q = trim((string) ($_GET['q'] ?? ''));
$results = [];

function add_search_results(array &$results, string $type, string $sql, array $params, string $titleField, string $subtitleField): void
{
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    foreach ($stmt->fetchAll() as $row) {
        $results[] = [
            'type' => $type,
            'title' => (string) ($row[$titleField] ?? ''),
            'subtitle' => (string) ($row[$subtitleField] ?? ''),
            'status' => (string) ($row['status'] ?? ''),
            'created_at' => (string) ($row['created_at'] ?? ''),
        ];
    }
}

if ($q !== '') {
    $like = '%' . $q . '%';
    if (role_allows(['secretary', 'treasurer', 'captain', 'staff', 'admin'])) {
        add_search_results($results, 'Resident', 'SELECT resident_code, CONCAT(first_name, " ", last_name) AS title, address, status, created_at FROM residents WHERE resident_code LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR address LIKE ? LIMIT 20', [$like, $like, $like, $like], 'title', 'address');
    }

    $requestSql = 'SELECT reference_no, title, requester_name, status, created_at FROM request_records WHERE reference_no LIKE ? OR title LIKE ? OR requester_name LIKE ?';
    $requestParams = [$like, $like, $like];
    if ($user['role'] === 'resident') {
        $requestSql .= ' AND (resident_id = ? OR requester_name = ?)';
        $requestParams[] = $user['resident_id'] ?? 0;
        $requestParams[] = $user['full_name'];
    }
    $requestSql .= ' LIMIT 20';
    add_search_results($results, 'Request', $requestSql, $requestParams, 'title', 'reference_no');

    if (role_allows(['treasurer', 'captain', 'admin'])) {
        add_search_results($results, 'Payment', 'SELECT transaction_no, purpose, status, created_at FROM payments WHERE transaction_no LIKE ? OR purpose LIKE ? LIMIT 20', [$like, $like], 'purpose', 'transaction_no');
    }

    $caseSql = "SELECT case_no, title, complainant, status, created_at FROM cases WHERE sensitivity = 'normal' AND (case_no LIKE ? OR title LIKE ? OR complainant LIKE ?)";
    $caseParams = [$like, $like, $like];
    if ($user['role'] === 'resident') {
        $caseSql .= ' AND complainant = ?';
        $caseParams[] = $user['full_name'];
    }
    $caseSql .= ' LIMIT 20';
    add_search_results($results, 'Case', $caseSql, $caseParams, 'title', 'case_no');
}

render_header('Search', 'search');
page_header('Global Search', 'Permission-aware results across residents, households, requests, payments, and authorized case records.');
?>
<form class="inline-form" method="get">
    <input type="search" name="q" placeholder="Search records" value="<?= e($q) ?>" autofocus>
    <button class="button" type="submit">Search</button>
</form>
<div class="table-wrap">
    <table>
        <thead><tr><th>Type</th><th>Title</th><th>Reference / Detail</th><th>Status</th><th>Date</th></tr></thead>
        <tbody>
            <?php foreach ($results as $result): ?>
                <tr>
                    <td><?= e($result['type']) ?></td>
                    <td><?= e($result['title']) ?></td>
                    <td><?= e($result['subtitle']) ?></td>
                    <td><?= $result['status'] !== '' ? status_chip($result['status']) : '' ?></td>
                    <td><?= e($result['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if ($q !== '' && !$results): ?><tr><td colspan="5" class="empty-state">No matching authorized results.</td></tr><?php endif; ?>
            <?php if ($q === ''): ?><tr><td colspan="5" class="empty-state">Enter a search term.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php render_footer(); ?>
