<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';

require_login();
render_header('Future Modules', 'locked');
page_header('Locked / Future Modules', 'These modules are visible for future expansion but intentionally non-operational in the active Programming 3 scope.');
locked_module_cards();
render_footer();
