<?php
require_once __DIR__ . '/includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim((string) ($_POST['email'] ?? ''));
    $stmt = db()->prepare('SELECT id, full_name FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user) {
        notify_user((int) $user['id'], 'Password reset requested', 'Use the reset password page or ask the system administrator for assistance.');
        audit_log('Password reset requested', 'users', (int) $user['id'], $email);
    }

    flash('success', 'If the email exists, a reset instruction has been recorded.');
    redirect(app_url('forgot_password.php'));
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Forgot Password | E-Barangay</title>
    <link rel="stylesheet" href="<?= e(app_url('assets/css/style.css')) ?>">
</head>
<body class="auth-page">
    <main class="auth-card">
        <p class="eyebrow">Account Recovery</p>
        <h1>Forgot password</h1>
        <?php if ($message = flash('success')): ?><div class="alert success"><?= e($message) ?></div><?php endif; ?>
        <form method="post" class="grid">
            <div class="field">
                <label>Email</label>
                <input type="email" name="email" required autofocus>
            </div>
            <button class="button" type="submit">Request reset</button>
        </form>
        <p class="muted"><a href="<?= e(app_url('reset_password.php')) ?>">I have approval to reset</a></p>
        <p class="muted"><a href="<?= e(app_url('login.php')) ?>">Back to login</a></p>
    </main>
</body>
</html>
