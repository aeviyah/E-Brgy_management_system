<?php
require_once __DIR__ . '/includes/auth.php';

if (current_user()) {
    redirect(app_url('dashboard.php'));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = trim((string) ($_POST['full_name'] ?? ''));
    $email = trim((string) ($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $confirm = (string) ($_POST['confirm_password'] ?? '');
    $address = trim((string) ($_POST['address'] ?? ''));
    $contact = trim((string) ($_POST['contact_number'] ?? ''));

    if ($fullName === '' || $email === '' || $password === '' || $address === '') {
        flash('error', 'Please complete all required fields.');
        redirect(app_url('register.php'));
    }

    if ($password !== $confirm) {
        flash('error', 'Passwords do not match.');
        redirect(app_url('register.php'));
    }

    $parts = preg_split('/\s+/', $fullName);
    $first = $parts[0] ?? $fullName;
    $last = count($parts) > 1 ? $parts[count($parts) - 1] : 'Resident';
    $middle = count($parts) > 2 ? implode(' ', array_slice($parts, 1, -1)) : null;

    try {
        db()->beginTransaction();
        $residentCode = reference_no('RES');
        $residentStmt = db()->prepare('INSERT INTO residents (resident_code, first_name, middle_name, last_name, contact_number, email, address, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $residentStmt->execute([$residentCode, $first, $middle, $last, $contact, $email, $address, 'Pending Verification']);
        $residentId = (int) db()->lastInsertId();

        $userStmt = db()->prepare('INSERT INTO users (resident_id, full_name, email, password_hash, role, status) VALUES (?, ?, ?, ?, ?, ?)');
        $userStmt->execute([$residentId, $fullName, $email, password_hash($password, PASSWORD_DEFAULT), 'resident', 'active']);
        $userId = (int) db()->lastInsertId();

        db()->commit();
        $_SESSION['user_id'] = $userId;
        audit_log('Resident registration', 'residents', $residentId, $residentCode);
        notify_user(null, 'Resident registration pending', $fullName . ' submitted a resident registration.');
        flash('success', 'Registration submitted. Your resident profile is pending verification.');
        redirect(app_url('dashboard.php'));
    } catch (Throwable $e) {
        if (db()->inTransaction()) {
            db()->rollBack();
        }
        flash('error', 'Registration failed. The email may already exist.');
        redirect(app_url('register.php'));
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Resident Registration | E-Barangay</title>
    <link rel="stylesheet" href="<?= e(app_url('assets/css/style.css')) ?>">
</head>
<body class="auth-page">
    <main class="auth-card">
        <p class="eyebrow">Resident Portal</p>
        <h1>Create account</h1>
        <?php if ($message = flash('error')): ?>
            <div class="alert error"><?= e($message) ?></div>
        <?php endif; ?>
        <form method="post" class="grid">
            <div class="field">
                <label>Full name</label>
                <input type="text" name="full_name" required>
            </div>
            <div class="field">
                <label>Email</label>
                <input type="email" name="email" required>
            </div>
            <div class="field">
                <label>Contact number</label>
                <input type="text" name="contact_number">
            </div>
            <div class="field">
                <label>Address</label>
                <input type="text" name="address" required>
            </div>
            <div class="field">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>
            <div class="field">
                <label>Confirm password</label>
                <input type="password" name="confirm_password" required>
            </div>
            <button class="button" type="submit">Register</button>
        </form>
        <p class="muted">Already registered? <a href="<?= e(app_url('login.php')) ?>">Login</a></p>
    </main>
</body>
</html>
