<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';

$announcements = db()->query("SELECT * FROM announcements WHERE status IN ('Published','Scheduled') ORDER BY id DESC LIMIT 6")->fetchAll();
$events = db()->query("SELECT * FROM events WHERE status IN ('Scheduled','Ongoing') ORDER BY starts_at IS NULL, starts_at ASC LIMIT 6")->fetchAll();
$officials = db()->query("SELECT * FROM officials WHERE status = 'Active' ORDER BY id ASC LIMIT 8")->fetchAll();
$verification = null;

if (isset($_GET['verify']) && trim((string) $_GET['verify']) !== '') {
    $code = trim((string) $_GET['verify']);
    $stmt = db()->prepare('SELECT reference_no, title, requester_name, status, document_no, qr_code FROM request_records WHERE reference_no = ? OR qr_code = ? OR document_no = ? LIMIT 1');
    $stmt->execute([$code, $code, $code]);
    $verification = $stmt->fetch() ?: false;
}

render_header('Public Barangay Portal', 'public');
?>
<section class="portal-hero">
    <p class="eyebrow">Public Barangay Portal</p>
    <h1><?= e(setting('barangay_name', 'Sample Barangay')) ?></h1>
    <p>Access announcements, events, officials, services, requirements, fees, emergency contacts, and document verification without exposing private resident records.</p>
    <div class="actions">
        <a class="button" href="<?= e(app_url('register.php')) ?>">Resident registration</a>
        <a class="button ghost" href="<?= e(app_url('login.php')) ?>">Login</a>
    </div>
</section>

<div class="grid cards-3" style="margin-top: 16px;">
    <section class="card">
        <h2>Office Information</h2>
        <ul class="quick-list">
            <li><span>Office hours</span><strong><?= e(setting('office_hours', 'Monday to Friday')) ?></strong></li>
            <li><span>Contact</span><strong><?= e(setting('contact_number', 'N/A')) ?></strong></li>
            <li><span>Email</span><strong><?= e(setting('email_address', 'N/A')) ?></strong></li>
        </ul>
    </section>
    <section class="card">
        <h2>Document Verification</h2>
        <form method="get" class="grid">
            <div class="field">
                <label>Reference, document, or QR code</label>
                <input type="text" name="verify" value="<?= e($_GET['verify'] ?? '') ?>">
            </div>
            <button class="button" type="submit">Verify</button>
        </form>
        <?php if ($verification !== null): ?>
            <div class="alert <?= $verification ? 'success' : 'error' ?>" style="margin-top: 12px;">
                <?= $verification ? e($verification['title'] . ' - ' . $verification['status']) : 'No matching public verification record found.' ?>
            </div>
        <?php endif; ?>
    </section>
    <section class="card">
        <h2>Services & Requirements</h2>
        <ul class="quick-list">
            <li><span>Barangay Clearance</span><strong>Valid ID</strong></li>
            <li><span>Certificate of Residency</span><strong>Proof of address</strong></li>
            <li><span>Business Clearance</span><strong>Owner and business details</strong></li>
        </ul>
    </section>
</div>

<div class="grid cards-3" style="margin-top: 14px;">
    <section class="card">
        <h2>Announcements</h2>
        <ul class="quick-list">
            <?php foreach ($announcements as $announcement): ?>
                <li><span><?= e($announcement['title']) ?></span><?= status_chip($announcement['status']) ?></li>
            <?php endforeach; ?>
            <?php if (!$announcements): ?><li>No public announcements yet.</li><?php endif; ?>
        </ul>
    </section>
    <section class="card">
        <h2>Events</h2>
        <ul class="quick-list">
            <?php foreach ($events as $event): ?>
                <li><span><?= e($event['title']) ?></span><small><?= e($event['starts_at'] ?? '') ?></small></li>
            <?php endforeach; ?>
            <?php if (!$events): ?><li>No scheduled events yet.</li><?php endif; ?>
        </ul>
    </section>
    <section class="card">
        <h2>Officials</h2>
        <ul class="quick-list">
            <?php foreach ($officials as $official): ?>
                <li><span><?= e($official['name']) ?></span><strong><?= e($official['position']) ?></strong></li>
            <?php endforeach; ?>
            <?php if (!$officials): ?><li>No official profiles published yet.</li><?php endif; ?>
        </ul>
    </section>
</div>
<?php render_footer(); ?>
