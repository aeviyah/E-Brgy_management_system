<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';

require_login();
$user = current_user();
$isResident = $user['role'] === 'resident';

render_header('Dashboard', 'dashboard');
page_header(
    $isResident ? 'Resident Dashboard' : 'Admin / Official Dashboard',
    $isResident
        ? 'Track your requests, payments, notifications, announcements, and available services.'
        : 'Operational control center for pending work, collections, cases, calendar, and recent activity.'
);

if ($isResident):
    $stmt = db()->prepare('SELECT * FROM request_records WHERE resident_id = ? OR requester_name = ? ORDER BY id DESC LIMIT 8');
    $stmt->execute([$user['resident_id'] ?? 0, $user['full_name']]);
    $myRequests = $stmt->fetchAll();
    $announcements = db()->query("SELECT * FROM announcements WHERE status IN ('Published','Scheduled') ORDER BY id DESC LIMIT 5")->fetchAll();
    ?>
    <div class="grid cards-3" style="margin-bottom: 14px;">
        <a class="card metric" href="<?= e(app_url('documents.php?action=new')) ?>"><span>Request</span><strong>Document</strong></a>
        <a class="card metric" href="<?= e(app_url('services.php?action=new')) ?>"><span>Ask for</span><strong>Service</strong></a>
        <a class="card metric" href="<?= e(app_url('cases.php?action=new')) ?>"><span>File</span><strong>Complaint</strong></a>
    </div>
    <div class="grid cards-2">
        <section class="card">
            <h2>My Requests</h2>
            <ul class="quick-list">
                <?php foreach ($myRequests as $request): ?>
                    <li><span><?= e($request['reference_no']) ?> - <?= e($request['title']) ?></span><?= status_chip($request['status']) ?></li>
                <?php endforeach; ?>
                <?php if (!$myRequests): ?><li>No requests yet.</li><?php endif; ?>
            </ul>
        </section>
        <section class="card">
            <h2>Announcements</h2>
            <ul class="quick-list">
                <?php foreach ($announcements as $announcement): ?>
                    <li><span><?= e($announcement['title']) ?></span><?= status_chip($announcement['status']) ?></li>
                <?php endforeach; ?>
                <?php if (!$announcements): ?><li>No announcements posted.</li><?php endif; ?>
            </ul>
        </section>
    </div>
<?php else: ?>
    <div class="grid cards-4" style="margin-bottom: 14px;">
        <div class="card metric"><span>Residents</span><strong><?= fetch_count('residents') ?></strong></div>
        <div class="card metric"><span>Households</span><strong><?= fetch_count('households') ?></strong></div>
        <div class="card metric"><span>Pending Requests</span><strong><?= fetch_count('request_records', "status IN ('Pending','Under Review','For Payment','For Approval')") ?></strong></div>
        <div class="card metric"><span>Open Cases</span><strong><?= fetch_count('cases', "status NOT IN ('Closed','Archived')") ?></strong></div>
    </div>
    <div class="grid cards-3" style="margin-bottom: 14px;">
        <a class="card metric" href="<?= e(app_url('residents.php?action=form')) ?>"><span>Quick action</span><strong>Register Resident</strong></a>
        <a class="card metric" href="<?= e(app_url('documents.php')) ?>"><span>Queue</span><strong>Process Documents</strong></a>
        <a class="card metric" href="<?= e(app_url('treasury.php')) ?>"><span>Finance</span><strong>Record Payment</strong></a>
    </div>
    <div class="grid cards-2">
        <section class="card">
            <h2>Pending Request Queue</h2>
            <ul class="quick-list">
                <?php
                $queue = db()->query("SELECT * FROM request_records WHERE status NOT IN ('Completed','Rejected','Cancelled','Archived') ORDER BY id DESC LIMIT 8")->fetchAll();
                foreach ($queue as $request): ?>
                    <li><span><?= e($request['reference_no']) ?> - <?= e($request['title']) ?></span><?= status_chip($request['status']) ?></li>
                <?php endforeach; ?>
                <?php if (!$queue): ?><li>No pending requests.</li><?php endif; ?>
            </ul>
        </section>
        <section class="card">
            <h2>Recent Activity</h2>
            <ul class="quick-list">
                <?php
                $logs = db()->query('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 8')->fetchAll();
                foreach ($logs as $log): ?>
                    <li><span><?= e($log['action']) ?> <?= e($log['table_name']) ?></span><small><?= e($log['created_at']) ?></small></li>
                <?php endforeach; ?>
                <?php if (!$logs): ?><li>No audit activity yet.</li><?php endif; ?>
            </ul>
        </section>
    </div>
<?php endif; ?>

<?php render_footer(); ?>
