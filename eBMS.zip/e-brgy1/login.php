<?php
require_once __DIR__ . '/includes/auth.php';

if (current_user()) {
    redirect(app_url('dashboard.php'));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim((string) ($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    if (login_attempt($email, $password)) {
        flash('success', 'Welcome back.');
        redirect(app_url('dashboard.php'));
    }

    flash('error', 'Invalid email, password, or inactive account.');
    redirect(app_url('login.php'));
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login | E-Barangay</title>
    <link rel="stylesheet" href="<?= e(app_url('assets/css/style.css')) ?>">
</head>
<body class="auth-page">
    <main class="auth-card">
        <p class="eyebrow">E-Barangay Management</p>
        <h1>Sign in</h1>
        <?php if ($message = flash('error')): ?>
            <div class="alert error"><?= e($message) ?></div>
        <?php endif; ?>
        <form method="post" class="grid">
            <div class="field">
                <label>Email</label>
                <input type="email" name="email" required autofocus value="admin@barangay.test">
            </div>
            <div class="field">
                <label>Password</label>
                <input type="password" name="password" required value="password">
            </div>
            <button class="button" type="submit">Login</button>
        </form>
        <p class="muted">No account yet? <a href="<?= e(app_url('register.php')) ?>">Register as resident</a></p>
        <p class="muted"><a href="<?= e(app_url('forgot_password.php')) ?>">Forgot password?</a></p>
        <p class="muted"><a href="<?= e(app_url('public_portal.php')) ?>">Open public portal</a></p>
    </main>
</body>
</html>
