<?php
$moduleKey = 'budget';
require __DIR__ . '/module.php';
