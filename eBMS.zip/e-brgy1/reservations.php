<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';

require_roles(['resident', 'secretary', 'captain', 'staff', 'admin']);

$user = current_user();
$canProcess = role_allows(['secretary', 'captain', 'staff', 'admin']);
$statuses = ['Pending', 'Under Review', 'Approved', 'Reserved', 'Completed', 'Rejected', 'Cancelled', 'Archived'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['form_action'] ?? '';

    if ($action === 'create') {
        $facilityId = (int) ($_POST['facility_id'] ?? 0);
        $requester = trim((string) ($_POST['requester_name'] ?? ''));
        $purpose = trim((string) ($_POST['purpose'] ?? ''));
        $starts = trim((string) ($_POST['starts_at'] ?? ''));
        $ends = trim((string) ($_POST['ends_at'] ?? ''));

        if ($facilityId <= 0 || $requester === '' || $purpose === '' || $starts === '' || $ends === '') {
            flash('error', 'Facility, requester, purpose, start and end are required.');
            redirect(app_url('reservations.php?action=new'));
        }

        $check = db()->prepare("SELECT COUNT(*) FROM reservations WHERE facility_id = ? AND status IN ('Approved','Reserved') AND NOT (ends_at <= ? OR starts_at >= ?)");
        $check->execute([$facilityId, $starts, $ends]);
        if ((int) $check->fetchColumn() > 0) {
            flash('error', 'Selected schedule conflicts with an approved reservation.');
            redirect(app_url('reservations.php?action=new'));
        }

        $stmt = db()->prepare('INSERT INTO reservations (facility_id, resident_id, requester_name, purpose, starts_at, ends_at, status, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([$facilityId, $user['resident_id'] ?? null, $requester, $purpose, $starts, $ends, 'Pending', trim((string) ($_POST['remarks'] ?? ''))]);
        audit_log('Create reservation', 'reservations', (int) db()->lastInsertId(), $purpose);
        flash('success', 'Reservation request submitted.');
        redirect(app_url('reservations.php'));
    }

    if ($action === 'status' && $canProcess) {
        $id = (int) ($_POST['id'] ?? 0);
        $status = (string) ($_POST['status'] ?? 'Pending');
        if (!in_array($status, $statuses, true)) {
            flash('error', 'Invalid reservation status.');
            redirect(app_url('reservations.php'));
        }
        db()->prepare('UPDATE reservations SET status = ?, remarks = ? WHERE id = ?')->execute([$status, trim((string) ($_POST['remarks'] ?? '')), $id]);
        audit_log('Update reservation', 'reservations', $id, $status);
        flash('success', 'Reservation updated.');
        redirect(app_url('reservations.php'));
    }
}

$facilities = db()->query("SELECT * FROM facilities WHERE status != 'Archived' ORDER BY name")->fetchAll();
render_header('Reservations', 'facilities');

if (($_GET['action'] ?? '') === 'new') {
    page_header('Facility Reservation Request', 'Check availability, submit request, approve, reserve, and keep reservation history.', '<a class="button ghost" href="' . e(app_url('reservations.php')) . '">Back</a>');
    ?>
    <form class="card" method="post">
        <input type="hidden" name="form_action" value="create">
        <div class="form-grid">
            <div class="field">
                <label>Facility</label>
                <select name="facility_id">
                    <?php foreach ($facilities as $facility): ?><option value="<?= (int) $facility['id'] ?>"><?= e($facility['name']) ?></option><?php endforeach; ?>
                </select>
            </div>
            <div class="field">
                <label>Requester name</label>
                <input type="text" name="requester_name" value="<?= e($user['full_name']) ?>" required>
            </div>
            <div class="field">
                <label>Starts at</label>
                <input type="datetime-local" name="starts_at" required>
            </div>
            <div class="field">
                <label>Ends at</label>
                <input type="datetime-local" name="ends_at" required>
            </div>
            <div class="field full">
                <label>Purpose</label>
                <input type="text" name="purpose" required>
            </div>
            <div class="field full">
                <label>Remarks</label>
                <textarea name="remarks"></textarea>
            </div>
        </div>
        <div class="actions" style="margin-top: 16px;"><button class="button" type="submit">Submit request</button></div>
    </form>
    <?php
    render_footer();
    exit;
}

$where = [];
$params = [];
if (!$canProcess) {
    $where[] = '(r.resident_id = ? OR r.requester_name = ?)';
    $params[] = $user['resident_id'] ?? 0;
    $params[] = $user['full_name'];
}
$sql = 'SELECT r.*, f.name AS facility_name FROM reservations r JOIN facilities f ON f.id = r.facility_id';
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY r.starts_at DESC LIMIT 200';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$reservations = $stmt->fetchAll();

page_header('Facility Reservations', 'Availability, request review, approval, double-booking prevention, and reservation history.', '<a class="button" href="' . e(app_url('reservations.php?action=new')) . '">New reservation</a>');
?>
<div class="table-wrap">
    <table>
        <thead><tr><th>Facility</th><th>Requester</th><th>Schedule</th><th>Purpose</th><th>Status</th><th>Action</th></tr></thead>
        <tbody>
            <?php foreach ($reservations as $reservation): ?>
                <tr>
                    <td><?= e($reservation['facility_name']) ?></td>
                    <td><?= e($reservation['requester_name']) ?></td>
                    <td><?= e($reservation['starts_at']) ?><br><?= e($reservation['ends_at']) ?></td>
                    <td><?= e($reservation['purpose']) ?></td>
                    <td><?= status_chip($reservation['status']) ?></td>
                    <td>
                        <?php if ($canProcess): ?>
                            <form method="post" class="stacked-form">
                                <input type="hidden" name="form_action" value="status">
                                <input type="hidden" name="id" value="<?= (int) $reservation['id'] ?>">
                                <select name="status">
                                    <?php foreach ($statuses as $option): ?><option value="<?= e($option) ?>" <?= selected($reservation['status'], $option) ?>><?= e($option) ?></option><?php endforeach; ?>
                                </select>
                                <input type="text" name="remarks" value="<?= e($reservation['remarks']) ?>" placeholder="Remarks">
                                <button class="button secondary" type="submit">Update</button>
                            </form>
                        <?php else: ?>
                            <span class="muted">Tracking only</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$reservations): ?><tr><td colspan="6" class="empty-state">No reservations found.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php render_footer(); ?>
