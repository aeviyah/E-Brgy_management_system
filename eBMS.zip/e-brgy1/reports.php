<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';

require_roles(['secretary', 'treasurer', 'captain', 'staff', 'admin']);

$report = (string) ($_GET['report'] ?? 'overview');
$allowedReports = ['overview', 'population', 'requests', 'cases', 'collections', 'projects'];
if (!in_array($report, $allowedReports, true)) {
    $report = 'overview';
}

function report_rows(string $report): array
{
    if ($report === 'population') {
        return db()->query("SELECT COALESCE(p.name, 'Unassigned') AS label, COUNT(r.id) AS total FROM residents r LEFT JOIN puroks p ON p.id = r.purok_id GROUP BY p.name ORDER BY total DESC")->fetchAll();
    }
    if ($report === 'requests') {
        return db()->query('SELECT CONCAT(type, " - ", status) AS label, COUNT(*) AS total FROM request_records GROUP BY type, status ORDER BY type, status')->fetchAll();
    }
    if ($report === 'cases') {
        return db()->query('SELECT CONCAT(case_type, " - ", status) AS label, COUNT(*) AS total FROM cases GROUP BY case_type, status ORDER BY case_type, status')->fetchAll();
    }
    if ($report === 'collections') {
        return db()->query("SELECT DATE(COALESCE(paid_at, created_at)) AS label, COALESCE(SUM(amount), 0) AS total FROM payments WHERE status = 'Paid' GROUP BY DATE(COALESCE(paid_at, created_at)) ORDER BY label DESC LIMIT 31")->fetchAll();
    }
    if ($report === 'projects') {
        return db()->query('SELECT status AS label, COUNT(*) AS total FROM projects GROUP BY status ORDER BY status')->fetchAll();
    }

    return [
        ['label' => 'Residents', 'total' => fetch_count('residents')],
        ['label' => 'Households', 'total' => fetch_count('households')],
        ['label' => 'Requests', 'total' => fetch_count('request_records')],
        ['label' => 'Cases', 'total' => fetch_count('cases')],
        ['label' => 'Paid Collections', 'total' => (float) db()->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status = 'Paid'")->fetchColumn()],
        ['label' => 'Projects', 'total' => fetch_count('projects')],
    ];
}

if (($_GET['export'] ?? '') === 'csv') {
    $rows = report_rows($report);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="e-barangay-' . $report . '-report.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Label', 'Total']);
    foreach ($rows as $row) {
        fputcsv($out, [$row['label'], $row['total']]);
    }
    fclose($out);
    exit;
}

$rows = report_rows($report);
render_header('Reports', 'reports');
page_header('Statistics & Analytics', 'Population, demographics, Purok, documents, requests, cases, collections, and project statistics.', '<a class="button" href="' . e(app_url('reports.php?report=' . $report . '&export=csv')) . '">Export CSV</a>');
?>
<form class="inline-form" method="get">
    <select name="report">
        <option value="overview" <?= selected($report, 'overview') ?>>Overview</option>
        <option value="population" <?= selected($report, 'population') ?>>Population by Purok</option>
        <option value="requests" <?= selected($report, 'requests') ?>>Requests by Status</option>
        <option value="cases" <?= selected($report, 'cases') ?>>Cases by Status</option>
        <option value="collections" <?= selected($report, 'collections') ?>>Collections</option>
        <option value="projects" <?= selected($report, 'projects') ?>>Projects</option>
    </select>
    <button class="button ghost" type="submit">View report</button>
</form>
<div class="grid cards-3" style="margin-bottom: 14px;">
    <?php foreach (array_slice($rows, 0, 6) as $row): ?>
        <div class="card metric"><span><?= e((string) $row['label']) ?></span><strong><?= is_numeric($row['total']) ? e(number_format((float) $row['total'], 2)) : e((string) $row['total']) ?></strong></div>
    <?php endforeach; ?>
</div>
<div class="table-wrap">
    <table>
        <thead><tr><th>Metric</th><th>Total</th></tr></thead>
        <tbody>
            <?php foreach ($rows as $row): ?>
                <tr><td><?= e((string) $row['label']) ?></td><td><?= e((string) $row['total']) ?></td></tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?><tr><td colspan="2" class="empty-state">No report data available.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php render_footer(); ?>
