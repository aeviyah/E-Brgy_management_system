<?php
require_once __DIR__ . '/includes/auth.php';

require_login();
redirect(app_url('dashboard.php'));
