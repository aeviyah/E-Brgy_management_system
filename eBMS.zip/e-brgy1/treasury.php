<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';

require_roles(['resident', 'treasurer', 'captain', 'admin']);

$user = current_user();
$canManage = can_manage_finance();
$methods = ['Cash', 'GCash', 'Bank Transfer', 'Check', 'Other'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $canManage) {
    $action = $_POST['form_action'] ?? '';

    if ($action === 'create') {
        $purpose = trim((string) ($_POST['purpose'] ?? ''));
        $amount = (float) ($_POST['amount'] ?? 0);
        if ($purpose === '' || $amount <= 0) {
            flash('error', 'Purpose and amount are required.');
            redirect(app_url('treasury.php?action=new'));
        }
        $stmt = db()->prepare('INSERT INTO payments (transaction_no, resident_id, purpose, amount, method, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            reference_no('PAY'),
            trim((string) ($_POST['resident_id'] ?? '')) ?: null,
            $purpose,
            $amount,
            (string) ($_POST['method'] ?? 'Cash'),
            'Pending',
            (int) $user['id'],
        ]);
        audit_log('Create payment', 'payments', (int) db()->lastInsertId(), $purpose);
        flash('success', 'Payment transaction created.');
        redirect(app_url('treasury.php'));
    }

    if ($action === 'paid') {
        $id = (int) ($_POST['id'] ?? 0);
        db()->prepare("UPDATE payments SET status = 'Paid', method = ?, paid_at = NOW(), created_by = ? WHERE id = ?")->execute([(string) ($_POST['method'] ?? 'Cash'), (int) $user['id'], $id]);

        $receiptCheck = db()->prepare('SELECT COUNT(*) FROM receipts WHERE payment_id = ?');
        $receiptCheck->execute([$id]);
        if ((int) $receiptCheck->fetchColumn() === 0) {
            db()->prepare('INSERT INTO receipts (or_number, payment_id, issued_by, issued_at) VALUES (?, ?, ?, NOW())')->execute([reference_no('OR'), $id, (int) $user['id']]);
        }
        audit_log('Record payment', 'payments', $id, 'Paid');
        flash('success', 'Payment marked paid and official receipt generated.');
        redirect(app_url('treasury.php'));
    }
}

render_header('Treasury', 'treasury');

if (($_GET['action'] ?? '') === 'new' && $canManage) {
    page_header('New Payment / Assessment', 'Record barangay, document, permit, service, or other official fee.', '<a class="button ghost" href="' . e(app_url('treasury.php')) . '">Back</a>');
    ?>
    <form class="card" method="post">
        <input type="hidden" name="form_action" value="create">
        <div class="form-grid">
            <div class="field">
                <label>Resident ID</label>
                <input type="number" name="resident_id">
            </div>
            <div class="field">
                <label>Purpose</label>
                <input type="text" name="purpose" required>
            </div>
            <div class="field">
                <label>Amount</label>
                <input type="number" step="0.01" name="amount" required>
            </div>
            <div class="field">
                <label>Method</label>
                <select name="method">
                    <?php foreach ($methods as $method): ?><option value="<?= e($method) ?>"><?= e($method) ?></option><?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="actions" style="margin-top: 16px;"><button class="button" type="submit">Save payment</button></div>
    </form>
    <?php
    render_footer();
    exit;
}

$where = [];
$params = [];
if (!$canManage) {
    $where[] = 'p.resident_id = ?';
    $params[] = $user['resident_id'] ?? 0;
}
$q = trim((string) ($_GET['q'] ?? ''));
if ($q !== '') {
    $where[] = '(p.transaction_no LIKE ? OR p.purpose LIKE ? OR r.or_number LIKE ?)';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
}
$sql = 'SELECT p.*, r.or_number, r.issued_at FROM payments p LEFT JOIN receipts r ON r.payment_id = p.id';
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY p.id DESC LIMIT 200';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$payments = $stmt->fetchAll();

page_header('Treasury / Payments / Official Receipts', 'Payment assessment, transaction recording, collections, OR generation, and financial reporting.', $canManage ? '<a class="button" href="' . e(app_url('treasury.php?action=new')) . '">New payment</a>' : '');
?>
<div class="grid cards-3" style="margin-bottom: 14px;">
    <div class="card metric"><span>Today Collections</span><strong>PHP <?= number_format((float) db()->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status = 'Paid' AND DATE(paid_at) = CURDATE()")->fetchColumn(), 2) ?></strong></div>
    <div class="card metric"><span>Pending Payments</span><strong><?= fetch_count('payments', "status = 'Pending'") ?></strong></div>
    <div class="card metric"><span>Paid Transactions</span><strong><?= fetch_count('payments', "status = 'Paid'") ?></strong></div>
</div>
<form class="inline-form" method="get">
    <input type="search" name="q" placeholder="Search transaction, purpose, OR" value="<?= e($q) ?>">
    <button class="button ghost" type="submit">Filter</button>
</form>
<div class="table-wrap">
    <table>
        <thead><tr><th>Transaction</th><th>Purpose</th><th>Amount</th><th>Status</th><th>Official Receipt</th><th>Action</th></tr></thead>
        <tbody>
            <?php foreach ($payments as $payment): ?>
                <tr>
                    <td><strong><?= e($payment['transaction_no']) ?></strong><br><?= e($payment['created_at']) ?></td>
                    <td><?= e($payment['purpose']) ?><br><span class="muted"><?= e($payment['method']) ?></span></td>
                    <td>PHP <?= number_format((float) $payment['amount'], 2) ?></td>
                    <td><?= status_chip($payment['status']) ?></td>
                    <td><?= e($payment['or_number'] ?? 'Not issued') ?><br><span class="muted"><?= e($payment['issued_at'] ?? '') ?></span></td>
                    <td>
                        <?php if ($canManage && $payment['status'] !== 'Paid'): ?>
                            <form method="post" class="stacked-form">
                                <input type="hidden" name="form_action" value="paid">
                                <input type="hidden" name="id" value="<?= (int) $payment['id'] ?>">
                                <select name="method">
                                    <?php foreach ($methods as $method): ?><option value="<?= e($method) ?>" <?= selected($payment['method'], $method) ?>><?= e($method) ?></option><?php endforeach; ?>
                                </select>
                                <button class="button secondary" type="submit">Mark paid</button>
                            </form>
                        <?php else: ?>
                            <span class="muted">Recorded</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$payments): ?><tr><td colspan="6" class="empty-state">No payments found.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php render_footer(); ?>
