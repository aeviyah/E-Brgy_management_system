<?php

declare(strict_types=1);

function navigation_items(): array
{
    return [
        ['key' => 'dashboard', 'label' => 'Dashboard', 'href' => 'dashboard.php', 'roles' => ['resident', 'secretary', 'treasurer', 'captain', 'staff', 'admin']],
        ['key' => 'residents', 'label' => 'Residents', 'href' => 'residents.php', 'roles' => ['secretary', 'captain', 'staff', 'admin']],
        ['key' => 'households', 'label' => 'Households', 'href' => 'households.php', 'roles' => ['secretary', 'captain', 'staff', 'admin']],
        ['key' => 'puroks', 'label' => 'Purok/Sitio', 'href' => 'puroks.php', 'roles' => ['secretary', 'captain', 'staff', 'admin']],
        ['key' => 'documents', 'label' => 'Documents', 'href' => 'documents.php', 'roles' => ['resident', 'secretary', 'captain', 'staff', 'admin']],
        ['key' => 'permits', 'label' => 'Permits', 'href' => 'permits.php', 'roles' => ['resident', 'secretary', 'captain', 'staff', 'admin']],
        ['key' => 'services', 'label' => 'Services', 'href' => 'services.php', 'roles' => ['resident', 'secretary', 'captain', 'staff', 'admin']],
        ['key' => 'cases', 'label' => 'Cases', 'href' => 'cases.php', 'roles' => ['resident', 'secretary', 'captain', 'staff', 'admin']],
        ['key' => 'governance', 'label' => 'Governance', 'href' => 'governance.php', 'roles' => ['secretary', 'captain', 'staff', 'admin']],
        ['key' => 'treasury', 'label' => 'Treasury', 'href' => 'treasury.php', 'roles' => ['resident', 'treasurer', 'captain', 'admin']],
        ['key' => 'budget', 'label' => 'Budget', 'href' => 'budget.php', 'roles' => ['treasurer', 'captain', 'admin']],
        ['key' => 'communication', 'label' => 'Communication', 'href' => 'communication.php', 'roles' => ['secretary', 'captain', 'staff', 'admin']],
        ['key' => 'events', 'label' => 'Events', 'href' => 'events.php', 'roles' => ['resident', 'secretary', 'captain', 'staff', 'admin']],
        ['key' => 'facilities', 'label' => 'Facilities', 'href' => 'facilities.php', 'roles' => ['resident', 'secretary', 'captain', 'staff', 'admin']],
        ['key' => 'assets', 'label' => 'Assets', 'href' => 'assets.php', 'roles' => ['secretary', 'captain', 'staff', 'admin']],
        ['key' => 'projects', 'label' => 'Projects', 'href' => 'projects.php', 'roles' => ['resident', 'secretary', 'captain', 'staff', 'admin']],
        ['key' => 'environment', 'label' => 'Environment', 'href' => 'environment.php', 'roles' => ['secretary', 'captain', 'staff', 'admin']],
        ['key' => 'assistance', 'label' => 'Assistance', 'href' => 'assistance.php', 'roles' => ['secretary', 'captain', 'staff', 'admin']],
        ['key' => 'reports', 'label' => 'Reports', 'href' => 'reports.php', 'roles' => ['secretary', 'treasurer', 'captain', 'staff', 'admin']],
        ['key' => 'search', 'label' => 'Search', 'href' => 'search.php', 'roles' => ['resident', 'secretary', 'treasurer', 'captain', 'staff', 'admin']],
        ['key' => 'audit', 'label' => 'Audit', 'href' => 'audit.php', 'roles' => ['captain', 'admin']],
        ['key' => 'settings', 'label' => 'Settings', 'href' => 'settings.php', 'roles' => ['admin']],
    ];
}

function locked_modules(): array
{
    return [
        ['label' => 'SK Management', 'description' => 'SK officials, youth records, youth programs, budget, and beneficiaries.'],
        ['label' => 'Barangay Health Center', 'description' => 'Patient records, consultations, appointments, immunization, medicines, and health programs.'],
        ['label' => 'Emergency & Disaster Response', 'description' => 'Emergency reports, responders, evacuation centers, disaster records, mapping, and mass alerts.'],
        ['label' => 'Other Specialized Modules', 'description' => 'Agriculture, dedicated senior citizen, dedicated PWD, and future sector systems.'],
    ];
}
