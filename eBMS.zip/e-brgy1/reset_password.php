<?php
require_once __DIR__ . '/includes/auth.php';

if (!current_user()) {
    flash('error', 'Password reset must be completed by the system administrator after a reset request.');
    redirect(app_url('login.php'));
}

require_roles(['admin']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim((string) ($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $confirm = (string) ($_POST['confirm_password'] ?? '');

    if ($email === '' || $password === '' || $password !== $confirm) {
        flash('error', 'Enter a valid email and matching passwords.');
        redirect(app_url('reset_password.php'));
    }

    $stmt = db()->prepare('UPDATE users SET password_hash = ? WHERE email = ?');
    $stmt->execute([password_hash($password, PASSWORD_DEFAULT), $email]);
    audit_log('Password reset completed', 'users', null, $email);
    flash('success', 'Password updated. You may now login.');
    redirect(app_url('settings.php'));
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Reset Password | E-Barangay</title>
    <link rel="stylesheet" href="<?= e(app_url('assets/css/style.css')) ?>">
</head>
<body class="auth-page">
    <main class="auth-card">
        <p class="eyebrow">Account Recovery</p>
        <h1>Admin password reset</h1>
        <?php if ($message = flash('error')): ?><div class="alert error"><?= e($message) ?></div><?php endif; ?>
        <form method="post" class="grid">
            <div class="field">
                <label>Email</label>
                <input type="email" name="email" required autofocus>
            </div>
            <div class="field">
                <label>New password</label>
                <input type="password" name="password" required>
            </div>
            <div class="field">
                <label>Confirm password</label>
                <input type="password" name="confirm_password" required>
            </div>
            <button class="button" type="submit">Reset password</button>
        </form>
        <p class="muted"><a href="<?= e(app_url('settings.php')) ?>">Back to settings</a></p>
    </main>
</body>
</html>
