<?php

require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

if (is_logged_in()) {
    redirect('dashboard.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim((string) ($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    try {
        $user = fetch_one(
            'SELECT users.*, roles.slug AS role_slug, roles.name AS role_name
             FROM users
             JOIN roles ON roles.id = users.role_id
             WHERE users.email = ?',
            [$email]
        );

        if ($user && $user['status'] === 'Active' && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int) $user['id'];
            audit_log('Login', 'User', (int) $user['id'], 'User logged in successfully.');
            redirect('dashboard.php');
        }

        flash('danger', 'Invalid email, password, or inactive account.');
    } catch (Throwable $error) {
        flash('danger', 'Database connection failed. Import database/schema.sql in phpMyAdmin and check config/database.php.');
    }
}

render_header('Login', ['body_class' => 'auth-page']);
?>
<section class="auth-card">
    <p class="eyebrow">Programming 3 Project</p>
    <h1><?= e(APP_NAME) ?></h1>
    <p>Sign in with a seeded demo account or register as a resident.</p>

    <form method="post" class="form-grid">
        <div class="form-field full">
            <label for="email">Email</label>
            <input class="form-control" id="email" type="email" name="email" value="<?= e(old('email', 'admin@barangay.test')) ?>" required>
        </div>
        <div class="form-field full">
            <label for="password">Password</label>
            <input class="form-control" id="password" type="password" name="password" value="password" required>
        </div>
        <div class="form-actions full">
            <button class="btn" type="submit">Login</button>
            <a class="btn btn-ghost" href="<?= e(app_url('register.php')) ?>">Resident Registration</a>
            <a class="btn btn-ghost" href="<?= e(app_url('public/index.php')) ?>">Public Portal</a>
        </div>
    </form>

    <p class="muted">Demo users: admin@barangay.test, secretary@barangay.test, treasurer@barangay.test, captain@barangay.test, staff@barangay.test, juan@example.com. Password: password.</p>
</section>
<?php render_footer(); ?>

