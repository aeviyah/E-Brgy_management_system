<?php

require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

require_login();

$user = current_user();
$residentFilter = role_slug() === 'resident' ? ' AND resident_id = ' . (int) current_resident_id() : '';

$stats = [
    'Residents' => (int) fetch_value('SELECT COUNT(*) FROM residents'),
    'Households' => (int) fetch_value('SELECT COUNT(*) FROM households'),
    'Pending Requests' => (int) fetch_value("SELECT COUNT(*) FROM service_records WHERE status IN ('Pending', 'Under Review', 'For Payment', 'For Approval', 'Processing')" . $residentFilter),
    'Open Cases' => (int) fetch_value("SELECT COUNT(*) FROM service_records WHERE module_slug IN ('complaints', 'katarungang', 'protection') AND status NOT IN ('Completed', 'Rejected', 'Cancelled', 'Archived')" . $residentFilter),
    'Today Collections' => (float) fetch_value('SELECT COALESCE(SUM(amount), 0) FROM payments WHERE DATE(paid_at) = CURDATE()'),
    'Active Projects' => (int) fetch_value("SELECT COUNT(*) FROM service_records WHERE module_slug = 'projects' AND status NOT IN ('Completed', 'Archived', 'Cancelled')"),
];

$queueSql = "SELECT service_records.*, residents.first_name, residents.last_name
             FROM service_records
             LEFT JOIN residents ON residents.id = service_records.resident_id
             WHERE status IN ('Pending', 'Under Review', 'For Payment', 'For Approval', 'Processing', 'Ready for Release')";
$queueParams = [];
if (role_slug() === 'resident') {
    $queueSql .= ' AND (service_records.resident_id = ? OR service_records.module_slug IN ("announcements", "events"))';
    $queueParams[] = current_resident_id();
}
$queueSql .= ' ORDER BY service_records.updated_at DESC LIMIT 8';
$queues = fetch_all($queueSql, $queueParams);

$notifications = fetch_all('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 6', [(int) $user['id']]);
$recentAudit = fetch_all('SELECT audit_logs.*, users.full_name FROM audit_logs LEFT JOIN users ON users.id = audit_logs.user_id ORDER BY audit_logs.created_at DESC LIMIT 8');

render_header('Dashboard');
page_header(
    role_slug() === 'resident' ? 'Resident Dashboard' : 'Operational Dashboard',
    'Role-based overview of residents, requests, cases, collections, activities and pending work.',
    '<a class="btn" href="' . e(app_url('modules/records.php?module=documents')) . '">Process Document</a>'
);
?>
<section class="grid grid-4">
    <?php foreach ($stats as $label => $value): ?>
        <article class="metric-card">
            <span><?= e($label) ?></span>
            <strong><?= $label === 'Today Collections' ? e(peso($value)) : e((string) $value) ?></strong>
        </article>
    <?php endforeach; ?>
</section>

<section class="panel">
    <div class="panel-header">
        <h2>Quick Actions</h2>
        <span class="muted">Only actions allowed for your role are shown.</span>
    </div>
    <div class="panel-body split-actions">
        <?php if (can_access_module('residents')): ?><a class="btn" href="<?= e(app_url('modules/residents.php')) ?>">Register Resident</a><?php endif; ?>
        <?php if (can_access_module('documents')): ?><a class="btn btn-secondary" href="<?= e(app_url('modules/records.php?module=documents')) ?>">Document Request</a><?php endif; ?>
        <?php if (can_access_module('services')): ?><a class="btn btn-secondary" href="<?= e(app_url('modules/records.php?module=services')) ?>">Service Request</a><?php endif; ?>
        <?php if (can_access_module('treasury')): ?><a class="btn btn-secondary" href="<?= e(app_url('modules/payments.php')) ?>">Record Payment</a><?php endif; ?>
        <?php if (can_access_module('complaints')): ?><a class="btn btn-secondary" href="<?= e(app_url('modules/records.php?module=complaints')) ?>">File / Review Case</a><?php endif; ?>
        <?php if (can_access_module('announcements')): ?><a class="btn btn-secondary" href="<?= e(app_url('modules/records.php?module=announcements')) ?>">Create Announcement</a><?php endif; ?>
    </div>
</section>

<section class="grid grid-2">
    <div class="panel">
        <div class="panel-header">
            <h2>Workflow Queue</h2>
            <a href="<?= e(app_url('modules/records.php?module=documents')) ?>">Open records</a>
        </div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Reference</th><th>Module</th><th>Status</th><th>Due</th></tr></thead>
                <tbody>
                <?php foreach ($queues as $row): ?>
                    <tr>
                        <td><a class="record-title" href="<?= e(app_url('modules/records.php?module=' . urlencode($row['module_slug']) . '&id=' . (int) $row['id'])) ?>"><strong><?= e($row['reference_no']) ?></strong><small><?= e($row['title']) ?></small></a></td>
                        <td><?= e(module_meta($row['module_slug'])['label'] ?? $row['module_slug']) ?></td>
                        <td><span class="<?= e(status_class($row['status'])) ?>"><?= e($row['status']) ?></span></td>
                        <td><?= e($row['due_date'] ?: 'Not set') ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$queues): ?>
                    <tr><td colspan="4">No pending workflow items.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="panel" id="notifications">
        <div class="panel-header">
            <h2>Notifications</h2>
            <span class="muted">In-app channel</span>
        </div>
        <div class="panel-body">
            <ul class="timeline">
                <?php foreach ($notifications as $notice): ?>
                    <li>
                        <strong><?= e($notice['title']) ?></strong>
                        <p><?= e($notice['message']) ?></p>
                        <small><?= e($notice['channel']) ?> - <?= e($notice['created_at']) ?></small>
                    </li>
                <?php endforeach; ?>
                <?php if (!$notifications): ?><li>No notifications yet.</li><?php endif; ?>
            </ul>
        </div>
    </div>
</section>

<section class="panel">
    <div class="panel-header">
        <h2>Active Modules</h2>
        <span class="muted">Mapped to the approved master scope</span>
    </div>
    <div class="panel-body grid grid-3">
        <?php foreach (app_modules() as $slug => $module): ?>
            <?php if (!can_access_module($slug)) { continue; } ?>
            <article class="module-card">
                <span class="eyebrow"><?= e($module['group']) ?></span>
                <h3><?= e($module['label']) ?></h3>
                <p><?= e($module['description']) ?></p>
                <a class="btn btn-ghost" href="<?= e(app_url(module_url($slug))) ?>">Open</a>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<section class="grid grid-2">
    <div class="panel">
        <div class="panel-header"><h2>Recent Activity</h2></div>
        <div class="panel-body">
            <ul class="timeline">
                <?php foreach ($recentAudit as $activity): ?>
                    <li>
                        <strong><?= e($activity['action']) ?></strong>
                        <p><?= e($activity['details']) ?></p>
                        <small><?= e($activity['full_name'] ?? 'System') ?> - <?= e($activity['created_at']) ?></small>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <div class="panel">
        <div class="panel-header"><h2>Locked / Future Modules</h2></div>
        <div class="panel-body grid grid-2">
            <?php foreach (future_modules() as $label): ?>
                <article class="module-card">
                    <span class="eyebrow">Future Module</span>
                    <h3><?= e($label) ?></h3>
                    <p>Visible for architecture planning, but intentionally non-operational in the active scope.</p>
                    <span class="locked-label">Locked</span>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php render_footer(); ?>

