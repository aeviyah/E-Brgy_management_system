document.addEventListener('click', function (event) {
    const toggle = event.target.closest('[data-toggle-sidebar]');
    if (toggle) {
        document.body.classList.toggle('sidebar-open');
    }
});

document.addEventListener('change', function (event) {
    const autosubmit = event.target.closest('[data-autosubmit]');
    if (autosubmit && autosubmit.form) {
        autosubmit.form.submit();
    }
});

