<?php

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';

$announcements = [];
$events = [];
$portalNotice = '';

try {
    $announcements = fetch_all(
        "SELECT * FROM service_records
         WHERE module_slug = 'announcements' AND status IN ('Ready for Release', 'Completed', 'Processing')
         ORDER BY due_date DESC, updated_at DESC
         LIMIT 6"
    );
    $events = fetch_all(
        "SELECT * FROM service_records
         WHERE module_slug = 'events' AND status NOT IN ('Cancelled', 'Archived', 'Rejected')
         ORDER BY due_date ASC
         LIMIT 6"
    );
} catch (Throwable $error) {
    $portalNotice = 'Import database/schema.sql in phpMyAdmin to show live announcements and events.';
}

render_header('Public Portal', ['body_class' => 'public-page', 'public' => true]);
?>
<section class="auth-card" style="width:min(100%, 1080px);">
    <p class="eyebrow">Public Barangay Portal</p>
    <h1><?= e(APP_BARANGAY) ?></h1>
    <p>Public information, services, requirements, announcements, events, official records and QR verification. Private resident information is only available after login.</p>
    <?php if ($portalNotice): ?><div class="alert alert-warning"><?= e($portalNotice) ?></div><?php endif; ?>
    <div class="form-actions">
        <a class="btn" href="<?= e(app_url('login.php')) ?>">Login</a>
        <a class="btn btn-ghost" href="<?= e(app_url('register.php')) ?>">Resident Registration</a>
        <a class="btn btn-ghost" href="<?= e(app_url('public/verify.php')) ?>">Verify Document</a>
    </div>
</section>

<section class="grid grid-3" style="width:min(100%, 1080px); margin-top:18px;">
    <article class="module-card">
        <h3>Office Hours</h3>
        <p>Monday to Friday, 8:00 AM to 5:00 PM. Emergency concerns may be reported through the barangay contact desk.</p>
    </article>
    <article class="module-card">
        <h3>Services</h3>
        <p>Barangay clearance, residency, indigency, good moral, business clearance, assistance requests and facility reservations.</p>
    </article>
    <article class="module-card">
        <h3>Emergency Contacts</h3>
        <p>Barangay Hall: 0917-000-0000. Tanod Desk: 0917-111-1111. Email: info@barangay.test.</p>
    </article>
</section>

<section class="grid grid-2" style="width:min(100%, 1080px); margin-top:18px;">
    <div class="panel">
        <div class="panel-header"><h2>Announcements</h2></div>
        <div class="panel-body">
            <ul class="timeline">
                <?php foreach ($announcements as $item): ?>
                    <li><strong><?= e($item['title']) ?></strong><p><?= e($item['description']) ?></p><small><?= e($item['updated_at']) ?></small></li>
                <?php endforeach; ?>
                <?php if (!$announcements): ?><li>No announcements posted.</li><?php endif; ?>
            </ul>
        </div>
    </div>
    <div class="panel">
        <div class="panel-header"><h2>Events</h2></div>
        <div class="panel-body">
            <ul class="timeline">
                <?php foreach ($events as $item): ?>
                    <li><strong><?= e($item['title']) ?></strong><p><?= e($item['description']) ?></p><small><?= e($item['due_date'] ?: $item['updated_at']) ?></small></li>
                <?php endforeach; ?>
                <?php if (!$events): ?><li>No events scheduled.</li><?php endif; ?>
            </ul>
        </div>
    </div>
</section>

<section class="panel" style="width:min(100%, 1080px); margin-top:18px;">
    <div class="panel-header"><h2>Public Requirements & Fees</h2></div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Service</th><th>Typical Requirements</th><th>Fee</th></tr></thead>
            <tbody>
                <tr><td>Barangay Clearance</td><td>Valid ID, resident verification, purpose</td><td>PHP 80.00</td></tr>
                <tr><td>Certificate of Residency</td><td>Valid ID, proof of address</td><td>PHP 50.00</td></tr>
                <tr><td>Certificate of Indigency</td><td>Valid ID, interview or eligibility review</td><td>Free / as assessed</td></tr>
                <tr><td>Business Clearance</td><td>Application, location, business details, assessment</td><td>As assessed</td></tr>
            </tbody>
        </table>
    </div>
</section>
<?php render_footer(); ?>

