<?php

declare(strict_types=1);

date_default_timezone_set('Asia/Manila');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/app.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

