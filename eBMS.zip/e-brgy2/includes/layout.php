<?php

declare(strict_types=1);

function render_header(string $title, array $options = []): void
{
    global $layoutUser;

    $bodyClass = $options['body_class'] ?? '';
    $user = !empty($options['public']) ? null : current_user();
    $layoutUser = $user;
    $unread = $user ? (int) fetch_value('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0', [(int) $user['id']]) : 0;
    ?>
    <!doctype html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= e($title) ?> - <?= e(APP_NAME) ?></title>
        <link rel="stylesheet" href="<?= e(app_url('assets/css/styles.css')) ?>">
    </head>
    <body class="<?= e($bodyClass) ?>">
    <?php if ($user): ?>
        <div class="app-shell">
            <aside class="sidebar" id="sidebar">
                <a class="brand" href="<?= e(app_url('dashboard.php')) ?>">
                    <span class="brand-mark">EB</span>
                    <span>
                        <strong><?= e(APP_BARANGAY) ?></strong>
                        <small>Management System</small>
                    </span>
                </a>
                <nav class="nav">
                    <a class="nav-link" href="<?= e(app_url('dashboard.php')) ?>">Dashboard</a>
                    <?php foreach (group_modules_for_sidebar() as $group => $items): ?>
                        <div class="nav-group"><?= e($group) ?></div>
                        <?php foreach ($items as [$slug, $module]): ?>
                            <a class="nav-link" href="<?= e(app_url(module_url($slug))) ?>"><?= e($module['label']) ?></a>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                    <div class="nav-group">Future Modules</div>
                    <?php foreach (future_modules() as $label): ?>
                        <span class="nav-link locked"><?= e($label) ?><small>Locked</small></span>
                    <?php endforeach; ?>
                </nav>
            </aside>
            <main class="main">
                <header class="topbar">
                    <button class="icon-button" type="button" data-toggle-sidebar aria-label="Toggle menu">Menu</button>
                    <form class="top-search" action="<?= e(app_url('modules/search.php')) ?>" method="get">
                        <input type="search" name="q" placeholder="Search residents, records, payments..." value="<?= e($_GET['q'] ?? '') ?>">
                    </form>
                    <a class="notification-pill" href="<?= e(app_url('dashboard.php#notifications')) ?>">
                        Notifications <span><?= $unread ?></span>
                    </a>
                    <div class="profile-chip">
                        <strong><?= e($user['full_name']) ?></strong>
                        <small><?= e($user['role_name']) ?></small>
                    </div>
                    <a class="btn btn-ghost" href="<?= e(app_url('logout.php')) ?>">Logout</a>
                </header>
                <div class="content">
                    <?php render_flash(); ?>
    <?php else: ?>
        <main class="auth-main">
            <?php render_flash(); ?>
    <?php endif;
}

function render_footer(): void
{
    global $layoutUser;

    $user = $layoutUser ?? current_user();
    ?>
        <?php if ($user): ?>
                </div>
            </main>
        </div>
        <?php else: ?>
        </main>
        <?php endif; ?>
        <script src="<?= e(app_url('assets/js/app.js')) ?>"></script>
    </body>
    </html>
    <?php
}

function render_flash(): void
{
    foreach (flash_messages() as $message) {
        echo '<div class="alert alert-' . e($message['type']) . '">' . e($message['message']) . '</div>';
    }
}

function page_header(string $title, string $description = '', string $actionHtml = ''): void
{
    echo '<section class="page-header">';
    echo '<div><p class="eyebrow">E-Barangay</p><h1>' . e($title) . '</h1>';
    if ($description !== '') {
        echo '<p>' . e($description) . '</p>';
    }
    echo '</div>';
    if ($actionHtml !== '') {
        echo '<div class="page-actions">' . $actionHtml . '</div>';
    }
    echo '</section>';
}

