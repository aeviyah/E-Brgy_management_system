<?php

declare(strict_types=1);

const APP_NAME = 'E-Barangay Management System';
const APP_BARANGAY = 'Barangay Mabuhay';

function app_modules(): array
{
    static $modules = null;

    if ($modules !== null) {
        return $modules;
    }

    $modules = [
        'residents' => [
            'label' => 'Residents',
            'group' => 'Core',
            'description' => 'Resident registration, verification, classifications and profile history.',
            'type' => 'custom',
            'url' => 'modules/residents.php',
            'prefix' => 'RES',
        ],
        'households' => [
            'label' => 'Households',
            'group' => 'Core',
            'description' => 'Household heads, family members, addresses, income and utility information.',
            'type' => 'custom',
            'url' => 'modules/households.php',
            'prefix' => 'HH',
        ],
        'puroks' => [
            'label' => 'Purok / Sitio',
            'group' => 'Core',
            'description' => 'Purok leaders, assigned areas and population summaries.',
            'type' => 'custom',
            'url' => 'modules/puroks.php',
            'prefix' => 'PRK',
        ],
        'documents' => [
            'label' => 'Documents & Certificates',
            'group' => 'Transactions',
            'description' => 'Clearances, certificates, requirements, payment, approval, release and QR verification.',
            'type' => 'records',
            'prefix' => 'DOC',
        ],
        'permits' => [
            'label' => 'Permits & Clearances',
            'group' => 'Transactions',
            'description' => 'Business clearances, permit applications, assessment, approval and release.',
            'type' => 'records',
            'prefix' => 'PER',
        ],
        'services' => [
            'label' => 'Barangay Services',
            'group' => 'Transactions',
            'description' => 'Assistance, facility-related requests, programs and service tracking.',
            'type' => 'records',
            'prefix' => 'SRV',
        ],
        'complaints' => [
            'label' => 'Complaints & Blotter',
            'group' => 'Cases',
            'description' => 'Complaint filing, incident logs, evidence, witnesses, referral and resolution.',
            'type' => 'records',
            'prefix' => 'CB',
        ],
        'katarungang' => [
            'label' => 'Katarungang Pambarangay',
            'group' => 'Cases',
            'description' => 'Case filing, summons, hearings, mediation, settlement and CFA history.',
            'type' => 'records',
            'prefix' => 'KP',
        ],
        'peace_order' => [
            'label' => 'Peace & Order',
            'group' => 'Cases',
            'description' => 'Tanod duty schedules, patrol logs, incidents and peace and order reports.',
            'type' => 'records',
            'prefix' => 'PO',
        ],
        'protection' => [
            'label' => 'BCPC / VAWC Protection',
            'group' => 'Cases',
            'description' => 'Restricted child protection and VAWC case monitoring workflows.',
            'type' => 'records',
            'prefix' => 'PRT',
            'sensitive' => true,
        ],
        'officials' => [
            'label' => 'Officials & Personnel',
            'group' => 'Governance',
            'description' => 'Barangay officials, personnel, terms, signatures and responsibilities.',
            'type' => 'records',
            'prefix' => 'OFC',
        ],
        'budget' => [
            'label' => 'Budget & Disbursement',
            'group' => 'Finance',
            'description' => 'Budget allocation, expenses, vouchers, utilization and financial reporting.',
            'type' => 'records',
            'prefix' => 'BDG',
        ],
        'treasury' => [
            'label' => 'Treasury & Receipts',
            'group' => 'Finance',
            'description' => 'Fees, payments, collections, official receipts and collection reports.',
            'type' => 'custom',
            'url' => 'modules/payments.php',
            'prefix' => 'PAY',
        ],
        'communication' => [
            'label' => 'Communication Center',
            'group' => 'Communication',
            'description' => 'Email, SMS, in-app notifications, recipient groups, templates and delivery history.',
            'type' => 'records',
            'prefix' => 'MSG',
        ],
        'announcements' => [
            'label' => 'Announcements',
            'group' => 'Communication',
            'description' => 'Public notices, audience targeting, publishing, scheduling and history.',
            'type' => 'records',
            'prefix' => 'ANN',
        ],
        'events' => [
            'label' => 'Events & Activities',
            'group' => 'Community',
            'description' => 'Calendar, registration, attendance, participants and activity history.',
            'type' => 'records',
            'prefix' => 'EVT',
        ],
        'assembly_meetings' => [
            'label' => 'Assembly & Meetings',
            'group' => 'Governance',
            'description' => 'Schedules, agenda, attendance, minutes, action items and resolutions.',
            'type' => 'records',
            'prefix' => 'MTG',
        ],
        'official_records' => [
            'label' => 'Ordinances & Resolutions',
            'group' => 'Governance',
            'description' => 'Ordinances, resolutions, memoranda, attachments, search and archive.',
            'type' => 'records',
            'prefix' => 'ORD',
        ],
        'projects' => [
            'label' => 'Barangay Development & Projects',
            'group' => 'Community',
            'description' => 'Development plans, proposals, timelines, progress and accomplishment reports.',
            'type' => 'records',
            'prefix' => 'PRJ',
        ],
        'facilities' => [
            'label' => 'Facilities & Reservations',
            'group' => 'Operations',
            'description' => 'Availability, reservation requests, approval, double-booking prevention and history.',
            'type' => 'records',
            'prefix' => 'FAC',
        ],
        'assets' => [
            'label' => 'Assets & Inventory',
            'group' => 'Operations',
            'description' => 'Properties, equipment, quantity, condition, location, assignment and maintenance.',
            'type' => 'records',
            'prefix' => 'AST',
        ],
        'environment' => [
            'label' => 'Environment & Sanitation',
            'group' => 'Operations',
            'description' => 'Waste schedules, clean-up activities, sanitation concerns and monitoring.',
            'type' => 'records',
            'prefix' => 'ENV',
        ],
        'assistance' => [
            'label' => 'Community Assistance',
            'group' => 'Community',
            'description' => 'Assistance programs, eligibility, beneficiaries, distribution and history.',
            'type' => 'records',
            'prefix' => 'ASTN',
        ],
        'reports' => [
            'label' => 'Reports & Analytics',
            'group' => 'Control',
            'description' => 'Population, requests, cases, collections, projects and printable exports.',
            'type' => 'custom',
            'url' => 'modules/reports.php',
            'prefix' => 'RPT',
        ],
        'search' => [
            'label' => 'Global Search',
            'group' => 'Control',
            'description' => 'Permission-aware search across residents, households, requests, payments and cases.',
            'type' => 'custom',
            'url' => 'modules/search.php',
            'prefix' => 'SRC',
        ],
        'audit' => [
            'label' => 'Audit Trail',
            'group' => 'Control',
            'description' => 'Who, what, when and affected record for official system actions.',
            'type' => 'custom',
            'url' => 'modules/audit.php',
            'prefix' => 'AUD',
        ],
        'settings' => [
            'label' => 'Settings',
            'group' => 'Control',
            'description' => 'Users, roles, permissions, backup reminders and system settings.',
            'type' => 'custom',
            'url' => 'modules/settings.php',
            'prefix' => 'SET',
        ],
    ];

    return $modules;
}

function future_modules(): array
{
    return [
        'sk' => 'SK Management',
        'health' => 'Barangay Health Center',
        'emergency' => 'Emergency & Disaster Response',
        'agriculture' => 'Agriculture',
        'senior_pwd' => 'Dedicated Senior Citizen / PWD Management',
    ];
}

function workflow_statuses(): array
{
    return [
        'Pending',
        'Under Review',
        'For Payment',
        'For Approval',
        'Processing',
        'Ready for Release',
        'Completed',
        'Rejected',
        'Returned for Correction',
        'Cancelled',
        'Archived',
    ];
}

function resident_statuses(): array
{
    return [
        'Pending Verification',
        'Active',
        'Inactive',
        'Transferred',
        'Deceased',
        'Archived',
    ];
}

function payment_statuses(): array
{
    return ['Unpaid', 'Partial', 'Paid', 'Refunded', 'Cancelled'];
}

