# E-Barangay Management System

Functional Programming 3 web application based on the approved E-Barangay Management System scope, workflow, UI/UX blueprint, and beginner-friendly PHP/MySQL stack.

## Stack

- HTML5, CSS3, basic JavaScript
- PHP with sessions, `password_hash()`, `password_verify()`, PDO prepared statements
- MySQL / phpMyAdmin
- XAMPP / Apache

## Setup

1. Copy this folder into `xampp/htdocs`.
2. Open phpMyAdmin and import `database/schema.sql`.
3. Check database credentials in `config/database.php`.
4. Visit `http://localhost/E-BARANGAY%20MANAGEMENT%20SYSTEM%202/`.

If you use PHP's built-in server instead of XAMPP, make sure the `pdo_mysql` extension is enabled. XAMPP normally includes it.

## Demo Accounts

All seeded accounts use password `password`.

- `admin@barangay.test` - System Administrator
- `secretary@barangay.test` - Barangay Secretary
- `treasurer@barangay.test` - Barangay Treasurer
- `captain@barangay.test` - Punong Barangay
- `staff@barangay.test` - Barangay Staff
- `juan@example.com` - Resident

## Implemented Scope

- Authentication, logout, registration, PHP sessions
- Role-based access control and hidden unauthorized actions
- Dashboard with KPIs, quick actions, pending workflow queue, notifications and audit activity
- Resident, household and Purok/Sitio management
- Shared workflow module for documents, permits, services, cases, governance, communication, events, facilities, assets, projects and operations
- Status tracking with timeline history
- Treasury payments, official receipt generation and collections
- Reports, global search, audit trail and user settings
- Public portal and document verification
- Locked future modules for SK, Health Center, Emergency/Disaster and other specialized systems

## Defense Flow

1. Log in as `admin@barangay.test`.
2. Show role-based sidebar and locked future modules.
3. Register or verify a resident.
4. Create a document request and move it through statuses.
5. Record payment and show the generated official receipt.
6. Show reports, global search and audit trail.
7. Log in as a resident to show the simplified resident view.

