document.addEventListener('click', function (event) {
    if (event.target.closest('[data-toggle-sidebar]')) {
        document.body.classList.toggle('sidebar-open');
        return;
    }
    if (document.body.classList.contains('sidebar-open') && !event.target.closest('.sidebar')) {
        document.body.classList.remove('sidebar-open');
    }
    var demo = event.target.closest('[data-demo-email]');
    if (demo) {
        document.getElementById('email').value = demo.dataset.demoEmail;
        document.getElementById('password').value = demo.dataset.demoPassword;
        document.getElementById('password').focus();
    }
});

document.addEventListener('change', function (event) {
    var autosubmit = event.target.closest('[data-autosubmit]');
    if (autosubmit && autosubmit.form) {
        autosubmit.form.submit();
    }
});

document.addEventListener('submit', function (event) {
    var form = event.target;
    if (form.dataset.confirm && !window.confirm(form.dataset.confirm)) {
        event.preventDefault();
    }
});
