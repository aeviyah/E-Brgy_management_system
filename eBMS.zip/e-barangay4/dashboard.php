<?php

require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

require_login();

$user = current_user();
$residentFilter = role_slug() === 'resident' ? ' AND resident_id = ' . (int) current_resident_id() : '';

$stats = [
    'Residents' => (int) fetch_value('SELECT COUNT(*) FROM residents'),
    'Households' => (int) fetch_value('SELECT COUNT(*) FROM households'),
    'Pending Requests' => (int) fetch_value("SELECT COUNT(*) FROM service_records WHERE status IN ('Pending', 'Under Review', 'For Payment', 'For Approval', 'Processing')" . $residentFilter),
    'Open Cases' => (int) fetch_value("SELECT COUNT(*) FROM service_records WHERE module_slug IN ('complaints', 'katarungang', 'protection') AND status NOT IN ('Completed', 'Rejected', 'Cancelled', 'Archived')" . $residentFilter),
    'Today Collections' => (float) fetch_value('SELECT COALESCE(SUM(amount), 0) FROM payments WHERE DATE(paid_at) = CURDATE()'),
    'Active Projects' => (int) fetch_value("SELECT COUNT(*) FROM service_records WHERE module_slug = 'projects' AND status NOT IN ('Completed', 'Archived', 'Cancelled')"),
];

$queueSql = "SELECT service_records.*, residents.first_name, residents.last_name
             FROM service_records
             LEFT JOIN residents ON residents.id = service_records.resident_id
             WHERE status IN ('Pending', 'Under Review', 'For Payment', 'For Approval', 'Processing', 'Ready for Release')";
$queueParams = [];
if (role_slug() === 'resident') {
    $queueSql .= ' AND (service_records.resident_id = ? OR service_records.module_slug IN ("announcements", "events"))';
    $queueParams[] = current_resident_id();
}
$queueSql .= ' ORDER BY service_records.updated_at DESC LIMIT 8';
$queues = fetch_all($queueSql, $queueParams);

$notifications = fetch_all('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 6', [(int) $user['id']]);
$recentAudit = fetch_all('SELECT audit_logs.*, users.full_name FROM audit_logs LEFT JOIN users ON users.id = audit_logs.user_id ORDER BY audit_logs.created_at DESC LIMIT 8');

$isStaff = role_slug() !== 'resident';
$statusCounts = $isStaff ? fetch_all("SELECT status, COUNT(*) AS total FROM service_records GROUP BY status ORDER BY total DESC") : [];
$maxStatus = max(1, ...array_map(fn ($r) => (int) $r['total'], $statusCounts ?: [['total' => 1]]));
$purokCounts = $isStaff ? fetch_all("SELECT COALESCE(puroks.name, 'Unassigned') AS name, COUNT(residents.id) AS total FROM residents LEFT JOIN puroks ON puroks.id = residents.purok_id GROUP BY puroks.name ORDER BY total DESC") : [];
$maxPurok = max(1, ...array_map(fn ($r) => (int) $r['total'], $purokCounts ?: [['total' => 1]]));
$upcoming = fetch_all("SELECT title, due_date, module_slug FROM service_records WHERE module_slug IN ('events','assembly_meetings','facilities') AND due_date >= CURDATE() AND status NOT IN ('Cancelled','Archived','Rejected') ORDER BY due_date ASC LIMIT 5");
$firstName = explode(' ', trim($user['full_name']))[0];
$hour = (int) date('G');
$greeting = $hour < 12 ? 'Magandang umaga' : ($hour < 18 ? 'Magandang hapon' : 'Magandang gabi');

render_header('Dashboard');
?>
<section class="hero">
    <span class="eyebrow"><?= e(APP_BARANGAY) ?> - <?= e($user['role_name']) ?></span>
    <h1><?= e($greeting) ?>, <?= e($firstName) ?>.</h1>
    <p><?= $isStaff ? 'Here is what needs attention in the barangay today: pending requests, open cases, collections and upcoming activities.' : 'Request documents, follow the status of your applications and read the latest barangay announcements.' ?></p>
    <div class="hero-actions">
        <?php if (can_access_module('documents')): ?><a class="btn btn-secondary" href="<?= e(app_url('modules/records.php?module=documents')) ?>"><?= icon('file') ?><?= $isStaff ? 'Process documents' : 'Request a document' ?></a><?php endif; ?>
        <a class="btn btn-ghost" href="#notifications"><?= icon('bell') ?>Notifications</a>
    </div>
</section>

<?php if ($isStaff): ?>
<section class="grid grid-3">
    <?php $metricIcons = ['users', 'home', 'file', 'alert', 'receipt', 'trending']; $i = 0; foreach ($stats as $label => $value): ?>
        <article class="metric-card">
            <span class="metric-icon"><?= icon($metricIcons[$i++ % 6]) ?></span>
            <span><?= e($label) ?></span>
            <strong><?= $label === 'Today Collections' ? e(peso($value)) : e((string) $value) ?></strong>
        </article>
    <?php endforeach; ?>
</section>
<?php endif; ?>

<section class="panel">
    <div class="panel-header"><h2>Quick actions</h2><span class="muted">Only actions allowed for your role are shown.</span></div>
    <div class="panel-body quick-grid">
        <?php foreach ([
            ['residents', 'modules/residents.php', 'users', 'Register resident'],
            ['documents', 'modules/records.php?module=documents', 'file', $isStaff ? 'Process document' : 'Request document'],
            ['services', 'modules/records.php?module=services', 'heart', $isStaff ? 'Review services' : 'Request a service'],
            ['treasury', 'modules/payments.php', 'receipt', 'Record payment'],
            ['complaints', 'modules/records.php?module=complaints', 'alert', $isStaff ? 'File / review case' : 'File a complaint'],
            ['announcements', 'modules/records.php?module=announcements', 'megaphone', $isStaff ? 'Create announcement' : 'Announcements'],
        ] as [$slug, $href, $ico, $label]): if (!can_access_module($slug)) { continue; } ?>
            <a class="quick-tile" href="<?= e(app_url($href)) ?>"><span class="tile-icon"><?= icon($ico) ?></span><?= e($label) ?></a>
        <?php endforeach; ?>
    </div>
</section>

<section class="grid grid-2">
    <div class="panel">
        <div class="panel-header"><h2><?= $isStaff ? 'Needs attention' : 'My requests' ?></h2><a href="<?= e(app_url('modules/records.php?module=documents')) ?>">Open records</a></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Reference</th><th>Module</th><th>Status</th><th>Due</th></tr></thead>
                <tbody>
                <?php foreach ($queues as $row): ?>
                    <tr>
                        <td><a class="record-title" href="<?= e(app_url('modules/records.php?module=' . urlencode($row['module_slug']) . '&id=' . (int) $row['id'])) ?>"><strong><?= e($row['reference_no']) ?></strong><small><?= e($row['title']) ?></small></a></td>
                        <td><?= e(module_meta($row['module_slug'])['label'] ?? $row['module_slug']) ?></td>
                        <td><span class="<?= e(status_class($row['status'])) ?>"><?= e($row['status']) ?></span></td>
                        <td><?= e($row['due_date'] ?: 'Not set') ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$queues): ?><tr><td colspan="4">Nothing pending. Magaling!</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="panel" id="notifications">
        <div class="panel-header"><h2>Notifications</h2><span class="muted">In-app</span></div>
        <div class="panel-body">
            <ul class="timeline">
                <?php foreach ($notifications as $notice): ?>
                    <li><strong><?= e($notice['title']) ?></strong><p><?= e($notice['message']) ?></p><small><?= e($notice['created_at']) ?></small></li>
                <?php endforeach; ?>
                <?php if (!$notifications): ?><li><strong>You are all caught up</strong><p>New updates about your requests will show here.</p></li><?php endif; ?>
            </ul>
        </div>
    </div>
</section>

<?php if ($isStaff): ?>
<section class="grid grid-3">
    <div class="panel">
        <div class="panel-header"><h2>Requests by status</h2></div>
        <div class="panel-body">
            <?php foreach ($statusCounts as $row): ?>
                <div class="bar-row"><span><?= e($row['status']) ?></span><div class="bar-track"><div class="bar-fill" style="width:<?= (int) round($row['total'] / $maxStatus * 100) ?>%"></div></div><b><?= (int) $row['total'] ?></b></div>
            <?php endforeach; ?>
            <?php if (!$statusCounts): ?><p class="muted">No records yet.</p><?php endif; ?>
        </div>
    </div>
    <div class="panel">
        <div class="panel-header"><h2>Residents per Purok</h2></div>
        <div class="panel-body">
            <?php foreach ($purokCounts as $row): ?>
                <div class="bar-row"><span><?= e($row['name']) ?></span><div class="bar-track"><div class="bar-fill" style="width:<?= (int) round($row['total'] / $maxPurok * 100) ?>%"></div></div><b><?= (int) $row['total'] ?></b></div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="panel">
        <div class="panel-header"><h2>Upcoming</h2></div>
        <div class="panel-body">
            <ul class="timeline">
                <?php foreach ($upcoming as $item): ?>
                    <li><strong><?= e($item['title']) ?></strong><small><?= e(date('M j, Y', strtotime($item['due_date']))) ?> - <?= e(module_meta($item['module_slug'])['label'] ?? '') ?></small></li>
                <?php endforeach; ?>
                <?php if (!$upcoming): ?><li><strong>No upcoming events</strong></li><?php endif; ?>
            </ul>
        </div>
    </div>
</section>

<section class="panel">
    <div class="panel-header"><h2>Modules</h2><span class="muted">Mapped to the approved master scope</span></div>
    <div class="panel-body grid grid-3">
        <?php foreach (app_modules() as $slug => $module): if (!can_access_module($slug)) { continue; } ?>
            <article class="module-card">
                <span class="module-icon"><?= module_icon($slug) ?></span>
                <h3><?= e($module['label']) ?></h3>
                <p><?= e($module['description']) ?></p>
                <a class="btn btn-ghost" href="<?= e(app_url(module_url($slug))) ?>">Open</a>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<section class="grid grid-2">
    <div class="panel">
        <div class="panel-header"><h2>Recent activity</h2></div>
        <div class="panel-body">
            <ul class="timeline">
                <?php foreach ($recentAudit as $activity): ?>
                    <li><strong><?= e($activity['action']) ?></strong><p><?= e($activity['details']) ?></p><small><?= e($activity['full_name'] ?? 'System') ?> - <?= e($activity['created_at']) ?></small></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <div class="panel">
        <div class="panel-header"><h2>Future modules</h2></div>
        <div class="panel-body grid grid-2">
            <?php foreach (future_modules() as $label): ?>
                <article class="module-card is-locked">
                    <span class="locked-label"><?= icon('lock') ?>Future module</span>
                    <h3><?= e($label) ?></h3>
                    <p>Planned for a later release. Not active in this scope.</p>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>
<?php render_footer(); ?>
