# E-Barangay Management System — Phase 2 Core Transactions

Built from the provided Programming 3 instructions and final scope/process/UI/UX blueprint.

## Phase 1 Foundation
- Authentication/session/roles
- Dashboard
- Residents CRUD + archive
- Households CRUD
- Purok/Sitio CRUD
- Activity log foundation

## Phase 2 Core Transactions
- Documents: catalog, request creation, search/filter, workflow status, fee handling
- Permits: business application, assessment, review/approval/rejection/release workflow
- Services: catalog, request creation, tracking/status workflow
- Treasury: payments, transaction records, official receipt generation, printable receipt

## Setup
1. Extract/copy to `C:\xampp\htdocs\e-barangay\`.
2. Start Apache and MySQL in XAMPP.
3. Import `database.sql` into phpMyAdmin. For an existing Phase 1 database, import the additional CREATE/INSERT statements from the Phase 2 section or recreate the database from the full script.
4. Open `http://localhost/e-barangay/`.
5. Demo administrator: `admin` / `admin123`.

## Role controls
- System Administrator: full Phase 2 management.
- Punong Barangay: review/approval and treasury access.
- Barangay Secretary/Staff: document, permit, and service processing.
- Barangay Treasurer: treasury/payment/OR processing.
- Resident: can be used as a role for future resident-facing portal refinement; staff-side Phase 2 screens are protected according to the workflow.

## Scope discipline
Locked/future modules remain non-operational: SK Management, Health Center, Emergency & Disaster Response, Agriculture, dedicated Senior Citizen/PWD modules, and other specialized future modules.

## Phase 3 — Governance & Cases

Phase 3 adds the governance/case-management layer:
- Complaints and case records
- Blotter workflow
- Katarungang Pambarangay workflow
- Peace & Order records
- BCPC records
- VAWC records with restricted access
- Case status workflow and timeline events
- Barangay officials roster
- Dashboard open-case KPI

### Phase 3 migration
For an existing Phase 1/Phase 2 installation, import `phase3_migration.sql` in phpMyAdmin. For a fresh installation, the tables are already included in `database.sql`.

### Sensitive case access
VAWC records are restricted to `Punong Barangay` and `System Administrator`. Other case types are available to authorized governance staff roles. Unauthorized access returns HTTP 403.


## Phase 4 — Communication & Community

Added modules:
- Announcements with audience targeting, publish/expiry dates, and resident visibility rules
- Community Events
- Meetings with agenda/minutes
- Ordinances & Community Records
- Communication Center for in-app/email/SMS workflow records
- Dashboard KPIs for published announcements, upcoming events, and scheduled meetings

For an existing Phase 3 installation, import `phase4_migration.sql` in phpMyAdmin. For a fresh installation, use the updated `database.sql`.

Note: Email/SMS entries are tracked as communication workflow records. Actual external delivery requires a configured email/SMS gateway; the application does not pretend that an external message was delivered when no gateway is connected.


## Phase 5 — Operations
Implemented operational modules:
- Projects
- Facilities & Reservations
- Assets & Inventory
- Assistance Requests
- Environment & Cleanliness

For an existing Phase 4 installation, import `phase5_migration.sql` after the previous migrations.

## Phase 6 — Reporting & Control
- Reports & Analytics: database-backed operational summaries and collection/assistance totals.
- Global Search: cross-module search across active resident and transaction records.
- Audit Trail: restricted activity review for Punong Barangay/System Administrator.
- Backup & Data Management: System Administrator SQL backup export.
- Settings: account information and secure password change.
- Phase 6 requires no new tables; `phase6_migration.sql` documents the upgrade.

## Phase 7 — Public Portal
- Public barangay information portal at `http://localhost/e-barangay/` when not logged in.
- Public announcements, upcoming events, active officials, service/document catalog, approved ordinances/resolutions, and configured emergency/public contacts.
- Public request tracking using transaction reference + applicant last name.
- Public verification for completed documents/services and released permits.
- Resident registration creates a Resident account and a `Pending Verification` resident record for barangay approval.
- Public/emergency contacts are managed by Punong Barangay/System Administrator.
- Sensitive cases, audit functions, and staff-only transaction management are not exposed through the public portal.
- `phase7_migration.sql` adds the `public_contacts` table for existing Phase 6 installations.
