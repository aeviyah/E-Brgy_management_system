<?php require 'auth.php'; if(user()){header('Location: dashboard.php');}else{header('Location: portal/index.php');} exit;
