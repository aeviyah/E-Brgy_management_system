<?php
require '../config/database.php'; require '../auth.php'; require_role(['System Administrator','Punong Barangay']);
$title='Audit Trail'; $base='../'; $q=trim($_GET['q']??''); $where='1=1'; $params=[]; if($q!==''){$where='(a.action LIKE ? OR a.description LIKE ? OR a.affected_record LIKE ? OR u.full_name LIKE ?)';$like='%'.$q.'%';$params=[$like,$like,$like,$like];}
$s=$pdo->prepare("SELECT a.*,u.full_name FROM activity_logs a LEFT JOIN users u ON u.id=a.user_id WHERE $where ORDER BY a.id DESC LIMIT 300");$s->execute($params);$logs=$s->fetchAll();
require '../includes/header.php'; ?>
<div class="page-head"><div><h1>Audit Trail</h1><p class="muted">Review recorded user and system actions. Access is restricted to management roles.</p></div></div>
<div class="card"><form class="filters"><input name="q" value="<?=h($q)?>" placeholder="Search action, description, record, user"><button class="btn primary">Filter</button></form></div><br>
<div class="card"><div class="table-wrap"><table class="table"><tr><th>Date</th><th>User</th><th>Action</th><th>Description</th><th>Affected Record</th></tr><?php foreach($logs as $l): ?><tr><td><?=h($l['created_at'])?></td><td><?=h($l['full_name']??'System')?></td><td><span class="badge"><?=h($l['action'])?></span></td><td><?=h($l['description'])?></td><td><?=h($l['affected_record'])?></td></tr><?php endforeach; if(!$logs): ?><tr><td colspan="5" class="muted">No audit records found.</td></tr><?php endif; ?></table></div></div>
<?php require '../includes/footer.php'; ?>
