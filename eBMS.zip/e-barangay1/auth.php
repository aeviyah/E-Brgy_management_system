<?php
session_start();
function require_login(){ if(empty($_SESSION['user'])){ header('Location: /e-barangay/login.php'); exit; } }
function user(){ return $_SESSION['user'] ?? null; }
function require_role($roles){ require_login(); $roles=(array)$roles; if(!in_array($_SESSION['user']['role'],$roles,true)){ http_response_code(403); exit('Access denied.'); } }
function resident_profile(){ if(!user() || user()['role']!=='Resident') return null; static $r=false; if($r!==false) return $r; require __DIR__.'/config/database.php'; $s=$pdo->prepare('SELECT * FROM residents WHERE user_id=? LIMIT 1'); $s->execute([user()['id']]); $r=$s->fetch() ?: null; return $r; }
function require_active_resident(){ require_login(); if(user()['role']==='Resident'){ $r=resident_profile(); if(!$r || $r['residency_status']!=='Active'){ http_response_code(403); exit('Resident account is pending verification or is not active.'); } return $r; } return null; }
function h($v){ return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function log_action($action,$description='',$affected=''){ require __DIR__.'/config/database.php'; $s=$pdo->prepare('INSERT INTO activity_logs(user_id,action,description,affected_record) VALUES(?,?,?,?)'); $s->execute([$_SESSION['user']['id']??null,$action,$description,$affected]); }
?>
