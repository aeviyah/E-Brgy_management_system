-- E-Barangay Management System - Phase 4 Migration
-- Communication & Community

CREATE TABLE IF NOT EXISTS announcements (
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(200) NOT NULL,
 body TEXT NOT NULL,
 audience ENUM('All Residents','Purok','Officials & Staff','Specific Resident') DEFAULT 'All Residents',
 purok_id INT NULL,
 resident_id INT NULL,
 publish_date DATETIME NULL,
 expiry_date DATETIME NULL,
 status ENUM('Draft','Published','Archived') DEFAULT 'Draft',
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (purok_id) REFERENCES puroks(id) ON DELETE SET NULL,
 FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS community_events (
 id INT AUTO_INCREMENT PRIMARY KEY,
 event_no VARCHAR(50) NOT NULL UNIQUE,
 title VARCHAR(200) NOT NULL,
 description TEXT,
 event_date DATETIME NOT NULL,
 end_date DATETIME NULL,
 venue VARCHAR(200),
 audience ENUM('All Residents','Purok','Officials & Staff') DEFAULT 'All Residents',
 purok_id INT NULL,
 status ENUM('Planned','Ongoing','Completed','Cancelled') DEFAULT 'Planned',
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (purok_id) REFERENCES puroks(id) ON DELETE SET NULL,
 FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS meetings (
 id INT AUTO_INCREMENT PRIMARY KEY,
 meeting_no VARCHAR(50) NOT NULL UNIQUE,
 title VARCHAR(200) NOT NULL,
 meeting_type ENUM('Barangay Council','Committee','Barangay Assembly','Special Meeting','Other') DEFAULT 'Barangay Council',
 meeting_date DATETIME NOT NULL,
 venue VARCHAR(200),
 agenda TEXT,
 minutes TEXT,
 status ENUM('Scheduled','Held','Cancelled') DEFAULT 'Scheduled',
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS community_records (
 id INT AUTO_INCREMENT PRIMARY KEY,
 record_no VARCHAR(50) NOT NULL UNIQUE,
 record_type ENUM('Ordinance','Resolution','Assembly Record','Meeting Minutes','Other') NOT NULL,
 title VARCHAR(200) NOT NULL,
 reference_no VARCHAR(100),
 record_date DATE NULL,
 description TEXT,
 file_path VARCHAR(255),
 status ENUM('Draft','Approved','Archived') DEFAULT 'Draft',
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS communications (
 id INT AUTO_INCREMENT PRIMARY KEY,
 communication_no VARCHAR(50) NOT NULL UNIQUE,
 channel ENUM('In-App','Email','SMS') NOT NULL,
 recipient_type ENUM('All Residents','Purok','Specific Resident','Officials & Staff') NOT NULL,
 purok_id INT NULL,
 resident_id INT NULL,
 subject VARCHAR(200),
 message TEXT NOT NULL,
 status ENUM('Draft','Scheduled','Sent','Failed','Cancelled') DEFAULT 'Draft',
 scheduled_at DATETIME NULL,
 sent_at DATETIME NULL,
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (purok_id) REFERENCES puroks(id) ON DELETE SET NULL,
 FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
