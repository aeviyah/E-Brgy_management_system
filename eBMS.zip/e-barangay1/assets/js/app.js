document.addEventListener('click', function (event) {
  var toggle = event.target.closest('[data-sidebar-toggle]');
  if (toggle) {
    var sidebar = document.getElementById('sidebar');
    if (sidebar) {
      sidebar.classList.toggle('open');
    }
  }

  var confirmButton = event.target.closest('[data-confirm]');
  if (confirmButton) {
    var message = confirmButton.getAttribute('data-confirm') || 'Continue?';
    if (!window.confirm(message)) {
      event.preventDefault();
    }
  }
});
