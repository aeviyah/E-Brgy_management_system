<?php
require '../config/database.php'; require '../auth.php';
require_role(['Barangay Secretary','Barangay Staff','Punong Barangay','System Administrator']);
$title='Complaints & Cases'; $base='../';
$type=$_GET['type']??''; $status=$_GET['status']??''; $q=trim($_GET['q']??'');
$where=[];$params=[];
if($type!==''){ $where[]='c.case_type=?';$params[]=$type; }
if($status!==''){ $where[]='c.status=?';$params[]=$status; }
if($q!==''){ $where[]='(c.case_no LIKE ? OR c.subject LIKE ? OR r1.full_name LIKE ? OR r2.full_name LIKE ?)';$like="%$q%";array_push($params,$like,$like,$like,$like);}
$role=user()['role'];
if($role!=='Punong Barangay' && $role!=='System Administrator') $where[]="c.case_type<>'VAWC'";
$sql='SELECT c.*,r1.full_name complainant_name,r2.full_name respondent_name FROM case_records c LEFT JOIN residents r1 ON r1.id=c.complainant_id LEFT JOIN residents r2 ON r2.id=c.respondent_id'.($where?' WHERE '.implode(' AND ',$where):'').' ORDER BY c.id DESC';
$s=$pdo->prepare($sql);$s->execute($params);$rows=$s->fetchAll();
require '../includes/header.php'; ?>
<div class="page-head"><div><h1>Complaints & Cases</h1><p class="muted">Complaints, blotter, Katarungang Pambarangay, Peace & Order, BCPC and restricted VAWC case workflows.</p></div><a class="btn primary" href="form.php">New Case</a></div>
<div class="card"><form class="filters"><input name="q" placeholder="Search case no., subject, complainant..." value="<?=h($q)?>"><select name="type"><option value="">All types</option><?php foreach(['Complaint','Blotter','Katarungang Pambarangay','Peace & Order','BCPC','VAWC'] as $x): if($x==='VAWC' && !in_array($role,['Punong Barangay','System Administrator'],true)) continue; ?><option <?= $type===$x?'selected':''?>><?=h($x)?></option><?php endforeach;?></select><select name="status"><option value="">All statuses</option><?php foreach(['Received','Under Review','For Mediation','Hearing Scheduled','Resolved','Dismissed','Referred','Closed'] as $x):?><option <?= $status===$x?'selected':''?>><?=h($x)?></option><?php endforeach;?></select><button class="btn secondary">Filter</button><a class="btn" href="index.php">Reset</a></form></div><br>
<div class="card"><div class="table-wrap"><table class="table"><tr><th>Case No.</th><th>Type</th><th>Subject</th><th>Parties</th><th>Status</th><th>Filed</th><th></th></tr><?php foreach($rows as $r):?><tr><td><?=h($r['case_no'])?></td><td><?=h($r['case_type'])?><?php if($r['case_type']==='VAWC'):?> <span class="badge">Restricted</span><?php endif;?></td><td><?=h($r['subject'])?></td><td><?=h($r['complainant_name']??'N/A')?> → <?=h($r['respondent_name']??'N/A')?></td><td><span class="badge"><?=h($r['status'])?></span></td><td><?=h($r['created_at'])?></td><td><a class="btn small" href="view.php?id=<?=$r['id']?>">View</a></td></tr><?php endforeach;if(!$rows):?><tr><td colspan="7" class="muted">No case records found.</td></tr><?php endif;?></table></div></div>
<?php require '../includes/footer.php'; ?>
