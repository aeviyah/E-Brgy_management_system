CREATE TABLE IF NOT EXISTS case_records (
 id INT AUTO_INCREMENT PRIMARY KEY,
 case_no VARCHAR(50) NOT NULL UNIQUE,
 case_type ENUM('Complaint','Blotter','Katarungang Pambarangay','Peace & Order','BCPC','VAWC') NOT NULL,
 complainant_id INT NULL,
 respondent_id INT NULL,
 subject VARCHAR(255) NOT NULL,
 incident_date DATE NULL,
 incident_location VARCHAR(255),
 narrative TEXT NOT NULL,
 status ENUM('Received','Under Review','For Mediation','Hearing Scheduled','Resolved','Dismissed','Referred','Closed') DEFAULT 'Received',
 sensitivity ENUM('Normal','Sensitive') DEFAULT 'Normal',
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (complainant_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY (respondent_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS case_events (
 id INT AUTO_INCREMENT PRIMARY KEY,
 case_id INT NOT NULL,
 event_type VARCHAR(100) NOT NULL,
 event_date DATETIME DEFAULT CURRENT_TIMESTAMP,
 notes TEXT,
 created_by INT NULL,
 FOREIGN KEY (case_id) REFERENCES case_records(id) ON DELETE CASCADE,
 FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS barangay_officials (
 id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(180) NOT NULL,
 position VARCHAR(100) NOT NULL,
 committee VARCHAR(150),
 term_start DATE NULL,
 term_end DATE NULL,
 contact_no VARCHAR(50),
 status ENUM('Active','Inactive') DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
