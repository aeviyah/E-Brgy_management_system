CREATE DATABASE IF NOT EXISTS e_barangay CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE e_barangay;
CREATE TABLE users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 full_name VARCHAR(150) NOT NULL,
 role ENUM('Resident','Barangay Secretary','Barangay Treasurer','Punong Barangay','Barangay Staff','System Administrator') NOT NULL,
 status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE puroks (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL UNIQUE,
 leader VARCHAR(150),
 assigned_area VARCHAR(255),
 description TEXT,
 status ENUM('Active','Inactive') DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE households (
 id INT AUTO_INCREMENT PRIMARY KEY,
 household_number VARCHAR(50) NOT NULL UNIQUE,
 household_head_id INT NULL,
 address VARCHAR(255) NOT NULL,
 purok_id INT NULL,
 household_classification VARCHAR(100),
 income_bracket VARCHAR(100),
 housing_info VARCHAR(255),
 utility_info VARCHAR(255),
 status ENUM('Active','Inactive','Archived') DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (purok_id) REFERENCES puroks(id) ON DELETE SET NULL
);
CREATE TABLE residents (
 id INT AUTO_INCREMENT PRIMARY KEY,
 resident_no VARCHAR(50) NOT NULL UNIQUE,
 user_id INT NULL,
 household_id INT NULL,
 first_name VARCHAR(80) NOT NULL,
 middle_name VARCHAR(80),
 last_name VARCHAR(80) NOT NULL,
 birthdate DATE,
 sex ENUM('Male','Female','Other') NULL,
 civil_status VARCHAR(50),
 contact_number VARCHAR(30),
 email VARCHAR(150),
 address VARCHAR(255),
 purok_id INT NULL,
 occupation VARCHAR(100),
 residency_status ENUM('Pending Verification','Active','Inactive','Transferred','Deceased','Archived') DEFAULT 'Pending Verification',
 is_senior TINYINT(1) DEFAULT 0,
 is_pwd TINYINT(1) DEFAULT 0,
 is_solo_parent TINYINT(1) DEFAULT 0,
 is_4ps TINYINT(1) DEFAULT 0,
 is_minor TINYINT(1) DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
 FOREIGN KEY (household_id) REFERENCES households(id) ON DELETE SET NULL,
 FOREIGN KEY (purok_id) REFERENCES puroks(id) ON DELETE SET NULL
);
ALTER TABLE households ADD CONSTRAINT fk_household_head FOREIGN KEY (household_head_id) REFERENCES residents(id) ON DELETE SET NULL;
CREATE TABLE activity_logs (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NULL,
 action VARCHAR(100) NOT NULL,
 description TEXT,
 affected_record VARCHAR(100),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);
INSERT INTO users(username,password,full_name,role) VALUES
('admin', '$2y$12$UvwNqOBiH2ZYSse9UMjoC.FmZ1lNQ5BYEw5PK9.jgpZjTNbBT8x/S', 'System Administrator', 'System Administrator');
INSERT INTO puroks(name,leader,assigned_area,description) VALUES ('Purok 1','Sample Leader','Area 1','Initial sample record');

CREATE TABLE document_types (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(150) NOT NULL,
 description TEXT,
 fee DECIMAL(10,2) NOT NULL DEFAULT 0,
 requirements TEXT,
 status ENUM('Active','Inactive') DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE document_requests (
 id INT AUTO_INCREMENT PRIMARY KEY,
 request_no VARCHAR(50) NOT NULL UNIQUE,
 resident_id INT NOT NULL,
 document_type_id INT NOT NULL,
 purpose VARCHAR(255) NOT NULL,
 remarks TEXT,
 status ENUM('Pending','Under Review','Approved','Rejected','Processing','Completed','Cancelled') DEFAULT 'Pending',
 requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 reviewed_by INT NULL,
 reviewed_at DATETIME NULL,
 completed_at DATETIME NULL,
 FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE RESTRICT,
 FOREIGN KEY (document_type_id) REFERENCES document_types(id) ON DELETE RESTRICT,
 FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE permit_applications (
 id INT AUTO_INCREMENT PRIMARY KEY,
 application_no VARCHAR(50) NOT NULL UNIQUE,
 resident_id INT NULL,
 business_name VARCHAR(180) NOT NULL,
 business_address VARCHAR(255) NOT NULL,
 business_type VARCHAR(120) NOT NULL,
 applicant_contact VARCHAR(50),
 purpose VARCHAR(255),
 assessment_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
 status ENUM('Pending','Under Review','For Assessment','Approved','Rejected','Released') DEFAULT 'Pending',
 remarks TEXT,
 applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 reviewed_by INT NULL,
 reviewed_at DATETIME NULL,
 FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE service_catalog (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(150) NOT NULL,
 description TEXT,
 fee DECIMAL(10,2) NOT NULL DEFAULT 0,
 processing_days INT NOT NULL DEFAULT 3,
 status ENUM('Active','Inactive') DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE service_requests (
 id INT AUTO_INCREMENT PRIMARY KEY,
 request_no VARCHAR(50) NOT NULL UNIQUE,
 resident_id INT NOT NULL,
 service_id INT NOT NULL,
 purpose VARCHAR(255) NOT NULL,
 details TEXT,
 status ENUM('Pending','Under Review','Approved','Processing','Completed','Rejected','Cancelled') DEFAULT 'Pending',
 requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 reviewed_by INT NULL,
 reviewed_at DATETIME NULL,
 completed_at DATETIME NULL,
 FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE RESTRICT,
 FOREIGN KEY (service_id) REFERENCES service_catalog(id) ON DELETE RESTRICT,
 FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE payments (
 id INT AUTO_INCREMENT PRIMARY KEY,
 transaction_no VARCHAR(50) NOT NULL UNIQUE,
 resident_id INT NULL,
 document_request_id INT NULL,
 permit_id INT NULL,
 service_request_id INT NULL,
 amount DECIMAL(10,2) NOT NULL,
 payment_method ENUM('Cash','GCash','Bank Transfer','Other') DEFAULT 'Cash',
 payment_status ENUM('Paid','Voided') DEFAULT 'Paid',
 paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 received_by INT NULL,
 remarks TEXT,
 FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY (document_request_id) REFERENCES document_requests(id) ON DELETE SET NULL,
 FOREIGN KEY (permit_id) REFERENCES permit_applications(id) ON DELETE SET NULL,
 FOREIGN KEY (service_request_id) REFERENCES service_requests(id) ON DELETE SET NULL,
 FOREIGN KEY (received_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE official_receipts (
 id INT AUTO_INCREMENT PRIMARY KEY,
 or_no VARCHAR(50) NOT NULL UNIQUE,
 payment_id INT NOT NULL UNIQUE,
 issued_by INT NULL,
 issued_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE RESTRICT,
 FOREIGN KEY (issued_by) REFERENCES users(id) ON DELETE SET NULL
);

INSERT INTO document_types(name,description,fee,requirements) VALUES
('Barangay Certificate of Residency','Certification confirming barangay residency.',50,'Valid ID; proof of residency if required'),
('Barangay Clearance','General barangay clearance for official purposes.',50,'Valid ID; purpose of request'),
('Certificate of Indigency','Certification for qualified residents needing proof of indigency.',0,'Valid ID; supporting document if applicable');
INSERT INTO service_catalog(name,description,fee,processing_days) VALUES
('Barangay Assistance Request','Request for available barangay assistance subject to assessment.',0,5),
('Community Certification Assistance','Assistance with preparation and verification of barangay certifications.',0,3),
('Referral Request','Request for a barangay referral for an external agency or service.',0,3);

CREATE TABLE IF NOT EXISTS case_records (
 id INT AUTO_INCREMENT PRIMARY KEY,
 case_no VARCHAR(50) NOT NULL UNIQUE,
 case_type ENUM('Complaint','Blotter','Katarungang Pambarangay','Peace & Order','BCPC','VAWC') NOT NULL,
 complainant_id INT NULL,
 respondent_id INT NULL,
 subject VARCHAR(255) NOT NULL,
 incident_date DATE NULL,
 incident_location VARCHAR(255),
 narrative TEXT NOT NULL,
 status ENUM('Received','Under Review','For Mediation','Hearing Scheduled','Resolved','Dismissed','Referred','Closed') DEFAULT 'Received',
 sensitivity ENUM('Normal','Sensitive') DEFAULT 'Normal',
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (complainant_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY (respondent_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS case_events (
 id INT AUTO_INCREMENT PRIMARY KEY,
 case_id INT NOT NULL,
 event_type VARCHAR(100) NOT NULL,
 event_date DATETIME DEFAULT CURRENT_TIMESTAMP,
 notes TEXT,
 created_by INT NULL,
 FOREIGN KEY (case_id) REFERENCES case_records(id) ON DELETE CASCADE,
 FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS barangay_officials (
 id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(180) NOT NULL,
 position VARCHAR(100) NOT NULL,
 committee VARCHAR(150),
 term_start DATE NULL,
 term_end DATE NULL,
 contact_no VARCHAR(50),
 status ENUM('Active','Inactive') DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS announcements (
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(200) NOT NULL,
 body TEXT NOT NULL,
 audience ENUM('All Residents','Purok','Officials & Staff','Specific Resident') DEFAULT 'All Residents',
 purok_id INT NULL,
 resident_id INT NULL,
 publish_date DATETIME NULL,
 expiry_date DATETIME NULL,
 status ENUM('Draft','Published','Archived') DEFAULT 'Draft',
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (purok_id) REFERENCES puroks(id) ON DELETE SET NULL,
 FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS community_events (
 id INT AUTO_INCREMENT PRIMARY KEY,
 event_no VARCHAR(50) NOT NULL UNIQUE,
 title VARCHAR(200) NOT NULL,
 description TEXT,
 event_date DATETIME NOT NULL,
 end_date DATETIME NULL,
 venue VARCHAR(200),
 audience ENUM('All Residents','Purok','Officials & Staff') DEFAULT 'All Residents',
 purok_id INT NULL,
 status ENUM('Planned','Ongoing','Completed','Cancelled') DEFAULT 'Planned',
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (purok_id) REFERENCES puroks(id) ON DELETE SET NULL,
 FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS meetings (
 id INT AUTO_INCREMENT PRIMARY KEY,
 meeting_no VARCHAR(50) NOT NULL UNIQUE,
 title VARCHAR(200) NOT NULL,
 meeting_type ENUM('Barangay Council','Committee','Barangay Assembly','Special Meeting','Other') DEFAULT 'Barangay Council',
 meeting_date DATETIME NOT NULL,
 venue VARCHAR(200),
 agenda TEXT,
 minutes TEXT,
 status ENUM('Scheduled','Held','Cancelled') DEFAULT 'Scheduled',
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS community_records (
 id INT AUTO_INCREMENT PRIMARY KEY,
 record_no VARCHAR(50) NOT NULL UNIQUE,
 record_type ENUM('Ordinance','Resolution','Assembly Record','Meeting Minutes','Other') NOT NULL,
 title VARCHAR(200) NOT NULL,
 reference_no VARCHAR(100),
 record_date DATE NULL,
 description TEXT,
 file_path VARCHAR(255),
 status ENUM('Draft','Approved','Archived') DEFAULT 'Draft',
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS communications (
 id INT AUTO_INCREMENT PRIMARY KEY,
 communication_no VARCHAR(50) NOT NULL UNIQUE,
 channel ENUM('In-App','Email','SMS') NOT NULL,
 recipient_type ENUM('All Residents','Purok','Specific Resident','Officials & Staff') NOT NULL,
 purok_id INT NULL,
 resident_id INT NULL,
 subject VARCHAR(200),
 message TEXT NOT NULL,
 status ENUM('Draft','Scheduled','Sent','Failed','Cancelled') DEFAULT 'Draft',
 scheduled_at DATETIME NULL,
 sent_at DATETIME NULL,
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (purok_id) REFERENCES puroks(id) ON DELETE SET NULL,
 FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS projects (
 id INT AUTO_INCREMENT PRIMARY KEY,
 project_no VARCHAR(50) NOT NULL UNIQUE,
 title VARCHAR(200) NOT NULL,
 description TEXT,
 project_type VARCHAR(100),
 location VARCHAR(200),
 start_date DATE NULL,
 target_date DATE NULL,
 budget DECIMAL(12,2) DEFAULT 0,
 funding_source VARCHAR(150),
 status ENUM('Planned','Ongoing','Completed','Suspended','Cancelled') DEFAULT 'Planned',
 progress_percent TINYINT UNSIGNED DEFAULT 0,
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS facilities (
 id INT AUTO_INCREMENT PRIMARY KEY,
 facility_no VARCHAR(50) NOT NULL UNIQUE,
 name VARCHAR(200) NOT NULL,
 facility_type VARCHAR(100),
 location VARCHAR(200),
 capacity INT DEFAULT 0,
 status ENUM('Available','Maintenance','Inactive') DEFAULT 'Available',
 description TEXT,
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS facility_reservations (
 id INT AUTO_INCREMENT PRIMARY KEY,
 reservation_no VARCHAR(50) NOT NULL UNIQUE,
 facility_id INT NOT NULL,
 resident_id INT NULL,
 purpose VARCHAR(255) NOT NULL,
 start_datetime DATETIME NOT NULL,
 end_datetime DATETIME NOT NULL,
 status ENUM('Pending','Approved','Rejected','Completed','Cancelled') DEFAULT 'Pending',
 notes TEXT,
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(facility_id) REFERENCES facilities(id) ON DELETE CASCADE,
 FOREIGN KEY(resident_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS assets (
 id INT AUTO_INCREMENT PRIMARY KEY,
 asset_no VARCHAR(50) NOT NULL UNIQUE,
 name VARCHAR(200) NOT NULL,
 category VARCHAR(100),
 quantity INT DEFAULT 1,
 unit VARCHAR(50) DEFAULT 'unit',
 condition_status ENUM('Good','Fair','Needs Repair','Unserviceable') DEFAULT 'Good',
 location VARCHAR(200),
 acquisition_date DATE NULL,
 acquisition_cost DECIMAL(12,2) DEFAULT 0,
 status ENUM('Active','Disposed','Lost') DEFAULT 'Active',
 description TEXT,
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS assistance_requests (
 id INT AUTO_INCREMENT PRIMARY KEY,
 assistance_no VARCHAR(50) NOT NULL UNIQUE,
 resident_id INT NOT NULL,
 assistance_type VARCHAR(100) NOT NULL,
 purpose TEXT,
 amount DECIMAL(12,2) DEFAULT 0,
 requirements TEXT,
 status ENUM('Pending','Under Review','Approved','Released','Rejected','Cancelled') DEFAULT 'Pending',
 release_date DATE NULL,
 notes TEXT,
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(resident_id) REFERENCES residents(id) ON DELETE CASCADE,
 FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS environment_requests (
 id INT AUTO_INCREMENT PRIMARY KEY,
 request_no VARCHAR(50) NOT NULL UNIQUE,
 resident_id INT NULL,
 request_type ENUM('Waste Concern','Clean-up Request','Tree/Greenery','Other') NOT NULL,
 location VARCHAR(200) NOT NULL,
 description TEXT NOT NULL,
 status ENUM('Pending','Under Review','Scheduled','Completed','Rejected','Cancelled') DEFAULT 'Pending',
 scheduled_date DATE NULL,
 notes TEXT,
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(resident_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS public_contacts (
 id INT AUTO_INCREMENT PRIMARY KEY,
 label VARCHAR(150) NOT NULL,
 contact_name VARCHAR(180),
 phone VARCHAR(50),
 email VARCHAR(150),
 address VARCHAR(255),
 sort_order INT NOT NULL DEFAULT 0,
 status ENUM('Active','Inactive') DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
