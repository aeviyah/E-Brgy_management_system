<?php
require '../config/database.php'; require '../auth.php';
require_role(['System Administrator','Punong Barangay']);
$title='Emergency/Public Contacts'; $base='../'; $id=(int)($_GET['id']??0); $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $data=[trim($_POST['label']??''),trim($_POST['contact_name']??''),trim($_POST['phone']??''),trim($_POST['email']??''),trim($_POST['address']??''),(int)($_POST['sort_order']??0),$_POST['status']??'Active'];
 try{
  if($id){$s=$pdo->prepare('UPDATE public_contacts SET label=?,contact_name=?,phone=?,email=?,address=?,sort_order=?,status=? WHERE id=?');$s->execute([...$data,$id]);$affected=$id;$action='UPDATE';}
  else{$s=$pdo->prepare('INSERT INTO public_contacts(label,contact_name,phone,email,address,sort_order,status) VALUES(?,?,?,?,?,?,?)');$s->execute($data);$affected=$pdo->lastInsertId();$action='CREATE';}
  log_action($action,'Managed public/emergency contact','public_contacts:'.$affected);header('Location: public_contacts.php');exit;
 }catch(Throwable $e){$error='Unable to save contact.';}
}
$row=[];
if($id){$s=$pdo->prepare('SELECT * FROM public_contacts WHERE id=?');$s->execute([$id]);$row=$s->fetch()?:[];}
$rows=$pdo->query('SELECT * FROM public_contacts ORDER BY sort_order,label')->fetchAll();
require '../includes/header.php';
?>
<div class="page-head"><div><h1>Public / Emergency Contacts</h1><p class="muted">Only authorized administrators can publish contact information to the public portal.</p></div></div>
<?php if($error):?><div class="alert error"><?=h($error)?></div><?php endif;?>
<div class="card"><form method="post" class="form-grid">
<label>Label<input name="label" required value="<?=h($row['label']??'')?>"></label>
<label>Contact Name<input name="contact_name" value="<?=h($row['contact_name']??'')?>"></label>
<label>Phone<input name="phone" value="<?=h($row['phone']??'')?>"></label>
<label>Email<input name="email" type="email" value="<?=h($row['email']??'')?>"></label>
<label>Address<input name="address" value="<?=h($row['address']??'')?>"></label>
<label>Sort Order<input name="sort_order" type="number" value="<?=h($row['sort_order']??0)?>"></label>
<label>Status<select name="status"><option>Active</option><option <?=($row['status']??'')==='Inactive'?'selected':''?>>Inactive</option></select></label>
<div class="full actions"><button class="btn primary">Save Contact</button><?php if($id):?><a class="btn secondary" href="public_contacts.php">Cancel</a><?php endif;?></div>
</form></div><br>
<div class="table-wrap"><table class="table"><tr><th>Label</th><th>Contact</th><th>Phone</th><th>Status</th><th></th></tr><?php foreach($rows as $r):?><tr><td><?=h($r['label'])?></td><td><?=h($r['contact_name']?:'—')?></td><td><?=h($r['phone']?:'—')?></td><td><?=h($r['status'])?></td><td><a class="btn secondary" href="public_contacts.php?id=<?=$r['id']?>">Edit</a></td></tr><?php endforeach;?></table></div>
<?php require '../includes/footer.php';?>
