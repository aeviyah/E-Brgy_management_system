<?php
require '../config/database.php'; require '../auth.php'; require_role(['System Administrator']);
if(isset($_GET['download']) && $_GET['download']==='sql'){
 $tables=$pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN); $out="-- E-Barangay database backup\n-- Generated: ".date('Y-m-d H:i:s')."\n\nSET FOREIGN_KEY_CHECKS=0;\n\n";
 foreach($tables as $table){$q=$pdo->query("SHOW CREATE TABLE `".str_replace('`','``',$table)."`")->fetch();$out.="DROP TABLE IF EXISTS `{$table}`;\n".$q['Create Table'].";\n\n";$rows=$pdo->query("SELECT * FROM `".str_replace('`','``',$table)."`");foreach($rows as $row){$vals=[];foreach($row as $v){$vals[]=$v===null?'NULL':$pdo->quote($v);} $out.="INSERT INTO `{$table}` VALUES (".implode(',',$vals).");\n";} $out.="\n";}
 $out.="SET FOREIGN_KEY_CHECKS=1;\n";header('Content-Type: application/sql');header('Content-Disposition: attachment; filename="e_barangay_backup_'.date('Ymd_His').'.sql"');echo $out;exit;
}
$title='Backup & Data Management'; $base='../'; require '../includes/header.php'; ?>
<div class="page-head"><div><h1>Backup & Data Management</h1><p class="muted">Generate a SQL backup of the current E-Barangay database. Restricted to System Administrator.</p></div></div>
<div class="card"><h2>Database Backup</h2><p>This export reads the active database tables and creates a portable SQL file containing table definitions and current records.</p><a class="btn primary" href="backup.php?download=sql">Download SQL Backup</a></div><br>
<div class="card"><h2>Data Safety</h2><ul><li>Store backups in a secure location.</li><li>Do not expose database backups through the public portal.</li><li>Test restoration procedures on a separate local database before relying on a backup.</li></ul></div>
<?php require '../includes/footer.php'; ?>
