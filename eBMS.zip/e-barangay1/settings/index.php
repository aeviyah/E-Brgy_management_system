<?php
require '../config/database.php'; require '../auth.php'; require_login();
$title='Settings'; $base='../'; $message=''; $error=''; $u=user();
if($_SERVER['REQUEST_METHOD']==='POST'){
 $current=$_POST['current_password']??''; $new=$_POST['new_password']??''; $confirm=$_POST['confirm_password']??'';
 $s=$pdo->prepare('SELECT password_hash FROM users WHERE id=?');$s->execute([$u['id']]);$row=$s->fetch();
 if(!$row || !password_verify($current,$row['password_hash'])) $error='Current password is incorrect.';
 elseif(strlen($new)<8) $error='New password must be at least 8 characters.';
 elseif($new!==$confirm) $error='New passwords do not match.';
 else{$s=$pdo->prepare('UPDATE users SET password_hash=? WHERE id=?');$s->execute([password_hash($new,PASSWORD_DEFAULT),$u['id']]);log_action('PASSWORD_CHANGED','User changed account password','users:'.$u['id']);$message='Password updated successfully.';}
}
require '../includes/header.php'; ?>
<div class="page-head"><div><h1>Settings</h1><p class="muted">Account and system-control settings.</p></div></div>
<?php if($message): ?><div class="alert success"><?=h($message)?></div><?php endif; ?><?php if($error): ?><div class="alert danger"><?=h($error)?></div><?php endif; ?>
<div class="grid"><div class="card"><h2>My Account</h2><p><strong><?=h($u['full_name'])?></strong></p><p><?=h($u['username'])?> · <?=h($u['role'])?></p></div><div class="card"><h2>Change Password</h2><form method="post"><label>Current Password<input type="password" name="current_password" required></label><label>New Password<input type="password" name="new_password" minlength="8" required></label><label>Confirm New Password<input type="password" name="confirm_password" minlength="8" required></label><button class="btn primary">Update Password</button></form></div></div>
<?php if($u['role']==='System Administrator'): ?><br><div class="card"><h2>System Controls</h2><p class="muted">Administrative data backup and audit controls are available here and are restricted to authorized users.</p><div class="actions"><a class="btn secondary" href="../admin/backup.php">Backup & Data Management</a><a class="btn secondary" href="../audit/index.php">Audit Trail</a></div></div><?php endif; ?>
<?php require '../includes/footer.php'; ?>
