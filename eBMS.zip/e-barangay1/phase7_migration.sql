USE e_barangay;
CREATE TABLE IF NOT EXISTS public_contacts (
 id INT AUTO_INCREMENT PRIMARY KEY,
 label VARCHAR(150) NOT NULL,
 contact_name VARCHAR(180),
 phone VARCHAR(50),
 email VARCHAR(150),
 address VARCHAR(255),
 sort_order INT NOT NULL DEFAULT 0,
 status ENUM('Active','Inactive') DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
