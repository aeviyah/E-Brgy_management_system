<?php
require '../config/database.php'; require '../auth.php'; require_login();
$title='Global Search'; $base='../'; $q=trim($_GET['q']??''); $results=[];
if($q!==''){
 $like='%'.$q.'%';
 $sources=[
 ['Residents','residents','id,name,resident_id,contact_number,residency_status','name LIKE ? OR resident_id LIKE ? OR contact_number LIKE ?','residents/index.php'],
 ['Households','households','id,household_no,address,status','household_no LIKE ? OR address LIKE ?','households/index.php'],
 ['Documents','document_requests','id,request_no,document_type,status','request_no LIKE ? OR document_type LIKE ? OR status LIKE ?','documents/index.php'],
 ['Permits','permit_applications','id,permit_no,business_name,status','permit_no LIKE ? OR business_name LIKE ? OR status LIKE ?','permits/index.php'],
 ['Services','service_requests','id,request_no,status','request_no LIKE ? OR status LIKE ?','services/index.php'],
 ['Cases','case_records','id,case_no,case_type,status','case_no LIKE ? OR case_type LIKE ? OR status LIKE ?','cases/index.php'],
 ['Announcements','announcements','id,title,status','title LIKE ? OR status LIKE ?','announcements/index.php'],
 ['Events','community_events','id,title,venue,status','title LIKE ? OR venue LIKE ? OR status LIKE ?','events/index.php'],
 ['Projects','projects','id,project_no,title,status','project_no LIKE ? OR title LIKE ? OR status LIKE ?','projects/index.php'],
 ['Assets','assets','id,asset_no,name,status','asset_no LIKE ? OR name LIKE ? OR status LIKE ?','assets/index.php'],
 ['Assistance','assistance_requests','id,assistance_no,assistance_type,status','assistance_no LIKE ? OR assistance_type LIKE ? OR status LIKE ?','assistance/index.php'],
 ['Environment','environment_requests','id,request_no,request_type,status','request_no LIKE ? OR request_type LIKE ? OR status LIKE ?','environment/index.php']
 ];
 foreach($sources as [$label,$table,$fields,$where,$url]){try{$params=array_fill(0,substr_count($where,'?'),$like); $s=$pdo->prepare("SELECT $fields FROM $table WHERE $where ORDER BY id DESC LIMIT 10");$s->execute($params);foreach($s->fetchAll() as $r){$results[]=['type'=>$label,'url'=>$url,'row'=>$r];}}catch(Throwable $e){}}
}
require '../includes/header.php'; ?>
<div class="page-head"><div><h1>Global Search</h1><p class="muted">Search common records across the active E-Barangay modules.</p></div></div>
<div class="card"><form class="filters"><input name="q" value="<?=h($q)?>" placeholder="Name, ID, request no., title, status..." required><button class="btn primary">Search</button></form></div><br>
<div class="card"><h2>Results <?= $q!=='' ? 'for “'.h($q).'”' : '' ?></h2><?php if($q===''): ?><p class="muted">Enter a search term to begin.</p><?php elseif(!$results): ?><p class="muted">No matching records found.</p><?php else: ?><div class="table-wrap"><table class="table"><tr><th>Module</th><th>Reference</th><th>Details</th><th>Action</th></tr><?php foreach($results as $r): $row=$r['row']; $ref=$row['resident_id']??$row['request_no']??$row['permit_no']??$row['case_no']??$row['project_no']??$row['asset_no']??$row['assistance_no']??$row['household_no']??($row['id']??''); ?><tr><td><?=h($r['type'])?></td><td><?=h($ref)?></td><td><?=h(implode(' | ',array_map(fn($v)=>substr((string)$v,0,100),$row)))?></td><td><a class="btn small" href="<?=h($base.$r['url'])?>">Open</a></td></tr><?php endforeach; ?></table></div><?php endif; ?></div>
<?php require '../includes/footer.php'; ?>
