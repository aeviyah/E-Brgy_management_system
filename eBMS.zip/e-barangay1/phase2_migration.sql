USE e_barangay;
CREATE TABLE IF NOT EXISTS document_types (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(150) NOT NULL,
 description TEXT,
 fee DECIMAL(10,2) NOT NULL DEFAULT 0,
 requirements TEXT,
 status ENUM('Active','Inactive') DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS document_requests (
 id INT AUTO_INCREMENT PRIMARY KEY,
 request_no VARCHAR(50) NOT NULL UNIQUE,
 resident_id INT NOT NULL,
 document_type_id INT NOT NULL,
 purpose VARCHAR(255) NOT NULL,
 remarks TEXT,
 status ENUM('Pending','Under Review','Approved','Rejected','Processing','Completed','Cancelled') DEFAULT 'Pending',
 requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 reviewed_by INT NULL,
 reviewed_at DATETIME NULL,
 completed_at DATETIME NULL,
 FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE RESTRICT,
 FOREIGN KEY (document_type_id) REFERENCES document_types(id) ON DELETE RESTRICT,
 FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS permit_applications (
 id INT AUTO_INCREMENT PRIMARY KEY,
 application_no VARCHAR(50) NOT NULL UNIQUE,
 resident_id INT NULL,
 business_name VARCHAR(180) NOT NULL,
 business_address VARCHAR(255) NOT NULL,
 business_type VARCHAR(120) NOT NULL,
 applicant_contact VARCHAR(50),
 purpose VARCHAR(255),
 assessment_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
 status ENUM('Pending','Under Review','For Assessment','Approved','Rejected','Released') DEFAULT 'Pending',
 remarks TEXT,
 applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 reviewed_by INT NULL,
 reviewed_at DATETIME NULL,
 FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS service_catalog (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(150) NOT NULL,
 description TEXT,
 fee DECIMAL(10,2) NOT NULL DEFAULT 0,
 processing_days INT NOT NULL DEFAULT 3,
 status ENUM('Active','Inactive') DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS service_requests (
 id INT AUTO_INCREMENT PRIMARY KEY,
 request_no VARCHAR(50) NOT NULL UNIQUE,
 resident_id INT NOT NULL,
 service_id INT NOT NULL,
 purpose VARCHAR(255) NOT NULL,
 details TEXT,
 status ENUM('Pending','Under Review','Approved','Processing','Completed','Rejected','Cancelled') DEFAULT 'Pending',
 requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 reviewed_by INT NULL,
 reviewed_at DATETIME NULL,
 completed_at DATETIME NULL,
 FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE RESTRICT,
 FOREIGN KEY (service_id) REFERENCES service_catalog(id) ON DELETE RESTRICT,
 FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS payments (
 id INT AUTO_INCREMENT PRIMARY KEY,
 transaction_no VARCHAR(50) NOT NULL UNIQUE,
 resident_id INT NULL,
 document_request_id INT NULL,
 permit_id INT NULL,
 service_request_id INT NULL,
 amount DECIMAL(10,2) NOT NULL,
 payment_method ENUM('Cash','GCash','Bank Transfer','Other') DEFAULT 'Cash',
 payment_status ENUM('Paid','Voided') DEFAULT 'Paid',
 paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 received_by INT NULL,
 remarks TEXT,
 FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY (document_request_id) REFERENCES document_requests(id) ON DELETE SET NULL,
 FOREIGN KEY (permit_id) REFERENCES permit_applications(id) ON DELETE SET NULL,
 FOREIGN KEY (service_request_id) REFERENCES service_requests(id) ON DELETE SET NULL,
 FOREIGN KEY (received_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE official_receipts (
 id INT AUTO_INCREMENT PRIMARY KEY,
 or_no VARCHAR(50) NOT NULL UNIQUE,
 payment_id INT NOT NULL UNIQUE,
 issued_by INT NULL,
 issued_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE RESTRICT,
 FOREIGN KEY (issued_by) REFERENCES users(id) ON DELETE SET NULL
);

INSERT IGNORE INTO document_types(name,description,fee,requirements) VALUES
('Barangay Certificate of Residency','Certification confirming barangay residency.',50,'Valid ID; proof of residency if required'),
('Barangay Clearance','General barangay clearance for official purposes.',50,'Valid ID; purpose of request'),
('Certificate of Indigency','Certification for qualified residents needing proof of indigency.',0,'Valid ID; supporting document if applicable');
INSERT IGNORE INTO service_catalog(name,description,fee,processing_days) VALUES
('Barangay Assistance Request','Request for available barangay assistance subject to assessment.',0,5),
('Community Certification Assistance','Assistance with preparation and verification of barangay certifications.',0,3),
('Referral Request','Request for a barangay referral for an external agency or service.',0,3);
