CREATE TABLE IF NOT EXISTS projects (
 id INT AUTO_INCREMENT PRIMARY KEY,
 project_no VARCHAR(50) NOT NULL UNIQUE,
 title VARCHAR(200) NOT NULL,
 description TEXT,
 project_type VARCHAR(100),
 location VARCHAR(200),
 start_date DATE NULL,
 target_date DATE NULL,
 budget DECIMAL(12,2) DEFAULT 0,
 funding_source VARCHAR(150),
 status ENUM('Planned','Ongoing','Completed','Suspended','Cancelled') DEFAULT 'Planned',
 progress_percent TINYINT UNSIGNED DEFAULT 0,
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS facilities (
 id INT AUTO_INCREMENT PRIMARY KEY,
 facility_no VARCHAR(50) NOT NULL UNIQUE,
 name VARCHAR(200) NOT NULL,
 facility_type VARCHAR(100),
 location VARCHAR(200),
 capacity INT DEFAULT 0,
 status ENUM('Available','Maintenance','Inactive') DEFAULT 'Available',
 description TEXT,
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS facility_reservations (
 id INT AUTO_INCREMENT PRIMARY KEY,
 reservation_no VARCHAR(50) NOT NULL UNIQUE,
 facility_id INT NOT NULL,
 resident_id INT NULL,
 purpose VARCHAR(255) NOT NULL,
 start_datetime DATETIME NOT NULL,
 end_datetime DATETIME NOT NULL,
 status ENUM('Pending','Approved','Rejected','Completed','Cancelled') DEFAULT 'Pending',
 notes TEXT,
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(facility_id) REFERENCES facilities(id) ON DELETE CASCADE,
 FOREIGN KEY(resident_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS assets (
 id INT AUTO_INCREMENT PRIMARY KEY,
 asset_no VARCHAR(50) NOT NULL UNIQUE,
 name VARCHAR(200) NOT NULL,
 category VARCHAR(100),
 quantity INT DEFAULT 1,
 unit VARCHAR(50) DEFAULT 'unit',
 condition_status ENUM('Good','Fair','Needs Repair','Unserviceable') DEFAULT 'Good',
 location VARCHAR(200),
 acquisition_date DATE NULL,
 acquisition_cost DECIMAL(12,2) DEFAULT 0,
 status ENUM('Active','Disposed','Lost') DEFAULT 'Active',
 description TEXT,
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS assistance_requests (
 id INT AUTO_INCREMENT PRIMARY KEY,
 assistance_no VARCHAR(50) NOT NULL UNIQUE,
 resident_id INT NOT NULL,
 assistance_type VARCHAR(100) NOT NULL,
 purpose TEXT,
 amount DECIMAL(12,2) DEFAULT 0,
 requirements TEXT,
 status ENUM('Pending','Under Review','Approved','Released','Rejected','Cancelled') DEFAULT 'Pending',
 release_date DATE NULL,
 notes TEXT,
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(resident_id) REFERENCES residents(id) ON DELETE CASCADE,
 FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS environment_requests (
 id INT AUTO_INCREMENT PRIMARY KEY,
 request_no VARCHAR(50) NOT NULL UNIQUE,
 resident_id INT NULL,
 request_type ENUM('Waste Concern','Clean-up Request','Tree/Greenery','Other') NOT NULL,
 location VARCHAR(200) NOT NULL,
 description TEXT NOT NULL,
 status ENUM('Pending','Under Review','Scheduled','Completed','Rejected','Cancelled') DEFAULT 'Pending',
 scheduled_date DATE NULL,
 notes TEXT,
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(resident_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
);
