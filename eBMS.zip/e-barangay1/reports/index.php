<?php
require '../config/database.php'; require '../auth.php'; require_login();
$title='Reports & Analytics'; $base='../';
$reports=[];
$queries=[
 'Residents by Purok'=>'SELECT p.name, COUNT(r.id) total FROM puroks p LEFT JOIN residents r ON r.purok_id=p.id AND r.residency_status<>"Archived" GROUP BY p.id ORDER BY p.name',
 'Document Requests by Status'=>'SELECT status, COUNT(*) total FROM document_requests GROUP BY status ORDER BY total DESC',
 'Services by Status'=>'SELECT status, COUNT(*) total FROM service_requests GROUP BY status ORDER BY total DESC',
 'Cases by Type'=>'SELECT case_type, COUNT(*) total FROM case_records GROUP BY case_type ORDER BY total DESC',
 'Projects by Status'=>'SELECT status, COUNT(*) total FROM projects GROUP BY status ORDER BY total DESC',
 'Treasury Collections by Payment Method'=>'SELECT payment_method, COUNT(*) transactions, COALESCE(SUM(amount),0) total FROM payments GROUP BY payment_method ORDER BY total DESC'
];
foreach($queries as $name=>$sql){ try{$reports[$name]=$pdo->query($sql)->fetchAll();}catch(Throwable $e){$reports[$name]=[];} }
$collection=(float)($pdo->query('SELECT COALESCE(SUM(amount),0) c FROM payments')->fetch()['c']??0);
$assistance=(float)($pdo->query('SELECT COALESCE(SUM(amount),0) c FROM assistance_requests WHERE status="Released"')->fetch()['c']??0);
require '../includes/header.php'; ?>
<div class="page-head"><div><h1>Reports & Analytics</h1><p class="muted">Database-backed operational summaries for barangay management.</p></div></div>
<div class="grid"><div class="card"><div class="muted">Total Recorded Collections</div><div class="kpi">₱<?=number_format($collection,2)?></div></div><div class="card"><div class="muted">Released Assistance</div><div class="kpi">₱<?=number_format($assistance,2)?></div></div><div class="card"><div class="muted">Residents</div><div class="kpi"><?=h($pdo->query('SELECT COUNT(*) c FROM residents WHERE residency_status<>"Archived"')->fetch()['c'])?></div></div><div class="card"><div class="muted">Open Cases</div><div class="kpi"><?=h($pdo->query('SELECT COUNT(*) c FROM case_records WHERE status NOT IN ("Resolved","Dismissed","Closed")')->fetch()['c'])?></div></div></div><br>
<div class="grid"><?php foreach($reports as $name=>$rows): ?><div class="card"><h2><?=h($name)?></h2><div class="table-wrap"><table class="table"><?php if($rows): ?><tr><?php foreach(array_keys($rows[0]) as $col): ?><th><?=h(ucwords(str_replace('_',' ',$col)))?></th><?php endforeach; ?></tr><?php foreach($rows as $row): ?><tr><?php foreach($row as $v): ?><td><?=h($v)?></td><?php endforeach; ?></tr><?php endforeach; ?><?php else: ?><tr><td class="muted">No records available.</td></tr><?php endif; ?></table></div></div><?php endforeach; ?></div>
<?php require '../includes/footer.php'; ?>
