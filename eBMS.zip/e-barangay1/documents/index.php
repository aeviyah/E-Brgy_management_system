<?php
require_once __DIR__.'/../auth.php'; require_login(); require_once __DIR__.'/../config/database.php';
$title='Documents'; $base='../';
$q=trim($_GET['q']??''); $status=$_GET['status']??'';
$sql="SELECT dr.*, CONCAT(r.first_name,' ',COALESCE(CONCAT(r.middle_name,' '),''),r.last_name) resident_name, dt.name document_name, dt.fee FROM document_requests dr JOIN residents r ON r.id=dr.resident_id JOIN document_types dt ON dt.id=dr.document_type_id WHERE 1=1"; $args=[]; if(user()['role']==='Resident'){ $me=resident_profile(); if(!$me || $me['residency_status']!=='Active'){ http_response_code(403); exit('Resident account is pending verification or is not active.'); } $sql.=' AND dr.resident_id=?'; $args[]=$me['id']; }
if($q!==''){ $sql.=" AND (dr.request_no LIKE ? OR r.first_name LIKE ? OR r.last_name LIKE ? OR dt.name LIKE ?)"; $x="%$q%"; array_push($args,$x,$x,$x,$x); }
if($status!==''){ $sql.=" AND dr.status=?"; $args[]=$status; }
$sql.=' ORDER BY dr.requested_at DESC'; $st=$pdo->prepare($sql); $st->execute($args); $rows=$st->fetchAll();
$types=$pdo->query("SELECT * FROM document_types WHERE status='Active' ORDER BY name")->fetchAll();
require __DIR__.'/../includes/header.php';
?>
<div class="page-head"><div><h1>Documents</h1><p class="muted">Document catalog and request workflow.</p></div><a class="btn primary" href="form.php">New Document Request</a></div>
<form class="card" method="get"><div class="form-grid"><label>Search<input name="q" value="<?=h($q)?>" placeholder="Request no., resident, document"></label><label>Status<select name="status"><option value="">All Statuses</option><?php foreach(['Pending','Under Review','Approved','Rejected','Processing','Completed','Cancelled'] as $x): ?><option <?= $status===$x?'selected':'' ?>><?=h($x)?></option><?php endforeach; ?></select></label></div><br><button class="btn secondary">Filter</button></form><br>
<div class="table-wrap"><table class="table"><tr><th>Request No.</th><th>Resident</th><th>Document</th><th>Fee</th><th>Status</th><th>Date</th><th>Action</th></tr><?php foreach($rows as $r): ?><tr><td><?=h($r['request_no'])?></td><td><?=h($r['resident_name'])?></td><td><?=h($r['document_name'])?></td><td>₱<?=number_format($r['fee'],2)?></td><td><span class="badge"><?=h($r['status'])?></span></td><td><?=h($r['requested_at'])?></td><td><a class="btn secondary" href="view.php?id=<?=$r['id']?>">Open</a></td></tr><?php endforeach; if(!$rows): ?><tr><td colspan="7" class="muted">No document requests found.</td></tr><?php endif; ?></table></div>
<?php require __DIR__.'/../includes/footer.php'; ?>
