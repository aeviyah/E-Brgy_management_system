<?php
require '../config/database.php'; require '../auth.php'; require_login();
$title='Announcements'; $base='../'; $role=user()['role'];
$where=['a.status<>"Archived"']; $params=[];
if($role==='Resident'){$where[]='a.status="Published"';$where[]='(a.created_at IS NULL OR a.created_at<=NOW())';$where[]='(a.expiry_date IS NULL OR a.expiry_date>=NOW())';$where[]='(a.audience="All Residents" OR (a.audience="Purok" AND a.purok_id=(SELECT purok_id FROM residents WHERE user_id=? LIMIT 1)) OR (a.audience="Specific Resident" AND a.resident_id=(SELECT id FROM residents WHERE user_id=? LIMIT 1)))';$params[]=user()['id'];$params[]=user()['id'];}
$sql='SELECT a.*,p.name purok_name,r.full_name resident_name,u.full_name creator FROM announcements a LEFT JOIN puroks p ON p.id=a.purok_id LEFT JOIN residents r ON r.id=a.resident_id LEFT JOIN users u ON u.id=a.created_by WHERE '.implode(' AND ',$where).' ORDER BY COALESCE(a.created_at,a.created_at) DESC';
$s=$pdo->prepare($sql);$s->execute($params);$rows=$s->fetchAll();
$canManage=in_array($role,['Barangay Secretary','Barangay Staff','Punong Barangay','System Administrator'],true);
require '../includes/header.php'; ?>
<div class="page-head"><div><h1>Announcements</h1><p class="muted">Publish and review barangay announcements by audience.</p></div><?php if($canManage):?><a class="btn primary" href="form.php">New Announcement</a><?php endif;?></div>
<div class="grid"><?php foreach($rows as $r):?><div class="card"><div class="page-head"><span class="badge"><?=h($r['status'])?></span><span class="muted"><?=h($r['audience'])?></span></div><h2><?=h($r['title'])?></h2><p><?=nl2br(h($r['body']))?></p><p class="muted">Publish: <?=h($r['created_at']??'Not scheduled')?><?php if($r['expiry_date']):?> · Expires: <?=h($r['expiry_date'])?><?php endif;?></p><?php if($canManage):?><a class="btn secondary" href="form.php?id=<?=$r['id']?>">Manage</a><?php endif;?></div><?php endforeach;if(!$rows):?><div class="card"><p class="muted">No announcements available.</p></div><?php endif;?></div>
<?php require '../includes/footer.php'; ?>
