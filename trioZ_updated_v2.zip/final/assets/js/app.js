document.addEventListener('click', function (event) {
    if (event.target.closest('[data-toggle-sidebar]')) {
        return; // handled once in the theme/sidebar block below
    }
    if (document.body.classList.contains('sidebar-open') && !event.target.closest('.sidebar')) {
        document.body.classList.remove('sidebar-open');
    }
    var demo = event.target.closest('[data-demo-email]');
    if (demo) {
        document.getElementById('identifier').value = demo.dataset.demoEmail;
        var portal = document.querySelector('input[name="portal"][value="' + (demo.dataset.demoPortal || 'Resident') + '"]');
        if (portal) { portal.checked = true; }
        document.getElementById('password').value = demo.dataset.demoPassword;
        document.getElementById('password').focus();
    }
});

document.addEventListener('change', function (event) {
    var autosubmit = event.target.closest('[data-autosubmit]');
    if (autosubmit && autosubmit.form) {
        autosubmit.form.submit();
    }
});

document.addEventListener('submit', function (event) {
    var form = event.target;
    if (form.dataset.confirm && !window.confirm(form.dataset.confirm)) {
        event.preventDefault();
    }
});

// Registration: show the position field only for barangay officials.
(function () {
    var radios = document.querySelectorAll('[data-account-type]');
    var official = document.querySelector('[data-official-only]');
    if (!radios.length || !official) { return; }
    function sync() {
        var checked = document.querySelector('[data-account-type]:checked');
        official.style.display = checked && checked.value === 'Barangay Official' ? '' : 'none';
    }
    radios.forEach(function (r) { r.addEventListener('change', sync); });
    sync();
}());


/* Theme and sidebar preferences; existing app interactions are preserved. */
(function () {
  var body = document.body;
  var stored = null;
  try { stored = localStorage.getItem('eBarangayTheme'); } catch (e) {}
  var theme = (stored === 'dark' || stored === 'light') ? stored : ((window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light');
  function applyTheme(value) {
    theme = value === 'dark' ? 'dark' : 'light';
    body.setAttribute('data-theme', theme); document.documentElement.setAttribute('data-theme', theme);
    var button = document.querySelector('[data-theme-toggle]'); var icon = document.querySelector('[data-theme-icon]'); var label = document.querySelector('.theme-toggle-label');
    if (button) { var next = theme === 'dark' ? 'light' : 'dark'; button.setAttribute('aria-label', 'Switch to ' + next + ' mode'); button.setAttribute('title', 'Switch to ' + next + ' mode'); button.setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false'); }
    if (icon) icon.textContent = theme === 'dark' ? '☀' : '☾'; if (label) label.textContent = theme === 'dark' ? 'Light mode' : 'Dark mode';
  }
  applyTheme(theme);
  try { if (localStorage.getItem('eBarangaySidebarCollapsed') === '1' && matchMedia('(min-width: 901px)').matches) body.classList.add('sidebar-collapsed'); } catch (e) {}
  document.addEventListener('click', function (event) {
    var themeButton = event.target.closest('[data-theme-toggle]');
    if (themeButton) { var next = theme === 'dark' ? 'light' : 'dark'; applyTheme(next); try { localStorage.setItem('eBarangayTheme', next); } catch (e) {} }
    if (event.target.closest('[data-collapse-sidebar]')) { body.classList.toggle('sidebar-collapsed'); try { localStorage.setItem('eBarangaySidebarCollapsed', body.classList.contains('sidebar-collapsed') ? '1' : '0'); } catch (e) {} }
    if (event.target.closest('[data-toggle-sidebar]')) body.classList.toggle('sidebar-open');
    if (event.target.closest('.sidebar .nav-link') && window.matchMedia('(max-width: 900px)').matches) body.classList.remove('sidebar-open');
  });
})();


/* Activities + facilities: click a card, the picture zooms out of the card and the details open beside it. */
(function () {
  var modal = document.querySelector('[data-info-modal]');
  if (!modal) return;
  var sheet = modal.querySelector('[data-info-sheet]');
  var img = modal.querySelector('[data-info-image]');
  var photo = modal.querySelector('.info-photo');
  var cards = Array.prototype.slice.call(document.querySelectorAll('[data-info-open]'));
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var opener = null, current = 0, closing = null;

  function set(sel, text) { var el = modal.querySelector(sel); if (el) el.textContent = text || ''; }
  function fill(card) {
    img.src = card.dataset.img; img.alt = card.dataset.title;
    set('[data-info-tag]', card.dataset.tag);
    set('[data-info-title]', card.dataset.title);
    set('[data-info-about]', card.dataset.about);
    var list = modal.querySelector('[data-info-list]');
    list.textContent = '';
    var rows = [];
    try { rows = JSON.parse(card.dataset.info || '[]'); } catch (e) { rows = []; }
    rows.forEach(function (row) {
      var wrap = document.createElement('div');
      var dt = document.createElement('dt'); dt.textContent = row[0];
      var dd = document.createElement('dd'); dd.textContent = row[1];
      wrap.appendChild(dt); wrap.appendChild(dd); list.appendChild(wrap);
    });
  }
  function open(card, index) {
    window.clearTimeout(closing);
    opener = card; current = index; fill(card);
    modal.hidden = false; document.body.style.overflow = 'hidden';
    sheet.classList.remove('is-ready');
    photo.style.transition = 'none'; photo.style.transform = 'none';
    if (!reduce) {
      // FLIP: begin exactly on top of the small picture in the card, then grow into place.
      var from = card.querySelector('.photo-frame').getBoundingClientRect();
      var to = photo.getBoundingClientRect();
      if (to.width && to.height) {
        var dx = (from.left + from.width / 2) - (to.left + to.width / 2);
        var dy = (from.top + from.height / 2) - (to.top + to.height / 2);
        photo.style.transform = 'translate(' + dx + 'px,' + dy + 'px) scale(' + (from.width / to.width) + ',' + (from.height / to.height) + ')';
      }
    }
    void photo.offsetWidth;
    modal.classList.add('is-open');
    photo.style.transition = reduce ? 'none' : 'transform .5s cubic-bezier(.2,.8,.2,1)';
    photo.style.transform = 'none';
    window.setTimeout(function () { sheet.classList.add('is-ready'); }, reduce ? 0 : 280);
    modal.querySelector('.info-close').focus({ preventScroll: true });
  }
  function close() {
    modal.classList.remove('is-open'); sheet.classList.remove('is-ready');
    document.body.style.overflow = '';
    closing = window.setTimeout(function () { modal.hidden = true; }, reduce ? 0 : 260);
    if (opener) opener.focus({ preventScroll: true });
  }
  function step(n) {
    if (modal.hidden || !cards.length) return;
    current = (current + n + cards.length) % cards.length;
    opener = cards[current]; fill(opener);
  }
  cards.forEach(function (card, i) { card.addEventListener('click', function () { open(card, i); }); });
  modal.addEventListener('click', function (e) {
    if (e.target.closest('[data-info-close]')) close();
    if (e.target.closest('[data-info-prev]')) step(-1);
    if (e.target.closest('[data-info-next]')) step(1);
  });
  document.addEventListener('keydown', function (e) {
    if (modal.hidden) return;
    if (e.key === 'Escape') close();
    if (e.key === 'ArrowLeft') step(-1);
    if (e.key === 'ArrowRight') step(1);
  });
}());


/* Officials: round avatars. Click = the avatar zooms to the middle, then it opens as an ID card
 * (avatar + name + position on the left, details about the post on the right). */
(function () {
  var modal = document.querySelector('[data-id-modal]');
  if (!modal) return;
  // The glass panels use backdrop-filter, which would trap a fixed modal inside the panel. Keep the modal on <body>.
  document.body.appendChild(modal);
  var sheet = modal.querySelector('[data-id-sheet]');
  var avatar = modal.querySelector('[data-id-avatar]');
  var dots = Array.prototype.slice.call(document.querySelectorAll('[data-official]'));
  var closeBtn = modal.querySelector('.id-close');
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var opener = null, timer = null, current = -1;

  function set(sel, text) { var el = modal.querySelector(sel); if (el) el.textContent = text; }
  function fill(dot) {
    set('[data-id-name]', dot.dataset.name);
    set('[data-id-pos]', dot.dataset.pos);
    set('[data-id-pos2]', dot.dataset.pos);
    set('[data-id-unit]', dot.dataset.unit);
    set('[data-id-duty]', dot.dataset.duty);
    set('[data-id-no]', dot.dataset.idno);
    set('[data-id-initials]', dot.dataset.initials);
    avatar.className = 'avatar-circle id-avatar is-' + dot.dataset.group;
  }
  function toCard() {
    sheet.setAttribute('data-stage', 'card');
    closeBtn.focus({ preventScroll: true });
  }
  function open(dot) {
    opener = dot; current = dots.indexOf(dot);
    window.clearTimeout(timer);
    fill(dot);
    sheet.setAttribute('data-stage', 'zoom');
    modal.hidden = false;
    document.body.style.overflow = 'hidden';
    avatar.style.transition = 'none';
    avatar.style.transform = 'none';
    if (reduce) { modal.classList.add('is-open'); toCard(); return; }
    // FLIP: start the big avatar exactly on top of the small circle, then let it grow to the middle.
    var from = dot.querySelector('.avatar-circle').getBoundingClientRect();
    var to = avatar.getBoundingClientRect();
    var dx = (from.left + from.width / 2) - (to.left + to.width / 2);
    var dy = (from.top + from.height / 2) - (to.top + to.height / 2);
    avatar.style.transform = 'translate(' + dx + 'px,' + dy + 'px) scale(' + (from.width / to.width) + ')';
    void avatar.offsetWidth;
    modal.classList.add('is-open');
    avatar.style.transition = 'transform .55s cubic-bezier(.2,.8,.2,1)';
    avatar.style.transform = 'none';
    timer = window.setTimeout(toCard, 520);
  }
  function close() {
    window.clearTimeout(timer);
    modal.classList.remove('is-open');
    window.setTimeout(function () { modal.hidden = true; sheet.setAttribute('data-stage', 'zoom'); }, reduce ? 0 : 280);
    document.body.style.overflow = '';
    if (opener) opener.focus({ preventScroll: true });
  }
  function step(n) {
    if (modal.hidden || !dots.length) return;
    current = (current + n + dots.length) % dots.length;
    opener = dots[current]; fill(opener);
  }

  dots.forEach(function (dot) { dot.addEventListener('click', function () { open(dot); }); });
  modal.addEventListener('click', function (e) { if (e.target.closest('[data-id-close]')) close(); });
  document.addEventListener('keydown', function (e) {
    if (modal.hidden) return;
    if (e.key === 'Escape') close();
    if (e.key === 'ArrowRight') step(1);
    if (e.key === 'ArrowLeft') step(-1);
    if (e.key === 'Tab') { e.preventDefault(); closeBtn.focus(); }
  });
}());
