<?php

require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accountType = ($_POST['account_type'] ?? 'Resident') === 'Barangay Official' ? 'Barangay Official' : 'Resident';
    $isOfficial = $accountType === 'Barangay Official';
    $position = (string) ($_POST['position'] ?? '');
    $username = trim((string) ($_POST['username'] ?? ''));
    $required = $isOfficial ? ['first_name', 'last_name', 'email', 'username', 'password'] : ['first_name', 'last_name', 'email', 'address', 'password'];
    $missing = [];

    foreach ($required as $field) {
        if (trim((string) ($_POST[$field] ?? '')) === '') {
            $missing[] = $field;
        }
    }

    if ($missing) {
        flash('danger', 'Please complete all required fields.');
    } elseif (strlen((string) $_POST['password']) < 6) {
        flash('danger', 'Password must be at least 6 characters.');
    } elseif (($username !== '' || $isOfficial) && !preg_match('/^[A-Za-z0-9_]{4,30}$/', $username)) {
        flash('danger', 'Username must be 4 to 30 characters: letters, numbers and underscore only.');
    } elseif ($isOfficial && !array_key_exists($position, official_positions())) {
        flash('danger', 'Please choose a valid position.');
    } elseif ($isOfficial) {
        // Barangay officials are active immediately after successful registration.
        try {
            $roleId = (int) fetch_value('SELECT id FROM roles WHERE slug = ?', [official_positions()[$position]]);
            $fullName = trim((string) $_POST['first_name'] . ' ' . (string) $_POST['last_name']);
            run_query(
                'INSERT INTO users (role_id, resident_id, full_name, username, email, position, password, status, created_at, updated_at)
                 VALUES (?, NULL, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
                [$roleId, $fullName, $username, trim((string) $_POST['email']), $position, password_hash((string) $_POST['password'], PASSWORD_DEFAULT), 'Active']
            );
            audit_log('Official sign-up requested', 'User', (int) db()->lastInsertId(), $fullName . ' as ' . $position);
            flash('success', 'Official account created. You can log in now.');
            redirect('login.php');
        } catch (PDOException $error) {
            flash('danger', 'Registration failed. The email or username may already be used.');
        }
    } else {
        $pdo = null;
        try {
            $pdo = db();
            $pdo->beginTransaction();
            $residentNo = generate_reference('RES');
            run_query(
                'INSERT INTO residents
                 (resident_no, first_name, middle_name, last_name, suffix, gender, birth_date, civil_status, contact_no, email, address, purok_id, occupation, education, voter_status, residency_status, is_pwd, is_senior, is_solo_parent, is_4ps, is_ofw, is_other, special_classification, status, notes, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
                [
                    $residentNo,
                    trim((string) $_POST['first_name']),
                    trim((string) ($_POST['middle_name'] ?? '')),
                    trim((string) $_POST['last_name']),
                    trim((string) ($_POST['suffix'] ?? '')),
                    trim((string) ($_POST['gender'] ?? '')),
                    $_POST['birth_date'] ?: null,
                    trim((string) ($_POST['civil_status'] ?? '')),
                    trim((string) ($_POST['contact_no'] ?? '')),
                    trim((string) $_POST['email']),
                    trim((string) $_POST['address']),
                    $_POST['purok_id'] ?: null,
                    trim((string) ($_POST['occupation'] ?? '')),
                    trim((string) ($_POST['education'] ?? '')),
                    trim((string) ($_POST['voter_status'] ?? '')),
                    'Resident',
                    isset($_POST['is_pwd']) ? 1 : 0,
                    isset($_POST['is_senior']) ? 1 : 0,
                    isset($_POST['is_solo_parent']) ? 1 : 0,
                    isset($_POST['is_4ps']) ? 1 : 0,
                    isset($_POST['is_ofw']) ? 1 : 0,
                    isset($_POST['is_other']) ? 1 : 0,
                    trim((string) ($_POST['special_classification'] ?? '')) ?: null,
                    'Pending Verification',
                    'Registered through resident portal.',
                ]
            );

            $residentId = (int) $pdo->lastInsertId();
            $roleId = (int) fetch_value('SELECT id FROM roles WHERE slug = ?', ['resident']);
            $fullName = trim((string) $_POST['first_name'] . ' ' . (string) $_POST['last_name']);

            run_query(
                'INSERT INTO users (role_id, resident_id, full_name, username, email, password, status, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
                [$roleId, $residentId, $fullName, $username !== '' ? $username : null, trim((string) $_POST['email']), password_hash((string) $_POST['password'], PASSWORD_DEFAULT), 'Active']
            );

            $pdo->commit();
            flash('success', 'Registration submitted. You can log in while your resident record is pending verification.');
            redirect('login.php');
        } catch (Throwable $error) {
            if ($pdo instanceof PDO && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            flash('danger', 'Registration failed. The email or username may already be used, or the database is not ready.');
        }
    }
}

$puroks = [];
try {
    $puroks = fetch_all('SELECT id, name FROM puroks ORDER BY name');
} catch (Throwable $error) {
    $puroks = [];
}


$logo = app_url('assets/img/logo.svg');
$flashes = flash_messages();
$allowedTypes = ['success', 'warning', 'danger', 'info'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Create account · E-Barangay Bigaan</title>
    <link rel="icon" href="<?= e($logo) ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bitter:wght@600;700;800&family=Nunito:wght@400;500;600;700;800&display=swap" media="print" onload="this.media='all'"><noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bitter:wght@600;700;800&family=Nunito:wght@400;500;600;700;800&display=swap"></noscript>
    <link rel="stylesheet" href="<?= e(app_url('assets/css/bg-scene.css')) ?>">
    <link rel="stylesheet" href="<?= e(app_url('assets/css/styles.css')) ?>">
    <link rel="stylesheet" href="<?= e(app_url('assets/css/landing.css')) ?>">
<?= theme_boot_script() ?>
</head>
<body class="auth-page auth-register">
<?= bg_scene() ?>

<header class="site-nav">
    <div class="nav-inner">
        <a class="brand" href="<?= e(app_url('login.php')) ?>" aria-label="E-Barangay, back to sign in">
            <img src="<?= e($logo) ?>" alt="Seal of <?= e(APP_BARANGAY) ?>">
            <span><strong>E-Barangay</strong><small>Bigaan, Calauag, Quezon</small></span>
        </a>
        <nav class="nav-links" aria-label="Account">
            <a href="<?= e(app_url('login.php#services')) ?>">Public services</a>
            <a href="<?= e(app_url('login.php#about')) ?>">About</a>
            <a class="nav-cta" href="<?= e(app_url('login.php')) ?>">Sign in</a>
            <button class="theme-toggle login-theme-toggle" type="button" data-theme-toggle aria-label="Switch theme" title="Switch theme"><span class="theme-toggle-icon" data-theme-icon aria-hidden="true">&#9790;</span><span class="theme-toggle-label">Dark mode</span></button>
        </nav>
    </div>
</header>

<main class="page">
<div class="container shell">
    <div class="reg-grid">

        <!-- Left: copy -->
        <aside class="reg-copy">
            <p class="eyebrow">Barangay Bigaan, Calauag, Quezon</p>
            <h1>Gumawa ng account, simulan na.</h1>
            <p class="lead">Register once, then request documents and track every step online. Your resident record is checked by the barangay.</p>
            <ol class="steps">
                <li><span class="tile"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg></span><span><b>Fill in your details</b>Name, contact and address.</span></li>
                <li><span class="tile"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="m8.5 12.5 2.5 2.5 4.5-5"/></svg></span><span><b>Barangay verifies</b>You can sign in while it is pending.</span></li>
                <li><span class="tile"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h4"/></svg></span><span><b>Request documents</b>Clearance, residency, indigency and more.</span></li>
            </ol>
        </aside>

        <!-- Right: form -->
        <section class="reg-card" aria-labelledby="reg-title">
            <h2 id="reg-title">Create your account</h2>
            <p class="card-sub">Fields marked <span class="req">*</span> are required.</p>

            <?php foreach ($flashes as $flash): ?>
                <?php $ftype = in_array($flash['type'] ?? '', $allowedTypes, true) ? $flash['type'] : 'info'; ?>
                <div class="alert alert-<?= e($ftype) ?>" role="alert"><?= e($flash['message'] ?? '') ?></div>
            <?php endforeach; ?>

            <form method="post" class="form-grid" autocomplete="on">

                <div class="form-field full">
                    <span class="label">I am registering as</span>
                    <div class="seg">
                        <label><input type="radio" name="account_type" value="Resident" data-account-type <?= checked(old('account_type', 'Resident') !== 'Barangay Official') ?>><span>Resident</span></label>
                        <label><input type="radio" name="account_type" value="Barangay Official" data-account-type <?= checked(old('account_type', 'Resident') === 'Barangay Official') ?>><span>Barangay official</span></label>
                    </div>
                    <p class="hint" data-official-hint hidden>Official accounts are active immediately after registration.</p>
                </div>

                <h3 class="group-title">PERSONAL</h3>
                <div class="form-field">
                    <label for="first_name">First name <span class="req">*</span></label>
                    <input class="form-control" id="first_name" name="first_name" value="<?= e(old('first_name')) ?>" autocomplete="given-name" required>
                </div>
                <div class="form-field">
                    <label for="last_name">Last name <span class="req">*</span></label>
                    <input class="form-control" id="last_name" name="last_name" value="<?= e(old('last_name')) ?>" autocomplete="family-name" required>
                </div>
                <div class="form-field">
                    <label for="middle_name">Middle name</label>
                    <input class="form-control" id="middle_name" name="middle_name" value="<?= e(old('middle_name')) ?>" autocomplete="additional-name">
                </div>
                <div class="form-field">
                    <label for="suffix">Suffix</label>
                    <input class="form-control" id="suffix" name="suffix" value="<?= e(old('suffix')) ?>" placeholder="Jr., Sr., III">
                </div>
                <div class="form-field">
                    <label for="gender">Gender</label>
                    <select class="form-control" id="gender" name="gender">
                        <option value="">Select</option>
                        <option <?= selected(old('gender'), 'Female') ?>>Female</option>
                        <option <?= selected(old('gender'), 'Male') ?>>Male</option>
                    </select>
                </div>
                <div class="form-field">
                    <label for="birth_date">Birth date</label>
                    <input class="form-control" id="birth_date" type="date" name="birth_date" value="<?= e(old('birth_date')) ?>" autocomplete="bday">
                </div>

                <h3 class="group-title">ACCOUNT</h3>
                <div class="form-field">
                    <label for="email">Email <span class="req">*</span></label>
                    <input class="form-control" id="email" type="email" name="email" value="<?= e(old('email')) ?>" autocomplete="email" required>
                </div>
                <div class="form-field">
                    <label for="contact_no">Contact no.</label>
                    <input class="form-control" id="contact_no" name="contact_no" value="<?= e(old('contact_no')) ?>" autocomplete="tel" inputmode="tel">
                </div>
                <div class="form-field">
                    <label for="username">Username <small class="muted">(required for officials)</small></label>
                    <input class="form-control" id="username" name="username" value="<?= e(old('username')) ?>" pattern="[A-Za-z0-9_]{4,30}" autocomplete="username">
                    <p class="hint">4 to 30 characters: letters, numbers, underscore.</p>
                </div>
                <div class="form-field">
                    <label for="password">Password <span class="req">*</span></label>
                    <div class="input-wrap">
                        <input class="form-control" id="password" type="password" name="password" minlength="6" autocomplete="new-password" required>
                        <button class="toggle-pass" type="button" aria-label="Show password" aria-pressed="false">
                            <svg class="icon-on" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>
                            <svg class="icon-off" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3l18 18"/><path d="M10.6 5.1A10 10 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4M6.5 6.6C3.7 8.3 2 12 2 12s3.5 7 10 7c1.6 0 3-.4 4.3-1"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>
                        </button>
                    </div>
                    <p class="hint">At least 6 characters.</p>
                </div>
                <div class="form-field full" data-official-only>
                    <label for="position">Position</label>
                    <select class="form-control" id="position" name="position">
                        <?php foreach (array_keys(official_positions()) as $positionName): ?>
                            <option <?= selected(old('position'), $positionName) ?>><?= e($positionName) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <h3 class="group-title">ADDRESS &amp; BACKGROUND</h3>
                <div class="form-field full">
                    <label for="purok_id">Purok / Sitio</label>
                    <select class="form-control" id="purok_id" name="purok_id">
                        <option value="">Select</option>
                        <?php foreach ($puroks as $purok): ?>
                            <option value="<?= (int) $purok['id'] ?>" <?= selected(old('purok_id'), $purok['id']) ?>><?= e($purok['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-field full">
                    <label for="address">Address <span class="req" data-resident-req>*</span> <small class="muted">(residents)</small></label>
                    <textarea class="form-control" id="address" name="address" rows="3" autocomplete="street-address"><?= e(old('address')) ?></textarea>
                </div>
                <div class="form-field">
                    <label for="occupation">Occupation</label>
                    <input class="form-control" id="occupation" name="occupation" value="<?= e(old('occupation')) ?>">
                </div>
                <div class="form-field">
                    <label for="education">Education</label>
                    <input class="form-control" id="education" name="education" value="<?= e(old('education')) ?>">
                </div>

                <div class="form-field full" data-resident-only>
                    <span class="label">Classifications</span>
                    <div class="chips">
                        <label><input type="checkbox" name="is_pwd" <?= checked(isset($_POST['is_pwd'])) ?>><span>PWD</span></label>
                        <label><input type="checkbox" name="is_senior" <?= checked(isset($_POST['is_senior'])) ?>><span>Senior Citizen</span></label>
                        <label><input type="checkbox" name="is_solo_parent" <?= checked(isset($_POST['is_solo_parent'])) ?>><span>Solo Parent</span></label>
                        <label><input type="checkbox" name="is_4ps" <?= checked(isset($_POST['is_4ps'])) ?>><span>4Ps</span></label>
                        <label><input type="checkbox" name="is_ofw" <?= checked(isset($_POST['is_ofw'])) ?>><span>OFW</span></label>
                        <label><input type="checkbox" name="is_other" <?= checked(isset($_POST['is_other'])) ?>><span>Other</span></label>
                    </div>
                    <input class="form-control" name="special_classification" placeholder="If Other, describe classification" value="<?= e(old('special_classification')) ?>" aria-label="Other classification">
                </div>

                <div class="form-actions full">
                    <button class="btn btn-primary" type="submit">Submit registration</button>
                    <a class="btn btn-ghost" href="<?= e(app_url('login.php')) ?>">Back to sign in</a>
                </div>
            </form>
        </section>
    </div>
</div>

<footer class="site-footer">
    <strong>Mapagdalita, Mark Luigi B. | Mendez, Justin Lloyd B. | Prada, Angel Ivy D.</strong>
    <span>BSIT-LQ-2-1 | PROGRAMMING 3</span>
</footer>
</main>

<script>
(() => {
    'use strict';

    /* Show the position field and official note only for barangay officials; hide resident-only parts */
    const radios = document.querySelectorAll('[data-account-type]');
    const officialOnly = document.querySelector('[data-official-only]');
    const hint = document.querySelector('[data-official-hint]');
    const residentOnly = document.querySelector('[data-resident-only]');
    const residentReq = document.querySelector('[data-resident-req]');
    const sync = () => {
        const checked = document.querySelector('[data-account-type]:checked');
        const official = !!checked && checked.value === 'Barangay Official';
        if (officialOnly) officialOnly.style.display = official ? '' : 'none';
        if (hint) hint.hidden = !official;
        if (residentOnly) residentOnly.style.display = official ? 'none' : '';
        if (residentReq) residentReq.style.display = official ? 'none' : '';
    };
    radios.forEach((r) => r.addEventListener('change', sync));
    sync();

    /* Password show / hide */
    const password = document.getElementById('password');
    const togglePass = document.querySelector('.toggle-pass');
    togglePass.addEventListener('click', () => {
        const show = password.type === 'password';
        password.type = show ? 'text' : 'password';
        togglePass.setAttribute('aria-pressed', String(show));
        togglePass.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    });
})();
</script>
<script src="<?= e(app_url('assets/js/app.js')) ?>"></script>
</body>
</html>