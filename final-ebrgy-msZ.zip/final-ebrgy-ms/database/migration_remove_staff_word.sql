-- Run this ONCE on an existing database (phpMyAdmin > SQL) if you do not want to re-import schema.sql / seed_50_each.sql.
-- It removes the word "Staff" from role names and from the demo login account. Passwords are unchanged ("password").
UPDATE roles SET name = 'Barangay Official' WHERE slug = 'staff';
UPDATE roles SET name = 'Senior Personnel'  WHERE slug = 'role_senior_staff';
UPDATE roles SET name = 'Junior Personnel'  WHERE slug = 'role_junior_staff';
UPDATE users SET full_name = 'Ramon Aquino', username = 'kagawad7', email = 'kagawad7@barangay.test'
 WHERE username = 'staff' AND email = 'staff@barangay.test';
