-- Bigaan AI: stores chatbot / insights / draft history. Safe to run more than once.
-- (The app also creates this table automatically the first time an AI feature is used.)
USE `e-bms-mine`;

CREATE TABLE IF NOT EXISTS ai_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    kind VARCHAR(30) NOT NULL,
    prompt TEXT NULL,
    response MEDIUMTEXT NULL,
    provider VARCHAR(30) NOT NULL DEFAULT 'local',
    created_at DATETIME NOT NULL,
    KEY idx_ai_user (user_id, created_at),
    KEY idx_ai_kind (kind),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
