<?php

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/ai.php';

require_module_access('ai');

ai_ensure_tables();
$isStaff = ai_is_staff();
$provider = ai_provider();
$user = current_user();
$recent = fetch_all(
    'SELECT kind, prompt, provider, created_at FROM ai_logs WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 8',
    [(int) $user['id']]
);

render_header('AI Assistant');
page_header('AI Assistant', 'Bigaan AI: chatbot, data insights at draft writer para sa barangay.');
?>
<section class="panel ai-status">
    <div class="panel-body ai-status-row">
        <span class="ai-badge"><?= icon('sparkle') ?>Engine: <?= e(ai_provider_label($provider)) ?></span>
        <small class="muted"><?= $provider === 'local'
            ? 'Gumagana nang offline gamit ang live na datos ng barangay. Maglagay ng API key sa config/ai.php para gumamit ng Gemini, Claude o OpenAI.'
            : 'Konektado sa language model. Mga bilang at pampublikong impormasyon lang ang ipinapadala, hindi ang pangalan ng residente.' ?></small>
    </div>
</section>

<section class="grid <?= $isStaff ? 'grid-2' : '' ?>">
    <div class="panel">
        <div class="panel-header"><h2>Barangay Assistant (chatbot)</h2><span class="muted">Tagalog / English</span></div>
        <div class="panel-body">
            <div data-ai-chat data-ai-print-url="<?= e(app_url('modules/ai_print.php')) ?>" data-ai-url="<?= e(app_url('modules/ai_api.php')) ?>" data-ai-token="<?= e(csrf_token()) ?>" data-ai-greeting="<?= e('Kumusta, ' . explode(' ', trim($user['full_name']))[0] . '! Ano ang maitutulong ko?') ?>" data-ai-suggestions="<?= e(json_encode(ai_suggestions(), JSON_UNESCAPED_UNICODE)) ?>" class="ai-chat ai-chat-page"></div>
        </div>
    </div>

    <?php if ($isStaff): ?>
    <div class="panel">
        <div class="panel-header"><h2>AI Insights (data analysis)</h2><button class="btn btn-ghost" type="button" data-ai-insights-run>Refresh analysis</button></div>
        <div class="panel-body" data-ai-insights data-ai-url="<?= e(app_url('modules/ai_api.php')) ?>" data-ai-token="<?= e(csrf_token()) ?>" data-ai-print-url="<?= e(app_url('modules/ai_print.php')) ?>">
            <p class="muted">Pindutin ang <b>Refresh analysis</b> para suriin ang pending requests, koleksyon, kaso at populasyon.</p>
        </div>
    </div>
    <?php endif; ?>
</section>

<?php if ($isStaff): ?>
<section class="panel">
    <div class="panel-header"><h2>AI Draft Writer (text generation)</h2><span class="muted">Anunsyo, imbitasyon, SMS at advisory</span></div>
    <div class="panel-body">
        <form class="form-grid" data-ai-print-url="<?= e(app_url('modules/ai_print.php')) ?>" data-ai-draft-form data-ai-url="<?= e(app_url('modules/ai_api.php')) ?>" data-ai-token="<?= e(csrf_token()) ?>" onsubmit="return false">
            <div class="form-field"><label>Uri ng mensahe</label>
                <select class="form-control" name="type"><?php foreach (ai_draft_types() as $key => $label): ?><option value="<?= e($key) ?>"><?= e($label) ?></option><?php endforeach; ?></select>
            </div>
            <div class="form-field"><label>Paksa / pamagat *</label><input class="form-control" name="topic" maxlength="160" placeholder="hal. Libreng medical mission" required></div>
            <div class="form-field"><label>Petsa at oras</label><input class="form-control" name="date" maxlength="60" placeholder="hal. Oktubre 20, 2026, 8:00 AM"></div>
            <div class="form-field"><label>Lugar</label><input class="form-control" name="venue" maxlength="120" placeholder="hal. Barangay Hall"></div>
            <div class="form-field" style="grid-column:1/-1"><label>Dagdag na detalye</label><textarea class="form-control" name="notes" rows="2" maxlength="400" placeholder="hal. Magdala ng valid ID. Para sa lahat ng senior."></textarea></div>
            <div style="grid-column:1/-1;display:flex;gap:10px;flex-wrap:wrap;align-items:center">
                <button class="btn" type="submit" data-ai-draft-run><?= icon('sparkle') ?>Generate draft</button>
                <a class="btn btn-ghost" href="<?= e(app_url('modules/records.php?module=announcements')) ?>">Open Announcements</a>
            </div>
        </form>
        <div class="ai-draft-out" data-ai-draft-out hidden>
            <label>Draft <small class="muted" data-ai-draft-engine></small></label>
            <textarea class="form-control" rows="9" data-ai-draft-text></textarea>
            <div class="ai-actions"><button class="btn btn-ghost" type="button" data-ai-copy>Copy text</button><a class="btn btn-ghost" href="#" target="_blank" rel="noopener" data-ai-print="draft" hidden>Print</a></div>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="panel">
    <div class="panel-header"><h2>Your recent AI activity</h2><span class="muted">Saved in the <code>ai_logs</code> table</span></div>
    <div class="table-wrap"><table>
        <thead><tr><th>When</th><th>Feature</th><th>Prompt</th><th>Engine</th></tr></thead>
        <tbody>
        <?php foreach ($recent as $row): ?>
            <tr><td><?= e(date('M j, g:i A', strtotime($row['created_at']))) ?></td><td><?= e(ucfirst($row['kind'])) ?></td><td><?= e(mb_strimwidth((string) $row['prompt'], 0, 80, '…')) ?></td><td><?= e(ai_provider_label($row['provider'])) ?></td></tr>
        <?php endforeach; ?>
        <?php if (!$recent): ?><tr><td colspan="4">Wala pang AI activity.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</section>
<?php render_footer(); ?>
