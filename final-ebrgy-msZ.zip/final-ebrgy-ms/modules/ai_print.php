<?php

/**
 * Prints AI output (a chat answer, a whole chat, insights or a draft) with the same themed
 * letterhead used for certificates and receipts (includes/print_layout.php).
 *   ai_print.php?id=12          one saved answer
 *   ai_print.php?ids=12,13,14   a whole conversation (in order)
 * Only the person who generated the item can print it.
 */

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/print_layout.php';
require_once __DIR__ . '/../includes/ai.php';

require_login();
require_module_access('ai');
ai_ensure_tables();

$user = current_user();
$ids = [];
foreach (explode(',', (string) ($_GET['ids'] ?? ($_GET['id'] ?? ''))) as $part) {
    $n = (int) trim($part);
    if ($n > 0) {
        $ids[$n] = $n;
    }
}
$ids = array_slice(array_values($ids), 0, 40);

$rows = [];
if ($ids) {
    $in = implode(',', array_fill(0, count($ids), '?'));
    $rows = fetch_all('SELECT * FROM ai_logs WHERE user_id = ? AND id IN (' . $in . ') ORDER BY id ASC', array_merge([(int) $user['id']], $ids));
}
if (!$rows) {
    http_response_code(404);
    echo '<!doctype html><meta charset="utf-8"><title>AI Print</title><div style="font-family:sans-serif;padding:40px;text-align:center;background:#fdecec;color:#a4262c"><h2>Walang makitang AI output na ipi-print.</h2><a href="javascript:history.back()">&larr; Bumalik</a></div>';
    exit;
}

$first = $rows[0];
$kind = count($rows) > 1 ? 'chat' : (string) $first['kind'];
$title = match ($kind) {
    'insights' => 'AI Insights Report',
    'draft' => 'AI Draft',
    'chat' => count($rows) > 1 ? 'AI Assistant: Chat Transcript' : 'AI Assistant: Answer',
    default => 'AI Assistant',
};
$engines = array_unique(array_map(fn ($r) => ai_provider_label((string) $r['provider']), $rows));

print_doc_open($title, ['back' => app_url('modules/ai.php'), 'office' => 'Office of the Punong Barangay']);
?>
<style>
    .ai-print { font-family: 'Nunito', 'Segoe UI', Arial, sans-serif; font-size: 14px; line-height: 1.65; color: #243021; }
    .ai-print p { margin: 0 0 3.2mm; text-indent: 0; text-align: left; }
    .ai-print ul, .ai-print ol { margin: 0 0 4mm 6mm; padding-left: 4mm; }
    .ai-print li { margin-bottom: 1.6mm; }
    .ai-print strong { color: #1d4a29; }
    .ai-print code { background: #f1ead0; padding: 0 4px; border-radius: 3px; }
    .ai-q { margin: 5mm 0 2mm; font-weight: 800; color: #2a7886; font-size: 12px; letter-spacing: .06em; text-transform: uppercase; }
    .ai-qtext { margin: 0 0 3mm; padding: 2.5mm 4mm; border-left: 1.2mm solid #e2a72e; background: #f8f2e0; font-weight: 700; }
    .ai-a { margin: 0 0 5mm; padding-bottom: 4mm; border-bottom: .3mm dashed #d9cfae; }
    .ai-note { margin-top: 4mm; font-size: 11px; color: #5b6b57; }
</style>
<div class="ai-print">
<?php
print_fields([
    'Petsa' => date('F j, Y, g:i A'),
    'Inihanda para kay' => $user['full_name'],
    'Role' => $user['role_name'] ?? '',
    'AI engine' => implode(', ', $engines),
]);
foreach ($rows as $row) {
    if ($kind === 'chat') {
        echo '<div class="ai-q">Tanong</div><div class="ai-qtext">' . e((string) $row['prompt']) . '</div><div class="ai-q">Sagot ng Bigaan AI</div>';
    }
    echo '<div class="ai-a">' . ($kind === 'draft' ? '<div class="doc-box-label">' . e((string) $row['prompt']) . '</div>' : '') . ai_md_html((string) $row['response']) . '</div>';
}
?>
    <p class="ai-note">Ang dokumentong ito ay binuo ng AI assistant at maaaring may pagkakamali. Kumpirmahin sa Barangay Hall bago gamitin bilang opisyal na batayan. Hindi ito sertipiko.</p>
</div>
            <div class="cert-ref"><span><b>Pinagmulan</b> Bigaan AI &middot; <?= e(APP_BARANGAY) ?></span><span><b>Ref</b> AI-<?= e(date('Ymd')) ?>-<?= (int) $first['id'] ?></span></div>
        </div>
    </div>
</body>
</html>
