<?php

require_once __DIR__ . '/../includes/bootstrap.php';

require_login();

$id = (int) ($_GET['id'] ?? 0);
$record = $id ? fetch_one(
    "SELECT service_records.*, residents.first_name, residents.middle_name, residents.last_name, residents.suffix,
            residents.address AS resident_address, residents.contact_no, residents.birth_date, residents.civil_status
     FROM service_records
     LEFT JOIN residents ON residents.id = service_records.resident_id
     WHERE service_records.id = ? AND service_records.module_slug IN ('documents', 'permits') AND service_records.deleted_at IS NULL",
    [$id]
) : null;

if (!$record || !can_access_module((string) $record['module_slug'])) {
    http_response_code(404);
    exit('Document request not found.');
}

if (role_slug() === 'resident') {
    http_response_code(403);
    exit('Requested documents are printed by barangay officials at the hall during pickup.');
}

function cert_notice(string $title, string $message): never
{
    http_response_code(409);
    echo '<!doctype html><meta charset="utf-8"><title>' . e($title) . '</title>'
        . '<div style="font-family:sans-serif;padding:40px;text-align:center;background:#fdecec;color:#a4262c">'
        . '<h2>' . e($title) . '</h2><p>' . e($message) . '</p>'
        . '<a href="javascript:history.back()" style="display:inline-block;margin-top:20px;padding:10px 24px;background:#2a7886;color:#fff;text-decoration:none;border-radius:8px">&larr; Bumalik</a></div>';
    exit;
}

if (!in_array($record['status'], release_statuses(), true)) {
    cert_notice('Not yet approved', 'Status: ' . $record['status'] . '. The certificate can be printed by an official after approval.');
}

$middle = trim((string) $record['middle_name']);
$fullName = trim($record['first_name'] . ' ' . ($middle !== '' ? mb_substr($middle, 0, 1) . '. ' : '') . $record['last_name'] . ' ' . ($record['suffix'] ?? ''));
if ($fullName === '') {
    $fullName = (string) $record['requester_name'];
}
$fullName = mb_strtoupper($fullName);

$type = (string) $record['category'];
$place = barangay_place();
$age = !empty($record['birth_date']) ? (int) (new DateTime((string) $record['birth_date']))->diff(new DateTime('today'))->y : null;
$civil = strtolower(trim((string) ($record['civil_status'] ?? '')));
$who = '<u>' . e($fullName) . '</u>' . ($age !== null ? ', ' . $age . ' yrs. old' : '') . ($civil !== '' ? ', ' . e($civil) : '');
$purpose = trim((string) $record['description']);

// Title and wording per document type (same tone as the barangay's printed certificates).
$title = 'CERTIFICATION';
$body = 'This is to certify that ' . $who . ' is a resident of ' . e($place) . '.';
if (stripos($type, 'Indigency') !== false) {
    $title = 'CERTIFICATE OF INDIGENCY';
    $body = 'This is to certify that ' . $who . ' and their family belongs to the indigent residents of ' . e($place) . '.';
} elseif (stripos($type, 'Residency') !== false) {
    $title = 'CERTIFICATE OF RESIDENCY';
    $body = 'This is to certify that ' . $who . ' is a bonafide resident of ' . e(trim((string) ($record['resident_address'] ?? '')) !== '' ? $record['resident_address'] . ', ' . $place : $place) . '.';
} elseif (stripos($type, 'Clearance') !== false && stripos($type, 'Business') === false) {
    $title = 'BARANGAY CLEARANCE';
    $body = 'This is to certify that ' . $who . ' is a resident of ' . e($place) . ' and has no derogatory record on file in this office as of this date.';
} elseif (stripos($type, 'Business') !== false) {
    $title = 'BUSINESS CLEARANCE';
    $body = 'This is to certify that ' . $who . ' is a resident of ' . e($place) . ' and is hereby cleared to operate' . ($purpose !== '' ? ' the business described as <u>' . e($purpose) . '</u>' : ' a business') . ' within this barangay, subject to existing laws and ordinances.';
    $purpose = '';
} elseif (stripos($type, 'Good Moral') !== false) {
    $title = 'CERTIFICATE OF GOOD MORAL CHARACTER';
    $body = 'This is to certify that ' . $who . ' is a resident of ' . e($place) . ', is of good moral character and has no pending case or derogatory record in this barangay.';
} elseif (stripos($type, 'Low Income') !== false) {
    $title = 'CERTIFICATE OF LOW INCOME';
    $body = 'This is to certify that ' . $who . ' is a resident of ' . e($place) . ' and belongs to a family with low income.';
} elseif (stripos($type, 'No Property') !== false) {
    $title = 'CERTIFICATE OF NO PROPERTY';
    $body = 'This is to certify that ' . $who . ' is a resident of ' . e($place) . ' and has no real property registered or known in this barangay.';
}

$issued = strtotime((string) $record['updated_at']) ?: time();
$day = (int) date('j', $issued);
$suffix = ($day % 100 >= 11 && $day % 100 <= 13) ? 'th' : ([1 => 'st', 2 => 'nd', 3 => 'rd'][$day % 10] ?? 'th');
$captain = fetch_one("SELECT users.full_name FROM users JOIN roles ON roles.id = users.role_id WHERE roles.slug = 'punong_barangay' AND users.status = 'Active' ORDER BY users.id LIMIT 1");
$captainName = trim((string) ($captain['full_name'] ?? ''));
if ($captainName !== '' && stripos($captainName, 'hon') !== 0) {
    $captainName = 'HON. ' . mb_strtoupper($captainName);
}
$verifyUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . app_url('public/verify.php?reference=' . urlencode($record['reference_no']));
$pdfName = preg_replace('/[^a-z0-9]+/i', '-', $type . '-' . $fullName);

// Optional images: drop these files into assets/img/ and they appear automatically.
$root = dirname(__DIR__) . '/assets/img/';
$optional = static fn (string $file): ?string => is_file($root . $file) ? app_url('assets/img/' . $file) : null;
$municipalSeal = app_url('assets/img/calauag-municipality-seal.jpg');
$signatureImg = $optional('signature.png');
$drySeal = $optional('dry-seal.png');
$barangaySeal = app_url('assets/img/logo.svg');

audit_log('Printed certificate', 'Documents', (int) $record['id'], $record['reference_no']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@500;600;700;800&family=Bitter:wght@700;800&display=swap">
    <title><?= e($title) ?> - <?= e($fullName) ?></title>
    <style>
        @page { size: A4 portrait; margin: 0; }
        * { box-sizing: border-box; margin: 0; padding: 0; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        :root { --forest:#1d4a29; --lime:#e2a72e; --teal:#2a7886; --sage:#f6f0dc; }
        body { font-family: Cambria, Georgia, 'Times New Roman', serif; background: #33513b; padding: 30px 0; color: #243021; }
        .preview-bar { max-width: 210mm; margin: 0 auto 20px; display: flex; justify-content: space-between; align-items: center; background: #1d4a29; padding: 12px 20px; border-radius: 14px; border: 1px solid #e2a72e; gap: 12px; flex-wrap: wrap; }
        .preview-title { color: #f6f0dc; font-family: 'Nunito', sans-serif; font-size: 14px; font-weight: 800; margin-top: 6px; }
        .preview-actions { display: flex; gap: 8px; flex-wrap: wrap; }
        .bar-btn { padding: 10px 20px; font: 800 13.5px 'Nunito', sans-serif; border-radius: 999px; cursor: pointer; border: none; text-decoration: none; color: #fff; }
        .bar-print { background: var(--lime); color: var(--forest); } .bar-back { background: rgba(255,255,255,.12); border: 1px solid rgba(255,255,255,.25); }

        .cert-paper { position: relative; width: 210mm; min-height: 297mm; margin: 0 auto; background: #fffdf6; padding: 15mm 18mm 12mm; display: flex; flex-direction: column; overflow: hidden; }
        /* decorative frame: thick forest border, thin lime inner line, corner blocks */
        .cert-paper:before { content: ""; position: absolute; inset: 5mm; border: 2.2mm solid var(--forest); border-radius: 3mm; pointer-events: none; }
        .cert-paper:after { content: ""; position: absolute; inset: 9.4mm; border: .5mm solid var(--lime); border-radius: 1.5mm; pointer-events: none; }
        .corner { position: absolute; width: 14mm; height: 14mm; background: var(--lime); border: 2.2mm solid var(--forest); z-index: 1; }
        .corner.tl { left: 3mm; top: 3mm; border-radius: 4mm 0 4mm 0; } .corner.tr { right: 3mm; top: 3mm; border-radius: 0 4mm 0 4mm; }
        .corner.bl { left: 3mm; bottom: 3mm; border-radius: 0 4mm 0 4mm; } .corner.br { right: 3mm; bottom: 3mm; border-radius: 4mm 0 4mm 0; }
        .top-band { position: relative; z-index: 2; margin: 3mm -3mm 0; height: 3.2mm; border-radius: 2mm; background: linear-gradient(90deg, var(--forest) 0 38%, var(--lime) 38% 56%, var(--teal) 56% 78%, #b3261e 78%); }
        .watermark { position: absolute; left: 50%; top: 53%; width: 140mm; height: 140mm; transform: translate(-50%, -50%); opacity: .08; pointer-events: none; }
        .cert-content { position: relative; z-index: 2; flex: 1; padding: 4mm 6mm 0; }
        .cert-head { display: grid; grid-template-columns: 44mm 1fr 30mm; align-items: center; gap: 6mm; }
        .cert-head .seal { width: 27mm; height: 27mm; object-fit: contain; }
        .cert-head .seal.right { justify-self: end; }
        .cert-locality { display: flex; align-items: center; gap: 3mm; color: var(--teal); font: 800 10pt 'Nunito', Arial, sans-serif; line-height: 1.2; }
        .cert-locality img { width: 20mm; height: 20mm; object-fit: contain; }
        .cert-center { text-align: center; font-family: 'Nunito', 'Segoe UI', Arial, sans-serif; line-height: 1.45; color: var(--forest); }
        .cert-center .gov { font-size: 15px; font-weight: 600; }
        .cert-office { text-align: center; font-family: 'Nunito', 'Segoe UI', Arial, sans-serif; margin-top: 8mm; padding: 3.5mm 0; background: var(--forest); color: #f6f0dc; border-radius: 3mm; }
        .cert-office b { display: block; font-size: 16px; font-weight: 800; letter-spacing: .6px; text-transform: uppercase; }
        .cert-office span { display: block; font-size: 15px; font-weight: 700; margin-top: 2px; color: var(--lime); }
        .cert-title { text-align: center; font: 800 31px 'Bitter', Georgia, 'Times New Roman', serif; letter-spacing: 1.5px; margin: 14mm 0 15mm; text-transform: uppercase; color: var(--forest); }
        .cert-title:after { content: ""; display: block; width: 46mm; height: 1.6mm; margin: 4mm auto 0; border-radius: 1mm; background: linear-gradient(90deg, var(--teal), var(--lime)); }
        .cert-body { font-size: 18px; line-height: 1.85; text-align: justify; }
        .cert-body p { margin-bottom: 11mm; text-indent: 14mm; }
        .cert-body p.no-indent { text-indent: 0; }
        .cert-body u { font-weight: 700; text-decoration: underline; text-decoration-color: var(--teal); text-underline-offset: 3px; padding: 0 5px; }
        .cert-body sup { font-size: .6em; }
        .cert-foot { position: relative; margin-top: 16mm; display: flex; justify-content: flex-end; }
        .sign { position: relative; min-width: 78mm; font-family: 'Nunito', 'Segoe UI', Arial, sans-serif; padding-top: 14mm; text-align: center; border-bottom: 0; }
        .sign img.sig { position: absolute; left: 50%; transform: translateX(-50%); top: -6mm; height: 26mm; max-width: 78mm; }
        .sign b { position: relative; display: block; font-size: 15.5px; font-weight: 800; text-transform: uppercase; padding-top: 2mm; border-top: .5mm solid var(--forest); color: var(--forest); }
        .sign span { position: relative; display: block; font-size: 14px; color: var(--teal); font-weight: 700; }
        .dry-seal { position: absolute; left: 50%; bottom: 14mm; width: 36mm; height: 36mm; transform: translateX(-50%); opacity: .55; z-index: 2; }
        .cert-ref { position: relative; margin: 10mm -6mm 0; padding: 2.6mm 6mm; font: 600 10px 'Nunito', Arial, sans-serif; color: #f3eed9; background: var(--forest); border-radius: 2mm; display: flex; justify-content: space-between; gap: 6mm; word-break: break-all; }
        .cert-ref b { color: var(--lime); white-space: nowrap; }
        @media print { .preview-bar { display: none !important; } body { background: #fff; padding: 0; } .cert-paper { width: 210mm; height: 297mm; min-height: 0; border: 0; } }
    </style>
</head>
<body>
    <div class="preview-bar">
        <div>
            <a class="bar-btn bar-back" href="javascript:window.close()">&larr; Close</a> <br>
            <br> <div class="preview-title"> Official Certificate Preview - <?= e($record['reference_no']) ?></div>
        </div>
        <div class="preview-actions">
            <button type="button" class="bar-btn bar-print" onclick="window.print()">Print at Barangay Hall</button>
        </div>
    </div>

    <div class="cert-paper" id="certPaper">
        <span class="corner tl"></span><span class="corner tr"></span><span class="corner bl"></span><span class="corner br"></span>
        <img class="watermark" src="<?= e($barangaySeal) ?>" alt="">
        <div class="cert-content">
            <div class="top-band"></div>
            <div class="cert-head" style="margin-top:6mm">
                <div class="cert-locality"><img src="<?= e($municipalSeal) ?>" alt="Municipality of Calauag seal"><strong>CALAUAG,<br>QUEZON</strong></div>
                <div class="cert-center">
                    <div class="gov">Republic of the Philippines</div>
                    <div class="gov">Province of <?= e(APP_PROVINCE) ?></div>
                    <div class="gov">Municipality of <?= e(APP_MUNICIPALITY) ?></div>
                </div>
                <img class="seal right" src="<?= e($barangaySeal) ?>" alt="Barangay seal">
            </div>
            <div class="cert-office"><b>Office of the Sangguniang Barangay</b><span><?= e(APP_BARANGAY) ?></span></div>

            <div class="cert-title"><?= e($title) ?></div>

            <div class="cert-body">
                <p class="no-indent"><strong>To whom it may concern,</strong></p>
                <p><?= $body ?></p>
                <p>Issued this <u><?= $day ?><sup><?= $suffix ?></sup></u> day of <u><?= e(strtoupper(date('F', $issued))) ?></u>, <strong><?= e(date('Y', $issued)) ?></strong> at <?= e($place) ?> upon request of the person mentioned above for whatever it may serve<?= $purpose !== '' ? ', particularly for <u>' . e($purpose) . '</u>' : '' ?>.</p>
            </div>

            <div class="cert-foot">
                <div class="sign">
                    <?php if ($signatureImg): ?><img class="sig" src="<?= e($signatureImg) ?>" alt="Signature"><?php endif; ?>
                    <b><?= e($captainName !== '' ? $captainName : 'HON. ____________________') ?></b>
                    <span>Punong Barangay</span>
                </div>
            </div>
            <div class="cert-ref"><span><b>Reference No.</b> <?= e($record['reference_no']) ?></span><span><b>Verify</b> <?= e($verifyUrl) ?></span></div>
        </div>
        <?php if ($drySeal): ?><img class="dry-seal" src="<?= e($drySeal) ?>" alt=""><?php endif; ?>
    </div>

</body>
</html>
