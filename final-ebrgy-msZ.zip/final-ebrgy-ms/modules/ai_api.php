<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/ai.php';

/** JSON endpoint for the AI features. POST only; CSRF is already verified by bootstrap.php. */
function ai_json(array $data, int $status = 200): never
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!is_logged_in()) {
    ai_json(['ok' => false, 'error' => 'Please log in again.'], 401);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    ai_json(['ok' => false, 'error' => 'Method not allowed.'], 405);
}
if (ai_rate_limited()) {
    ai_json(['ok' => false, 'error' => 'Sandali lang po. Masyadong maraming tanong sa isang minuto; subukan ulit mamaya.'], 429);
}

$action = (string) ($_POST['action'] ?? '');

try {
    if ($action === 'chat') {
        $message = trim((string) ($_POST['message'] ?? ''));
        if ($message === '') {
            ai_json(['ok' => false, 'error' => 'Type a question first.'], 422);
        }

        $history = [];
        $decoded = json_decode((string) ($_POST['history'] ?? '[]'), true);
        if (is_array($decoded)) {
            foreach (array_slice($decoded, -8) as $turn) {
                $role = ($turn['role'] ?? '') === 'assistant' ? 'assistant' : (($turn['role'] ?? '') === 'user' ? 'user' : null);
                $text = trim(mb_substr((string) ($turn['content'] ?? ''), 0, 600));
                if ($role !== null && $text !== '') {
                    $history[] = ['role' => $role, 'content' => $text];
                }
            }
        }

        $result = ai_chat($message, $history);
        ai_json(['ok' => true, 'reply' => $result['reply'], 'provider' => ai_provider_label($result['provider']), 'suggestions' => $result['suggestions'], 'log_id' => $result['log_id']]);
    }

    if ($action === 'insights') {
        if (!ai_is_staff()) {
            ai_json(['ok' => false, 'error' => 'Insights are for barangay officials only.'], 403);
        }
        $result = ai_insights();
        ai_json(['ok' => true, 'summary' => $result['summary'], 'items' => $result['items'], 'provider' => ai_provider_label($result['provider']), 'log_id' => $result['log_id']]);
    }

    if ($action === 'draft') {
        if (!ai_is_staff()) {
            ai_json(['ok' => false, 'error' => 'The draft writer is for barangay officials only.'], 403);
        }
        $topic = trim((string) ($_POST['topic'] ?? ''));
        if ($topic === '') {
            ai_json(['ok' => false, 'error' => 'Ilagay muna ang paksa o pamagat.'], 422);
        }
        $result = ai_draft((string) ($_POST['type'] ?? 'announcement'), $topic, (string) ($_POST['date'] ?? ''), (string) ($_POST['venue'] ?? ''), (string) ($_POST['notes'] ?? ''));
        ai_json(['ok' => true, 'text' => $result['text'], 'provider' => ai_provider_label($result['provider']), 'log_id' => $result['log_id']]);
    }

    ai_json(['ok' => false, 'error' => 'Unknown action.'], 400);
} catch (Throwable $e) {
    ai_json(['ok' => false, 'error' => 'Hindi makumpleto ng AI ang request ngayon. Subukan ulit.'], 500);
}
