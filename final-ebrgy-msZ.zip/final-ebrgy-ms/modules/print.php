<?php

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/print_layout.php';

require_login();

$user = current_user();
$isResident = role_slug() === 'resident';
$type = (string) ($_GET['type'] ?? '');
$id = (int) ($_GET['id'] ?? 0);
$form = (string) ($_GET['form'] ?? '');
$myResidentId = (int) fetch_value('SELECT resident_id FROM users WHERE id = ?', [(int) $user['id']]);

function print_deny(string $message, int $code = 403): never
{
    http_response_code($code);
    echo '<!doctype html><meta charset="utf-8"><title>Print</title>'
        . '<div style="font-family:sans-serif;padding:40px;text-align:center;background:#fdecec;color:#a4262c">'
        . '<h2>' . e($message) . '</h2>'
        . '<a href="javascript:history.back()" style="display:inline-block;margin-top:20px;padding:10px 24px;background:#2a7886;color:#fff;text-decoration:none;border-radius:8px">&larr; Bumalik</a></div>';
    exit;
}

function print_date(?string $value, string $format = 'F j, Y'): string
{
    $time = $value ? strtotime($value) : false;
    return $time ? date($format, $time) : '';
}

/* ------------------------------------------------------------------ Official Receipt */
if ($type === 'receipt') {
    $p = fetch_one('SELECT payments.*, users.full_name AS cashier FROM payments LEFT JOIN users ON users.id = payments.received_by WHERE payments.id = ?', [$id]);
    if (!$p) {
        print_deny('Receipt not found.', 404);
    }
    $own = $isResident && $myResidentId > 0 && (int) $p['resident_id'] === $myResidentId;
    if (!$own && ($isResident || !can_access_module('treasury'))) {
        print_deny('You are not allowed to print this receipt.');
    }
    audit_log('Printed receipt', 'Payments', (int) $p['id'], (string) $p['receipt_no']);
    print_doc_open('Official Receipt', ['size' => 'a5l', 'back' => app_url('modules/payments.php?receipt=' . (int) $p['id']), 'office' => 'Office of the Barangay Treasurer']);
    print_fields([
        'OR No.' => $p['receipt_no'],
        'Transaction ID' => $p['transaction_no'],
        'Date & time' => print_date($p['paid_at'], 'M j, Y g:i A'),
        'Received from' => $p['payer_name'],
        'Purpose' => $p['purpose'],
        'Payment method' => payment_method_label((string) $p['payment_method']) . (!empty($p['reference_number']) ? ' - Ref. ' . $p['reference_number'] : ''),
    ]);
    echo '<div class="doc-total"><span>AMOUNT PAID</span><strong>' . e(peso($p['amount'])) . '</strong></div>';
    print_doc_close((string) $p['receipt_no'], [[mb_strtoupper((string) ($p['cashier'] ?: 'Barangay Treasurer')), 'Barangay Treasurer / Collecting Officer']]);
    exit;
}

/* ------------------------------------------------------------------ Events */
if ($type === 'event') {
    if ($isResident || !can_access_module('events')) {
        print_deny('You are not allowed to print this.');
    }
    $ev = fetch_one('SELECT * FROM events WHERE id = ?', [$id]);
    if (!$ev) {
        print_deny('Event not found.', 404);
    }
    audit_log('Printed event notice', 'Events', (int) $ev['id'], (string) $ev['title']);
    print_doc_open('Notice of Event', ['back' => app_url('modules/events.php')]);
    print_fields([
        'Activity' => $ev['title'],
        'Status' => $ev['status'],
        'Date' => print_date($ev['event_date'], 'l, F j, Y'),
        'Time' => !empty($ev['event_time']) ? date('g:i A', strtotime((string) $ev['event_time'])) : '',
        'Venue' => $ev['location'],
        'Organizer' => $ev['organizer'],
    ]);
    print_box('Details / Paalala', (string) $ev['description'], '55mm');
    print_doc_close('EVT-' . str_pad((string) $ev['id'], 5, '0', STR_PAD_LEFT), [[mb_strtoupper((string) ($ev['organizer'] ?: 'Organizer')), 'Organizer'], [print_captain_name(), 'Punong Barangay']]);
    exit;
}

/* ------------------------------------------------------------------ Facility reservation */
if ($type === 'reservation') {
    $rv = fetch_one('SELECT facility_reservations.*, facilities.name AS facility_name, facilities.fee, facilities.capacity FROM facility_reservations JOIN facilities ON facilities.id = facility_reservations.facility_id WHERE facility_reservations.id = ?', [$id]);
    if (!$rv) {
        print_deny('Reservation not found.', 404);
    }
    $own = $isResident && $myResidentId > 0 && (int) $rv['resident_id'] === $myResidentId;
    if (!$own && ($isResident || !can_access_module('facilities'))) {
        print_deny('You are not allowed to print this.');
    }
    audit_log('Printed reservation slip', 'Facilities', (int) $rv['id'], (string) $rv['reference_no']);
    print_doc_open('Facility Reservation Slip', ['back' => app_url('modules/facilities.php')]);
    print_fields([
        'Reference No.' => $rv['reference_no'],
        'Status' => $rv['status'],
        'Facility' => $rv['facility_name'],
        'Capacity' => $rv['capacity'],
        'Applicant' => $rv['applicant_name'],
        'Fee' => peso($rv['fee']),
        'Date' => print_date($rv['reservation_date'], 'l, F j, Y'),
        'Time' => date('g:i A', strtotime((string) $rv['start_time'])) . ' - ' . date('g:i A', strtotime((string) $rv['end_time'])),
    ]);
    print_box('Purpose', (string) $rv['purpose'], '35mm');
    echo '<div class="cert-body"><p class="no-indent">Ipakita ang slip na ito sa Barangay Hall bago gamitin ang pasilidad. Ang approval ay nakadepende sa status sa itaas.</p></div>';
    print_doc_close((string) $rv['reference_no'], [[mb_strtoupper((string) $rv['applicant_name']), 'Applicant'], [print_captain_name(), 'Punong Barangay']]);
    exit;
}

/* ------------------------------------------------------------------ Resident information sheet */
if ($type === 'resident') {
    if ($isResident || !can_access_module('residents')) {
        print_deny('You are not allowed to print this.');
    }
    $r = fetch_one('SELECT residents.*, puroks.name AS purok_name FROM residents LEFT JOIN puroks ON puroks.id = residents.purok_id WHERE residents.id = ?', [$id]);
    if (!$r) {
        print_deny('Resident not found.', 404);
    }
    $tags = [];
    foreach (['is_pwd' => 'PWD', 'is_senior' => 'Senior Citizen', 'is_solo_parent' => 'Solo Parent', 'is_4ps' => '4Ps', 'is_ofw' => 'OFW', 'is_youth' => 'Youth'] as $col => $label) {
        if (!empty($r[$col])) {
            $tags[] = $label;
        }
    }
    audit_log('Printed resident sheet', 'Residents', (int) $r['id'], (string) $r['resident_no']);
    print_doc_open('Resident Information Sheet', ['back' => app_url('modules/residents.php')]);
    print_fields([
        'Resident No.' => $r['resident_no'],
        'Record status' => $r['status'],
        'Full name' => mb_strtoupper(resident_full_name($r)),
        'Sex' => $r['gender'],
        'Birth date' => print_date($r['birth_date']),
        'Civil status' => $r['civil_status'],
        'Contact no.' => $r['contact_no'],
        'Email' => $r['email'],
        'Address' => $r['address'],
        'Purok / Sitio' => $r['purok_name'],
        'Occupation' => $r['occupation'],
        'Education' => $r['education'],
        'Voter status' => $r['voter_status'],
        'Classification' => $tags ? implode(', ', $tags) : 'None',
    ]);
    print_box('Notes', (string) ($r['notes'] ?? ''), '28mm');
    print_doc_close((string) $r['resident_no'], [[mb_strtoupper(resident_full_name($r)), 'Resident'], [print_role_name('secretary', 'BARANGAY SECRETARY'), 'Barangay Secretary']]);
    exit;
}

/* ------------------------------------------------------------------ Household record sheet */
if ($type === 'household') {
    if ($isResident || !can_access_module('households')) {
        print_deny('You are not allowed to print this.');
    }
    $h = fetch_one('SELECT households.*, puroks.name AS purok_name, residents.first_name, residents.middle_name, residents.last_name, residents.suffix FROM households LEFT JOIN puroks ON puroks.id = households.purok_id LEFT JOIN residents ON residents.id = households.household_head_id WHERE households.id = ?', [$id]);
    if (!$h) {
        print_deny('Household not found.', 404);
    }
    $members = fetch_all('SELECT household_members.relationship, residents.* FROM household_members JOIN residents ON residents.id = household_members.resident_id WHERE household_members.household_id = ? ORDER BY household_members.id', [$id]);
    $headName = trim((string) ($h['first_name'] ?? '') . ' ' . (string) ($h['last_name'] ?? ''));
    audit_log('Printed household sheet', 'Households', (int) $h['id'], (string) $h['household_no']);
    print_doc_open('Household Record Sheet', ['back' => app_url('modules/households.php')]);
    print_fields([
        'Household No.' => $h['household_no'],
        'Status' => $h['status'],
        'Household head' => mb_strtoupper($headName),
        'Purok / Sitio' => $h['purok_name'],
        'Address' => $h['address'],
        'Classification' => $h['classification'],
        'Income bracket' => $h['income_bracket'],
        'Housing' => $h['housing_type'],
        'Utilities' => $h['utilities'],
        'Members' => count($members),
    ]);
    echo '<table class="doc-table"><thead><tr><th>#</th><th>Name</th><th>Relationship</th><th>Sex</th><th>Birth date</th></tr></thead><tbody>';
    foreach ($members as $i => $m) {
        echo '<tr><td>' . ($i + 1) . '</td><td>' . e(resident_full_name($m)) . '</td><td>' . e((string) $m['relationship']) . '</td><td>' . e((string) $m['gender']) . '</td><td>' . e(print_date($m['birth_date'], 'M j, Y')) . '</td></tr>';
    }
    if (!$members) {
        echo '<tr><td colspan="5">No members listed.</td></tr>';
    }
    echo '</tbody></table>';
    print_doc_close((string) $h['household_no'], [[mb_strtoupper($headName), 'Household Head'], [print_role_name('secretary', 'BARANGAY SECRETARY'), 'Barangay Secretary']]);
    exit;
}

/* ------------------------------------------------------------------ Service records: letters, slips, notices */
if ($type !== 'record') {
    print_deny('Unknown document type.', 404);
}

$record = fetch_one(
    "SELECT service_records.*, residents.first_name, residents.middle_name, residents.last_name, residents.suffix,
            residents.address AS resident_address, residents.contact_no
     FROM service_records
     LEFT JOIN residents ON residents.id = service_records.resident_id
     WHERE service_records.id = ? AND service_records.deleted_at IS NULL",
    [$id]
);
if (!$record) {
    print_deny('Record not found.', 404);
}

$slug = (string) $record['module_slug'];
$ownRecord = $isResident && $myResidentId > 0 && (int) $record['resident_id'] === $myResidentId;
if ($isResident && !$ownRecord) {
    print_deny('You are not allowed to print this.');
}
if (!$isResident && !can_access_module($slug)) {
    print_deny('You are not allowed to print this.');
}

if (in_array($slug, ['documents', 'permits'], true) && $form !== 'slip') {
    redirect('modules/certificate.php?id=' . (int) $record['id']);
}

$formsByModule = [
    'complaints' => ['letter', 'blotter', 'summons'],
    'katarungang' => ['summons', 'letter', 'settlement'],
    'peace_order' => ['incident'],
    'protection' => ['referral'],
    'services' => ['assistance'],
    'announcements' => ['notice'],
];
$allowedForms = array_merge($formsByModule[$slug] ?? [], ['slip']);
if ($isResident) {
    $allowedForms = ['slip'];
}
if ($form === '' || !in_array($form, $allowedForms, true)) {
    $form = $allowedForms[0];
}

$fullName = trim((string) $record['first_name'] . ' ' . (string) $record['last_name'] . ' ' . (string) ($record['suffix'] ?? ''));
$requester = mb_strtoupper($fullName !== '' ? $fullName : (string) $record['requester_name']);
$respondent = trim((string) ($record['respondent_name'] ?? ''));
$location = trim((string) ($record['location'] ?? ''));
$address = trim((string) ($record['resident_address'] ?? ''));
$ref = (string) $record['reference_no'];
$captain = print_captain_name();
$secretary = print_role_name('secretary', 'BARANGAY SECRETARY');
$backUrl = app_url('modules/records.php?module=' . urlencode($slug) . '&id=' . (int) $record['id']);
$u = static fn (string $v): string => '<u>' . e($v !== '' ? $v : '__________') . '</u>';

audit_log('Printed ' . $form, 'Records', (int) $record['id'], $ref);

if ($form === 'letter') {
    print_doc_open('Complaint Letter', ['back' => $backUrl]);
    echo '<div class="cert-body">';
    echo '<p class="no-indent">' . e(date('F j, Y')) . '</p>';
    echo '<p class="no-indent"><strong>' . e($captain) . '</strong><br>Punong Barangay<br>' . e(APP_BARANGAY) . ', ' . e(APP_MUNICIPALITY) . ', ' . e(APP_PROVINCE) . '</p>';
    echo '<p class="no-indent"><strong>Paksa: Reklamo' . ($respondent !== '' ? ' laban kay ' . e($respondent) : '') . '</strong></p>';
    echo '<p class="no-indent">Mahal na Punong Barangay:</p>';
    echo '<p>Ako po si ' . $u($requester) . ', residente ng ' . $u($address) . ', ay magalang na naghahain ng reklamo' . ($respondent !== '' ? ' laban kay ' . $u($respondent) : '') . ($location !== '' ? ' na naganap sa ' . $u($location) : '') . '. Ito po ang salaysay ng pangyayari:</p>';
    echo '</div>';
    print_box('Salaysay / Narrative', (string) $record['description'], '55mm');
    echo '<div class="cert-body"><p>Hinihiling ko po ang inyong mabuting tulong upang ito ay mapag-usapan at maayos alinsunod sa Katarungang Pambarangay. Maraming salamat po.</p></div>';
    print_doc_close($ref, [[$requester, 'Complainant'], [$secretary, 'Received by: Barangay Secretary']]);
} elseif ($form === 'blotter') {
    print_doc_open('Barangay Blotter Report', ['back' => $backUrl, 'office' => 'Office of the Punong Barangay']);
    print_fields([
        'Blotter / Case No.' => $ref,
        'Date filed' => print_date($record['created_at'], 'M j, Y g:i A'),
        'Complainant' => $requester,
        'Contact no.' => $record['contact_no'],
        'Respondent' => $respondent,
        'Incident location' => $location,
        'Category' => $record['category'],
        'Priority / Status' => $record['priority'] . ' / ' . $record['status'],
    ]);
    print_box('Details of the incident', (string) $record['description'], '60mm');
    print_doc_close($ref, [[$requester, 'Complainant'], [$secretary, 'Desk Officer'], [$captain, 'Punong Barangay']]);
} elseif ($form === 'summons') {
    $hearing = print_date($record['due_date']);
    print_doc_open('Summons / Notice of Hearing', ['back' => $backUrl, 'office' => 'Lupong Tagapamayapa']);
    echo '<div class="cert-body">';
    echo '<p class="no-indent"><strong>Kaso Blg.:</strong> ' . e($ref) . '</p>';
    echo '<p class="no-indent"><strong>Para kay:</strong> ' . $u(mb_strtoupper($respondent)) . '</p>';
    echo '<p>Ikaw ay ipinatatawag upang humarap sa Punong Barangay / Lupong Tagapamayapa sa ' . e(APP_BARANGAY) . ' Hall sa ' . $u($hearing) . ' para sa pagpapagitna sa reklamong inihain ni ' . $u($requester) . ($location !== '' ? ' na naganap sa ' . e($location) : '') . '.</p>';
    echo '<p>Ang hindi pagsipot nang walang katanggap-tanggap na dahilan ay maaaring magresulta sa pagpapalabas ng sertipikasyon upang magsampa ng kaso sa korte alinsunod sa Katarungang Pambarangay.</p>';
    echo '</div>';
    print_box('Maikling paglalarawan ng reklamo', (string) $record['description'], '35mm');
    print_doc_close($ref, [[$captain, 'Punong Barangay / Pangkat Chairperson'], [mb_strtoupper($respondent !== '' ? $respondent : 'Respondent'), 'Received by (Respondent)']]);
} elseif ($form === 'settlement') {
    print_doc_open('Kasunduan sa Pag-aayos', ['back' => $backUrl, 'office' => 'Lupong Tagapamayapa']);
    echo '<div class="cert-body">';
    echo '<p class="no-indent"><strong>Kaso Blg.:</strong> ' . e($ref) . '</p>';
    echo '<p>Kami, sina ' . $u($requester) . ' (Complainant) at ' . $u(mb_strtoupper($respondent)) . ' (Respondent), ay malayang nagkasundo na ayusin ang usapin tungkol sa ' . $u((string) $record['category']) . ' sa pamamagitan ng sumusunod na kasunduan:</p>';
    echo '</div>';
    print_box('Mga napagkasunduan', (string) $record['description'], '60mm');
    echo '<div class="cert-body"><p>Nilagdaan namin ito ngayong ' . e(date('j')) . '<sup>' . e(print_ordinal((int) date('j'))) . '</sup> araw ng ' . e(date('F Y')) . ' sa ' . e(barangay_place()) . '.</p></div>';
    print_doc_close($ref, [[$requester, 'Complainant'], [mb_strtoupper($respondent !== '' ? $respondent : 'Respondent'), 'Respondent'], [$captain, 'Punong Barangay']]);
} elseif ($form === 'incident') {
    print_doc_open('Incident / Patrol Report', ['back' => $backUrl, 'office' => 'Peace & Order Committee']);
    print_fields([
        'Report No.' => $ref,
        'Date' => print_date($record['created_at'], 'M j, Y g:i A'),
        'Reported by' => $requester,
        'Location' => $location,
        'Category' => $record['category'],
        'Status' => $record['status'],
    ]);
    print_box('Narrative of the incident', (string) $record['description'], '70mm');
    print_doc_close($ref, [[$requester, 'Reporting Officer / Tanod'], [$captain, 'Punong Barangay']]);
} elseif ($form === 'referral') {
    print_doc_open('Case Referral Form (Confidential)', ['back' => $backUrl, 'office' => 'BCPC / VAWC Desk']);
    print_fields([
        'Case No.' => $ref,
        'Date' => print_date($record['created_at'], 'M j, Y'),
        'Client' => $requester,
        'Category' => $record['category'],
        'Respondent' => $respondent,
        'Status' => $record['status'],
    ]);
    print_box('Summary of the case', (string) $record['description'], '60mm');
    echo '<div class="cert-body"><p class="no-indent"><em>Confidential. Para lamang sa awtorisadong tauhan ng barangay at kaukulang ahensiya.</em></p></div>';
    print_doc_close($ref, [[$secretary, 'Desk Officer'], [$captain, 'Punong Barangay']]);
} elseif ($form === 'assistance') {
    print_doc_open('Assistance Endorsement', ['back' => $backUrl]);
    echo '<div class="cert-body">';
    echo '<p class="no-indent"><strong>To whom it may concern,</strong></p>';
    echo '<p>This is to certify that ' . $u($requester) . ($address !== '' ? ' of ' . $u($address) : '') . ' is a resident of ' . e(barangay_place()) . ' and has requested <strong>' . e((string) $record['category']) . '</strong> from this office.</p>';
    echo '<p>Details of the request: ' . e((string) $record['description']) . '</p>';
    echo '<p>This endorsement is issued on ' . e(date('F j, Y')) . ' upon request of the person mentioned above for whatever legal purpose it may serve.</p>';
    echo '</div>';
    print_doc_close($ref, [[$captain, 'Punong Barangay']]);
} elseif ($form === 'notice') {
    print_doc_open('Public Notice', ['back' => $backUrl]);
    echo '<div class="cert-body"><p class="no-indent" style="text-align:center;font-size:1.25em"><strong>' . e((string) $record['title']) . '</strong></p>';
    echo '<p class="no-indent">' . nl2br(e((string) $record['description'])) . '</p>';
    echo '<p class="no-indent">Petsa ng paglabas: <strong>' . e(print_date($record['created_at'])) . '</strong></p></div>';
    print_doc_close($ref, [[$captain, 'Punong Barangay']]);
} else {
    print_doc_open('Request Acknowledgement Slip', ['size' => 'a5l', 'back' => $backUrl]);
    print_fields([
        'Reference No.' => $ref,
        'Date filed' => print_date($record['created_at'], 'M j, Y g:i A'),
        'Request' => $record['title'],
        'Category' => $record['category'],
        'Requester' => $requester,
        'Status' => $record['status'],
        'Fee' => peso($record['amount']),
        'Due date' => print_date($record['due_date']),
    ]);
    echo '<div class="cert-body"><p class="no-indent" style="font-size:13px">Itago ang slip na ito. Gamitin ang reference number sa ibabaw para i-track ang status ng iyong request sa online portal ng barangay.</p></div>';
    print_doc_close($ref, [[$secretary, 'Received by']]);
}
