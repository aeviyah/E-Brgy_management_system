# Login Accounts (50)

Password ng lahat: `password`

| # | Pangalan | Username | Email | Role | Portal |
|---|---|---|---|---|---|
| 1 | System Administrator | `admin` | admin@barangay.test | System Administrator | Official / Admin |
| 2 | Barangay Secretary | `secretary` | secretary@barangay.test | Barangay Secretary | Official / Admin |
| 3 | Barangay Treasurer | `treasurer` | treasurer@barangay.test | Barangay Treasurer | Official / Admin |
| 4 | Punong Barangay | `captain` | captain@barangay.test | Punong Barangay | Official / Admin |
| 5 | Ramon Aquino | `kagawad7` | kagawad7@barangay.test | Barangay Official | Official / Admin |
| 6 | Juan Dela Cruz | `juan` | juan@example.com | Resident | Resident |
| 7 | Eduardo Mendoza | `kagawad1` | kagawad1@barangay.test | Barangay Official | Official / Admin |
| 8 | Rosa Bautista | `kagawad2` | kagawad2@barangay.test | Barangay Official | Official / Admin |
| 9 | Noel Villanueva | `kagawad3` | kagawad3@barangay.test | Barangay Official | Official / Admin |
| 10 | Liza Navarro | `kagawad4` | kagawad4@barangay.test | Barangay Official | Official / Admin |
| 11 | Rey Castillo | `kagawad5` | kagawad5@barangay.test | Barangay Official | Official / Admin |
| 12 | Grace Domingo | `kagawad6` | kagawad6@barangay.test | Barangay Official | Official / Admin |
| 13 | Jericho Salvador | `skchair` | skchair@barangay.test | Barangay Official | Official / Admin |
| 14 | Hazel Pascual | `skkagawad1` | skkagawad1@barangay.test | Barangay Official | Official / Admin |
| 15 | Ana Reyes | `anareyes15` | ana@example.com | Resident | Resident |
| 16 | Carlo Garcia | `carlogarcia16` | carlo@example.com | Resident | Resident |
| 17 | Jun Magsaysay | `junmagsaysay17` | jun.magsaysay4@example.com | Resident | Resident |
| 18 | Manuel Reyes | `manuelreyes18` | manuel.reyes5@example.com | Resident | Resident |
| 19 | Jun Mendoza | `junmendoza19` | jun.mendoza6@example.com | Resident | Resident |
| 20 | Marites Soriano | `maritessoriano20` | marites.soriano7@example.com | Resident | Resident |
| 21 | Jenny Torres | `jennytorres21` | jenny.torres8@example.com | Resident | Resident |
| 22 | Noel Cruz | `noelcruz22` | noel.cruz9@example.com | Resident | Resident |
| 23 | Rey Fernandez | `reyfernandez23` | rey.fernandez10@example.com | Resident | Resident |
| 24 | Luz Mendoza | `luzmendoza24` | luz.mendoza11@example.com | Resident | Resident |
| 25 | Albert Pascual | `albertpascual25` | albert.pascual12@example.com | Resident | Resident |
| 26 | Perla Flores | `perlaflores26` | perla.flores13@example.com | Resident | Resident |
| 27 | Lorna Alcantara | `lornaalcantara27` | lorna.alcantara14@example.com | Resident | Resident |
| 28 | Cristina Navarro | `cristinanavarro28` | cristina.navarro15@example.com | Resident | Resident |
| 29 | Angelo Dela Cruz | `angelodelacruz29` | angelo.delacruz16@example.com | Resident | Resident |
| 30 | Jose Pascual | `josepascual30` | jose.pascual17@example.com | Resident | Resident |
| 31 | Cecilia Fernandez | `ceciliafernandez31` | cecilia.fernandez18@example.com | Resident | Resident |
| 32 | Noel Santos | `noelsantos32` | noel.santos19@example.com | Resident | Resident |
| 33 | Albert Bautista | `albertbautista33` | albert.bautista20@example.com | Resident | Resident |
| 34 | Cesar Mendoza | `cesarmendoza34` | cesar.mendoza21@example.com | Resident | Resident |
| 35 | Hazel Fernandez | `hazelfernandez35` | hazel.fernandez22@example.com | Resident | Resident |
| 36 | Ana Cruz | `anacruz36` | ana.cruz23@example.com | Resident | Resident |
| 37 | Dante Villanueva | `dantevillanueva37` | dante.villanueva24@example.com | Resident | Resident |
| 38 | Jenny Gonzales | `jennygonzales38` | jenny.gonzales25@example.com | Resident | Resident |
| 39 | Victor Flores | `victorflores39` | victor.flores26@example.com | Resident | Resident |
| 40 | Ernesto Navarro | `ernestonavarro40` | ernesto.navarro27@example.com | Resident | Resident |
| 41 | Flordeliza Gonzales | `flordelizagonzales41` | flordeliza.gonzales28@example.com | Resident | Resident |
| 42 | Rey Magsaysay | `reymagsaysay42` | rey.magsaysay29@example.com | Resident | Resident |
| 43 | Eduardo Flores | `eduardoflores43` | eduardo.flores30@example.com | Resident | Resident |
| 44 | Arnel Rivera | `arnelrivera44` | arnel.rivera31@example.com | Resident | Resident |
| 45 | Marites Garcia | `maritesgarcia45` | marites.garcia32@example.com | Resident | Resident |
| 46 | Manuel Bautista | `manuelbautista46` | manuel.bautista33@example.com | Resident | Resident |
| 47 | Cesar Fernandez | `cesarfernandez47` | cesar.fernandez34@example.com | Resident | Resident |
| 48 | Juan Soriano | `juansoriano48` | juan.soriano35@example.com | Resident | Resident |
| 49 | Albert Fernandez | `albertfernandez49` | albert.fernandez36@example.com | Resident | Resident |
| 50 | Manuel Soriano | `manuelsoriano50` | manuel.soriano37@example.com | Resident | Resident |
