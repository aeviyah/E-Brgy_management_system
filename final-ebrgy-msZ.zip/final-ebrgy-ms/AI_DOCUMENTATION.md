# Bigaan AI: documentation (Rubric items 2, 3 and 7)

## What the AI does

| Feature | Type of AI | Where | Who can use it |
|---|---|---|---|
| **Barangay Assistant** | Chatbot (Tagalog / English / Taglish) | Dashboard hero (beside "Magandang hapon") and `modules/ai.php` | Everyone logged in |
| **AI Insights** | Intelligent data analysis and recommendations | `modules/ai.php` → "Refresh analysis" | Officials only |
| **AI Draft Writer** | Text generation (announcement, event invitation, clean-up drive, SMS, advisory) | `modules/ai.php` | Officials only |

The chatbot has a built-in **knowledge base** (`includes/ai_knowledge.php`, about 40 topics) covering the website and Public Portal, accounts and login, document processes, fees and requirements, tracking and QR verification, complaints, Katarungang Pambarangay, VAWC/BCPC, officials, office hours and contacts, facilities, programs, health, day care, waste, senior/PWD/4Ps assistance, other IDs, privacy and how to use the system. Replies are formatted with short paragraphs, bullets and numbered steps.

**Role limits:** topics marked `for => 'staff'` (approving requests, recording payments, accounts and roles, reports, audit trail, confidential cases, backups, budget) are officials-only. A resident who asks gets a polite "officials only" answer, and those topics are never sent to the language model for residents. Nobody can get another person's private details from the AI.

**Printing:** every answer, a whole chat, the Insights report and Drafts have a Print link that uses the same themed letterhead as certificates (`modules/ai_print.php`).

The chatbot answers fees, requirements, how to request a document, the resident's own request status, events, facilities and complaint filing. For officials it also answers pending counts, collections and population questions from live database numbers.

## Two engines, one interface

1. **Local Barangay AI** (default, no setup, no internet): rule-based NLP (keyword and intent matching) plus live SQL analytics. Always works, so a demo cannot fail because of Wi-Fi or a missing key.
2. **Language model** (optional): paste a key in `config/ai.php` (or set an environment variable) and the same screens use a real LLM, grounded with the barangay's own fees, events and statistics.
   * `GEMINI_API_KEY`: free key at https://aistudio.google.com/apikey (recommended for students)
   * `ANTHROPIC_API_KEY`: Claude
   * `OPENAI_API_KEY`: OpenAI

If the model is slow, offline or returns an error, the system automatically falls back to the Local engine. The active engine is shown as a badge in the chat.

> XAMPP on Windows and "cURL error 60 / SSL certificate": for local testing only, set `'verify_ssl' => false` in `config/ai.php`.

## How it is connected to the system

```
Browser (assets/js/app.js)  --POST + CSRF token-->  modules/ai_api.php  --->  includes/ai.php
                                                                               |-- ai_stats() / SQL (PDO, prepared statements)
                                                                               |-- ai_llm()  (cURL, optional)
                                                                               |-- ai_local_answer() / ai_insights() / ai_draft()
                                                                               `-- ai_logs table (history)
```

* Role-based access uses the existing `can_access_module('ai')`, with an extra staff check on Insights and Draft Writer.
* Every request is a POST with the existing CSRF protection, and is rate-limited (`rate_limit`, default 20 per minute).
* All SQL uses prepared statements. Output is escaped in the browser with `textContent`.
* History is stored in `ai_logs` (user, feature, prompt, response, engine, time). The table is in `database/schema.sql` and `database/migration_ai.sql`, and is also created automatically on first use.

## Privacy

Only aggregate numbers and public information (fees, events, facility list) are sent to an outside model. Names, addresses and other residents' records are never sent. A resident can only ask about their own requests.

## How to use (for the user manual)

1. Log in. On the **Dashboard**, use the **Bigaan AI** box next to the greeting: type a question or tap a suggestion.
2. Open **AI Assistant** in the sidebar for the full chatbot.
3. Officials: **Refresh analysis** gives a summary plus warnings and recommendations. **Generate draft** creates an announcement, invitation, SMS or advisory that can be edited and copied into Announcements.
4. Always check AI drafts before publishing.

## Setup for existing databases

No action needed (the table is created automatically). Or import `database/migration_ai.sql` in phpMyAdmin.

## Acknowledgement of tools and generated content

* Google Gemini / Anthropic Claude / OpenAI APIs: optional language-model back ends, used only if the team adds a key.
* AI coding assistance (Claude by Anthropic) was used to help write and review parts of the source code and this documentation; the team is responsible for understanding and explaining it.
* Fonts: Bitter and Nunito (Google Fonts). Icons: inline SVG paths in `includes/layout.php`. Background photos: Barangay Bigaan aerial photos in `assets/img/photos`.
* PHP, PDO/MySQL, XAMPP/phpMyAdmin, plain JavaScript (no external JS libraries).

## Suggested demo flow (5 minutes)

1. Login as `secretary` → dashboard → ask the chatbot "Ilan ang pending requests?" and "Magkano ang Barangay Clearance?".
2. Login as `juan` (resident) → ask "Ano ang status ng requests ko?" and show that population/collection questions are refused.
3. AI Assistant page → Refresh analysis → explain how stats become recommendations.
4. Draft Writer → "Libreng medical mission" → copy into Announcements.
5. Show `ai_logs` in phpMyAdmin, then the dark/light toggle moving between pages without flashing.

## Likely Q&A

* **Why two engines?** Reliability: the demo works offline, and the LLM is an upgrade, not a dependency.
* **How do you stop made-up answers?** The model gets only listed facts and is told not to invent fees or dates; unknown questions are referred to the Barangay Hall.
* **Is resident data safe?** Aggregates only; role checks; CSRF; prepared statements; logs per user.
* **Where is the AI code?** `includes/ai.php` (logic), `modules/ai_api.php` (endpoint), `modules/ai.php` (page), `assets/js/app.js` (UI).
