<?php

require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

if (is_logged_in()) {
    redirect('dashboard.php');
}

/* ------------------------------------------------------------------
 * Page-local helpers (prefixed lg_ so they never clash with yours)
 * ------------------------------------------------------------------ */

/** Inline SVG icon (stroke style). */
function lg_icon(string $name): string
{
    static $paths = [
        'file'    => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h4"/>',
        'check'   => '<circle cx="12" cy="12" r="9"/><path d="m8.5 12.5 2.5 2.5 4.5-5"/>',
        'chart'   => '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
        'user'    => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
        'lock'    => '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
        'eye'     => '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
        'eye-off' => '<path d="M3 3l18 18"/><path d="M10.6 5.1A10 10 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4M6.5 6.6C3.7 8.3 2 12 2 12s3.5 7 10 7c1.6 0 3-.4 4.3-1"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
        'home'    => '<path d="M3 11.5 12 4l9 7.5"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
        'heart'   => '<path d="M12 20s-8-4.7-8-10.5A4.5 4.5 0 0 1 12 7a4.5 4.5 0 0 1 8 2.5C20 15.3 12 20 12 20z"/>',
    ];

    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'
        . ($paths[$name] ?? '') . '</svg>';
}

/**
 * Pull messages that other pages left in the session (e.g. after registering).
 * If your flash() helper uses a different session key, add it to the list.
 */
function lg_take_flashes(): array
{
    $allowed = ['success', 'warning', 'danger', 'info'];
    $out = [];

    foreach (['flashes', 'flash', 'flash_messages'] as $key) {
        if (empty($_SESSION[$key]) || !is_array($_SESSION[$key])) {
            continue;
        }
        foreach ($_SESSION[$key] as $k => $item) {
            if (is_array($item) && isset($item['message'])) {
                $type = (string) ($item['type'] ?? 'info');
                $out[] = ['type' => in_array($type, $allowed, true) ? $type : 'info', 'message' => (string) $item['message']];
            } elseif (is_string($item) && is_string($k)) {
                $out[] = ['type' => in_array($k, $allowed, true) ? $k : 'info', 'message' => $item];
            }
        }
        unset($_SESSION[$key]);
    }

    return $out;
}

/* ------------------------------------------------------------------
 * Login handling (same logic as before)
 * ------------------------------------------------------------------ */

$alerts = lg_take_flashes();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim((string) ($_POST['identifier'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $portal = ($_POST['portal'] ?? 'Resident') === 'Official' ? 'Official' : 'Resident';

    try {
        // Accept either the account email or the username.
        $user = fetch_one(
            'SELECT users.*, roles.slug AS role_slug, roles.name AS role_name
             FROM users
             JOIN roles ON roles.id = users.role_id
             WHERE users.email = ? OR users.username = ?',
            [$identifier, $identifier]
        );

        $portalMatches = $user && (($portal === 'Resident') === ($user['role_slug'] === 'resident'));

        if ($user && password_verify($password, $user['password']) && $portalMatches) {
            if ($user['status'] === 'Pending') {
                $alerts[] = ['type' => 'warning', 'message' => 'Your official account is waiting for approval by the System Administrator.'];
            } elseif ($user['status'] !== 'Active') {
                $alerts[] = ['type' => 'danger', 'message' => 'Your account is inactive. Please contact your barangay administrator.'];
            } else {
                session_regenerate_id(true);
                $_SESSION['user_id'] = (int) $user['id'];
                audit_log('Login', 'User', (int) $user['id'], 'User logged in successfully.');
                redirect('dashboard.php');
            }
        } else {
            audit_log('Failed login', 'User', null, 'Failed login attempt for ' . $identifier . ' (' . $portal . ' portal)');
            $alerts[] = ['type' => 'danger', 'message' => 'Wrong username/email, password, or portal. Check that you picked the right portal above.'];
        }
    } catch (Throwable $error) {
        $alerts[] = ['type' => 'danger', 'message' => 'Database connection failed. Check config/database.php and follow the setup or safe migration instructions in README.md.'];
    }
}

$logo = app_url('assets/img/logo.svg');

$points = [
    ['file',  'Request documents online', 'Clearance, residency and indigency certificates without the queue.'],
    ['check', 'Track every request',      'See each step from submitted to ready for pickup.'],
    ['chart', 'Open barangay budget',     'Read how public funds and projects are being used.'],
];

$services = [
    ['file',  'Barangay clearance',        'For jobs, IDs, and other official transactions.',          'Sign in to request'],
    ['home',  'Certificate of residency', 'Proof that you live in Barangay Bigaan.',                    'Sign in to request'],
    ['heart', 'Certificate of indigency', 'For assistance programs, scholarships, and medical help.',  'Sign in to request'],
    ['check', 'Track my request',         'Follow each step until your document is ready for pickup.', 'Sign in to track'],
];

$residentCount = 0;
try {
    $residentCount = (int) fetch_value("SELECT COUNT(*) FROM residents WHERE status = 'Active'");
} catch (Throwable $error) {
    $residentCount = 0;
}

$stats = [
    ['24/7', 'Online access sa mga serbisyo'],
    ['7',    'Uri ng dokumentong maaaring hilingin'],
    [number_format($residentCount), 'Residenteng nakatala sa sistema'],
];

$quick = [
    ['file',  'Clearance',   'Barangay clearance'],
    ['home',  'Residency',   'Certificate of residency'],
    ['heart', 'Indigency',   'Certificate of indigency'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sign in · E-Barangay Bigaan</title>
    <link rel="icon" href="<?= e($logo) ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bitter:wght@600;700;800&family=Nunito:wght@400;500;600;700;800&display=swap" media="print" onload="this.media='all'"><noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bitter:wght@600;700;800&family=Nunito:wght@400;500;600;700;800&display=swap"></noscript>
    <link rel="stylesheet" href="<?= e(app_url('assets/css/bg-scene.css')) ?>">
    <link rel="stylesheet" href="<?= e(app_url('assets/css/styles.css')) ?>">
    <link rel="stylesheet" href="<?= e(app_url('assets/css/landing.css')) ?>">
    <?= theme_boot_script() ?>
</head>
<body class="auth-page auth-login">
<?= bg_scene() ?>

<!-- Navigation -->
<header class="site-nav">
    <div class="nav-inner">
        <a class="brand" href="#home" aria-label="E-Barangay, back to top">
            <img src="<?= e($logo) ?>" alt="Seal of <?= e(APP_BARANGAY) ?>">
            <span>
                <strong>E-Barangay</strong>
                <small>Bigaan, Calauag, Quezon</small>
            </span>
        </a>
        <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="nav-menu" aria-label="Toggle menu">
            <span></span><span></span><span></span>
        </button>
        <nav id="nav-menu" class="nav-links" aria-label="Page sections">
            <a href="#home">Home</a>
            <a href="#services">Public services</a>
            <a href="#activities">Activities</a>
            <a href="#facilities">Facilities</a>
            <a href="#officials">Officials</a>
            <a href="#about">About</a>
            <button class="theme-toggle login-theme-toggle" type="button" data-theme-toggle aria-label="Switch theme" title="Switch theme"><span class="theme-toggle-icon" data-theme-icon aria-hidden="true">☾</span><span class="theme-toggle-label">Dark mode</span></button>
            <a class="nav-cta" href="<?= e(app_url('register.php')) ?>">Create account</a>
        </nav>
    </div>
</header>

<main>
    <!-- HOME -->
    <section id="home" class="page-section page-section--home" data-section>
        <div class="container">
            <div class="hero-grid">

                <!-- Column 1: copy -->
                <div class="auth-hero">
                    <p class="eyebrow">Barangay Bigaan, Calauag, Quezon</p>
                    <h1>Serbisyo ng Barangay, abot-kamay na.</h1>
                    <p class="lead">Request barangay documents, follow your application, and see what is happening in the community, all from one secure portal.</p>
                    <a class="cta" href="#services">Explore services <span aria-hidden="true">→</span></a>
                    <ul class="stats">
                        <?php foreach ($stats as [$num, $label]): ?>
                            <li><b><?= e($num) ?></b><span><?= e($label) ?></span></li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <!-- Column 2: sign in -->
                <div class="auth-card">
                    <h2>Welcome back</h2>
                    <p class="card-sub">Sign in to request and track your documents.</p>

                    <?php foreach ($alerts as $alert): ?>
                        <div class="alert alert-<?= e($alert['type']) ?>" role="alert"><?= e($alert['message']) ?></div>
                    <?php endforeach; ?>

                    <form method="post" class="login-form" autocomplete="on">
                        <fieldset class="portal-field">
                            <legend class="sr-only">Sign in to</legend>
                            <div class="portal-switch">
                                <label class="portal-option">
                                    <input type="radio" name="portal" value="Resident" <?= checked(old('portal', 'Resident') !== 'Official') ?>>
                                    <span>Resident</span>
                                </label>
                                <label class="portal-option">
                                    <input type="radio" name="portal" value="Official" <?= checked(old('portal', 'Resident') === 'Official') ?>>
                                    <span>Official / Admin</span>
                                </label>
                            </div>
                        </fieldset>

                        <div class="field">
                            <label for="identifier">Username</label>
                            <div class="input-wrap">
                                <span class="lead-icon"><?= lg_icon('user') ?></span>
                                <input class="form-control" id="identifier" type="text" name="identifier" placeholder="Enter your username" autocomplete="username" required>
                            </div>
                        </div>

                        <div class="field">
                            <label for="password">Password</label>
                            <div class="input-wrap">
                                <span class="lead-icon"><?= lg_icon('lock') ?></span>
                                <input class="form-control" id="password" type="password" name="password" placeholder="Enter your password" autocomplete="current-password" required>
                                <button class="toggle-pass" type="button" aria-label="Show password" aria-pressed="false">
                                    <span class="icon-on"><?= lg_icon('eye') ?></span>
                                    <span class="icon-off"><?= lg_icon('eye-off') ?></span>
                                </button>
                            </div>
                        </div>

                        <button class="btn" type="submit">Sign in</button>
                    </form>

                    <p class="card-foot">New to the portal? <a href="<?= e(app_url('register.php')) ?>">Register as a resident</a></p>

                    <?php if (APP_DEMO): ?>
                    <details class="demo-box">
                        <summary>Demo / Test Credentials (Click to Autofill)</summary>
                        <div class="demo-chips">
                            <?php foreach (['admin' => 'Administrator', 'secretary' => 'Secretary', 'treasurer' => 'Treasurer', 'captain' => 'Punong Barangay', 'kagawad7' => 'Kagawad', 'juan' => 'Resident'] as $uname => $label): ?>
                                <button type="button" data-demo-email="<?= e($uname) ?>" data-demo-portal="<?= $uname === 'juan' ? 'Resident' : 'Official' ?>" data-demo-password="password"><?= e($label) ?></button>
                            <?php endforeach; ?>
                        </div>
                    </details>
                    <?php endif; ?>
                </div>



            </div>
        </div>
    </section>

    <!-- PUBLIC SERVICES -->
    <section id="services" class="page-section" data-section aria-labelledby="services-title">
        <div class="container">
            <div class="panel">
                <div class="section-head"><h2 id="services-title">Public services</h2><p>Services you can request online from Barangay Bigaan. Sign in to your resident account to start a request.</p></div>
                <div class="service-grid">
                    <?php foreach ($services as [$icon, $title, $text, $cta]): ?>
                        <a class="service-card" href="#home" data-focus="identifier">
                            <span class="tile"><?= lg_icon($icon) ?></span>
                            <h3><?= e($title) ?></h3>
                            <p><?= e($text) ?></p>
                            <span class="card-link"><?= e($cta) ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- COMMUNITY ACTIVITIES -->
    <section id="activities" class="page-section" data-section aria-labelledby="activities-title">
        <div class="container">
            <div class="panel">
                <div class="section-head"><h2 id="activities-title">Mga Gawain sa Barangay</h2><p>Mga programang nagpapakita ng bayanihan, kalinisan at pangangalaga sa kalikasan.</p></div>
                <?= community_photo_cards(community_activities()) ?>
                <p class="community-disclaimer">Pindutin ang isang gawain para makita ang larawan at buong detalye nito.</p>
            </div>
        </div>
    </section>

    <!-- BARANGAY FACILITIES -->
    <section id="facilities" class="page-section" data-section aria-labelledby="facilities-title">
        <div class="container">
            <div class="panel">
                <div class="section-head"><h2 id="facilities-title">Mga Pasilidad ng Barangay</h2><p>Mga lugar na ginagamit ng mga residente. Pindutin ang pasilidad para makita ang oras, gamit at paano ito gamitin.</p></div>
                <?= community_photo_cards(community_facilities()) ?>
            </div>
        </div>
    </section>

    <!-- BARANGAY OFFICIALS -->
    <section id="officials" class="page-section" data-section aria-labelledby="officials-title">
        <div class="container">
            <div class="panel officials-section">
                <div class="section-head"><h2 id="officials-title">Mga Opisyal ng Barangay</h2><p>Mga lingkod-bayan ng Bigaan.</p></div>
                <?= community_officials_html() ?>
                <p class="officials-hint">Pindutin ang bilog ng opisyal para makita ang kanyang ID at tungkulin.</p>
            </div>
        </div>
    </section>

    <!-- ABOUT -->
    <section id="about" class="page-section page-section--end" data-section aria-labelledby="about-title">
        <div class="container">
            <div class="panel about-panel">
                <img class="about-seal-img" src="<?= e($logo) ?>" alt="Seal of <?= e(APP_BARANGAY) ?>">
                <div>
                    <h2 id="about-title">About Barangay Bigaan</h2>
                    <p class="panel-lead">Barangay Bigaan is in Calauag, Quezon. E-Barangay brings its everyday services online, so residents can request documents and follow their applications without waiting in line.</p>
                    <dl class="seal-facts">
                        <div><dt>Niyog</dt><dd>Coconut palms on the barangay seal.</dd></div>
                        <div><dt>Riles ng tren</dt><dd>The railway that runs through the seal.</dd></div>
                        <div><dt>Gabi at palay</dt><dd>Crops that grow in the community.</dd></div>
                    </dl>
                </div>
            </div>
            <footer class="site-footer">Barangay Bigaan, Calauag, Quezon &middot; E-Barangay System</footer>
        </div>
    </section>
</main>

<script>
(() => {
    'use strict';

    const nav = document.querySelector('.site-nav');
    const toggle = document.querySelector('.nav-toggle');
    const menu = document.getElementById('nav-menu');
    const navLinks = Array.from(document.querySelectorAll('.nav-links a[href^="#"]'));
    const sections = Array.from(document.querySelectorAll('[data-section]'));
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    const GAP = 12; // space kept between the nav bar and the top of a section

    /* Mobile menu */
    const setMenu = (open) => {
        menu.classList.toggle('is-open', open);
        toggle.setAttribute('aria-expanded', String(open));
    };
    toggle.addEventListener('click', () => setMenu(!menu.classList.contains('is-open')));
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setMenu(false); });
    document.addEventListener('click', (e) => {
        if (menu.classList.contains('is-open') && !nav.contains(e.target)) setMenu(false);
    });

    /* Active nav link */
    const setActive = (id) => {
        navLinks.forEach((a) => {
            const on = a.getAttribute('href') === '#' + id;
            a.classList.toggle('is-active', on);
            if (on) a.setAttribute('aria-current', 'true'); else a.removeAttribute('aria-current');
        });
    };

    /* Smooth scroll to a section (just below the nav bar) */
    const scrollToId = (id, opts = {}) => {
        const target = document.getElementById(id);
        if (!target) return false;
        const push = opts.push !== false;
        const top = id === 'home'
            ? 0
            : Math.max(0, target.getBoundingClientRect().top + window.scrollY - nav.offsetHeight - GAP);

        window.scrollTo({ top, behavior: reduceMotion.matches ? 'auto' : 'smooth' });
        if (push && location.hash !== '#' + id) history.pushState(null, '', '#' + id);

        if (opts.focusId) {
            window.setTimeout(() => {
                const el = document.getElementById(opts.focusId);
                if (el) el.focus({ preventScroll: true });
            }, reduceMotion.matches ? 0 : 700);
        }
        return true;
    };

    document.addEventListener('click', (e) => {
        const link = e.target.closest('a[href^="#"]');
        if (!link) return;
        const hash = link.getAttribute('href');
        if (hash.length < 2) return;
        if (scrollToId(decodeURIComponent(hash.slice(1)), { focusId: link.dataset.focus || null })) {
            e.preventDefault();
            setMenu(false);
        }
    });

    window.addEventListener('popstate', () => {
        scrollToId(decodeURIComponent(location.hash.slice(1)) || 'home', { push: false });
    });

    /* Scrollspy: the active section is the last one whose top has passed the nav bar */
    let ticking = false;
    const updateActive = () => {
        ticking = false;
        const line = nav.offsetHeight + GAP + 60;
        let current = sections[0].id;
        sections.forEach((s) => { if (s.getBoundingClientRect().top <= line) current = s.id; });
        if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 2) {
            current = sections[sections.length - 1].id;
        }
        setActive(current);
    };
    window.addEventListener('scroll', () => {
        if (!ticking) { ticking = true; window.requestAnimationFrame(updateActive); }
    }, { passive: true });
    window.addEventListener('resize', updateActive);
    updateActive();

    /* Password show / hide */
    const password = document.getElementById('password');
    const togglePass = document.querySelector('.toggle-pass');
    togglePass.addEventListener('click', () => {
        const show = password.type === 'password';
        password.type = show ? 'text' : 'password';
        togglePass.setAttribute('aria-pressed', String(show));
        togglePass.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    });

    /* Demo credentials autofill */
    const identifier = document.getElementById('identifier');
    document.querySelectorAll('[data-demo-email]').forEach((btn) => {
        btn.addEventListener('click', () => {
            identifier.value = btn.dataset.demoEmail || '';
            password.value = btn.dataset.demoPassword || '';
            const radio = document.querySelector('input[name="portal"][value="' + (btn.dataset.demoPortal || 'Resident') + '"]');
            if (radio) radio.checked = true;
            identifier.focus();
        });
    });
})();
</script>
<?= community_lightbox_html() ?>
<script src="<?= e(app_url('assets/js/app.js')) ?>"></script>
</body>
</html>