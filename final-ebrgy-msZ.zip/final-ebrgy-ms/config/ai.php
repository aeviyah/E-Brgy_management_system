<?php

/**
 * AI settings for the Barangay Assistant.
 *
 * The assistant ALWAYS works: with no API key it uses the built-in "Local Barangay AI"
 * (rule-based NLP + live database analytics). Add a key below (or as an environment
 * variable) and the same screens switch to a real large language model automatically.
 *
 *   provider : 'auto' (first provider that has a key), 'gemini', 'anthropic', 'openai' or 'local'
 *
 * Free key for students: https://aistudio.google.com/apikey  (Google Gemini)
 */
return [
    'provider'        => 'auto',

    'gemini_key'      => getenv('GEMINI_API_KEY') ?: '',
    'gemini_model'    => 'gemini-2.5-flash',

    'anthropic_key'   => getenv('ANTHROPIC_API_KEY') ?: '',
    'anthropic_model' => 'claude-haiku-5-5',

    'openai_key'      => getenv('OPENAI_API_KEY') ?: '',
    'openai_model'    => 'gpt-4o-mini',

    'timeout'         => 25,     // seconds
    'verify_ssl'      => true,   // XAMPP on Windows with "cURL error 60"? set to false for local testing only
    'rate_limit'      => 20,     // max AI requests per user per minute
];
