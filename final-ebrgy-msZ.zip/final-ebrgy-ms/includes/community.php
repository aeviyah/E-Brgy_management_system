<?php

declare(strict_types=1);

/**
 * Shared pieces for the login landing page and the public portal:
 * activity cards, facility cards, the officials circles + ID card, and the info viewer.
 *
 * PICTURES: every card has a 'slug'. The picture is looked up in
 *   assets/img/activities/<slug>.(jpg|jpeg|png|webp)   for activities
 *   assets/img/facilities/<slug>.(jpg|jpeg|png|webp)   for facilities
 * If no photo with that name exists, the built-in illustration <slug>.svg is shown instead.
 * So to use a real photo of your own barangay, just save it with the card's slug as the file name
 * (example: assets/img/facilities/barangay-hall.jpg). The picture always matches the label.
 *
 * Details ('info') are general descriptions. Edit the lists below to match the real schedule,
 * venue and contact person of Barangay Bigaan.
 */
function community_activities(): array
{
    return [
        [
            'slug' => 'linis-barangay', 'folder' => 'activities', 'tag' => 'Kalinisan', 'title' => 'Linis-Barangay',
            'text' => 'Sama-samang paglilinis ng kalsada, kanal at baybayin.',
            'about' => 'Regular na gawain kung saan nagtutulungan ang mga residente na linisin ang mga kalsada, kanal at dalampasigan para maging malinis at ligtas ang komunidad.',
            'info' => [['Iskedyul', 'Karaniwang tuwing Sabado ng umaga, 6:00 - 9:00 AM'], ['Lugar', 'Mga kalsada, kanal at tabing-dagat ng barangay'], ['Sino ang kasali', 'Mga residente, kabataan ng SK, tanod at mga opisyal'], ['Dalhin', 'Guwantes, walis, sako at sariling inumin'], ['Paano sumali', 'Magpatala sa barangay hall o abangan ang anunsyo sa Community Feed']],
        ],
        [
            'slug' => 'pagtatanim-bakawan', 'folder' => 'activities', 'tag' => 'Kalikasan', 'title' => 'Pagtatanim ng Bakawan',
            'text' => 'Pagtatanim at pagbabantay ng bakawan, kalasag ng baybayin.',
            'about' => 'Tumutulong ang bakawan na protektahan ang baybayin laban sa malalakas na alon at bagyo, at tahanan din ito ng mga isda at alimango.',
            'info' => [['Iskedyul', 'Isang beses kada ilang buwan, kapag mababa ang tubig'], ['Lugar', 'Baybayin at bakawanan ng barangay'], ['Sino ang kasali', 'Mga residente, mangingisda, estudyante at kabataan'], ['Dalhin', 'Pambahay na damit na puwedeng mabasa at putikan, tubig na inumin'], ['Paano sumali', 'Makipag-ugnayan sa barangay hall o sa mga lider ng purok']],
        ],
        [
            'slug' => 'feeding-program', 'folder' => 'activities', 'tag' => 'Kalusugan', 'title' => 'Feeding Program',
            'text' => 'Pagpapakain sa mga batang nangangailangan ng sustansya.',
            'about' => 'Programang naghahain ng masustansyang pagkain sa mga bata, kasama ang pagtitimbang at payo mula sa health worker ng barangay.',
            'info' => [['Iskedyul', 'Itinatakda ng barangay, karaniwang tuwing umaga'], ['Lugar', 'Day Care Center o barangay hall'], ['Para kanino', 'Mga batang nasa day care at mga batang kulang sa timbang'], ['Mga kasama', 'Barangay Health Worker, mga magulang at boluntaryo'], ['Paano sumali', 'Magtanong sa Barangay Health Worker o sa barangay hall']],
        ],
        [
            'slug' => 'libreng-checkup', 'folder' => 'activities', 'tag' => 'Kalusugan', 'title' => 'Libreng Check-up',
            'text' => 'Libreng konsulta at gamot para sa mga residente.',
            'about' => 'Medical mission kung saan makakapagpa-check ng presyon, timbang at makakakuha ng payo mula sa nars at doktor nang walang bayad.',
            'info' => [['Iskedyul', 'Ayon sa anunsyo ng barangay o ng Rural Health Unit'], ['Lugar', 'Barangay Health Center o barangay hall'], ['Para kanino', 'Lahat ng residente, lalo na ang senior citizen at PWD'], ['Dalhin', 'Valid ID at anumang lumang reseta o record'], ['Paano sumali', 'Dumating nang maaga; first come, first served']],
        ],
        [
            'slug' => 'palarong-barangay', 'folder' => 'activities', 'tag' => 'Palakasan', 'title' => 'Palarong Barangay',
            'text' => 'Liga ng basketbol at iba pang laro para sa kabataan.',
            'about' => 'Taunang palaro na pinangungunahan ng Sangguniang Kabataan para mailayo ang kabataan sa bisyo at mapalakas ang samahan ng mga purok.',
            'info' => [['Iskedyul', 'Karaniwang tuwing summer o kapag may pista'], ['Lugar', 'Covered Court ng barangay'], ['Sino ang kasali', 'Mga koponan ng bawat purok'], ['Pinamumunuan ng', 'Sangguniang Kabataan'], ['Paano sumali', 'Magpalista ang koponan sa SK bago ang araw ng liga']],
        ],
        [
            'slug' => 'pulong-barangay', 'folder' => 'activities', 'tag' => 'Pamamahala', 'title' => 'Pulong Barangay',
            'text' => 'Pagtitipon ng mga residente at opisyal para sa mahahalagang usapin.',
            'about' => 'Ang Barangay Assembly ay pagkakataon ng bawat residente na malaman ang ginagawa ng pamahalaang barangay, magtanong at magbigay ng mungkahi.',
            'info' => [['Iskedyul', 'Dalawang beses kada taon, ayon sa batas'], ['Lugar', 'Covered Court o barangay hall'], ['Sino ang kasali', 'Lahat ng residente na 15 taong gulang pataas'], ['Pinamumunuan ng', 'Punong Barangay'], ['Paano sumali', 'Dumalo sa araw ng pulong; ibibigay ang anunsyo sa Community Feed']],
        ],
    ];
}

function community_facilities(): array
{
    return [
        [
            'slug' => 'barangay-hall', 'folder' => 'facilities', 'tag' => 'Pasilidad', 'title' => 'Barangay Hall',
            'text' => 'Opisina ng mga opisyal at lugar ng mga serbisyo ng barangay.',
            'about' => 'Dito nakaupo ang Punong Barangay, Kagawad, Kalihim at Ingat-yaman. Dito rin kinukuha ang mga sertipiko, clearance at permit.',
            'info' => [['Oras', 'Lunes - Biyernes, 8:00 AM - 5:00 PM'], ['Lokasyon', 'Sentro ng ' . APP_BARANGAY], ['Mga serbisyo', 'Clearance, residency, indigency, blotter at iba pa'], ['Para kanino', 'Lahat ng residente'], ['Paano gamitin', 'Maaaring mag-request online sa E-Barangay at kunin ang dokumento sa hall']],
        ],
        [
            'slug' => 'health-center', 'folder' => 'facilities', 'tag' => 'Pasilidad', 'title' => 'Barangay Health Center',
            'text' => 'Pook para sa konsulta, bakuna at pagsusuri ng kalusugan.',
            'about' => 'Matatagpuan dito ang Barangay Health Worker at midwife para sa prenatal check-up, bakuna ng mga bata at payo sa kalusugan.',
            'info' => [['Oras', 'Lunes - Biyernes, 8:00 AM - 4:00 PM'], ['Mga serbisyo', 'Konsulta, bakuna, prenatal, pagtitimbang ng bata'], ['Para kanino', 'Mga buntis, sanggol, bata, senior citizen at lahat ng residente'], ['Mga kawani', 'Barangay Health Worker at midwife'], ['Paano gamitin', 'Pumunta nang walang bayad; magdala ng health record kung mayroon']],
        ],
        [
            'slug' => 'covered-court', 'folder' => 'facilities', 'tag' => 'Pasilidad', 'title' => 'Covered Court',
            'text' => 'Multi-purpose na court para sa palaro, pulong at pagdiriwang.',
            'about' => 'Ginagamit para sa basketbol, volleyball, pulong barangay, kasalan, pista at iba pang malalaking pagtitipon.',
            'info' => [['Oras', 'Araw-araw, 6:00 AM - 9:00 PM'], ['Gamit', 'Palakasan, pulong, pista at programa ng barangay'], ['Para kanino', 'Mga residente at samahan ng barangay'], ['Reserbasyon', 'Kailangan ng reserbasyon para sa pribadong okasyon'], ['Paano gamitin', 'Mag-sign in at buksan ang Facilities para mag-reserve ng oras']],
        ],
        [
            'slug' => 'day-care-center', 'folder' => 'facilities', 'tag' => 'Pasilidad', 'title' => 'Day Care Center',
            'text' => 'Paaralan at pangangalaga para sa mga batang maliliit.',
            'about' => 'Dito natututo ng alpabeto, bilang at magagandang asal ang mga batang 3 hanggang 5 taong gulang sa gabay ng Day Care Worker.',
            'info' => [['Oras', 'Lunes - Biyernes, 8:00 - 11:30 AM'], ['Para kanino', 'Mga batang 3 - 5 taong gulang'], ['Mga kawani', 'Day Care Worker'], ['Mga programa', 'Pag-aaral, feeding program at laro'], ['Paano mag-enroll', 'Magdala ng birth certificate at immunization record sa barangay hall']],
        ],
        [
            'slug' => 'tanod-outpost', 'folder' => 'facilities', 'tag' => 'Pasilidad', 'title' => 'Tanod Outpost',
            'text' => 'Bantayan ng mga barangay tanod para sa kapayapaan at kaayusan.',
            'about' => 'Dito nagpapahinga at nakaabang ang mga tanod na nagro-ronda at tumutugon sa mga ulat ng gulo, aksidente o emergency sa barangay.',
            'info' => [['Oras', 'Bukas buong araw at gabi, may nakaduty na tanod'], ['Mga serbisyo', 'Pagro-ronda, pag-aayos ng gulo, tulong sa emergency'], ['Para kanino', 'Lahat ng residente'], ['Pinamumunuan ng', 'Punong Barangay at Chief Tanod'], ['Paano makipag-ugnayan', 'Pumunta sa outpost o tumawag sa numero sa Emergency Contacts']],
        ],
        [
            'slug' => 'mrf', 'folder' => 'facilities', 'tag' => 'Pasilidad', 'title' => 'Materials Recovery Facility',
            'text' => 'Taguan at hiwalayan ng basurang nabubulok, recyclable at residual.',
            'about' => 'Dito dinadala ang mga hiwa-hiwalay na basura. Ang nabubulok ay ginagawang pataba, at ang recyclable ay napapakinabangan o naibebenta.',
            'info' => [['Oras', 'Lunes - Sabado, 7:00 AM - 4:00 PM'], ['Tinatanggap', 'Nabubulok, plastik, papel, bote at lata'], ['Para kanino', 'Lahat ng residente'], ['Paalala', 'Ihiwalay muna ang basura bago dalhin'], ['Paano gamitin', 'Dalhin ang hiwalay na basura sa oras ng operasyon']],
        ],
    ];
}

/** Finds the picture for a card: a real photo named after the slug wins; otherwise the illustration (.svg). */
function community_image_url(array $item): string
{
    $folder = (string) ($item['folder'] ?? 'activities');
    $slug = (string) $item['slug'];
    $dir = dirname(__DIR__) . '/assets/img/' . $folder . '/';
    foreach (['jpg', 'jpeg', 'png', 'webp', 'svg'] as $ext) {
        if (is_file($dir . $slug . '.' . $ext)) {
            return app_url('assets/img/' . $folder . '/' . $slug . '.' . $ext);
        }
    }

    return app_url('assets/img/' . $folder . '/' . $slug . '.svg');
}

/** Cards: each one is a button. Click = the picture zooms and the details open beside it (community_lightbox_html). */
function community_photo_cards(array $items): string
{
    $html = '';
    foreach ($items as $item) {
        $url = e(community_image_url($item));
        $info = e((string) json_encode($item['info'], JSON_UNESCAPED_UNICODE));
        $html .= '<button class="photo-card" type="button" data-info-open'
            . ' data-img="' . $url . '" data-title="' . e($item['title']) . '" data-tag="' . e($item['tag']) . '"'
            . ' data-about="' . e($item['about']) . '" data-info="' . $info . '"'
            . ' aria-label="Tingnan ang detalye: ' . e($item['title']) . '">'
            . '<span class="photo-frame"><img loading="lazy" src="' . $url . '" alt="' . e($item['title']) . '"></span>'
            . '<span class="photo-label"><small>' . e($item['tag']) . '</small><strong>' . e($item['title']) . '</strong><em>' . e($item['text']) . '</em></span>'
            . '</button>';
    }

    return '<div class="photo-grid">' . $html . '</div>';
}

function community_lightbox_html(): string
{
    return '<div class="info-modal" data-info-modal hidden role="dialog" aria-modal="true" aria-label="Detalye">'
        . '<div class="info-backdrop" data-info-close></div>'
        . '<article class="info-sheet" data-info-sheet>'
        . '<button class="info-close" type="button" data-info-close aria-label="Isara">&times;</button>'
        . '<div class="info-photo"><img src="" alt="" data-info-image></div>'
        . '<div class="info-body"><span class="info-tag" data-info-tag></span><h3 data-info-title></h3><p class="info-about" data-info-about></p><dl data-info-list></dl></div>'
        . '<button class="info-arrow info-prev" type="button" data-info-prev aria-label="Nakaraan">&lsaquo;</button>'
        . '<button class="info-arrow info-next" type="button" data-info-next aria-label="Susunod">&rsaquo;</button>'
        . '</article></div>';
}

function community_officials(): array
{
    $rows = [];
    try {
        $rows = fetch_all(
            "SELECT users.id, users.full_name, users.position
             FROM users JOIN roles ON roles.id = users.role_id
             WHERE users.status = 'Active' AND users.position IS NOT NULL AND users.position <> ''
               AND roles.slug IN ('punong_barangay','secretary','treasurer','staff')
             ORDER BY users.id"
        );
    } catch (Throwable $error) {
        $rows = [];
    }

    // 12 seats, in this order: Captain, Secretary, Treasurer, 7 Kagawad, SK Chairperson, SK Kagawad.
    $seats = [
        'Barangay Captain' => 1, 'Barangay Secretary' => 1, 'Barangay Treasurer' => 1,
        'Barangay Kagawad' => 7, 'SK Chairperson' => 1, 'SK Kagawad' => 1,
    ];
    $byPosition = [];
    foreach ($rows as $row) {
        $byPosition[(string) $row['position']][] = $row;
    }

    $list = [];
    foreach ($seats as $position => $count) {
        $found = $byPosition[$position] ?? [];
        for ($i = 0; $i < $count; $i++) {
            $list[] = $found[$i] ?? ['id' => 0, 'full_name' => $position, 'position' => $position];
        }
    }

    return $list;
}

/**
 * Officials: only round avatars at first. Clicking one zooms the avatar, then it opens
 * as an ID card (avatar + name + position on the left, details about the post on the right).
 * Behaviour: assets/js/app.js ("Officials" block).
 */
function community_officials_html(): string
{
    $logo = app_url('assets/img/logo.svg');
    $committees = ['Peace & Order', 'Health & Sanitation', 'Education & Culture', 'Infrastructure', 'Finance & Appropriations', 'Agriculture & Environment', 'Women, Family & Youth'];
    $roleInfo = [
        'Barangay Captain'   => ['Punong Barangay', 'Pinuno ng barangay; namumuno sa Sangguniang Barangay at sa mga programa ng komunidad.', 'captain'],
        'Barangay Kagawad'   => ['Sangguniang Barangay', 'Kasapi ng konseho; gumagawa ng ordinansa at namumuno sa isang komite.', 'kagawad'],
        'Barangay Secretary' => ['Talaan at Dokumentasyon', 'Nag-iingat ng mga talaan, sertipiko at katitikan ng pulong ng barangay.', 'council'],
        'Barangay Treasurer' => ['Pananalapi at Badyet', 'Humahawak ng koleksyon, resibo at pondo ng barangay.', 'council'],
        'SK Chairperson'     => ['Sangguniang Kabataan', 'Namumuno sa mga programa ng kabataan, palakasan at iskolarsip.', 'sk'],
        'SK Kagawad'         => ['Sangguniang Kabataan', 'Katuwang sa mga proyekto at gawain ng konseho ng kabataan.', 'sk'],
    ];
    $silhouette = '<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="22" r="12"/><path d="M10 60c1-14 9-22 22-22s21 8 22 22z"/></svg>';

    $dots = '';
    $kag = 0;
    foreach (community_officials() as $n => $official) {
        $name = (string) $official['full_name'];
        $pos = (string) $official['position'];
        $info = $roleInfo[$pos] ?? [$pos, 'Naglilingkod sa komunidad ng ' . APP_BARANGAY . '.', 'council'];
        $unit = $pos === 'Barangay Kagawad' ? $committees[$kag++ % count($committees)] : $info[0];
        $idNo = 'BRGY-OFC-' . str_pad((string) ($official['id'] ?: $n + 1), 4, '0', STR_PAD_LEFT);
        $initials = '';
        foreach (array_slice(preg_split('/\s+/', trim($name)) ?: [], 0, 2) as $part) {
            $initials .= mb_strtoupper(mb_substr($part, 0, 1));
        }

        $dots .= '<button class="official-dot is-' . e($info[2]) . '" type="button" data-official'
            . ' data-name="' . e($name) . '" data-pos="' . e($pos) . '" data-unit="' . e($pos === 'Barangay Kagawad' ? 'Komite: ' . $unit : $unit) . '"'
            . ' data-duty="' . e($info[1]) . '" data-idno="' . e($idNo) . '" data-initials="' . e($initials) . '"'
            . ' data-group="' . e($info[2]) . '" aria-label="' . e($name . ', ' . $pos . '. Pindutin para makita ang ID.') . '">'
            . '<span class="avatar-circle">' . $silhouette . '<b>' . e($initials) . '</b></span>'
            . '</button>';
    }

    $modal = '<div class="id-modal" data-id-modal hidden role="dialog" aria-modal="true" aria-label="Opisyal ng barangay">'
        . '<div class="id-backdrop" data-id-close></div>'
        . '<article class="id-sheet" data-id-sheet data-stage="zoom">'
        . '<button class="id-close" type="button" data-id-close aria-label="Isara">&times;</button>'
        . '<header class="id-band"><span class="id-slot" aria-hidden="true"></span><img src="' . e($logo) . '" alt=""><div><strong>' . e(APP_BARANGAY) . '</strong><small>Opisyal na ID &middot; ' . e(APP_MUNICIPALITY) . ', ' . e(APP_PROVINCE) . '</small></div></header>'
        . '<div class="id-body">'
        . '<div class="id-main"><div class="avatar-circle id-avatar" data-id-avatar>' . $silhouette . '<b data-id-initials></b></div>'
        . '<h3 data-id-name></h3><p class="id-role" data-id-pos></p><span class="id-no" data-id-no></span></div>'
        . '<aside class="id-aside"><dl>'
        . '<div><dt>Posisyon</dt><dd data-id-pos2></dd></div>'
        . '<div><dt>Tanggapan / Komite</dt><dd data-id-unit></dd></div>'
        . '<div><dt>Tungkulin</dt><dd data-id-duty></dd></div>'
        . '<div><dt>Oras ng Opisina</dt><dd>Lunes&ndash;Biyernes, 8:00 AM &ndash; 5:00 PM</dd></div>'
        . '<div><dt>Barangay</dt><dd>' . e(barangay_place()) . '</dd></div>'
        . '</dl></aside>'
        . '</div></article></div>';

    return '<div class="official-row">' . $dots . '</div>' . $modal;
}
