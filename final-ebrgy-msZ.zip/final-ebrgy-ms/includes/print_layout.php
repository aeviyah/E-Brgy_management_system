<?php
/**
 * Shared themed print template (same forest-green / lime look as the UI).
 * Used by modules/print.php for letters, slips, receipts and sheets.
 */

function print_ordinal(int $day): string
{
    return ($day % 100 >= 11 && $day % 100 <= 13) ? 'th' : ([1 => 'st', 2 => 'nd', 3 => 'rd'][$day % 10] ?? 'th');
}

function print_captain_name(): string
{
    $row = fetch_one("SELECT users.full_name FROM users JOIN roles ON roles.id = users.role_id WHERE roles.slug = 'punong_barangay' AND users.status = 'Active' ORDER BY users.id LIMIT 1");
    $name = trim((string) ($row['full_name'] ?? ''));
    if ($name !== '' && stripos($name, 'hon') !== 0) {
        $name = 'HON. ' . mb_strtoupper($name);
    }
    return $name !== '' ? $name : 'HON. ____________________';
}

function print_role_name(string $slug, string $fallback): string
{
    $row = fetch_one('SELECT users.full_name FROM users JOIN roles ON roles.id = users.role_id WHERE roles.slug = ? AND users.status = \'Active\' ORDER BY users.id LIMIT 1', [$slug]);
    $name = trim((string) ($row['full_name'] ?? ''));
    return $name !== '' ? mb_strtoupper($name) : $fallback;
}

function print_verify_url(string $reference): string
{
    return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . app_url('public/verify.php?reference=' . urlencode($reference));
}

/** Opens the page: head, preview bar, paper, frame and letterhead. $opts: size (a4|a5l), back, office */
function print_doc_open(string $title, array $opts = []): void
{
    $landscape = ($opts['size'] ?? 'a4') === 'a5l';
    $back = (string) ($opts['back'] ?? '');
    $office = (string) ($opts['office'] ?? 'Office of the Sangguniang Barangay');
    $municipalSeal = app_url('assets/img/calauag-municipality-seal.jpg');
    $barangaySeal = app_url('assets/img/logo.svg');
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@500;600;700;800&family=Bitter:wght@700;800&display=swap">
    <title><?= e($title) ?> - <?= e(APP_BARANGAY) ?></title>
    <style>
        @page { size: <?= $landscape ? 'A5 landscape' : 'A4 portrait' ?>; margin: 0; }
        * { box-sizing: border-box; margin: 0; padding: 0; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        :root { --forest:#1d4a29; --lime:#e2a72e; --teal:#2a7886; --sage:#f6f0dc; --ink:#243021; }
        body { font-family: Cambria, Georgia, 'Times New Roman', serif; background: #33513b; padding: 30px 0; color: var(--ink); }
        .preview-bar { max-width: <?= $landscape ? '210mm' : '210mm' ?>; margin: 0 auto 20px; display: flex; justify-content: space-between; align-items: center; background: #1d4a29; padding: 12px 20px; border-radius: 14px; border: 1px solid #e2a72e; gap: 12px; flex-wrap: wrap; }
        .preview-title { color: #f6f0dc; font: 800 14px 'Nunito', sans-serif; }
        .preview-actions { display: flex; gap: 8px; flex-wrap: wrap; }
        .bar-btn { padding: 10px 20px; font: 800 13.5px 'Nunito', sans-serif; border-radius: 999px; cursor: pointer; border: none; text-decoration: none; color: #fff; }
        .bar-print { background: var(--lime); color: var(--forest); } .bar-back { background: rgba(255,255,255,.12); border: 1px solid rgba(255,255,255,.25); }

        .cert-paper { position: relative; width: 210mm; min-height: <?= $landscape ? '148mm' : '297mm' ?>; margin: 0 auto; background: #fffdf6; padding: <?= $landscape ? '11mm 14mm 15mm' : '15mm 18mm 12mm' ?>; display: flex; flex-direction: column; overflow: hidden; }
        .cert-paper:before { content: ""; position: absolute; inset: 5mm; border: 2.2mm solid var(--forest); border-radius: 3mm; pointer-events: none; }
        .cert-paper:after { content: ""; position: absolute; inset: 9.4mm; border: .5mm solid var(--lime); border-radius: 1.5mm; pointer-events: none; }
        .corner { position: absolute; width: 14mm; height: 14mm; background: var(--lime); border: 2.2mm solid var(--forest); z-index: 1; }
        .corner.tl { left: 3mm; top: 3mm; border-radius: 4mm 0 4mm 0; } .corner.tr { right: 3mm; top: 3mm; border-radius: 0 4mm 0 4mm; }
        .corner.bl { left: 3mm; bottom: 3mm; border-radius: 0 4mm 0 4mm; } .corner.br { right: 3mm; bottom: 3mm; border-radius: 4mm 0 4mm 0; }
        .top-band { position: relative; z-index: 2; margin: 3mm -3mm 0; height: 3.2mm; border-radius: 2mm; background: linear-gradient(90deg, var(--forest) 0 38%, var(--lime) 38% 56%, var(--teal) 56% 78%, #b3261e 78%); }
        .watermark { position: absolute; left: 50%; top: 53%; width: <?= $landscape ? '100mm' : '140mm' ?>; height: <?= $landscape ? '100mm' : '140mm' ?>; transform: translate(-50%, -50%); opacity: .07; pointer-events: none; }
        .cert-content { position: relative; z-index: 2; flex: 1; padding: 4mm 6mm 0; display: flex; flex-direction: column; }
        .cert-head { display: grid; grid-template-columns: 44mm 1fr 30mm; align-items: center; gap: 6mm; margin-top: 5mm; }
        .cert-head .seal { width: <?= $landscape ? '20mm' : '27mm' ?>; height: <?= $landscape ? '20mm' : '27mm' ?>; object-fit: contain; justify-self: end; }
        .cert-locality { display: flex; align-items: center; gap: 3mm; color: var(--teal); font: 800 10pt 'Nunito', Arial, sans-serif; line-height: 1.2; }
        .cert-locality img { width: <?= $landscape ? '16mm' : '20mm' ?>; height: <?= $landscape ? '16mm' : '20mm' ?>; object-fit: contain; }
        .cert-center { text-align: center; font: 600 <?= $landscape ? '12px' : '15px' ?> 'Nunito', 'Segoe UI', Arial, sans-serif; line-height: 1.45; color: var(--forest); }
        .cert-office { text-align: center; font-family: 'Nunito', 'Segoe UI', Arial, sans-serif; margin-top: <?= $landscape ? '4mm' : '7mm' ?>; padding: 3mm 0; background: var(--forest); color: var(--sage); border-radius: 3mm; }
        .cert-office b { display: block; font-size: 15px; font-weight: 800; letter-spacing: .6px; text-transform: uppercase; }
        .cert-office span { display: block; font-size: 14px; font-weight: 700; margin-top: 2px; color: var(--lime); }
        .cert-title { text-align: center; font: 800 <?= $landscape ? '22px' : '27px' ?> 'Bitter', Georgia, 'Times New Roman', serif; letter-spacing: 1.2px; margin: <?= $landscape ? '6mm 0 5mm' : '10mm 0 9mm' ?>; text-transform: uppercase; color: var(--forest); }
        .cert-title:after { content: ""; display: block; width: 46mm; height: 1.6mm; margin: 3mm auto 0; border-radius: 1mm; background: linear-gradient(90deg, var(--teal), var(--lime)); }
        .cert-body { font-size: <?= $landscape ? '15px' : '17px' ?>; line-height: 1.8; text-align: justify; }
        .cert-body p { margin-bottom: 6mm; text-indent: 12mm; } .cert-body p.no-indent { text-indent: 0; }
        .cert-body u { font-weight: 700; text-decoration: underline; text-decoration-color: var(--teal); text-underline-offset: 3px; padding: 0 4px; }
        .cert-body sup { font-size: .6em; }
        .doc-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 3mm 8mm; margin: 0 0 6mm; font-family: 'Nunito', 'Segoe UI', Arial, sans-serif; }
        .doc-grid.cols-1 { grid-template-columns: 1fr; } .doc-grid.cols-3 { grid-template-columns: repeat(3, 1fr); }
        .doc-field { border-bottom: .3mm solid #d9cfae; padding-bottom: 1.4mm; min-width: 0; }
        .doc-field small { display: block; font-size: 9px; font-weight: 800; letter-spacing: .1em; text-transform: uppercase; color: var(--teal); }
        .doc-field b { display: block; font-size: 13.5px; font-weight: 700; color: var(--forest); word-break: break-word; }
        .doc-box { border: .4mm solid var(--forest); border-radius: 3mm; padding: 4mm 5mm; margin: 0 0 6mm; background: repeating-linear-gradient(transparent 0 26px, rgba(31,111,92,.18) 26px 27px); font-size: 15px; line-height: 27px; min-height: 40mm; white-space: pre-wrap; }
        .doc-box-label { font: 800 10px 'Nunito', sans-serif; letter-spacing: .12em; text-transform: uppercase; color: var(--teal); margin-bottom: 1.5mm; }
        .doc-total { display: flex; justify-content: space-between; align-items: center; margin: 2mm 0 6mm; padding: 4mm 6mm; border-radius: 4mm; background: linear-gradient(135deg, var(--forest), var(--teal)); color: var(--sage); font-family: 'Nunito', sans-serif; }
        .doc-total span { font-size: 12px; font-weight: 800; letter-spacing: .14em; } .doc-total strong { font-size: 26px; color: var(--lime); }
        table.doc-table { width: 100%; border-collapse: collapse; margin: 0 0 6mm; font: 600 12.5px 'Nunito', Arial, sans-serif; }
        .doc-table th { background: var(--forest); color: var(--lime); text-align: left; padding: 2.2mm 3mm; font-size: 11px; letter-spacing: .06em; text-transform: uppercase; }
        .doc-table td { padding: 2.2mm 3mm; border-bottom: .3mm solid #e6dcc0; } .doc-table tr:nth-child(even) td { background: #f8f2e0; }
        .sig-row { display: flex; justify-content: space-around; gap: 8mm; margin-top: auto; padding-top: 10mm; font-family: 'Nunito', 'Segoe UI', Arial, sans-serif; }
        .sign { min-width: 55mm; text-align: center; padding-top: 11mm; }
        .sign b { display: block; font-size: 13.5px; font-weight: 800; text-transform: uppercase; padding-top: 1.6mm; border-top: .5mm solid var(--forest); color: var(--forest); }
        .sign span { display: block; font-size: 12px; color: var(--teal); font-weight: 700; }
        .cert-ref { position: relative; margin: 6mm -6mm 0; padding: 2.4mm 6mm; font: 600 9.5px 'Nunito', Arial, sans-serif; color: #f3eed9; background: var(--forest); border-radius: 2mm; display: flex; justify-content: space-between; gap: 6mm; word-break: break-all; }
        .cert-ref b { color: var(--lime); white-space: nowrap; }
        @media print { .preview-bar { display: none !important; } body { background: #fff; padding: 0; } .cert-paper { width: <?= $landscape ? '210mm' : '210mm' ?>; height: <?= $landscape ? '148mm' : '297mm' ?>; min-height: 0; } }
    </style>
</head>
<body>
    <div class="preview-bar">
        <div><div class="preview-title"><?= e($title) ?></div></div>
        <div class="preview-actions">
            <?php if ($back !== ''): ?><a class="bar-btn bar-back" href="<?= e($back) ?>">&larr; Bumalik</a><?php endif; ?>
            <button type="button" class="bar-btn bar-print" onclick="window.print()">Print</button>
        </div>
    </div>
    <div class="cert-paper">
        <span class="corner tl"></span><span class="corner tr"></span><span class="corner bl"></span><span class="corner br"></span>
        <img class="watermark" src="<?= e($barangaySeal) ?>" alt="">
        <div class="cert-content">
            <div class="top-band"></div>
            <div class="cert-head">
                <div class="cert-locality"><img src="<?= e($municipalSeal) ?>" alt=""><strong>CALAUAG,<br>QUEZON</strong></div>
                <div class="cert-center"><div>Republic of the Philippines</div><div>Province of <?= e(APP_PROVINCE) ?></div><div>Municipality of <?= e(APP_MUNICIPALITY) ?></div></div>
                <img class="seal" src="<?= e($barangaySeal) ?>" alt="">
            </div>
            <div class="cert-office"><b><?= e($office) ?></b><span><?= e(APP_BARANGAY) ?></span></div>
            <div class="cert-title"><?= e($title) ?></div>
<?php
}

/** Closes the page. $signers: list of [name, role]. */
function print_doc_close(string $reference, array $signers = []): void
{
    ?>
            <?php if ($signers): ?>
            <div class="sig-row">
                <?php foreach ($signers as [$name, $role]): ?><div class="sign"><b><?= e($name) ?></b><span><?= e($role) ?></span></div><?php endforeach; ?>
            </div>
            <?php endif; ?>
            <div class="cert-ref"><span><b>Reference No.</b> <?= e($reference) ?></span><span><b>Verify</b> <?= e(print_verify_url($reference)) ?></span></div>
        </div>
    </div>
</body>
</html>
<?php
}

/** Prints a grid of label/value pairs. */
function print_fields(array $pairs, int $cols = 2): void
{
    echo '<div class="doc-grid' . ($cols === 1 ? ' cols-1' : ($cols === 3 ? ' cols-3' : '')) . '">';
    foreach ($pairs as $label => $value) {
        $value = trim((string) $value);
        echo '<div class="doc-field"><small>' . e((string) $label) . '</small><b>' . e($value !== '' ? $value : '-') . '</b></div>';
    }
    echo '</div>';
}

function print_box(string $label, string $text, string $minHeight = ''): void
{
    echo '<div class="doc-box-label">' . e($label) . '</div><div class="doc-box"' . ($minHeight ? ' style="min-height:' . e($minHeight) . '"' : '') . '>' . e($text) . '</div>';
}
