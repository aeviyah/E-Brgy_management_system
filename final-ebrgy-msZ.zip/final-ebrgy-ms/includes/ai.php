<?php

declare(strict_types=1);

/**
 * E-Barangay AI layer.
 *
 *  1. Barangay Assistant  (chatbot)            ai_chat()
 *  2. AI Insights         (data analysis)      ai_insights()
 *  3. AI Draft Writer     (text generation)    ai_draft()
 *
 * Two engines behind one interface:
 *  - LLM engine  : Gemini / Claude / OpenAI over cURL, grounded with live barangay data.
 *  - Local engine: rule-based NLP + SQL analytics. Used when no API key is set or the API fails,
 *                  so the system never shows a broken AI feature.
 *
 * Privacy: only aggregate numbers and public information (fees, events, announcements) are ever
 * sent to an external model. Names, addresses and other residents' records are never sent.
 */

require_once __DIR__ . '/ai_knowledge.php';

function ai_config(): array
{
    static $cfg = null;
    if ($cfg === null) {
        $file = __DIR__ . '/../config/ai.php';
        $cfg = is_file($file) ? (array) require $file : [];
    }
    return $cfg;
}

/** Active engine: gemini | anthropic | openai | local */
function ai_provider(): string
{
    $cfg = ai_config();
    $want = (string) ($cfg['provider'] ?? 'auto');
    $order = ['gemini', 'anthropic', 'openai'];

    if (!function_exists('curl_init')) {
        return 'local';
    }
    if (in_array($want, $order, true)) {
        return !empty($cfg[$want . '_key']) ? $want : 'local';
    }
    if ($want === 'local') {
        return 'local';
    }
    foreach ($order as $name) {
        if (!empty($cfg[$name . '_key'])) {
            return $name;
        }
    }
    return 'local';
}

function ai_provider_label(string $provider): string
{
    return match ($provider) {
        'gemini' => 'Google Gemini',
        'anthropic' => 'Claude (Anthropic)',
        'openai' => 'OpenAI',
        default => 'Local Barangay AI',
    };
}

function ai_ensure_tables(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    run_query(
        'CREATE TABLE IF NOT EXISTS ai_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NULL,
            kind VARCHAR(30) NOT NULL,
            prompt TEXT NULL,
            response MEDIUMTEXT NULL,
            provider VARCHAR(30) NOT NULL DEFAULT \'local\',
            created_at DATETIME NOT NULL,
            KEY idx_ai_user (user_id, created_at),
            KEY idx_ai_kind (kind)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
    );
}

function ai_log(string $kind, string $prompt, string $response, string $provider): int
{
    try {
        ai_ensure_tables();
        $user = current_user();
        run_query(
            'INSERT INTO ai_logs (user_id, kind, prompt, response, provider, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
            [$user['id'] ?? null, $kind, mb_substr($prompt, 0, 2000), mb_substr($response, 0, 8000), $provider]
        );
        return (int) db()->lastInsertId();
    } catch (Throwable $e) {
        return 0; // logging must never break the feature
    }
}

/** Tiny Markdown subset ("- " bullets, "1." steps, **bold**, `code`) to safe HTML. Used for printing. */
function ai_md_html(string $text): string
{
    $inline = function (string $t): string {
        $t = e($t);
        $t = preg_replace('/\*\*(.+?)\*\*/s', '<strong>$1</strong>', $t) ?? $t;
        return preg_replace('/`([^`]+)`/', '<code>$1</code>', $t) ?? $t;
    };
    $html = '';
    foreach (preg_split('/\n{2,}/', trim(str_replace("\r", '', $text))) ?: [] as $block) {
        $lines = array_values(array_filter(array_map('rtrim', explode("\n", $block)), fn ($l) => $l !== ''));
        $i = 0;
        $para = [];
        $flush = function () use (&$para, &$html, $inline): void {
            if ($para) {
                $html .= '<p>' . implode('<br>', array_map($inline, $para)) . '</p>';
                $para = [];
            }
        };
        while ($i < count($lines)) {
            if (preg_match('/^\s*[-•]\s+/u', $lines[$i])) {
                $flush();
                $html .= '<ul>';
                while ($i < count($lines) && preg_match('/^\s*[-•]\s+(.*)$/u', $lines[$i], $m)) {
                    $html .= '<li>' . $inline($m[1]) . '</li>';
                    $i++;
                }
                $html .= '</ul>';
            } elseif (preg_match('/^\s*\d+[.)]\s+/', $lines[$i])) {
                $flush();
                $html .= '<ol>';
                while ($i < count($lines) && preg_match('/^\s*\d+[.)]\s+(.*)$/', $lines[$i], $m)) {
                    $html .= '<li>' . $inline($m[1]) . '</li>';
                    $i++;
                }
                $html .= '</ol>';
            } else {
                $para[] = $lines[$i];
                $i++;
            }
        }
        $flush();
    }
    return $html;
}

/** True when the user has used up the per-minute allowance. */
function ai_rate_limited(): bool
{
    $limit = (int) (ai_config()['rate_limit'] ?? 20);
    $now = time();
    $hits = array_filter((array) ($_SESSION['ai_hits'] ?? []), fn ($t) => $t > $now - 60);
    if (count($hits) >= $limit) {
        $_SESSION['ai_hits'] = $hits;
        return true;
    }
    $hits[] = $now;
    $_SESSION['ai_hits'] = array_values($hits);
    return false;
}

function ai_is_staff(): bool
{
    return role_slug() !== 'resident';
}

/* ------------------------------------------------------------------ *
 * Knowledge the assistant can rely on
 * ------------------------------------------------------------------ */

/** Typical requirements per document. Barangay staff may ask for more. */
function ai_requirements(): array
{
    return [
        'Barangay Clearance' => 'Valid ID at patunay ng paninirahan sa barangay.',
        'Certificate of Indigency' => 'Valid ID at maikling dahilan ng pangangailangan (hal. scholarship, ayuda, medical).',
        'Certificate of Residency' => 'Valid ID at patunay ng paninirahan (hal. utility bill o household record).',
        'Business Permit Clearance' => 'Valid ID, pangalan at lokasyon ng negosyo, at DTI/Mayor\'s permit kung mayroon na.',
        'Good Moral Certificate' => 'Valid ID at layunin ng sertipiko (trabaho, paaralan, atbp.).',
        'Low Income Certificate' => 'Valid ID at patunay ng kita o trabaho ng sambahayan.',
        'No Property Certificate' => 'Valid ID at layunin ng sertipiko.',
    ];
}

/** Keyword => official document name, used to understand what the person is asking about. */
function ai_document_aliases(): array
{
    return [
        'Barangay Clearance' => ['clearance', 'barangay clearance'],
        'Certificate of Indigency' => ['indigency', 'indigent', 'mahirap', 'kahirapan'],
        'Certificate of Residency' => ['residency', 'resident certificate', 'paninirahan', 'cert of residency'],
        'Business Permit Clearance' => ['business', 'negosyo', 'permit', 'tindahan'],
        'Good Moral Certificate' => ['good moral', 'moral'],
        'Low Income Certificate' => ['low income', 'mababang kita'],
        'No Property Certificate' => ['no property', 'walang ari'],
    ];
}

function ai_match_document(string $text): ?string
{
    $text = mb_strtolower($text);
    // longest alias first so "business permit" wins over "permit"
    $pairs = [];
    foreach (ai_document_aliases() as $doc => $aliases) {
        foreach ($aliases as $alias) {
            $pairs[$alias] = $doc;
        }
    }
    uksort($pairs, fn ($a, $b) => mb_strlen($b) <=> mb_strlen($a));
    foreach ($pairs as $alias => $doc) {
        if (str_contains($text, $alias)) {
            return $doc;
        }
    }
    return null;
}

function ai_has(string $text, array $words): bool
{
    foreach ($words as $word) {
        if (str_contains($text, $word)) {
            return true;
        }
    }
    return false;
}

/* ------------------------------------------------------------------ *
 * Live data (aggregate only)
 * ------------------------------------------------------------------ */

function ai_stats(): array
{
    $one = fn (string $sql, array $p = []) => fetch_value($sql, $p);

    $pendingByModule = fetch_all(
        "SELECT module_slug, COUNT(*) AS total FROM service_records
         WHERE status = 'Pending' AND deleted_at IS NULL GROUP BY module_slug ORDER BY total DESC LIMIT 4"
    );
    $topPurok = fetch_one(
        "SELECT COALESCE(puroks.name, 'Unassigned') AS name, COUNT(residents.id) AS total
         FROM residents LEFT JOIN puroks ON puroks.id = residents.purok_id
         GROUP BY puroks.name ORDER BY total DESC LIMIT 1"
    );
    $res = fetch_one(
        'SELECT COUNT(*) AS total, COALESCE(SUM(is_senior = 1),0) AS seniors, COALESCE(SUM(is_pwd = 1),0) AS pwd,
                COALESCE(SUM(is_solo_parent = 1),0) AS solo, COALESCE(SUM(is_4ps = 1),0) AS fourps FROM residents'
    ) ?: ['total' => 0, 'seniors' => 0, 'pwd' => 0, 'solo' => 0, 'fourps' => 0];

    return [
        'residents' => (int) $res['total'],
        'seniors' => (int) $res['seniors'],
        'pwd' => (int) $res['pwd'],
        'solo_parents' => (int) $res['solo'],
        'four_ps' => (int) $res['fourps'],
        'households' => (int) $one('SELECT COUNT(*) FROM households'),
        'pending_total' => (int) $one("SELECT COUNT(*) FROM service_records WHERE status = 'Pending' AND deleted_at IS NULL"),
        'pending_documents' => (int) $one("SELECT COUNT(*) FROM service_records WHERE module_slug = 'documents' AND status = 'Pending' AND deleted_at IS NULL"),
        'overdue' => (int) $one("SELECT COUNT(*) FROM service_records WHERE status = 'Pending' AND deleted_at IS NULL AND due_date IS NOT NULL AND due_date < CURDATE()"),
        'oldest_pending_days' => (int) $one("SELECT COALESCE(MAX(DATEDIFF(CURDATE(), DATE(created_at))), 0) FROM service_records WHERE status = 'Pending' AND deleted_at IS NULL"),
        'open_cases' => (int) $one("SELECT COUNT(*) FROM service_records WHERE module_slug IN ('complaints','katarungang','protection') AND status = 'Pending' AND deleted_at IS NULL"),
        'approved_total' => (int) $one("SELECT COUNT(*) FROM service_records WHERE status = 'Approved' AND deleted_at IS NULL"),
        'rejected_total' => (int) $one("SELECT COUNT(*) FROM service_records WHERE status = 'Rejected' AND deleted_at IS NULL"),
        'collected_today' => (float) $one('SELECT COALESCE(SUM(amount),0) FROM payments WHERE DATE(paid_at) = CURDATE() AND deleted_at IS NULL'),
        'collected_7d' => (float) $one('SELECT COALESCE(SUM(amount),0) FROM payments WHERE paid_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) AND deleted_at IS NULL'),
        'collected_prev_7d' => (float) $one('SELECT COALESCE(SUM(amount),0) FROM payments WHERE paid_at >= DATE_SUB(CURDATE(), INTERVAL 13 DAY) AND paid_at < DATE_SUB(CURDATE(), INTERVAL 6 DAY) AND deleted_at IS NULL'),
        'collected_month' => (float) $one('SELECT COALESCE(SUM(amount),0) FROM payments WHERE YEAR(paid_at) = YEAR(CURDATE()) AND MONTH(paid_at) = MONTH(CURDATE()) AND deleted_at IS NULL'),
        'events_next_7d' => (int) $one("SELECT COUNT(*) FROM events WHERE status = 'Scheduled' AND event_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)"),
        'pending_reservations' => (int) $one("SELECT COUNT(*) FROM facility_reservations WHERE status = 'Pending'"),
        'top_purok' => $topPurok ? ['name' => $topPurok['name'], 'residents' => (int) $topPurok['total']] : null,
        'pending_by_module' => array_map(
            fn ($r) => ['module' => module_meta($r['module_slug'])['label'] ?? $r['module_slug'], 'pending' => (int) $r['total']],
            $pendingByModule
        ),
    ];
}

function ai_upcoming_events(int $limit = 5): array
{
    return fetch_all(
        "SELECT title, event_date, event_time, location FROM events
         WHERE status = 'Scheduled' AND event_date >= CURDATE() ORDER BY event_date, event_time LIMIT " . (int) $limit
    );
}

function ai_my_requests(int $limit = 5): array
{
    $rid = current_resident_id();
    if (!$rid) {
        return [];
    }
    return fetch_all(
        'SELECT reference_no, title, status, updated_at FROM service_records
         WHERE resident_id = ? AND deleted_at IS NULL ORDER BY updated_at DESC LIMIT ' . (int) $limit,
        [$rid]
    );
}

/* ------------------------------------------------------------------ *
 * LLM transport
 * ------------------------------------------------------------------ */

/**
 * @param array<int, array{role:string, content:string}> $messages  roles: user | assistant
 * @return string|null  model text, or null on any failure (caller falls back to the local engine)
 */
function ai_llm(string $system, array $messages, int $maxTokens = 600): ?string
{
    $provider = ai_provider();
    if ($provider === 'local') {
        return null;
    }
    $cfg = ai_config();
    $key = (string) $cfg[$provider . '_key'];
    $model = (string) $cfg[$provider . '_model'];
    $headers = ['Content-Type: application/json'];

    if ($provider === 'gemini') {
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent';
        $headers[] = 'x-goog-api-key: ' . $key;
        $contents = [];
        foreach ($messages as $m) {
            $contents[] = ['role' => $m['role'] === 'assistant' ? 'model' : 'user', 'parts' => [['text' => $m['content']]]];
        }
        $body = [
            'system_instruction' => ['parts' => [['text' => $system]]],
            'contents' => $contents,
            'generationConfig' => ['temperature' => 0.4, 'maxOutputTokens' => $maxTokens],
        ];
    } elseif ($provider === 'anthropic') {
        $url = 'https://api.anthropic.com/v1/messages';
        $headers[] = 'x-api-key: ' . $key;
        $headers[] = 'anthropic-version: 2023-06-01';
        $body = ['model' => $model, 'max_tokens' => $maxTokens, 'system' => $system, 'messages' => $messages];
    } else {
        $url = 'https://api.openai.com/v1/chat/completions';
        $headers[] = 'Authorization: Bearer ' . $key;
        $body = [
            'model' => $model,
            'max_tokens' => $maxTokens,
            'temperature' => 0.4,
            'messages' => array_merge([['role' => 'system', 'content' => $system]], $messages),
        ];
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_POSTFIELDS => json_encode($body, JSON_UNESCAPED_UNICODE),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => (int) ($cfg['timeout'] ?? 25),
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => (bool) ($cfg['verify_ssl'] ?? true),
        CURLOPT_SSL_VERIFYHOST => ($cfg['verify_ssl'] ?? true) ? 2 : 0,
    ]);
    $raw = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($raw === false || $code < 200 || $code >= 300) {
        return null;
    }
    $data = json_decode((string) $raw, true);
    if (!is_array($data)) {
        return null;
    }

    $text = match ($provider) {
        'gemini' => implode('', array_map(fn ($p) => (string) ($p['text'] ?? ''), (array) ($data['candidates'][0]['content']['parts'] ?? []))),
        'anthropic' => implode('', array_map(fn ($b) => ($b['type'] ?? '') === 'text' ? (string) $b['text'] : '', (array) ($data['content'] ?? []))),
        default => (string) ($data['choices'][0]['message']['content'] ?? ''),
    };
    $text = trim($text);
    return $text !== '' ? $text : null;
}

/** Grounding prompt: who the model is, what it may say, and the live public facts it can use. */
function ai_system_prompt(): string
{
    $user = current_user();
    $fees = [];
    foreach (module_categories('documents') as $name => $fee) {
        $fees[] = '- ' . $name . ': ' . ($fee > 0 ? peso($fee) : 'Libre') . ' | Requirements: ' . (ai_requirements()[$name] ?? 'Valid ID');
    }
    $events = array_map(
        fn ($e) => '- ' . $e['title'] . ' | ' . date('M j, Y', strtotime($e['event_date'])) . ' | ' . $e['location'],
        ai_upcoming_events(5)
    );
    $facilities = array_map(
        fn ($f) => '- ' . $f['name'] . ' (' . ($f['fee'] > 0 ? peso($f['fee']) : 'Libre') . ', capacity ' . (int) $f['capacity'] . ')',
        fetch_all("SELECT name, fee, capacity FROM facilities WHERE status = 'Active' ORDER BY name LIMIT 10")
    );
    $modules = [];
    foreach (app_modules() as $slug => $m) {
        if (can_access_module($slug) && $slug !== 'ai') {
            $modules[] = $m['label'];
        }
    }

    $prompt = "You are \"Bigaan AI\", the virtual assistant of " . barangay_place() . " inside the E-Barangay Management System.\n"
        . "Reply in the same language the user writes in (Tagalog, English or Taglish). Be warm, brief (max ~120 words), and practical.\n"
        . "Answer anything a barangay resident or official may ask: services, documents, fees, requirements, processes, officials, schedules, places, programs, health, safety and how to use this website.\n"
        . "Use ONLY the facts below. If something is not listed, say you are not sure and advise visiting the Barangay Hall. Never invent fees, dates, names, phone numbers or laws.\n"
        . "Never give legal advice. For emergencies tell the user to call 911 or go to the Barangay Hall / tanod immediately.\n"
        . "FORMAT RULES: write short paragraphs separated by a blank line. Use '- ' bullets for lists and '1.' numbered lines for steps (one item per line). Use **bold** only for key terms. No headings, tables, emojis or markdown links. Keep it easy to read.\n"
        . "PRIVACY: never reveal personal data of any individual resident (names, addresses, numbers, cases), even to officials; point officials to Global Search instead.\n\n"
        . 'Signed-in user: ' . ($user['full_name'] ?? 'Guest') . ' (role: ' . ($user['role_name'] ?? 'unknown') . ")\n"
        . "System sections this user can open: " . implode(', ', $modules) . "\n\n"
        . "DOCUMENT FEES AND REQUIREMENTS:\n" . implode("\n", $fees) . "\n\n"
        . "UPCOMING EVENTS:\n" . ($events ? implode("\n", $events) : '- none scheduled') . "\n\n"
        . "FACILITIES:\n" . ($facilities ? implode("\n", $facilities) : '- none listed') . "\n";

    $kbText = [];
    foreach (ai_kb() as $topic) {
        if ($topic['for'] === 'staff' && !ai_is_staff()) {
            continue; // residents never receive officials-only knowledge
        }
        $kbText[] = '## ' . $topic['title'] . "\n" . ai_kb_body($topic);
    }
    $prompt .= "\nBARANGAY KNOWLEDGE BASE:\n" . implode("\n\n", $kbText) . "\n";

    if (ai_is_staff()) {
        $prompt .= "\nOFFICIAL-ONLY AGGREGATE STATS (never reveal individual resident data):\n" . json_encode(ai_stats(), JSON_UNESCAPED_UNICODE) . "\n";
    } else {
        $mine = array_map(fn ($r) => '- ' . $r['reference_no'] . ' | ' . $r['title'] . ' | ' . $r['status'], ai_my_requests(5));
        $prompt .= "\nTHIS RESIDENT'S OWN RECENT REQUESTS:\n" . ($mine ? implode("\n", $mine) : '- none yet') . "\n"
            . "This user is a RESIDENT. If asked about officials-only matters (approving/rejecting requests, recording payments, user accounts and roles, reports and statistics, confidential VAWC/BCPC cases, other residents' data, backups, audit trail), politely say that this is for barangay officials only and offer what they can ask instead.\n";
    }
    return $prompt;
}

/* ------------------------------------------------------------------ *
 * 1. Chatbot
 * ------------------------------------------------------------------ */

/**
 * @param array<int, array{role:string, content:string}> $history previous turns (already sanitised)
 * @return array{reply:string, provider:string, suggestions:array<int,string>, log_id:int}
 */
function ai_chat(string $message, array $history = []): array
{
    $message = trim(mb_substr($message, 0, 600));
    $provider = ai_provider();
    $reply = null;

    if ($provider !== 'local') {
        $messages = array_slice($history, -6);
        $messages[] = ['role' => 'user', 'content' => $message];
        // providers need the first turn to be from the user
        while ($messages && $messages[0]['role'] !== 'user') {
            array_shift($messages);
        }
        $reply = ai_llm(ai_system_prompt(), $messages, 500);
    }

    if ($reply === null) {
        $provider = 'local';
        $reply = ai_local_answer($message);
    }

    $logId = ai_log('chat', $message, $reply, $provider);
    return ['reply' => $reply, 'provider' => $provider, 'suggestions' => ai_suggestions(), 'log_id' => $logId];
}

function ai_suggestions(): array
{
    if (ai_is_staff()) {
        return ['Ilan ang pending requests?', 'Magkano ang collection ngayon?', 'Ano ang mga paparating na event?', 'Magkano ang Barangay Clearance?'];
    }
    return ['Paano mag-request ng Barangay Clearance?', 'Magkano ang bayad sa mga dokumento?', 'Ano ang status ng requests ko?', 'May events ba this week?'];
}

/** Rule-based answer engine (works offline). Replies use the same Markdown-lite format as the LLM. */
function ai_local_answer(string $message): string
{
    $q = mb_strtolower(trim($message));
    $doc = ai_match_document($q);
    $staff = ai_is_staff();
    $user = current_user();
    $first = explode(' ', trim((string) ($user['full_name'] ?? '')))[0] ?: 'po';
    $fees = module_categories('documents');

    if ($q === '') {
        return 'Magtanong lang po tungkol sa mga dokumento, bayad, requirements, events o status ng request.';
    }

    // 1. Emergencies always come first
    if (ai_has($q, ['emergency', 'sunog', 'saklolo', 'tulong agad', 'holdap', 'may baril', 'nalulunod', 'may namatay'])) {
        return "**Kung may emergency, huwag nang maghintay ng sagot dito.**\n\n" . ai_bul([
            'Tumawag agad sa **911**.',
            'Pumunta sa pinakamalapit na **Tanod Outpost** o Barangay Hall.',
            'Ilayo ang sarili at ang mga bata sa panganib.',
        ]);
    }

    // 2. Nobody gets another person's private details from the assistant
    if (preg_match('/\b(address|numero|number|telepono|impormasyon|datos|detalye|kaso|reklamo|record)\s+ni\s+\p{L}+/u', $q)) {
        return "Hindi ko maibibigay ang personal na impormasyon ng sinumang residente para protektahan ang kanilang privacy.\n\n"
            . ($staff
                ? 'Kung kailangan mo ito sa trabaho, gamitin ang **Global Search** sa itaas. Nakabase ito sa pahintulot ng role mo at naitatala sa audit trail.'
                : 'Kung sarili mong impormasyon ang hanap mo, buksan ang iyong **Profile** (pindutin ang pangalan mo sa kanang itaas).');
    }

    // 3. Live numbers (officials)
    if ($staff && ai_has($q, ['pending', 'queue', 'need attention', 'naghihintay', 'ilan ang request', 'ilang request', 'backlog', 'ilan ang kaso', 'bukas na kaso']) && !ai_has($q, ['ibig sabihin', 'bakit'])) {
        $s = ai_stats();
        $out = 'Mayroong **' . $s['pending_total'] . '** na pending na request ngayon.' . "\n\n" . ai_bul([
            'Dokumento: ' . $s['pending_documents'],
            'Bukas na kaso: ' . $s['open_cases'],
            'Lampas sa due date: ' . $s['overdue'],
            'Pinakamatagal na naghihintay: ' . $s['oldest_pending_days'] . ' araw',
        ]);
        if ($s['pending_by_module']) {
            $out .= "\n\nPinakamarami sa:\n" . ai_bul(array_map(fn ($m) => $m['module'] . ' (' . $m['pending'] . ')', $s['pending_by_module']));
        }
        return $out . "\n\nBuksan ang **Certification Requests** para i-process.";
    }
    if ($staff && ai_has($q, ['collection', 'koleksyon', 'kinita', 'nakolekta', 'revenue', 'bayad ngayon', 'ilan ang nabayad'])) {
        $s = ai_stats();
        $trend = '';
        if ($s['collected_prev_7d'] > 0) {
            $pct = (int) round(($s['collected_7d'] - $s['collected_prev_7d']) / $s['collected_prev_7d'] * 100);
            $trend = "\n\nKumpara sa nakaraang 7 araw, " . ($pct >= 0 ? 'tumaas' : 'bumaba') . ' ito ng **' . abs($pct) . '%**.';
        }
        return "Ito ang koleksyon:\n" . ai_bul([
            'Ngayong araw: **' . peso($s['collected_today']) . '**',
            'Huling 7 araw: ' . peso($s['collected_7d']),
            'Ngayong buwan: ' . peso($s['collected_month']),
        ]) . $trend;
    }
    if ($staff && !$doc && ai_has($q, ['ilan ang resident', 'ilang resident', 'population', 'populasyon', 'ilan ang senior', 'ilan ang pwd', 'solo parent', '4ps', 'ilan ang household', 'ilang household', 'total na residente'])) {
        $s = ai_stats();
        $out = 'Nakarehistro ang **' . $s['residents'] . '** residente sa **' . $s['households'] . '** sambahayan.' . "\n\n" . ai_bul([
            'Senior citizen: ' . $s['seniors'],
            'PWD: ' . $s['pwd'],
            'Solo parent: ' . $s['solo_parents'],
            '4Ps: ' . $s['four_ps'],
        ]);
        if ($s['top_purok']) {
            $out .= "\n\nPinakamalaking Purok: **" . $s['top_purok']['name'] . '** (' . $s['top_purok']['residents'] . ' residente).';
        }
        return $out;
    }
    if (!$staff && ai_has($q, ['ilan ang resident', 'ilang resident', 'population', 'populasyon', 'collection', 'koleksyon', 'kinita', 'ilan ang pending', 'ilang request ang pending', 'audit', 'user account'])) {
        return "Ang impormasyong iyan ay para lang sa mga **opisyal ng barangay** (statistics, koleksyon at pamamahala ng sistema).\n\nMaaari kitang tulungan sa:\n" . ai_bul(['Requests at status mo', 'Bayad at requirements', 'Events, facilities at programa', 'Reklamo at proteksyon']);
    }

    // 4. Status of requests
    if (ai_has($q, ['status ng', 'status ko', 'request ko', 'requests ko', 'application ko', 'nasaan na', 'update sa request', 'kumusta na ang request'])) {
        if ($staff) {
            $s = ai_stats();
            return "Sa buong sistema:\n" . ai_bul(['Pending: ' . $s['pending_total'], 'Approved: ' . $s['approved_total'], 'Rejected: ' . $s['rejected_total']]) . "\n\nPara sa isang partikular na reference, gamitin ang **Global Search** sa itaas.";
        }
        $mine = ai_my_requests(5);
        if (!$mine) {
            return 'Wala ka pang request sa ngayon. Pumunta sa **Certification Requests** para mag-request ng dokumento.';
        }
        return "Ito ang pinakabago mong requests:\n" . ai_bul(array_map(fn ($r) => '**' . $r['reference_no'] . '**: ' . $r['title'] . ' (' . $r['status'] . ')', $mine)) . "\n\nKapag **Approved** na, maaari mo na itong kunin sa Barangay Hall.";
    }

    // 5. Requirements and fees (live fee schedule)
    if (ai_has($q, ['requirement', 'kailangan', 'dalhin', 'dala ', 'papeles', 'ano ang kelangan'])) {
        if ($doc) {
            $f = (float) ($fees[$doc] ?? 0);
            return '**' . $doc . "**\n\n" . ai_bul(['Requirements: ' . ai_requirements()[$doc], 'Bayad: ' . ($f > 0 ? peso($f) : 'Libre')]) . "\n\nMaaaring humingi pa ng dagdag na papeles ang barangay.";
        }
        $lines = [];
        foreach (ai_requirements() as $name => $req) {
            $lines[] = '**' . $name . '**: ' . $req;
        }
        return "Mga karaniwang requirements:\n" . ai_bul($lines);
    }
    if (ai_has($q, ['magkano', 'bayad sa', 'fee', 'presyo', 'singil', 'libre ba', 'price', 'how much'])) {
        if ($doc) {
            $f = (float) ($fees[$doc] ?? 0);
            return '**' . $doc . '**: ' . ($f > 0 ? '**' . peso($f) . '**' : '**Libre** (walang bayad)') . ".\n\nAwtomatikong nakalagay ang bayad sa request mo."
                . "\n\nTanungin mo rin ako tungkol sa requirements nito.";
        }
        $lines = [];
        foreach ($fees as $name => $fee) {
            $lines[] = '**' . $name . '**: ' . ($fee > 0 ? peso($fee) : 'Libre');
        }
        return "Ito ang fee schedule:\n" . ai_bul($lines);
    }

    // 6. Live events / announcements
    if (ai_has($q, ['event', 'kaganapan', 'schedule', 'this week', 'paparating', 'upcoming', 'sa linggo', 'ngayong buwan'])) {
        $events = ai_upcoming_events(5);
        if (!$events) {
            return 'Wala pang nakaiskedyul na event ngayon. Silipin ulit ang **Events & Activities** mamaya.';
        }
        return "Paparating na events:\n" . ai_bul(array_map(fn ($e) => '**' . $e['title'] . '**: ' . date('M j', strtotime($e['event_date'])) . ($e['event_time'] ? ', ' . date('g:i A', strtotime($e['event_time'])) : '') . ' sa ' . $e['location'], $events));
    }
    if (ai_has($q, ['announcement', 'anunsyo', 'balita', 'news', 'bagong abiso'])) {
        $rows = fetch_all("SELECT title FROM service_records WHERE module_slug = 'announcements' AND status = 'Approved' AND deleted_at IS NULL ORDER BY updated_at DESC LIMIT 3");
        if (!$rows) {
            return 'Walang opisyal na anunsyo sa ngayon.';
        }
        return "Pinakabagong anunsyo:\n" . ai_bul(array_map(fn ($r) => $r['title'], $rows));
    }

    // 7. Knowledge base (processes, people, places, services, how-to)
    $topic = ai_kb_match($q);
    if ($topic) {
        if ($topic['for'] === 'staff' && !$staff) {
            return "Ang paksang iyan (**" . $topic['title'] . "**) ay para lang sa mga **opisyal ng barangay**.\n\nMaaari kitang tulungan sa:\n" . ai_bul(['Paano mag-request ng dokumento', 'Bayad at requirements', 'Status ng request mo', 'Reklamo at proteksyon', 'Facilities, events at programa']);
        }
        return ai_kb_body($topic);
    }

    // 8. A document was named but no other intent
    if ($doc || ai_has($q, ['paano', 'how to', 'how do i', 'mag-request', 'magrequest', 'mag request', 'kumuha', 'apply'])) {
        $name = $doc ?: 'dokumento';
        if ($staff) {
            return 'Para i-process ang **' . $name . "**:\n\n" . ai_num(['Buksan ang **Certification Requests**.', 'Piliin ang request at suriin ang detalye.', 'I-**Approve** o i-**Reject**.', 'Sa approved, gamitin ang Print / Certificate.']);
        }
        $out = 'Para mag-request ng **' . $name . "**:\n\n" . ai_num([
            'Buksan ang **Certification Requests**.',
            'Piliin ang uri ng dokumento at ilagay ang detalye (puwedeng mag-upload ng ID o larawan).',
            'Hintayin ang approval ng opisyal; may notification kapag may update.',
            'Kunin ang dokumento sa Barangay Hall.',
        ]);
        if ($doc) {
            $f = (float) ($fees[$doc] ?? 0);
            $out .= "\n\n" . ai_bul(['Bayad: ' . ($f > 0 ? peso($f) : 'Libre'), 'Requirements: ' . ai_requirements()[$doc]]);
        }
        return $out;
    }

    // 9. Small talk
    if (ai_has($q, ['salamat', 'thanks', 'thank you', 'ok na', 'sige'])) {
        return 'Walang anuman! Narito lang ako kung may iba ka pang tanong.';
    }
    if (ai_has($q, ['hello', 'kumusta', 'musta', 'magandang', 'hey']) || preg_match('/^(hi|hoy|po)\b/u', $q) || mb_strlen($q) < 3) {
        return 'Magandang araw, **' . $first . "**! Ako si **Bigaan AI**.\n\nMaaari mo akong tanungin tungkol sa:\n" . ai_bul($staff
            ? ['Pending requests, koleksyon at populasyon', 'Proseso ng approval at pagbabayad', 'Dokumento, events at facilities']
            : ['Dokumento: bayad at requirements', 'Status ng request mo', 'Reklamo, facilities at events']);
    }

    return "Pasensya na, hindi ako sigurado sa sagot diyan, at ayaw kong magbigay ng maling impormasyon.\n\nSubukan mong itanong ang:\n" . ai_bul($staff
        ? ['"Ilan ang pending requests?"', '"Paano mag-approve ng request?"', '"Sino ang mga opisyal?"', '"Anong oras bukas ang Barangay Hall?"']
        : ['"Paano mag-request ng Barangay Clearance?"', '"Paano magreklamo?"', '"Sino ang kapitan?"', '"Anong oras bukas ang Barangay Hall?"'])
        . "\n\nPara sa ibang concern, pumunta sa **Barangay Hall**.";
}

/* ------------------------------------------------------------------ *
 * 2. Insights (data analysis, officials only)
 * ------------------------------------------------------------------ */

/**
 * @return array{summary:string, items:array<int,array{level:string,title:string,text:string}>, provider:string, stats:array, log_id:int}
 */
function ai_insights(): array
{
    $s = ai_stats();
    $items = [];
    $add = function (string $level, string $title, string $text) use (&$items): void {
        $items[] = ['level' => $level, 'title' => $title, 'text' => $text];
    };

    // Workload
    if ($s['pending_total'] === 0) {
        $add('good', 'Walang backlog', 'Wala nang pending na request. Magaling!');
    } elseif ($s['overdue'] > 0 || $s['oldest_pending_days'] >= 7) {
        $add('warn', 'May naantalang request', $s['pending_total'] . ' ang pending; ' . $s['overdue'] . ' ang lampas due date at ang pinakamatagal ay ' . $s['oldest_pending_days'] . ' araw na. Unahin ang pinakamatagal.');
    } else {
        $add('info', 'Normal ang workload', $s['pending_total'] . ' ang pending, at wala pang lampas sa due date.');
    }

    // Where the queue is
    if ($s['pending_by_module']) {
        $top = $s['pending_by_module'][0];
        $add('info', 'Pinakamataas na pila', $top['module'] . ' ang may pinakamaraming pending (' . $top['pending'] . '). Isaalang-alang ang paglalaan ng dagdag na tauhan dito.');
    }

    // Cases
    if ($s['open_cases'] > 0) {
        $add($s['open_cases'] >= 5 ? 'warn' : 'info', 'Bukas na kaso', $s['open_cases'] . ' complaint/KP/VAWC case ang naghihintay ng aksyon. I-schedule ang mediation sa lalong madaling panahon.');
    }

    // Collections trend
    if ($s['collected_prev_7d'] > 0) {
        $pct = (int) round(($s['collected_7d'] - $s['collected_prev_7d']) / $s['collected_prev_7d'] * 100);
        $add($pct >= 0 ? 'good' : 'warn', 'Trend ng koleksyon', 'Huling 7 araw: ' . peso($s['collected_7d']) . ' (' . ($pct >= 0 ? '+' : '') . $pct . '% kumpara sa naunang 7 araw). Ngayong buwan: ' . peso($s['collected_month']) . '.');
    } else {
        $add('info', 'Koleksyon', 'Ngayon: ' . peso($s['collected_today']) . ' • 7 araw: ' . peso($s['collected_7d']) . ' • Buwan: ' . peso($s['collected_month']) . '.');
    }

    // Population
    if ($s['residents'] > 0) {
        $vulnerable = $s['seniors'] + $s['pwd'] + $s['solo_parents'];
        $share = (int) round($vulnerable / $s['residents'] * 100);
        $add('info', 'Profile ng komunidad', $s['seniors'] . ' senior, ' . $s['pwd'] . ' PWD at ' . $s['solo_parents'] . ' solo parent (' . $share . '% ng populasyon). Gamitin ito sa pagpaplano ng ayuda at health programs.');
    }
    if ($s['top_purok']) {
        $add('info', 'Pinakamalaking Purok', $s['top_purok']['name'] . ' – ' . $s['top_purok']['residents'] . ' residente. Dito unahin ang outreach at clean-up drives.');
    }

    // Upcoming
    if ($s['pending_reservations'] > 0) {
        $add('warn', 'Reservations', $s['pending_reservations'] . ' reservation ng facility ang naghihintay ng approval.');
    }
    if ($s['events_next_7d'] > 0) {
        $add('info', 'Events this week', $s['events_next_7d'] . ' event ang nakaiskedyul sa susunod na 7 araw. Siguraduhing may anunsyo.');
    } else {
        $add('info', 'Walang event this week', 'Walang nakaiskedyul na event sa susunod na 7 araw; maaaring mag-post ng community activity.');
    }

    // Local summary
    $warns = count(array_filter($items, fn ($i) => $i['level'] === 'warn'));
    $summary = 'Ngayon ay ' . $s['pending_total'] . ' ang pending na request at ' . $s['open_cases'] . ' ang bukas na kaso. '
        . ($warns > 0 ? 'May ' . $warns . ' bagay na nangangailangan ng agarang atensyon.' : 'Maayos ang takbo ng barangay ngayon.');

    $provider = 'local';
    $llm = null;
    if (ai_provider() !== 'local') {
        $llm = ai_llm(
            "You are a data analyst for a Philippine barangay. Write a 3-4 sentence briefing in Taglish for the Punong Barangay based ONLY on the JSON stats. "
            . "Highlight the most urgent issue first, then one concrete recommendation. No lists, no markdown, do not invent numbers.",
            [['role' => 'user', 'content' => json_encode($s, JSON_UNESCAPED_UNICODE)]],
            350
        );
    }
    if ($llm !== null) {
        $summary = $llm;
        $provider = ai_provider();
    }

    $md = "**Buod**\n\n" . $summary . "\n\n" . ai_bul(array_map(fn ($i) => '**' . $i['title'] . '**: ' . $i['text'], $items));
    $logId = ai_log('insights', 'Barangay insights ' . date('M j, Y'), $md, $provider);
    return ['summary' => $summary, 'items' => $items, 'provider' => $provider, 'stats' => $s, 'log_id' => $logId];
}

/* ------------------------------------------------------------------ *
 * 3. Draft writer (text generation, officials only)
 * ------------------------------------------------------------------ */

function ai_draft_types(): array
{
    return [
        'announcement' => 'Public announcement',
        'event' => 'Event invitation',
        'cleanup' => 'Clean-up drive / community activity',
        'sms' => 'SMS reminder (short)',
        'advisory' => 'Advisory (weather / safety)',
    ];
}

/** @return array{text:string, provider:string, log_id:int} */
function ai_draft(string $type, string $topic, string $date, string $venue, string $notes): array
{
    $types = ai_draft_types();
    if (!isset($types[$type])) {
        $type = 'announcement';
    }
    $topic = trim(mb_substr($topic, 0, 160));
    $date = trim(mb_substr($date, 0, 60));
    $venue = trim(mb_substr($venue, 0, 120));
    $notes = trim(mb_substr($notes, 0, 400));
    $user = current_user();
    $sender = trim((string) ($user['position'] ?? '')) !== '' ? $user['position'] : ($user['role_name'] ?? 'Barangay Official');
    $place = barangay_place();

    $text = null;
    $provider = 'local';
    if (ai_provider() !== 'local') {
        $length = $type === 'sms' ? 'Max 300 characters, plain text.' : 'About 80-140 words.';
        $text = ai_llm(
            "You write official notices for " . $place . ". Language: Taglish (mostly Tagalog, formal but friendly). Output only the finished text, no preface, no markdown. " . $length
            . ' Do not invent dates, venues, amounts or phone numbers that are not provided; leave them out instead.',
            [['role' => 'user', 'content' => 'Type: ' . $types[$type] . "\nTopic: " . $topic . "\nDate/time: " . ($date ?: 'not provided') . "\nVenue: " . ($venue ?: 'not provided') . "\nNotes: " . ($notes ?: 'none') . "\nSigned by: " . $sender]],
            500
        );
        if ($text !== null) {
            $provider = ai_provider();
        }
    }

    if ($text === null) {
        $when = $date !== '' ? ' sa ' . $date : '';
        $where = $venue !== '' ? ' sa ' . $venue : '';
        $extra = $notes !== '' ? "\n\n" . rtrim($notes, '.') . '.' : '';
        $topicText = $topic !== '' ? $topic : 'mahalagang gawain ng barangay';
        $text = match ($type) {
            'event' => "IMBITASYON\n\nMagandang araw, mga kabarangay! Inaanyayahan po namin kayong dumalo sa \"" . $topicText . "\"" . $when . $where . ".\n\nAng inyong presensya at suporta ay mahalaga sa ikatatagumpay ng gawaing ito." . $extra . "\n\nMaraming salamat po.\n\n- " . $sender . ', ' . $place,
            'cleanup' => "TARA, LINISIN NATIN ANG BIGAAN!\n\nAnyayahan ang lahat ng residente na makiisa sa \"" . $topicText . "\"" . $when . $where . ". Magdala ng walis, kalaykay, sako at sariling inuming tubig." . $extra . "\n\nSama-sama nating pangalagaan ang kalinisan at kalikasan ng ating barangay.\n\n- " . $sender . ', ' . $place,
            'sms' => 'BRGY ' . mb_strtoupper(APP_BARANGAY === 'Barangay Bigaan' ? 'BIGAAN' : APP_BARANGAY) . ': ' . $topicText . $when . $where . '.' . ($notes !== '' ? ' ' . rtrim($notes, '.') . '.' : '') . ' Salamat po.',
            'advisory' => "ADVISORY\n\nAbiso sa lahat ng residente: " . $topicText . $when . $where . ". Maging alerto, sundin ang mga payo ng barangay at ilayo sa panganib ang mga bata, senior at PWD." . $extra . "\n\nPara sa tulong, makipag-ugnayan sa Barangay Hall o tumawag sa 911 kung emergency.\n\n- " . $sender . ', ' . $place,
            default => "ANUNSYO\n\nMagandang araw po, mga kabarangay! Ipinababatid po ng " . $place . " ang tungkol sa \"" . $topicText . "\"" . $when . $where . "." . $extra . "\n\nPara sa mga katanungan, magtungo lamang po sa Barangay Hall.\n\nMaraming salamat po.\n\n- " . $sender,
        };
    }

    $logId = ai_log('draft', $types[$type] . ': ' . $topic, $text, $provider);
    return ['text' => $text, 'provider' => $provider, 'log_id' => $logId];
}
