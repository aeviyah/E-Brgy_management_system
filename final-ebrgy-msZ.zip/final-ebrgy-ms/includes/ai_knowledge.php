<?php

declare(strict_types=1);

/**
 * Knowledge base for Bigaan AI: what a barangay's people usually ask.
 *
 *  'for' => 'all'   : residents and officials may ask
 *  'for' => 'staff' : officials only (residents get a polite "officials only" reply and these topics are
 *                     never given to the language model when a resident is chatting)
 *  'body' is Markdown-lite ("- " bullets, "1." steps, **bold**) or a function that builds it from live data.
 *
 * Edit the text to match the real practice of Barangay Bigaan. Anything not listed here, the assistant
 * says it is not sure and refers the person to the Barangay Hall, so it never invents facts.
 */

function ai_bul(array $items): string
{
    return implode("\n", array_map(fn ($i) => '- ' . $i, $items));
}

function ai_num(array $items): string
{
    $out = [];
    foreach (array_values($items) as $i => $text) {
        $out[] = ($i + 1) . '. ' . $text;
    }
    return implode("\n", $out);
}

function ai_kb(): array
{
    static $kb = null;
    if ($kb !== null) {
        return $kb;
    }

    $place = barangay_place();

    $kb = [
        /* ================= Everyone ================= */
        ['key' => 'ai_help', 'for' => 'all', 'title' => 'Ano ang kaya kong gawin',
         'kw' => ['ano ang kaya mo', 'ano kaya mong', 'what can you do', 'sino ka', 'ikaw ba', 'ano ka', 'bigaan ai'],
         'body' => "Ako si **Bigaan AI**, ang katulong ninyo sa E-Barangay.\n\nMaaari akong sumagot tungkol sa:\n" . ai_bul([
             'Mga dokumento: bayad, requirements at proseso',
             'Status ng request mo at kung paano mag-track',
             'Reklamo, Katarungang Pambarangay at proteksyon (VAWC/BCPC)',
             'Mga opisyal, oras ng opisina at contact',
             'Facilities, reserbasyon, events at programa',
             'Kalusugan, day care, basura at iba pang serbisyo',
             'Paggamit ng website: login, profile, tracking at QR verification',
         ]) . "\n\nHindi ako nagbibigay ng legal advice at hindi ko ibinibigay ang personal na datos ng ibang tao."],

        ['key' => 'system', 'for' => 'all', 'title' => 'Tungkol sa E-Barangay',
         'kw' => ['e-barangay', 'ebarangay', 'website', 'web site', 'ano ang system', 'ano ang sistema', 'para saan ang system', 'para saan ang website', 'ano ito', 'ano itong', 'about'],
         'body' => "Ang **E-Barangay Management System** ng {$place} ay online na serbisyo para hindi na kailangang pumila para sa lahat ng bagay.\n\nMga magagawa rito:\n" . ai_bul([
             'Mag-request ng sertipiko, clearance at permit',
             'Subaybayan ang status ng request gamit ang reference number',
             'Mag-file ng reklamo o blotter',
             'Mag-reserve ng facility tulad ng Covered Court',
             'Magbasa ng anunsyo, balita at events',
             'I-verify ang dokumento gamit ang QR / reference number',
         ]) . "\n\nMay sariling account ang bawat residente at opisyal, at ang makikita mo ay ayon sa iyong role."],

        ['key' => 'public_portal', 'for' => 'all', 'title' => 'Public Portal',
         'kw' => ['public portal', 'walang account', 'bisita', 'guest', 'public page', 'hindi pa naka-login', 'bago login'],
         'body' => "May **Public Portal** na puwedeng buksan ng sinuman kahit walang account.\n\nDito makikita ang:\n" . ai_bul([
             'Mga programa/gawain at facilities ng barangay',
             'Mga opisyal ng barangay (pindutin ang bilog para sa ID)',
             '**Track request** para sa status ng request gamit ang reference number',
             '**Verify document** para tiyakin kung totoo ang isang dokumento',
         ]) . "\n\nPara mag-request ng dokumento, kailangan munang mag-login o mag-register."],

        ['key' => 'track', 'for' => 'all', 'title' => 'Paano mag-track ng request',
         'kw' => ['track', 'tracking', 'reference number', 'reference no', 'ref no', 'hanapin ang request', 'nasaan na ang request ko', 'nasaan na ang dokumento'],
         'body' => "Para i-track ang request:\n\n" . ai_num([
             'Buksan ang **Track request** sa Public Portal (hindi kailangan ng login).',
             'Ilagay ang reference number, halimbawa `DOC-20261006-A10001`.',
             'Makikita mo ang kasalukuyang status at ang kasaysayan nito.',
         ]) . "\n\nNasa loob ng account mo rin ang listahan ng requests mo, o tanungin mo ako ng \"Ano ang status ng requests ko?\"."],

        ['key' => 'verify', 'for' => 'all', 'title' => 'Pag-verify ng dokumento',
         'kw' => ['verify', 'i-verify', 'qr', 'totoo ba', 'peke', 'authentic', 'validity', 'tunay ba'],
         'body' => "Bawat opisyal na sertipiko ay may reference number at QR code.\n\n" . ai_num([
             'Buksan ang **Verify document** sa Public Portal.',
             'I-scan ang QR o ilagay ang reference number.',
             'Ipapakita ng sistema kung totoo ang dokumento at ang kasalukuyang status nito.',
         ]) . "\n\nHindi ipinapakita sa publiko ang pangalan o halaga; status lang."],

        ['key' => 'account', 'for' => 'all', 'title' => 'Account, login at password',
         'kw' => ['mag-register', 'magregister', 'register', 'sign up', 'signup', 'gumawa ng account', 'create account', 'mag-login', 'paano mag login', 'log in', 'login', 'forgot password', 'nakalimutan', 'password', 'username'],
         'body' => "**Mag-register:** pindutin ang Register sa login page, piliin kung **Resident** o **Barangay Official**. Ang opisyal ay pipili ng posisyon (Captain, Kagawad, Secretary, Treasurer o SK).\n\n**Mag-login:** piliin ang portal (Resident o Officials), ilagay ang username **o** email, at ang password.\n\n**Nakalimutan ang password?** Makipag-ugnayan sa Secretary o Administrator ng barangay para ma-reset ito. Kapag nakapasok na, puwede mo itong palitan sa **Profile** (pindutin ang pangalan mo sa itaas)."],

        ['key' => 'profile', 'for' => 'all', 'title' => 'Profile at pagpapalit ng password',
         'kw' => ['profile ko', 'baguhin ang profile', 'i-edit ang profile', 'palitan ang password', 'change password', 'palitan ang address', 'update ng impormasyon', 'maling impormasyon'],
         'body' => "Para baguhin ang impormasyon mo o ang password:\n\n" . ai_num([
             'Pindutin ang **pangalan mo** sa kanang itaas.',
             'Sa **Profile**, i-edit ang detalye o piliin ang pagpapalit ng password.',
             'I-save. Kung hindi mo mabago ang isang field (halimbawa pangalan o birthdate), lumapit sa Barangay Hall para sa beripikasyon.',
         ])],

        ['key' => 'doc_process', 'for' => 'all', 'title' => 'Proseso ng dokumento',
         'kw' => ['proseso ng dokumento', 'process ng dokumento', 'paano kumuha ng sertipiko', 'paano kumuha ng dokumento', 'kumuha ng certificate', 'gaano katagal', 'ilang araw', 'kailan makukuha', 'kailan ko makukuha', 'processing time'],
         'body' => "Ganito ang daloy ng request ng dokumento:\n\n" . ai_num([
             'Mag-login at buksan ang **Certification Requests**.',
             'Piliin ang uri ng dokumento, ilagay ang detalye at mag-upload ng ID o patunay kung kailangan.',
             'Awtomatikong lalabas ang bayad (kung mayroon). Hindi ito mababago ng residente.',
             'Susuriin ito ng opisyal. Makakatanggap ka ng notification kapag may update.',
             'Kapag **Approved**, kunin ang dokumento sa Barangay Hall dala ang valid ID.',
         ]) . "\n\nAng haba ng proseso ay depende sa dami ng request at sa kumpleto ng papeles; karaniwang mas mabilis kapag kumpleto ang requirements."],

        ['key' => 'statuses', 'for' => 'all', 'title' => 'Ibig sabihin ng status',
         'kw' => ['ibig sabihin ng pending', 'ibig sabihin ng approved', 'ibig sabihin ng rejected', 'bakit pending', 'bakit rejected', 'bakit na-reject', 'tinanggihan', 'ano ang pending', 'ano ang approved', 'ano ang rejected', 'status meaning'],
         'body' => "May tatlong status ang bawat request:\n" . ai_bul([
             '**Pending**: natanggap na, hinihintay pang suriin ng opisyal.',
             '**Approved**: aprubado na. Maaari mo na itong kunin o i-print ayon sa uri ng dokumento.',
             '**Rejected**: hindi naaprubahan, kadalasan dahil kulang o malabo ang papeles.',
         ]) . "\n\nKung Rejected, tingnan ang tala sa request at mag-file ulit nang kumpleto, o magtanong sa Barangay Hall."],

        ['key' => 'payment', 'for' => 'all', 'title' => 'Paano magbayad',
         'kw' => ['paano magbayad', 'magbayad', 'payment method', 'gcash', 'maya', 'e-wallet', 'ewallet', 'bank transfer', 'resibo', 'official receipt', 'cash'],
         'body' => "May tatlong paraan ng bayad: **Cash**, **E-Wallet** at **Bank Transfer**.\n\n" . ai_num([
             'Alamin ang bayad sa dokumento (tanungin ako ng "Magkano ang Barangay Clearance?").',
             'Magbayad sa Barangay Hall o sa napiling paraan; itatala ng Treasurer ang bayad.',
             'Makakatanggap ka ng **Official Receipt**. Itago ito bilang patunay.',
         ]) . "\n\nAng ilang dokumento tulad ng Indigency ay **libre**."],

        ['key' => 'complaints', 'for' => 'all', 'title' => 'Paano magreklamo',
         'kw' => ['reklamo', 'magreklamo', 'ireklamo', 'complaint', 'blotter', 'nang-away', 'inaaway', 'gulo', 'ingay', 'nakawan', 'napinsala', 'harassment', 'pananakit', 'pananakot'],
         'body' => "Para magsampa ng reklamo o blotter:\n\n" . ai_num([
             'Buksan ang **Complaints & Blotter** sa account mo (o pumunta nang personal sa Barangay Hall).',
             'Ilagay ang detalye: ano ang nangyari, kailan, saan, at sino ang inirereklamo.',
             'Mag-upload ng larawan o ebidensya kung mayroon.',
             'Susuriin ito ng barangay at maaaring i-refer sa **Katarungang Pambarangay** para sa pag-uusap.',
         ]) . "\n\n**Kung may panganib o kasalukuyang krimen**, tumawag agad sa **911** o sa tanod. Huwag nang maghintay ng online na sagot."],

        ['key' => 'kp', 'for' => 'all', 'title' => 'Katarungang Pambarangay',
         'kw' => ['katarungang pambarangay', 'lupon', 'mediation', 'pagkakasundo', 'kasunduan', 'settlement', 'cfa', 'certificate to file action', 'summon', 'pangkat', 'conciliation'],
         'body' => "Ang **Katarungang Pambarangay** ay paraan ng pag-aayos ng alitan sa barangay bago pumunta sa korte.\n\nKaraniwang daloy:\n" . ai_num([
             'Magsampa ng reklamo sa barangay.',
             'Magpapatawag ang **Punong Barangay** ng mediation (karaniwang sa loob ng 15 araw).',
             'Kung walang kasunduan, bubuo ng **Pangkat ng Tagapagkasundo** para sa conciliation (karaniwang 15 araw pa).',
             'Kapag nagkasundo, ihahanda ang **kasunduan**. Kapag hindi, maaaring ibigay ang **Certificate to File Action (CFA)** para madala sa korte.',
         ]) . "\n\nMay mga alitang hindi sakop nito; itatanong ito ng barangay sa pag-file."],

        ['key' => 'vawc', 'for' => 'all', 'title' => 'VAWC at proteksyon ng bata',
         'kw' => ['vawc', 'violence against women', 'pang-aabuso', 'inaabuso', 'bcpc', 'child abuse', 'karahasan', 'binubugbog', 'bugbog', 'battered', 'protection order', 'bpo', 'abused'],
         'body' => "Kung ikaw o ang kakilala mo ay nakararanas ng pang-aabuso, hindi ka nag-iisa.\n\n" . ai_bul([
             '**Kung may panganib ngayon:** tumawag sa **911** o pumunta sa pinakamalapit na Tanod Outpost.',
             'Maaaring humingi ng **Barangay Protection Order (BPO)** sa Punong Barangay sa ilalim ng batas laban sa karahasan sa kababaihan at mga anak.',
             'Ang mga kaso ng VAWC at BCPC ay **kumpidensyal**. Ang awtorisadong opisyal lang ang may access sa detalye.',
             'Maaari kang pumunta nang personal sa Barangay Hall at hilingin na kausapin nang pribado ang opisyal.',
         ])],

        ['key' => 'officials', 'for' => 'all', 'title' => 'Mga opisyal ng barangay',
         'kw' => ['sino ang kapitan', 'sino ang captain', 'sino ang punong barangay', 'punong barangay', 'kapitan', 'sino ang mga opisyal', 'mga opisyal', 'opisyal ng barangay', 'sino sino', 'kagawad', 'kalihim', 'ingat-yaman', 'sino ang secretary', 'sino ang treasurer', 'officials'],
         'body' => function (): string {
             $names = [];
             foreach (community_officials() as $o) {
                 if ($o['full_name'] !== $o['position']) {
                     $names[] = '**' . $o['full_name'] . '**: ' . $o['position'];
                 }
             }
             $intro = "Ang Sangguniang Barangay ay binubuo ng Punong Barangay, pitong Kagawad, Kalihim (Secretary), Ingat-yaman (Treasurer) at ang Sangguniang Kabataan (SK).\n\n";
             if ($names) {
                 return $intro . "Mga nakatalaga ngayon sa sistema:\n" . ai_bul($names) . "\n\nMakikita rin sila sa **Mga Opisyal** sa Public Portal.";
             }
             return $intro . "Hindi pa naipapasok sa sistema ang mga pangalan. Makikita ang listahan sa **Mga Opisyal** sa Public Portal o itanong sa Barangay Hall.";
         }],

        ['key' => 'contact', 'for' => 'all', 'title' => 'Oras, lokasyon at contact',
         'kw' => ['anong oras bukas', 'oras ng barangay hall', 'bukas ang barangay hall', 'saan ang barangay hall', 'anong oras', 'oras ng opisina', 'office hours', 'bukas ba', 'sarado', 'contact', 'numero', 'telepono', 'phone', 'email', 'hotline', 'nasaan ang barangay', 'saan ang barangay hall', 'address ng barangay', 'lokasyon ng barangay', 'paano makontak', 'tawagan'],
         'body' => function (): string {
             $rows = [];
             try {
                 $rows = fetch_all("SELECT label, value, availability FROM public_contacts WHERE status = 'Active' ORDER BY id LIMIT 6");
             } catch (Throwable $e) {
                 $rows = [];
             }
             $out = "**Barangay Hall**: " . barangay_place() . ".\nKaraniwang oras: Lunes hanggang Biyernes, 8:00 AM - 5:00 PM.";
             if ($rows) {
                 $out .= "\n\nMga contact:\n" . ai_bul(array_map(fn ($r) => '**' . $r['label'] . '**: ' . $r['value'] . ($r['availability'] ? ' (' . $r['availability'] . ')' : ''), $rows));
             }
             return $out . "\n\nPara sa emergency, tumawag sa **911**.";
         }],

        ['key' => 'facilities', 'for' => 'all', 'title' => 'Facilities at reserbasyon',
         'kw' => ['facility', 'facilities', 'pasilidad', 'reserve', 'reservation', 'reserbasyon', 'covered court', 'barangay hall', 'mrf', 'tanod outpost', 'hiramin', 'rent', 'upahan'],
         'body' => function (): string {
             $lines = [];
             foreach (community_facilities() as $f) {
                 $when = '';
                 foreach ($f['info'] as [$label, $val]) {
                     if ($label === 'Oras') {
                         $when = $val;
                     }
                 }
                 $lines[] = '**' . $f['title'] . '**: ' . $f['text'] . ($when ? ' (' . $when . ')' : '');
             }
             $fees = [];
             try {
                 foreach (fetch_all("SELECT name, fee FROM facilities WHERE status = 'Active' ORDER BY name LIMIT 8") as $r) {
                     $fees[] = $r['name'] . ': ' . ((float) $r['fee'] > 0 ? peso($r['fee']) : 'Libre');
                 }
             } catch (Throwable $e) {
                 $fees = [];
             }
             return "Mga pasilidad ng barangay:\n" . ai_bul($lines)
                 . ($fees ? "\n\nBayad sa reserbasyon:\n" . ai_bul($fees) : '')
                 . "\n\nPara mag-reserve:\n" . ai_num(['Buksan ang **Facilities & Reservations**.', 'Piliin ang facility, petsa at oras.', 'Hintayin ang approval; bawal ang magkaparehong oras (overlap).']);
         }],

        ['key' => 'activities', 'for' => 'all', 'title' => 'Mga programa at gawain',
         'kw' => ['activity', 'activities', 'programa', 'gawain', 'linis-barangay', 'linis barangay', 'feeding', 'check-up', 'checkup', 'medical mission', 'palarong barangay', 'palaro', 'pulong barangay', 'assembly', 'pagtatanim', 'bakawan', 'sumali'],
         'body' => function (): string {
             $lines = [];
             foreach (community_activities() as $a) {
                 $sched = '';
                 foreach ($a['info'] as [$label, $val]) {
                     if ($label === 'Iskedyul') {
                         $sched = $val;
                     }
                 }
                 $lines[] = '**' . $a['title'] . '**: ' . $a['text'] . ($sched ? ' (' . $sched . ')' : '');
             }
             return "Mga regular na programa ng barangay:\n" . ai_bul($lines) . "\n\nAng eksaktong petsa ay ipinapaskil sa **Events** at **Announcements**. Itanong sa akin ang \"mga paparating na event\".";
         }],

        ['key' => 'health', 'for' => 'all', 'title' => 'Kalusugan',
         'kw' => ['kalusugan', 'health center', 'bakuna', 'vaccine', 'prenatal', 'buntis', 'doktor', 'nars', 'midwife', 'bhw', 'health worker', 'gamot', 'may sakit', 'timbang'],
         'body' => "Ang **Barangay Health Center** ay para sa konsulta, bakuna, prenatal check-up at pagtitimbang ng mga bata.\n\n" . ai_bul([
             'Oras: Lunes hanggang Biyernes, 8:00 AM - 4:00 PM',
             'Para sa lahat ng residente, lalo na sa buntis, sanggol, bata, senior at PWD',
             'May **Libreng Check-up / medical mission** kapag ipinaskil sa Announcements',
         ]) . "\n\nKung malubha ang sakit o emergency, pumunta sa pinakamalapit na ospital o tumawag sa **911**."],

        ['key' => 'daycare', 'for' => 'all', 'title' => 'Day Care Center',
         'kw' => ['day care', 'daycare', 'mag-enroll', 'enroll', 'pag-enroll', 'toddler', 'batang 3'],
         'body' => "Ang **Day Care Center** ay para sa mga batang 3 hanggang 5 taong gulang.\n\n" . ai_bul([
             'Oras: Lunes hanggang Biyernes, 8:00 - 11:30 AM',
             'Magdala ng birth certificate at ID ng magulang kapag mag-eenroll',
             'May pag-aaral, feeding program at laro',
         ]) . "\n\nKumpirmahin ang eksaktong schedule ng enrollment sa Barangay Hall."],

        ['key' => 'waste', 'for' => 'all', 'title' => 'Basura at kalinisan',
         'kw' => ['basura', 'garbage', 'waste', 'recycl', 'segregation', 'ihiwalay', 'kolekta ng basura', 'nabubulok', 'kalinisan', 'kanal'],
         'body' => "Ang **Materials Recovery Facility (MRF)** ang tumatanggap ng hiwalay na basura.\n\n" . ai_bul([
             'Oras: Lunes hanggang Sabado, 7:00 AM - 4:00 PM',
             'Ihiwalay ang **nabubulok**, **recyclable** (plastik, papel, bote, lata) at **residual**',
             'May **Linis-Barangay** na gawain tuwing ipinapaskil ng barangay',
         ]) . "\n\nMaaari kang mag-file ng sanitation concern sa **Barangay Services**."],

        ['key' => 'senior_pwd', 'for' => 'all', 'title' => 'Senior, PWD, Solo Parent at ayuda',
         'kw' => ['senior citizen', 'senior id', 'pwd', 'solo parent', '4ps', 'ayuda', 'assistance', 'benepisyo', 'discount', 'scholarship', 'iskolarsip', 'tulong pinansyal'],
         'body' => "Ang barangay ang unang pinupuntahan para sa mga programa ng tulong.\n\n" . ai_bul([
             'Siguraduhing **kumpleto at tama ang profile** mo bilang Senior, PWD, Solo Parent o 4Ps; ginagamit ito sa pagpili ng mga makakatanggap.',
             'Kumuha ng **Certificate of Indigency** o **Residency** (karaniwang hinihingi ng ahensya).',
             'Ang mismong ID ng Senior at PWD ay karaniwang inilalabas sa **munisipyo** (OSCA / PDAO). Magtanong sa Barangay Hall kung ano ang dadalhin.',
             'Silipin ang **Community Assistance** at **Announcements** para sa mga bukas na programa.',
         ])],

        ['key' => 'other_ids', 'for' => 'all', 'title' => 'Cedula, voter at iba pang ID',
         'kw' => ['cedula', 'sedula', 'community tax', 'voter', 'comelec', 'passport', 'nbi', 'police clearance', 'philhealth', 'sss', 'umid'],
         'body' => "Hindi lahat ng dokumento ay galing sa barangay.\n\n" . ai_bul([
             '**Barangay:** Clearance, Residency, Indigency, Good Moral, Business clearance',
             '**Munisipyo:** Cedula (Community Tax Certificate), business permit, senior/PWD ID',
             '**COMELEC:** voter\'s registration',
             '**NBI, Pulis, PSA, SSS, PhilHealth, Passport:** sa kani-kanilang opisina',
         ]) . "\n\nMadalas na hinihingi ng mga ahensyang iyon ang **Barangay Clearance o Residency**, kaya doon ka magsimula."],

        ['key' => 'sk', 'for' => 'all', 'title' => 'Sangguniang Kabataan',
         'kw' => ['sangguniang kabataan', 'sk chairperson', 'sk chairman', 'kabataan', 'youth', 'liga ng kabataan'],
         'body' => "Ang **Sangguniang Kabataan (SK)** ang namumuno sa mga programa ng kabataan: palakasan, iskolarsip at community projects.\n\n" . ai_bul([
             'Pinamumunuan ng SK Chairperson at mga SK Kagawad',
             'Namamahala sa **Palarong Barangay**',
             'Ang mga kabataan ay maaaring sumali sa pamamagitan ng pagpapalista sa Barangay Hall o sa SK',
         ])],

        ['key' => 'privacy', 'for' => 'all', 'title' => 'Privacy at seguridad ng datos',
         'kw' => ['privacy', 'data privacy', 'ligtas ba ang datos', 'ligtas ba ang impormasyon', 'personal data', 'confidential ba', 'hack', 'saan napupunta ang datos'],
         'body' => "Pinoprotektahan ang datos mo:\n" . ai_bul([
             'Ang bawat residente ay nakakakita **lang ng sarili** niyang requests at dokumento.',
             'May **role-based access**: iba-iba ang nakikita ng residente, kagawad, treasurer, secretary at captain.',
             'Ang mga sensitibong kaso (VAWC/BCPC) ay para lang sa awtorisadong opisyal.',
             'Ang AI assistant ay hindi nagbibigay ng personal na impormasyon ng ibang residente.',
         ])],

        ['key' => 'howto', 'for' => 'all', 'title' => 'Paano gamitin ang website',
         'kw' => ['paano gamitin', 'tutorial', 'guide', 'navigation', 'sidebar', 'dark mode', 'light mode', 'theme', 'saan makikita', 'hindi ko makita', 'paano maghanap', 'search'],
         'body' => "Mabilis na gabay:\n" . ai_bul([
             '**Sidebar (kaliwa):** lahat ng seksyon na pinapayagan sa role mo. Pindutin ang icon sa taas para paliitin ito.',
             '**Search bar (itaas):** hanapin ang mga record sa buong sistema.',
             '**Dark / Light mode:** pindutin ang buton sa itaas.',
             '**Kampana:** mga notification sa status ng request mo.',
             '**Pangalan mo (kanan itaas):** Profile at pagpapalit ng password.',
         ])],

        /* ================= Officials only ================= */
        ['key' => 's_workflow', 'for' => 'staff', 'title' => 'Pag-approve o pag-reject ng request',
         'kw' => ['paano mag-approve', 'i-approve', 'approve', 'i-reject', 'reject', 'paano i-process', 'paano ko ipoproseso', 'proseso ng approval', 'workflow', 'review ng request', 'paano suriin'],
         'body' => "Para i-process ang request:\n\n" . ai_num([
             'Buksan ang **Certification Requests** (o ang kaukulang module).',
             'Piliin ang request at suriin ang detalye at attachment.',
             'Pindutin ang **Approve** o **Reject** at maglagay ng tala.',
             'Awtomatikong aabisuhan ang residente at maitatala ito sa **Audit Trail**.',
         ]) . "\n\nSa Approved na dokumento, lalabas ang **Print / PDF / Word / Excel** ng sertipiko. Hindi na mababalik ang Rejected sa Pending; magfa-file muli ang residente."],

        ['key' => 's_treasury', 'for' => 'staff', 'title' => 'Pagtatala ng bayad (Treasury)',
         'kw' => ['record payment', 'magtala ng bayad', 'i-record ang bayad', 'ipasok ang bayad', 'collection report', 'treasury', 'pagkolekta', 'payment approval', 'official receipt', 'resibo'],
         'body' => "Sa **Payment Transactions**:\n\n" . ai_num([
             'Pindutin ang bagong payment at piliin ang request o ilagay ang purpose.',
             'Piliin ang paraan (Cash, E-Wallet, Bank Transfer) at ilagay ang reference kung online.',
             'I-approve ang bayad para mailabas ang **Official Receipt**.',
             'Makikita ang kabuuan sa **Reports & Analytics** at sa Today Collections sa dashboard.',
         ]) . "\n\nTreasurer, Secretary, Punong Barangay, Staff at Admin lang ang may access."],

        ['key' => 's_residents', 'for' => 'staff', 'title' => 'Residente, sambahayan at Purok',
         'kw' => ['magdagdag ng residente', 'add resident', 'i-edit ang resident', 'verify resident', 'pending verification', 'resident profile', 'magrehistro ng residente', 'sambahayan', 'household', 'purok'],
         'body' => "Pamamahala ng talaan:\n" . ai_bul([
             '**Resident Profiles:** magdagdag, mag-edit, mag-verify (Pending Verification → Active) at i-update ang klasipikasyon (Senior, PWD, Solo Parent, 4Ps).',
             '**Households:** itala ang head ng pamilya, miyembro at address.',
             '**Purok / Sitio:** i-assign ang residente at tingnan ang populasyon kada Purok.',
             'Gamitin ang **Export** (PDF, Excel, Word) para sa ulat.',
         ])],

        ['key' => 's_audit', 'for' => 'staff', 'title' => 'Audit Trail',
         'kw' => ['audit', 'audit trail', 'sino ang nag', 'activity log', 'logs', 'history ng gawain'],
         'body' => "Ang **Audit Trail** ay nagtatala ng *sino, ano, kailan at saang record* sa bawat mahalagang aksyon (approve, reject, bayad, pagbabago).\n\nGamitin ito para suriin ang mga pagbabago o kung may hindi inaasahang galaw. Ang mga tanong at sagot sa **AI Assistant** ay may sariling tala sa `ai_logs`."],

        ['key' => 's_accounts', 'for' => 'staff', 'title' => 'Mga account at role',
         'kw' => ['user account', 'mga account', 'role', 'permission', 'sino ang may access', 'access ng', 'magdagdag ng user', 'official account', 'i-activate', 'i-deactivate', 'admin account'],
         'body' => "Mga role sa sistema:\n" . ai_bul([
             '**Administrator:** lahat ng module, kasama ang User Accounts at backup.',
             '**Punong Barangay / Secretary:** halos lahat ng module, kasama ang sensitibong kaso.',
             '**Treasurer:** pananalapi, budget, dokumento, ulat at audit.',
             '**Staff / Kagawad:** residente, dokumento, reklamo, bayad at facilities (walang sensitibong kaso).',
             '**Resident:** sariling requests, anunsyo, events, facilities at feed lang.',
         ]) . "\n\nAng opisyal na nag-register ay awtomatikong aktibo. Ang Administrator ang namamahala ng mga account sa **User Accounts**."],

        ['key' => 's_reports', 'for' => 'staff', 'title' => 'Ulat at export',
         'kw' => ['report', 'ulat', 'export', 'excel', 'analytics', 'i-download ang ulat', 'monthly report'],
         'body' => "Sa **Reports & Analytics**:\n" . ai_bul([
             'Populasyon, klasipikasyon (Senior, PWD, Solo Parent, 4Ps) at bilang kada Purok',
             'Requests ayon sa status at module',
             'Koleksyon kada araw',
         ]) . "\n\nGamitin ang **Export** (PDF, Excel, Word) o i-print. Para sa mabilis na pagsusuri, buksan ang **AI Insights**."],

        ['key' => 's_publish', 'for' => 'staff', 'title' => 'Pag-post ng anunsyo at balita',
         'kw' => ['mag-post ng anunsyo', 'gumawa ng anunsyo', 'magpost', 'i-publish', 'publish', 'feed', 'mag-announce', 'paano mag-post'],
         'body' => "Para mag-post:\n\n" . ai_num([
             'Gamitin ang **AI Draft Writer** para makagawa ng unang bersyon, at i-edit ito.',
             'Buksan ang **Announcements** (opisyal na anunsyo) o **Community Feed** (balita na may larawan).',
             'I-save. Lalabas agad ang anunsyo sa dashboard at Public Portal.',
         ])],

        ['key' => 's_confidential', 'for' => 'staff', 'title' => 'Mga kumpidensyal na kaso',
         'kw' => ['confidential', 'kumpidensyal', 'sensitive', 'sensitibo', 'vawc case', 'bcpc case', 'restricted', 'protection module', 'paano hawakan ang kaso'],
         'body' => "Ang **BCPC / VAWC Protection** ay restricted.\n" . ai_bul([
             'Secretary, Punong Barangay at Administrator lang ang may access.',
             'Huwag ibahagi ang pangalan o detalye sa chat, social media o sa taong walang awtoridad.',
             'Itala ang bawat aksyon para lumabas sa Audit Trail.',
             'Kapag may panganib, i-refer agad sa pulis, DSWD o sa Women and Children Protection Desk.',
         ])],

        ['key' => 's_certificates', 'for' => 'staff', 'title' => 'Pag-print at paglalabas ng sertipiko',
         'kw' => ['i-print ang certificate', 'print certificate', 'print ng sertipiko', 'signatory', 'pirma', 'i-release', 'ilabas ang dokumento', 'qr code ng dokumento'],
         'body' => "Pagkatapos i-approve ang request:\n\n" . ai_num([
             'Buksan ang request at pindutin ang **Print / Certificate**.',
             'Piliin ang PDF, Word o Excel kung kailangan ng kopya.',
             'Ipirma ng Punong Barangay at ibigay sa residente. May **reference number at QR** ang bawat sertipiko para ma-verify.',
         ]) . "\n\nAng mga resident ay hindi makakapag-print ng sertipiko ng iba."],

        ['key' => 's_backup', 'for' => 'staff', 'title' => 'Backup at seguridad',
         'kw' => ['backup', 'back up', 'seguridad', 'security', 'csrf', 'settings', 'i-reset', 'reset ng password ng user'],
         'body' => "Para sa **Administrator**:\n" . ai_bul([
             'Mag-download ng **SQL backup** sa Settings nang regular (halimbawa lingguhan) at itago sa ligtas na lugar.',
             'I-set ang `APP_DEMO` sa `false` sa `includes/app.php` bago gamitin nang totoo.',
             'Gumamit ng malalakas na password; i-reset ng Admin ang password ng nakalimutan.',
         ])],

        ['key' => 's_budget', 'for' => 'staff', 'title' => 'Budget at disbursement',
         'kw' => ['budget', 'disbursement', 'voucher', 'pondo', 'gastos', 'utilization'],
         'body' => "Ang **Budget & Disbursement** (Treasurer, Secretary, Punong Barangay, Admin) ay para sa:\n" . ai_bul([
             'Alokasyon ng badyet at gastos',
             'Voucher at disbursement',
             'Pag-uulat ng paggamit ng pondo',
         ]) . "\n\nAng mga koleksyon naman ay nasa **Payment Transactions** at sa Reports."],
    ];

    return $kb;
}

/** Whole-word match for very short keywords (sk, kp, qr...), substring match for longer ones. */
function ai_kw_hit(string $q, string $kw): bool
{
    if (mb_strlen($kw) <= 3) {
        return (bool) preg_match('/(?<![\p{L}\p{N}])' . preg_quote($kw, '/') . '(?![\p{L}\p{N}])/u', $q);
    }
    return str_contains($q, $kw);
}

/** Best matching knowledge-base topic for a question (longest keyword wins), or null. */
function ai_kb_match(string $q): ?array
{
    $best = null;
    $bestScore = 0;
    foreach (ai_kb() as $topic) {
        $score = 0;
        foreach ($topic['kw'] as $kw) {
            if (ai_kw_hit($q, $kw)) {
                $score += mb_strlen($kw);
            }
        }
        if ($score > $bestScore) {
            $bestScore = $score;
            $best = $topic;
        }
    }
    return $best;
}

function ai_kb_body(array $topic): string
{
    return $topic['body'] instanceof Closure ? (string) ($topic['body'])() : (string) $topic['body'];
}
