
<?php
$pdo = new PDO(
    "mysql:host=localhost;dbname=ebarangay_management;charset=utf8mb4",
    "root",
    "",
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);

$firstNames = [
    "Juan", "Maria", "Jose", "Ana", "Mark",
    "Angela", "Carlo", "Sofia", "Miguel", "Andrea",
    "Daniel", "Camille", "Rafael", "Patricia", "Gabriel",
    "Nicole", "Adrian", "Jasmine", "Christian", "Isabella",
    "Joshua", "Bianca", "Nathan", "Ella", "Paolo",
    "Grace", "Francis", "Christine", "John", "Mary",
    "Kevin", "Bea", "Patrick", "Denise", "Ryan",
    "Trisha", "Angelo", "Mika", "Lorenzo", "Faith",
    "Jerome", "Joy", "Aaron", "Leah", "Vincent",
    "Diana", "Samuel", "Celine", "Marco", "Alexis"
];

$lastNames = [
    "Santos", "Reyes", "Cruz", "Garcia", "Mendoza",
    "Ramos", "Flores", "Castillo", "Torres", "Rivera"
];

$password = password_hash("TestUser123!", PASSWORD_DEFAULT);

$sql = "INSERT INTO users
        (name, username, email, password, role)
        VALUES (?, ?, ?, ?, ?)";

$stmt = $pdo->prepare($sql);

for ($i = 0; $i < 50; $i++) {
    $name = $firstNames[$i] . " " .
            $lastNames[$i % count($lastNames)];

    $username = "testuser" . str_pad($i + 1, 3, "0", STR_PAD_LEFT);
    $email = $username . "@example.com";

    $stmt->execute([
        $name,
        $username,
        $email,
        $password,
        "staff"
    ]);
}

echo "Successfully created 50 test users!";
?>