<?php

declare(strict_types=1);

/*
|==========================================================================
| Database connection + application constants
|==========================================================================
*/

// ---------------------------------------------------------------------
// Application identity
// ---------------------------------------------------------------------
defined('APP_NAME')         || define('APP_NAME', 'E-Barangay System');
defined('APP_BARANGAY')     || define('APP_BARANGAY', 'Mabuhay');
defined('APP_PROVINCE')     || define('APP_PROVINCE', 'Metro Manila');
defined('APP_MUNICIPALITY') || define('APP_MUNICIPALITY', 'Quezon City');

// ---------------------------------------------------------------------
// Feature flags
// ---------------------------------------------------------------------
defined('APP_DEMO')         || define('APP_DEMO', false);   // true to show demo creds on login
defined('APP_DEBUG')        || define('APP_DEBUG', true);   // true to surface PHP errors

// ---------------------------------------------------------------------
// Error reporting — driven by APP_DEBUG
// ---------------------------------------------------------------------
if (APP_DEBUG) {
    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
}

// ---------------------------------------------------------------------
// Database credentials — adjust to match your XAMPP setup
// ---------------------------------------------------------------------
defined('DB_HOST') || define('DB_HOST', '127.0.0.1');
defined('DB_PORT') || define('DB_PORT', '3306');
defined('DB_NAME') || define('DB_NAME', 'e_barangay');
defined('DB_USER') || define('DB_USER', 'root');
defined('DB_PASS') || define('DB_PASS', '');
defined('DB_CHARSET') || define('DB_CHARSET', 'utf8mb4');

/**
 * Return a shared PDO connection.
 * First call opens the connection; subsequent calls reuse it.
 */
if (!function_exists('db')) {
    function db(): PDO
    {
        static $pdo = null;

        if ($pdo instanceof PDO) {
            return $pdo;
        }

        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=%s',
            DB_HOST,
            DB_PORT,
            DB_NAME,
            DB_CHARSET
        );

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            if (APP_DEBUG) {
                exit('Database connection failed: ' . $e->getMessage());
            }
            exit('Database connection failed. Please try again later.');
        }

        return $pdo;
    }
}