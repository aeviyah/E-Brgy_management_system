<?php

/**
 * IDE-ONLY STUB — never include this at runtime.
 * Provides signatures for VS Code + Intelephense so dynamic definitions
 * don't show up as "undefined constant" / "undefined function" errors.
 *
 * @noinspection ALL
 */

declare(strict_types=1);

// Application constants
defined('APP_NAME')         || define('APP_NAME', '');
defined('APP_BARANGAY')     || define('APP_BARANGAY', '');
defined('APP_PROVINCE')     || define('APP_PROVINCE', '');
defined('APP_MUNICIPALITY') || define('APP_MUNICIPALITY', '');
defined('APP_DEMO')         || define('APP_DEMO', false);
defined('APP_DEBUG')        || define('APP_DEBUG', false);

// Database constants
defined('DB_HOST')    || define('DB_HOST', '');
defined('DB_PORT')    || define('DB_PORT', '');
defined('DB_NAME')    || define('DB_NAME', '');
defined('DB_USER')    || define('DB_USER', '');
defined('DB_PASS')    || define('DB_PASS', '');
defined('DB_CHARSET') || define('DB_CHARSET', '');

// Core stubs
if (!function_exists('db'))                     { function db(): PDO { throw new RuntimeException('stub'); } }
if (!function_exists('app_modules'))            { function app_modules(): array { return []; } }
if (!function_exists('future_modules'))         { function future_modules(): array { return []; } }
if (!function_exists('workflow_statuses'))      { function workflow_statuses(): array { return []; } }
if (!function_exists('workflow_transitions'))   { function workflow_transitions(): array { return []; } }
if (!function_exists('payment_statuses'))       { function payment_statuses(): array { return []; } }
if (!function_exists('resident_statuses'))      { function resident_statuses(): array { return []; } }

// Auth stubs
if (!function_exists('current_user'))           { function current_user(): ?array { return null; } }
if (!function_exists('role_slug'))              { function role_slug(): string { return ''; } }
if (!function_exists('require_login'))          { function require_login(): void {} }
if (!function_exists('require_post'))           { function require_post(): void {} }
if (!function_exists('require_module_access'))  { function require_module_access(string $slug): void {} }
if (!function_exists('can_access_module'))      { function can_access_module(string $slug): bool { return false; } }
if (!function_exists('can_manage_module'))      { function can_manage_module(string $slug): bool { return false; } }
if (!function_exists('can_approve_module'))     { function can_approve_module(string $slug): bool { return false; } }
if (!function_exists('is_resident'))            { function is_resident(): bool { return false; } }
if (!function_exists('is_barangay_official'))   { function is_barangay_official(): bool { return false; } }
if (!function_exists('can_full_control_records')) { function can_full_control_records(string $slug): bool { return false; } }

// Layout stubs
if (!function_exists('render_header'))  { function render_header(string $title = ''): void {} }
if (!function_exists('render_footer'))  { function render_footer(): void {} }
if (!function_exists('page_header'))    { function page_header(string $title = '', string $subtitle = '', string $actionsHtml = ''): void {} }
if (!function_exists('icon'))           { function icon(string $name): string { return ''; } }
if (!function_exists('module_icon'))    { function module_icon(string $slug): string { return ''; } }