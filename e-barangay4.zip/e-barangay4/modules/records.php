<?php

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';

$__docFile = __DIR__ . '/../includes/documents.php';
if (file_exists($__docFile)) {
    require_once $__docFile;
}

$slug = (string) ($_GET['module'] ?? '');
$module = module_meta($slug);

if (!$module || ($module['type'] ?? '') !== 'records') {
    flash('warning', 'Module not found.');
    redirect('dashboard.php');
}

require_module_access($slug);

$user       = current_user();
$isStaff    = is_barangay_official();
$isResident = is_resident();

$canCreate  = can_manage_module($slug) || ($isResident && $slug === 'documents');
$canApprove = $isStaff && (can_manage_module($slug) || can_approve_module($slug));

$requiresRespondent   = in_array($slug, ['complaints', 'katarungang', 'blotter', 'protection'], true);
$isDocumentModule     = ($slug === 'documents');
$requiresAttachments  = $isDocumentModule;

function resident_record_clause(string $slug, array &$params): string
{
    if (!is_resident()) {
        return '';
    }
    if (in_array($slug, ['announcements', 'events'], true)) {
        return '';
    }
    $params[] = current_resident_id();
    return ' AND service_records.resident_id = ?';
}

/** Residents: only their own Pending records. Staff: full control. */
function can_modify_record(array $record, string $slug): bool
{
    if (is_barangay_official()) {
        return true;
    }

    if (in_array($slug, ['announcements', 'events'], true)) {
        return false;
    }

    if (($record['status'] ?? '') !== 'Pending') {
        return false;
    }

    return (int) ($record['resident_id'] ?? 0) === (int) current_resident_id();
}

function can_delete_record(array $record, string $slug): bool
{
    if (is_barangay_official()) {
        return true;
    }
    return can_modify_record($record, $slug);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $action = (string) ($_POST['action'] ?? '');

    /* -------- CREATE / UPDATE -------- */
    if ($action === 'create' && $canCreate) {
        $editId             = (int) ($_POST['id'] ?? 0);
        $title              = trim((string) ($_POST['title'] ?? ''));
        $category           = trim((string) ($_POST['category'] ?? ''));
        $respondentName     = trim((string) ($_POST['respondent_name'] ?? ''));
        $respondentStreet   = trim((string) ($_POST['respondent_street'] ?? ''));
        $respondentPurok    = trim((string) ($_POST['respondent_purok'] ?? ''));
        $respondentBarangay = trim((string) ($_POST['respondent_barangay'] ?? ''));
        $respondentCity     = trim((string) ($_POST['respondent_city'] ?? ''));

        $existing = null;
        if ($editId > 0) {
            $params = [$editId, $slug];
            $clause = resident_record_clause($slug, $params);
            $existing = fetch_one('SELECT * FROM service_records WHERE id = ? AND module_slug = ?' . $clause, $params);

            if (!$existing) {
                flash('danger', 'Record not found or access denied.');
                redirect('modules/records.php?module=' . urlencode($slug));
            }
            if (!can_modify_record($existing, $slug)) {
                flash('danger', 'You are not allowed to edit this record.');
                redirect('modules/records.php?module=' . urlencode($slug) . '&id=' . $editId);
            }
        }

        $errors = [];
        if ($title === '')    { $errors[] = 'Title is required.'; }
        if ($category === '') { $errors[] = 'Category is required.'; }

        if ($requiresRespondent && (
            $respondentName === '' ||
            $respondentStreet === '' ||
            $respondentPurok === '' ||
            $respondentBarangay === '' ||
            $respondentCity === ''
        )) {
            $errors[] = 'Respondent full name and complete address (Street, Purok, Barangay, City/Municipality) are required for complaints and blotter records.';
        }

        if (!$errors) {
            $residentId = is_resident()
                ? current_resident_id()
                : (($_POST['resident_id'] ?? '') !== '' ? (int) $_POST['resident_id'] : null);

            $requester = trim((string) ($_POST['requester_name'] ?? ''));
            if ($requester === '') {
                $requester = $user['full_name'];
            }

            if ($editId > 0 && $existing) {
                run_query(
                    'UPDATE service_records SET
                        title = ?, category = ?, description = ?, amount = ?, priority = ?,
                        due_date = ?, assigned_to = ?, resident_id = ?, requester_name = ?,
                        respondent_name = ?, respondent_street = ?, respondent_purok = ?,
                        respondent_barangay = ?, respondent_city = ?,
                        updated_by = ?, updated_at = NOW()
                     WHERE id = ?',
                    [
                        $title, $category,
                        trim((string) ($_POST['description'] ?? '')),
                        (float) ($_POST['amount'] ?? 0),
                        trim((string) ($_POST['priority'] ?? 'Normal')),
                        $_POST['due_date'] ?: null,
                        ($_POST['assigned_to'] ?? '') ?: null,
                        $residentId, $requester,
                        $requiresRespondent ? $respondentName     : null,
                        $requiresRespondent ? $respondentStreet   : null,
                        $requiresRespondent ? $respondentPurok    : null,
                        $requiresRespondent ? $respondentBarangay : null,
                        $requiresRespondent ? $respondentCity     : null,
                        (int) $user['id'], $editId,
                    ]
                );

                // Optional new attachments during edit
                $attachErrors = handle_attachment_uploads($editId, (int) $user['id']);
                foreach ($attachErrors as $err) { flash('warning', $err); }

                record_history($editId, (string) $existing['status'], 'Record edited by ' . $user['full_name']);
                audit_log('Updated record', $module['label'], $editId, $title);
                flash('success', 'Record updated.');
                redirect('modules/records.php?module=' . urlencode($slug) . '&id=' . $editId);
            } else {
                run_query(
                    'INSERT INTO service_records
                     (module_slug, reference_no, title, resident_id, requester_name,
                      respondent_name, respondent_street, respondent_purok, respondent_barangay, respondent_city,
                      category, description, amount, status, priority, due_date, assigned_to,
                      created_by, updated_by, created_at, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
                    [
                        $slug,
                        generate_reference($module['prefix']),
                        $title, $residentId, $requester,
                        $requiresRespondent ? $respondentName     : null,
                        $requiresRespondent ? $respondentStreet   : null,
                        $requiresRespondent ? $respondentPurok    : null,
                        $requiresRespondent ? $respondentBarangay : null,
                        $requiresRespondent ? $respondentCity     : null,
                        $category,
                        trim((string) ($_POST['description'] ?? '')),
                        (float) ($_POST['amount'] ?? 0),
                        'Pending',
                        trim((string) ($_POST['priority'] ?? 'Normal')),
                        $_POST['due_date'] ?: null,
                        ($_POST['assigned_to'] ?? '') ?: null,
                        (int) $user['id'], (int) $user['id'],
                    ]
                );

                $recordId = (int) db()->lastInsertId();

                // Attachments (optional for complaints, expected for documents)
                $attachErrors = handle_attachment_uploads($recordId, (int) $user['id']);
                foreach ($attachErrors as $err) { flash('warning', $err); }

                // Requirement: documents need at least one valid ID or birth certificate.
                if ($requiresAttachments) {
                    $hasSupporting = (int) fetch_value(
                        "SELECT COUNT(*) FROM service_record_attachments
                         WHERE record_id = ? AND doc_type IN ('valid_id','birth_certificate')",
                        [$recordId]
                    );
                    if ($hasSupporting === 0) {
                        run_query('DELETE FROM service_records WHERE id = ?', [$recordId]);
                        flash('danger', 'Please attach a Valid ID or Birth Certificate before submitting a document request.');
                        redirect('modules/records.php?module=' . urlencode($slug));
                    }
                }

                record_history($recordId, 'Pending', 'Record created.');
                audit_log('Created record', $module['label'], $recordId, $title);

                if ($residentId) {
                    $residentUser = fetch_one('SELECT id FROM users WHERE resident_id = ?', [$residentId]);
                    notify_user($residentUser['id'] ?? null, $module['label'] . ' submitted', 'Your request is now Pending.');
                }

                flash('success', 'Record created and added to the workflow queue.');
                redirect('modules/records.php?module=' . urlencode($slug) . '&id=' . $recordId);
            }
        } else {
            foreach ($errors as $e) { flash('danger', $e); }
        }
    }

    /* -------- DELETE -------- */
    if ($action === 'delete') {
        $recordId = (int) ($_POST['record_id'] ?? 0);
        $params = [$recordId, $slug];
        $clause = resident_record_clause($slug, $params);
        $record = fetch_one('SELECT * FROM service_records WHERE id = ? AND module_slug = ?' . $clause, $params);

        if (!$record) {
            flash('danger', 'Record not found.');
            redirect('modules/records.php?module=' . urlencode($slug));
        }
        if (!can_delete_record($record, $slug)) {
            flash('danger', 'You are not allowed to delete this record.');
            redirect('modules/records.php?module=' . urlencode($slug) . '&id=' . $recordId);
        }

        $paymentCount = (int) fetch_value('SELECT COUNT(*) FROM payments WHERE record_id = ?', [$recordId]);
        if ($paymentCount > 0) {
            flash('danger', 'Cannot delete: this record already has payments recorded against it.');
            redirect('modules/records.php?module=' . urlencode($slug) . '&id=' . $recordId);
        }

        // Delete files
        foreach (attachments_for_record($recordId) as $att) {
            $path = attachment_storage_dir() . '/' . $att['stored_name'];
            if (is_file($path)) { @unlink($path); }
        }

        try {
            run_query('DELETE FROM service_record_attachments WHERE record_id = ?', [$recordId]);
            run_query('DELETE FROM record_history WHERE record_id = ?', [$recordId]);
            run_query('DELETE FROM service_records WHERE id = ?', [$recordId]);
            audit_log('Deleted record', $module['label'], $recordId, (string) ($record['reference_no'] ?? ''));
            flash('success', 'Record deleted.');
        } catch (PDOException $e) {
            flash('danger', 'Could not delete the record: ' . $e->getMessage());
        }

        redirect('modules/records.php?module=' . urlencode($slug));
    }

    /* -------- DELETE ATTACHMENT -------- */
    if ($action === 'delete_attachment') {
        $attId    = (int) ($_POST['attachment_id'] ?? 0);
        $recordId = (int) ($_POST['record_id'] ?? 0);

        $params = [$recordId, $slug];
        $clause = resident_record_clause($slug, $params);
        $record = fetch_one('SELECT * FROM service_records WHERE id = ? AND module_slug = ?' . $clause, $params);

        if ($record && can_modify_record($record, $slug)) {
            delete_attachment($attId, $recordId);
            audit_log('Deleted attachment', $module['label'], $recordId, 'Attachment #' . $attId);
            flash('success', 'Attachment removed.');
        } else {
            flash('danger', 'Not allowed.');
        }

        redirect('modules/records.php?module=' . urlencode($slug) . '&id=' . $recordId);
    }

    /* -------- UPDATE STATUS (staff only) -------- */
    if ($action === 'update_status' && $canApprove) {
        $recordId = (int) ($_POST['record_id'] ?? 0);
        $status   = (string) ($_POST['status'] ?? 'Pending');
        $notes    = trim((string) ($_POST['notes'] ?? ''));

        $params = [$recordId, $slug];
        $clause = resident_record_clause($slug, $params);
        $record = fetch_one('SELECT * FROM service_records WHERE id = ? AND module_slug = ?' . $clause, $params);

        if ($record
            && in_array($status, workflow_statuses(), true)
            && can_transition($record['status'], $status, $slug)
        ) {
            run_query(
                'UPDATE service_records SET status = ?, updated_by = ?, updated_at = NOW() WHERE id = ?',
                [$status, (int) $user['id'], $recordId]
            );
            record_history($recordId, $status, $notes);
            audit_log('Updated status', $module['label'], $recordId, $status . ($notes ? ': ' . $notes : ''));

            if (!empty($record['resident_id'])) {
                $residentUser = fetch_one('SELECT id FROM users WHERE resident_id = ?', [(int) $record['resident_id']]);
                notify_user($residentUser['id'] ?? null, 'Status updated', $record['reference_no'] . ' is now ' . $status . '.');
            }

            flash('success', 'Status updated.');
        } else {
            flash('danger', 'That status change is not allowed.');
        }

        redirect('modules/records.php?module=' . urlencode($slug) . '&id=' . $recordId);
    }
}

$residents = is_resident()
    ? []
    : fetch_all("SELECT id, resident_no, first_name, last_name FROM residents WHERE status != 'Archived' ORDER BY last_name, first_name");
$staff = is_resident()
    ? []
    : fetch_all("SELECT users.id, users.full_name, roles.name AS role_name FROM users JOIN roles ON roles.id = users.role_id WHERE roles.slug != 'resident' AND users.status = 'Active' ORDER BY users.full_name");

$detailId = (int) ($_GET['id'] ?? 0);
$detail = null;
$history = [];
$payments = [];
$attachments = [];

if ($detailId) {
    $params = [$detailId, $slug];
    $clause = resident_record_clause($slug, $params);
    $detail = fetch_one(
        'SELECT service_records.*, residents.resident_no, residents.first_name, residents.last_name, users.full_name AS assigned_name
         FROM service_records
         LEFT JOIN residents ON residents.id = service_records.resident_id
         LEFT JOIN users ON users.id = service_records.assigned_to
         WHERE service_records.id = ? AND service_records.module_slug = ?' . $clause,
        $params
    );

    if ($detail) {
        $history = fetch_all(
            'SELECT record_history.*, users.full_name
             FROM record_history
             LEFT JOIN users ON users.id = record_history.changed_by
             WHERE record_id = ?
             ORDER BY created_at DESC',
            [$detailId]
        );
        $payments    = fetch_all('SELECT * FROM payments WHERE record_id = ? ORDER BY paid_at DESC', [$detailId]);
        $attachments = attachments_for_record($detailId);
    }
}

$editId = (int) ($_GET['edit'] ?? 0);
$editRecord = null;
if ($editId > 0) {
    $params = [$editId, $slug];
    $clause = resident_record_clause($slug, $params);
    $candidate = fetch_one('SELECT * FROM service_records WHERE id = ? AND module_slug = ?' . $clause, $params);

    if ($candidate && can_modify_record($candidate, $slug)) {
        $editRecord = $candidate;
    } else {
        flash('warning', 'That record cannot be edited.');
        redirect('modules/records.php?module=' . urlencode($slug));
    }
}

$search = trim((string) ($_GET['q'] ?? ''));
$status = trim((string) ($_GET['status'] ?? ''));
$params = [$slug];
$where = 'WHERE service_records.module_slug = ?';
if ($search !== '') {
    $where .= ' AND (service_records.reference_no LIKE ? OR service_records.title LIKE ? OR service_records.requester_name LIKE ? OR service_records.category LIKE ?)';
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like, $like);
}
if ($status !== '') {
    $where .= ' AND service_records.status = ?';
    $params[] = $status;
}
$where .= resident_record_clause($slug, $params);

$records = fetch_all(
    'SELECT service_records.*, residents.resident_no, residents.first_name, residents.last_name
     FROM service_records
     LEFT JOIN residents ON residents.id = service_records.resident_id
     ' . $where . '
     ORDER BY service_records.updated_at DESC
     LIMIT 100',
    $params
);

render_header($module['label']);
page_header($module['label'], $module['description'], '<a class="btn btn-ghost" href="' . e(app_url('dashboard.php')) . '">Back to Dashboard</a>');
?>

<?php if ($detail): ?>
<section class="grid grid-2">
    <div class="panel">
        <div class="panel-header">
            <h2><?= e($detail['title']) ?></h2>
            <span class="<?= e(status_class($detail['status'])) ?>"><?= e($detail['status']) ?></span>
        </div>
        <div class="panel-body">
            <div class="grid grid-2">
                <p><strong>Reference</strong><br><?= e($detail['reference_no']) ?></p>
                <p><strong>Category</strong><br><?= e($detail['category']) ?></p>
                <p><strong>Requester</strong><br><?= e($detail['requester_name']) ?></p>
                <p><strong>Resident</strong><br><?= e(trim(($detail['first_name'] ?? '') . ' ' . ($detail['last_name'] ?? '')) ?: 'Not linked') ?></p>
                <p><strong>Amount / Fee</strong><br><?= e(peso($detail['amount'])) ?></p>
                <p><strong>Priority</strong><br><?= e($detail['priority']) ?></p>
                <p><strong>Due date</strong><br><?= e($detail['due_date'] ?: 'Not set') ?></p>
                <p><strong>Assigned to</strong><br><?= e($detail['assigned_name'] ?: 'Unassigned') ?></p>
                <p><strong>Printed</strong><br><?= e($detail['printed_at'] ?: 'Not yet') ?></p>
                <p><strong>Print count</strong><br><?= (int) ($detail['print_count'] ?? 0) ?></p>
            </div>

            <?php if (!empty($detail['respondent_name'])): ?>
                <p><strong>Respondent / Reported Party</strong><br>
                    <?= e($detail['respondent_name']) ?><br>
                    <?= e($detail['respondent_street']) ?><br>
                    <?= e($detail['respondent_purok']) ?><br>
                    <?= e($detail['respondent_barangay']) ?><br>
                    <?= e($detail['respondent_city']) ?>
                </p>
            <?php endif; ?>

            <p><strong>Description</strong><br><?= nl2br(e($detail['description'])) ?></p>

            <?php if ($attachments): ?>
                <p><strong>Attachments</strong></p>
                <ul class="timeline">
                    <?php foreach ($attachments as $att): ?>
                        <li>
                            <strong><?= e($att['original_name']) ?></strong>
                            <small>
                                <?= e($att['doc_type']) ?>
                                &middot; <?= number_format((int) $att['size_bytes'] / 1024, 1) ?> KB
                                &middot; <?= e($att['created_at']) ?>
                            </small>
                            <div style="margin-top:6px; display:flex; gap:6px;">
                                <a class="btn btn-ghost" style="padding:2px 8px; font-size:12px;"
                                   target="_blank"
                                   href="<?= e(app_url('modules/attachment_file.php?id=' . (int) $att['id'])) ?>">View</a>
                                <?php if (can_modify_record($detail, $slug)): ?>
                                    <form method="post" style="display:inline;"
                                          onsubmit="return confirm('Remove this attachment?');">
                                        <input type="hidden" name="action" value="delete_attachment">
                                        <input type="hidden" name="attachment_id" value="<?= (int) $att['id'] ?>">
                                        <input type="hidden" name="record_id" value="<?= (int) $detail['id'] ?>">
                                        <button class="btn btn-ghost" style="padding:2px 8px; font-size:12px; color:#b91c1c;" type="submit">Remove</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <div class="form-actions" style="display:flex; flex-wrap:wrap; gap:8px;">
                <a class="btn btn-ghost" href="<?= e(app_url('modules/records.php?module=' . urlencode($slug))) ?>">Back to List</a>

                <?php if ($isDocumentModule): ?>
                    <?php $canPrint = function_exists('document_can_be_printed')
                        ? document_can_be_printed($detail, $isStaff)
                        : (document_allows_printing((string) $detail['status']) && ($isStaff || (int) ($detail['resident_id'] ?? 0) === (int) current_resident_id())); ?>
                    <?php if ($canPrint): ?>
                        <a class="btn btn-secondary" target="_blank" rel="noopener"
                           href="<?= e(app_url('modules/document_print.php?module=' . urlencode($slug) . '&id=' . (int) $detail['id'] . '&format=print')) ?>">
                            <?= icon('file') ?> Print / Save as PDF
                        </a>
                        <a class="btn btn-ghost"
                           href="<?= e(app_url('modules/document_print.php?module=' . urlencode($slug) . '&id=' . (int) $detail['id'] . '&format=word')) ?>">
                            <?= icon('file') ?> Download Word
                        </a>
                        <?php if (file_exists(__DIR__ . '/../includes/vendor/fpdf/fpdf.php')): ?>
                            <a class="btn btn-ghost"
                               href="<?= e(app_url('modules/document_print.php?module=' . urlencode($slug) . '&id=' . (int) $detail['id'] . '&format=pdf')) ?>">
                                <?= icon('file') ?> Download PDF
                            </a>
                        <?php endif; ?>
                    <?php else: ?>
                        <span class="muted" style="align-self:center;">
                            Document becomes printable once it is <strong>Approved</strong>.
                        </span>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if (can_modify_record($detail, $slug)): ?>
                    <a class="btn btn-ghost"
                       href="<?= e(app_url('modules/records.php?module=' . urlencode($slug) . '&edit=' . (int) $detail['id'])) ?>">
                        <?= icon('file') ?> Edit
                    </a>
                <?php endif; ?>

                <?php if (can_delete_record($detail, $slug)): ?>
                    <form method="post" style="display:inline;"
                          onsubmit="return confirm('Delete this record permanently? This cannot be undone.');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="record_id" value="<?= (int) $detail['id'] ?>">
                        <button class="btn btn-ghost" type="submit" style="color:#b91c1c;">Delete</button>
                    </form>
                <?php endif; ?>

                <?php if (can_access_module('treasury') && (float) $detail['amount'] > 0): ?>
                    <a class="btn" href="<?= e(app_url('modules/payments.php?record_id=' . (int) $detail['id'])) ?>">Record Payment</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="panel">
        <div class="panel-header"><h2>Status Timeline</h2></div>
        <div class="panel-body">
            <ul class="timeline">
                <?php foreach ($history as $item): ?>
                    <li>
                        <strong><?= e($item['status']) ?></strong>
                        <p><?= e($item['notes'] ?: 'No notes') ?></p>
                        <small><?= e($item['full_name'] ?? 'System') ?> - <?= e($item['created_at']) ?></small>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</section>

<?php if ($canApprove): ?>
<section class="panel">
    <div class="panel-header"><h2>Process / Update Status</h2></div>
    <div class="panel-body">
        <form method="post" class="form-grid">
            <input type="hidden" name="action" value="update_status">
            <input type="hidden" name="record_id" value="<?= (int) $detail['id'] ?>">
            <div class="form-field">
                <label>Status</label>
                <select class="form-control" name="status">
                    <option value="<?= e($detail['status']) ?>" selected><?= e($detail['status']) ?> (current)</option>
                    <?php foreach (workflow_transitions()[$detail['status']] ?? [] as $ws): if (!can_transition($detail['status'], $ws, $slug)) { continue; } ?>
                        <option><?= e($ws) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-field full">
                <label>Notes</label>
                <textarea class="form-control" name="notes" rows="3" placeholder="Verification result, approval reason, or rejection note"></textarea>
            </div>
            <div class="form-actions full">
                <button class="btn" type="submit">Save Status</button>
            </div>
        </form>
    </div>
</section>
<?php endif; ?>

<?php if ($payments): ?>
<section class="panel">
    <div class="panel-header"><h2>Payment / OR History</h2></div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>OR No.</th><th>Transaction</th><th>Purpose</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
            <?php foreach ($payments as $payment): ?>
                <tr>
                    <td><?= e($payment['receipt_no']) ?></td>
                    <td><?= e($payment['transaction_no']) ?></td>
                    <td><?= e($payment['purpose']) ?></td>
                    <td><?= e(peso($payment['amount'])) ?></td>
                    <td><span class="<?= e(status_class($payment['payment_status'])) ?>"><?= e($payment['payment_status']) ?></span></td>
                    <td><?= e($payment['paid_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
<?php endif; ?>
<?php endif; ?>

<section class="panel">
    <div class="panel-header">
        <h2><?= $detail ? 'Other Records' : 'Records' ?></h2>
        <span class="muted">Residents create &amp; view. Officials and admins manage.</span>
    </div>
    <form class="filter-bar" method="get">
        <input type="hidden" name="module" value="<?= e($slug) ?>">
        <input name="q" placeholder="Search reference, title, requester or category" value="<?= e($search) ?>">
        <select name="status" data-autosubmit>
            <option value="">All statuses</option>
            <?php foreach (workflow_statuses() as $ws): ?>
                <option value="<?= e($ws) ?>" <?= selected($status, $ws) ?>><?= e($ws) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn" type="submit">Filter</button>
    </form>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Reference</th><th>Requester</th><th>Category</th>
                    <th>Amount</th><th>Status</th><th>Updated</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($records as $record): ?>
                <tr>
                    <td><a class="record-title" href="<?= e(app_url('modules/records.php?module=' . urlencode($slug) . '&id=' . (int) $record['id'])) ?>"><strong><?= e($record['reference_no']) ?></strong><small><?= e($record['title']) ?></small></a></td>
                    <td><?= e($record['requester_name']) ?></td>
                    <td><?= e($record['category']) ?></td>
                    <td><?= e(peso($record['amount'])) ?></td>
                    <td><span class="<?= e(status_class($record['status'])) ?>"><?= e($record['status']) ?></span></td>
                    <td><?= e($record['updated_at']) ?></td>
                    <td style="white-space:nowrap;">
                        <?php $rowPrintable = $isDocumentModule
                            && (function_exists('document_can_be_printed')
                                ? document_can_be_printed($record, $isStaff)
                                : (document_allows_printing((string) $record['status']))); ?>
                        <?php if ($rowPrintable): ?>
                            <a class="btn btn-ghost" style="padding:4px 10px; font-size:12px;"
                               target="_blank" rel="noopener"
                               href="<?= e(app_url('modules/document_print.php?module=' . urlencode($slug) . '&id=' . (int) $record['id'] . '&format=print')) ?>">Print</a>
                        <?php endif; ?>
                        <?php if (can_modify_record($record, $slug)): ?>
                            <a class="btn btn-ghost" style="padding:4px 10px; font-size:12px;"
                               href="<?= e(app_url('modules/records.php?module=' . urlencode($slug) . '&edit=' . (int) $record['id'])) ?>">Edit</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$records): ?>
                <tr><td colspan="7">No records found.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>

<?php if ($canCreate): ?>
<section class="panel">
    <div class="panel-header">
        <h2><?= $editRecord ? 'Edit Record — ' . e($editRecord['reference_no']) : 'Create ' . e($module['label']) . ' Record' ?></h2>
    </div>
    <div class="panel-body">
        <form method="post" class="form-grid" enctype="multipart/form-data">
            <input type="hidden" name="action" value="create">
            <input type="hidden" name="id" value="<?= (int) ($editRecord['id'] ?? 0) ?>">

            <div class="form-field">
                <label>Title *</label>
                <input class="form-control" name="title" value="<?= e($editRecord['title'] ?? '') ?>" required>
            </div>
            <div class="form-field">
                <label>Category *</label>
                <input class="form-control" name="category"
                       placeholder="Barangay Clearance, Certificate of Indigency, Business Permit, Certificate of Residency, Cedula, Certificate of Good Moral Character, Barangay Resolution"
                       value="<?= e($editRecord['category'] ?? '') ?>" required>
            </div>

            <?php if (!$isResident): ?>
            <div class="form-field">
                <label>Linked resident</label>
                <select class="form-control" name="resident_id">
                    <option value="">None / public record</option>
                    <?php foreach ($residents as $resident): ?>
                        <option value="<?= (int) $resident['id'] ?>" <?= selected($editRecord['resident_id'] ?? '', $resident['id']) ?>>
                            <?= e($resident['resident_no'] . ' - ' . $resident['last_name'] . ', ' . $resident['first_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-field">
                <label>Requester name</label>
                <input class="form-control" name="requester_name" value="<?= e($editRecord['requester_name'] ?? '') ?>">
            </div>
            <?php endif; ?>

            <?php if ($requiresRespondent): ?>
                <div class="form-field full">
                    <label>Respondent / Reported Party — Complete Name *</label>
                    <input class="form-control" name="respondent_name" required value="<?= e($editRecord['respondent_name'] ?? '') ?>">
                </div>
                <div class="form-field full">
                    <label>Respondent / Reported Party — Complete Address *</label>
                    <div class="grid grid-3" style="margin-bottom:6px;">
                        <input class="form-control" name="respondent_street"   placeholder="Street / House No. / Sitio" required value="<?= e($editRecord['respondent_street'] ?? '') ?>">
                        <input class="form-control" name="respondent_purok"    placeholder="Purok" required value="<?= e($editRecord['respondent_purok'] ?? '') ?>">
                        <input class="form-control" name="respondent_barangay" placeholder="Barangay" required value="<?= e($editRecord['respondent_barangay'] ?? '') ?>">
                    </div>
                    <input class="form-control" name="respondent_city" placeholder="City / Municipality" required value="<?= e($editRecord['respondent_city'] ?? '') ?>">
                </div>
            <?php endif; ?>

            <?php if ($isDocumentModule): ?>
                <div class="form-field full">
                    <label>Supporting Attachments <?= $editRecord ? '' : '*' ?></label>
                    <small class="muted">Attach at least one of: Valid ID or Birth Certificate. Accepted: JPG, PNG, WEBP, PDF (max 5 MB each).</small>
                    <div class="grid grid-2" style="margin-top:6px;">
                        <div>
                            <select class="form-control" name="attachment_type[]">
                                <option value="valid_id">Valid ID</option>
                                <option value="birth_certificate">Birth Certificate</option>
                                <option value="other">Other supporting document</option>
                            </select>
                        </div>
                        <div>
                            <input class="form-control" type="file" name="attachments[]" accept=".jpg,.jpeg,.png,.webp,.pdf">
                        </div>
                        <div>
                            <select class="form-control" name="attachment_type[]">
                                <option value="valid_id">Valid ID</option>
                                <option value="birth_certificate">Birth Certificate</option>
                                <option value="other">Other supporting document</option>
                            </select>
                        </div>
                        <div>
                            <input class="form-control" type="file" name="attachments[]" accept=".jpg,.jpeg,.png,.webp,.pdf">
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="form-field">
                <label>Amount / fee</label>
                <input class="form-control" type="number" step="0.01" min="0" name="amount" value="<?= e((string) ($editRecord['amount'] ?? '0')) ?>">
            </div>
            <div class="form-field">
                <label>Priority</label>
                <select class="form-control" name="priority">
                    <?php foreach (['Normal', 'High', 'Urgent', 'Low'] as $p): ?>
                        <option <?= selected($editRecord['priority'] ?? 'Normal', $p) ?>><?= e($p) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-field">
                <label>Due date</label>
                <input class="form-control" type="date" name="due_date" value="<?= e($editRecord['due_date'] ?? '') ?>">
            </div>
            <?php if (!$isResident): ?>
            <div class="form-field">
                <label>Assigned personnel</label>
                <select class="form-control" name="assigned_to">
                    <option value="">Unassigned</option>
                    <?php foreach ($staff as $person): ?>
                        <option value="<?= (int) $person['id'] ?>" <?= selected($editRecord['assigned_to'] ?? '', $person['id']) ?>>
                            <?= e($person['full_name'] . ' - ' . $person['role_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
            <div class="form-field full">
                <label>Description / purpose / requirements</label>
                <textarea class="form-control" name="description" rows="4"><?= e($editRecord['description'] ?? '') ?></textarea>
            </div>
            <div class="form-actions full">
                <button class="btn" type="submit"><?= $editRecord ? 'Save Changes' : 'Create Record' ?></button>
                <?php if ($editRecord): ?>
                    <a class="btn btn-ghost" href="<?= e(app_url('modules/records.php?module=' . urlencode($slug) . '&id=' . (int) $editRecord['id'])) ?>">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</section>
<?php endif; ?>

<?php render_footer(); ?>