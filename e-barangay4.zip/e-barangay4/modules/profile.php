<?php

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';

require_login();

$user = current_user();
$residentId = current_resident_id();

if (!$residentId) {
    flash('warning', 'Your account is not yet linked to a resident record. Please contact the barangay office.');
    redirect('dashboard.php');
}

/*
|--------------------------------------------------------------------------
| Load resident + related display fields
|--------------------------------------------------------------------------
| Intentionally avoids households.head_name (may not exist). The
| household is loaded separately so we can safely skip missing columns.
|--------------------------------------------------------------------------
*/
$resident = fetch_one(
    'SELECT residents.*,
            puroks.name AS purok_name
     FROM residents
     LEFT JOIN puroks ON puroks.id = residents.purok_id
     WHERE residents.id = ?',
    [$residentId]
);

if (!$resident) {
    flash('danger', 'Resident record not found.');
    redirect('dashboard.php');
}

// Load the linked household (if any), tolerating missing optional columns.
$household = null;
if (!empty($resident['household_id'])) {
    $household = fetch_one('SELECT * FROM households WHERE id = ?', [(int) $resident['household_id']]);
}

// Load all households for the "Link to existing" dropdown.
$allHouseholds = fetch_all('SELECT * FROM households ORDER BY id DESC LIMIT 200');

$puroks = fetch_all('SELECT id, name FROM puroks ORDER BY name');

$purokClassifications = ['Poblacion', 'Interior', 'Coastal', 'Upland', 'Commercial', 'Residential'];
$civilStatuses        = ['Single', 'Married', 'Widowed', 'Separated', 'Annulled'];
$voterStatuses        = ['Registered', 'Not Registered'];
$residencyStatuses    = ['Resident', 'Non-Resident', 'Transient'];
$sexOptions           = ['Male', 'Female'];
$householdRoles       = ['Head', 'Spouse', 'Child', 'Parent', 'Sibling', 'Relative', 'Other'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'update_profile') {

        $currentPassword = (string) ($_POST['current_password'] ?? '');

        // ---- Re-authentication -----------------------------------------
        if (!verify_user_password((int) $user['id'], $currentPassword)) {
            flash('danger', 'Incorrect password. Profile was not updated.');
            redirect('modules/profile.php');
        }

        // ---- Collect raw inputs ----------------------------------------
        $firstName            = trim((string) ($_POST['first_name'] ?? ''));
        $middleName           = trim((string) ($_POST['middle_name'] ?? ''));
        $lastName             = trim((string) ($_POST['last_name'] ?? ''));
        $suffix               = trim((string) ($_POST['suffix'] ?? ''));
        $sex                  = trim((string) ($_POST['sex'] ?? ''));
        $birthDate            = trim((string) ($_POST['birth_date'] ?? ''));
        $civilStatus          = trim((string) ($_POST['civil_status'] ?? ''));
        $contactNo            = trim((string) ($_POST['contact_no'] ?? ''));
        $email                = trim((string) ($_POST['email'] ?? ''));
        $address              = trim((string) ($_POST['address'] ?? ''));
        $purokId              = ($_POST['purok_id'] ?? '') !== '' ? (int) $_POST['purok_id'] : null;
        $purokClassification  = trim((string) ($_POST['purok_classification'] ?? ''));
        $occupation           = trim((string) ($_POST['occupation'] ?? ''));
        $education            = trim((string) ($_POST['education'] ?? ''));
        $voterStatus          = trim((string) ($_POST['voter_status'] ?? ''));
        $residencyStatus      = trim((string) ($_POST['residency_status'] ?? 'Resident'));
        $isPwd                = isset($_POST['is_pwd']) ? 1 : 0;
        $isSenior             = isset($_POST['is_senior']) ? 1 : 0;
        $isSoloParent         = isset($_POST['is_solo_parent']) ? 1 : 0;
        $is4ps                = isset($_POST['is_4ps']) ? 1 : 0;

        // ---- Household inputs ------------------------------------------
        $householdMode       = (string) ($_POST['household_mode'] ?? 'keep');   // keep | existing | new
        $householdRole       = trim((string) ($_POST['household_role'] ?? ''));
        $householdId         = ($_POST['household_id'] ?? '') !== '' ? (int) $_POST['household_id'] : null;
        $newHouseholdHead    = trim((string) ($_POST['new_household_head'] ?? ''));
        $newHouseholdAddress = trim((string) ($_POST['new_household_address'] ?? ''));
        $newHouseholdPurokId = ($_POST['new_household_purok_id'] ?? '') !== '' ? (int) $_POST['new_household_purok_id'] : null;

        if (!in_array($householdMode, ['keep', 'existing', 'new'], true)) {
            $householdMode = 'keep';
        }
        if ($householdRole !== '' && !in_array($householdRole, $householdRoles, true)) {
            $householdRole = '';
        }

        // ---- Validation -------------------------------------------------
        $errors = [];

        if ($firstName === '') { $errors[] = 'First name is required.'; }
        if ($lastName === '')  { $errors[] = 'Last name is required.'; }
        if ($address === '')   { $errors[] = 'Complete address is required.'; }

        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }

        if ($sex !== '' && !in_array($sex, $sexOptions, true))                { $sex = ''; }
        if ($civilStatus !== '' && !in_array($civilStatus, $civilStatuses, true)) { $civilStatus = ''; }
        if ($voterStatus !== '' && !in_array($voterStatus, $voterStatuses, true)) { $voterStatus = ''; }
        if ($residencyStatus !== '' && !in_array($residencyStatus, $residencyStatuses, true)) { $residencyStatus = ''; }
        if ($purokClassification !== '' && !in_array($purokClassification, $purokClassifications, true)) { $purokClassification = ''; }

        if ($birthDate !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $birthDate)) {
            $errors[] = 'Birth date must be a valid date.';
        }

        // Household-mode specific validation
        if ($householdMode === 'existing' && !$householdId) {
            $errors[] = 'Please choose a household to link to (or switch to "Keep current").';
        }
        if ($householdMode === 'new') {
            if ($newHouseholdAddress === '') {
                $errors[] = 'Please enter an address for the new household.';
            }
        }

        if ($errors) {
            flash('danger', implode(' ', $errors));
            redirect('modules/profile.php');
        }

        // ---- Resolve household_id --------------------------------------
        $finalHouseholdId = $resident['household_id'] ?? null;   // default: keep

        if ($householdMode === 'existing' && $householdId) {
            // Verify the target household exists before linking.
            $exists = fetch_one('SELECT id FROM households WHERE id = ?', [$householdId]);
            if ($exists) {
                $finalHouseholdId = (int) $exists['id'];
            } else {
                flash('danger', 'The selected household no longer exists. Please pick another.');
                redirect('modules/profile.php');
            }
        } elseif ($householdMode === 'new') {
            // Build an INSERT that only touches columns that actually exist.
            $hhCols = table_columns('households');

            if (!in_array('household_no', $hhCols, true)) {
                flash('danger', 'Households table is missing "household_no" — cannot create a household. Please contact staff.');
                redirect('modules/profile.php');
            }

            $cols = ['household_no'];
            $phs  = ['?'];
            $vals = [generate_reference('HH')];

            if (in_array('address', $hhCols, true)) {
                $cols[] = 'address';  $phs[] = '?';  $vals[] = $newHouseholdAddress;
            }
            if (in_array('purok_id', $hhCols, true)) {
                $cols[] = 'purok_id'; $phs[] = '?';  $vals[] = $newHouseholdPurokId;
            }
            if (in_array('head_name', $hhCols, true)) {
                $cols[] = 'head_name'; $phs[] = '?'; $vals[] = $newHouseholdHead ?: null;
            }
            if (in_array('created_at', $hhCols, true)) {
                $cols[] = 'created_at'; $phs[] = 'NOW()';
            }
            if (in_array('updated_at', $hhCols, true)) {
                $cols[] = 'updated_at'; $phs[] = 'NOW()';
            }

            $insertSql = 'INSERT INTO households (' . implode(', ', $cols) . ') '
                       . 'VALUES (' . implode(', ', $phs) . ')';

            try {
                run_query($insertSql, $vals);
                $finalHouseholdId = (int) db()->lastInsertId();
            } catch (PDOException $e) {
                flash('danger', 'Could not create the household: ' . $e->getMessage());
                redirect('modules/profile.php');
            }
        }

        // ---- Detect name change for re-verification flag ---------------
        $nameChanged = (
            $firstName  !== (string) ($resident['first_name']  ?? '')
            || $lastName !== (string) ($resident['last_name']  ?? '')
            || $middleName !== (string) ($resident['middle_name'] ?? '')
            || $suffix   !== (string) ($resident['suffix']     ?? '')
        );

        $statusToSet = $nameChanged ? 'Pending Verification' : (string) ($resident['status'] ?? 'Active');

        // ---- Persist resident -------------------------------------------
        try {
            run_query(
                'UPDATE residents SET
                    first_name            = ?,
                    middle_name           = ?,
                    last_name             = ?,
                    suffix                = ?,
                    sex                   = ?,
                    birth_date            = ?,
                    civil_status          = ?,
                    contact_no            = ?,
                    email                 = ?,
                    address               = ?,
                    purok_id              = ?,
                    purok_classification  = ?,
                    occupation            = ?,
                    education             = ?,
                    voter_status          = ?,
                    residency_status      = ?,
                    is_pwd                = ?,
                    is_senior             = ?,
                    is_solo_parent        = ?,
                    is_4ps                = ?,
                    household_id          = ?,
                    household_role        = ?,
                    status                = ?,
                    updated_at            = NOW()
                 WHERE id = ?',
                [
                    $firstName,
                    $middleName,
                    $lastName,
                    $suffix,
                    $sex ?: null,
                    $birthDate ?: null,
                    $civilStatus ?: null,
                    $contactNo ?: null,
                    $email ?: null,
                    $address,
                    $purokId,
                    $purokClassification ?: null,
                    $occupation ?: null,
                    $education ?: null,
                    $voterStatus ?: null,
                    $residencyStatus ?: null,
                    $isPwd,
                    $isSenior,
                    $isSoloParent,
                    $is4ps,
                    $finalHouseholdId !== null ? (int) $finalHouseholdId : null,
                    $householdRole ?: null,
                    $statusToSet,
                    $residentId,
                ]
            );
        } catch (PDOException $e) {
            flash('danger', 'Could not save your profile: ' . $e->getMessage());
            redirect('modules/profile.php');
        }

        // ---- Audit + notify --------------------------------------------
        $detailParts = ['Self-service update'];
        if ($nameChanged)                          { $detailParts[] = 'name changed — flagged for re-verification'; }
        if ($householdMode === 'new')              { $detailParts[] = 'created household #' . (int) $finalHouseholdId; }
        if ($householdMode === 'existing')         { $detailParts[] = 'linked to household #' . (int) $finalHouseholdId; }

        audit_log('Updated own profile', 'Resident', $residentId, implode('; ', $detailParts));

        notify_user(
            (int) $user['id'],
            'Profile updated',
            $nameChanged
                ? 'Your profile changes were saved. Because your name changed, staff will re-verify your record.'
                : 'Your profile changes have been saved.'
        );

        flash(
            'success',
            $nameChanged
                ? 'Profile updated. Because your name changed, your record is now Pending Verification.'
                : 'Your profile has been updated.'
        );

        redirect('modules/profile.php');
    }
}

render_header('My Profile');
page_header(
    'My Profile',
    'View and securely update your personal information.',
    '<a class="btn btn-ghost" href="' . e(app_url('dashboard.php')) . '">Back to Dashboard</a>'
);
?>

<style>
    /* Page-scoped: guarantee readable inputs regardless of theme */
    .profile-form .section-heading {
        grid-column: 1 / -1;
        margin: 18px 0 2px;
        padding-bottom: 8px;
        border-bottom: 1px solid #e2e8f0;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: #4a5568;
    }
    .profile-form .section-heading:first-of-type { margin-top: 0; }
    .profile-form .form-field label {
        display: block;
        margin-bottom: 6px;
        font-size: 13px;
        font-weight: 600;
        color: #2d3748;
    }
    .profile-form .form-field label.muted {
        color: #4a5568;
        font-weight: 500;
        font-size: 12px;
    }
    .profile-form .form-control {
        width: 100%;
        box-sizing: border-box;
        background: #ffffff;
        color: #1a202c;
        border: 1px solid #cbd5e0;
        border-radius: 6px;
        padding: 10px 12px;
        font-size: 14px;
        line-height: 1.4;
        transition: border-color .15s ease, box-shadow .15s ease;
    }
    .profile-form .form-control::placeholder { color: #a0aec0; }
    .profile-form .form-control:focus {
        outline: none;
        border-color: #2b6cb0;
        box-shadow: 0 0 0 3px rgba(43, 108, 176, 0.15);
    }
    .profile-form textarea.form-control {
        resize: vertical;
        min-height: 72px;
    }
    .profile-form .split-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 18px;
        padding: 8px 0;
    }
    .profile-form .split-actions label {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        font-weight: 500;
        color: #2d3748;
        cursor: pointer;
    }
    .profile-form small.muted {
        display: block;
        margin-top: 4px;
        font-size: 12px;
        color: #718096;
    }
    .profile-form .household-block { display: none; }
    .profile-form .household-block.is-visible { display: block; }
</style>

<section class="grid grid-2">

    <div class="panel">
        <div class="panel-header">
            <h2>Account Summary</h2>
        </div>
        <div class="panel-body">
            <div class="grid grid-2">
                <p><strong>Resident No.</strong><br><?= e($resident['resident_no']) ?></p>
                <p><strong>Full name</strong><br><?= e(resident_full_name($resident)) ?></p>
                <p><strong>Sex</strong><br><?= e($resident['sex'] ?: '—') ?></p>
                <p><strong>Birth date</strong><br><?= e($resident['birth_date'] ?: '—') ?></p>
                <p><strong>Civil status</strong><br><?= e($resident['civil_status'] ?: '—') ?></p>
                <p><strong>Voter status</strong><br><?= e($resident['voter_status'] ?: '—') ?></p>
                <p><strong>Residency</strong><br><?= e($resident['residency_status'] ?: '—') ?></p>
                <p><strong>Record status</strong><br>
                    <span class="<?= e(status_class($resident['status'])) ?>"><?= e($resident['status']) ?></span>
                </p>
                <p><strong>Purok</strong><br>
                    <?= e($resident['purok_name'] ?: 'Unassigned') ?>
                    <?php if (!empty($resident['purok_classification'])): ?>
                        <br><small class="muted"><?= e($resident['purok_classification']) ?></small>
                    <?php endif; ?>
                </p>
                <p><strong>Last updated</strong><br><?= e($resident['updated_at'] ?: '—') ?></p>
            </div>

            <p><strong>Household</strong><br>
                <?php if ($household): ?>
                    <?= e($household['household_no'] ?? 'HH-' . (int) $household['id']) ?>
                    <?php if (!empty($resident['household_role'])): ?>
                        <br><small class="muted">Role: <?= e($resident['household_role']) ?></small>
                    <?php endif; ?>
                    <?php if (!empty($household['head_name'])): ?>
                        <br><small class="muted">Head: <?= e($household['head_name']) ?></small>
                    <?php endif; ?>
                    <?php if (!empty($household['address'])): ?>
                        <br><small class="muted"><?= e($household['address']) ?></small>
                    <?php endif; ?>
                <?php else: ?>
                    <span class="muted">Not linked yet — use the form on the right to link or create a household.</span>
                <?php endif; ?>
            </p>

            <p><strong>Classifications</strong><br>
                <?= e(trim(($resident['is_senior'] ? 'Senior ' : '') . ($resident['is_pwd'] ? 'PWD ' : '') . ($resident['is_solo_parent'] ? 'Solo Parent ' : '') . ($resident['is_4ps'] ? '4Ps' : '')) ?: 'None') ?>
            </p>
            <p class="muted">
                Changes to your name will flag your record for staff re-verification.
                All other updates appear immediately in barangay records.
            </p>
        </div>
    </div>

    <div class="panel">
        <div class="panel-header">
            <h2>Edit My Information</h2>
        </div>
        <div class="panel-body">
            <form method="post" class="form-grid profile-form" novalidate>
                <input type="hidden" name="action" value="update_profile">

                <h3 class="section-heading">Personal Information</h3>

                <div class="form-field">
                    <label>First name *</label>
                    <input class="form-control" name="first_name" value="<?= e($resident['first_name'] ?? '') ?>" required>
                </div>
                <div class="form-field">
                    <label>Middle name</label>
                    <input class="form-control" name="middle_name" value="<?= e($resident['middle_name'] ?? '') ?>">
                </div>
                <div class="form-field">
                    <label>Last name *</label>
                    <input class="form-control" name="last_name" value="<?= e($resident['last_name'] ?? '') ?>" required>
                </div>
                <div class="form-field">
                    <label>Suffix</label>
                    <input class="form-control" name="suffix" placeholder="Jr., Sr., III" value="<?= e($resident['suffix'] ?? '') ?>">
                </div>
                <div class="form-field">
                    <label>Sex</label>
                    <select class="form-control" name="sex">
                        <option value="">Select</option>
                        <?php foreach ($sexOptions as $opt): ?>
                            <option value="<?= e($opt) ?>" <?= selected($resident['sex'] ?? '', $opt) ?>><?= e($opt) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-field">
                    <label>Birth date</label>
                    <input class="form-control" type="date" name="birth_date" value="<?= e($resident['birth_date'] ?? '') ?>">
                </div>

                <h3 class="section-heading">Contact &amp; Address</h3>

                <div class="form-field">
                    <label>Contact no.</label>
                    <input class="form-control" name="contact_no" placeholder="09XXXXXXXXX" value="<?= e($resident['contact_no'] ?? '') ?>">
                </div>
                <div class="form-field">
                    <label>Email</label>
                    <input class="form-control" type="email" name="email" placeholder="you@example.com" value="<?= e($resident['email'] ?? '') ?>">
                </div>
                <div class="form-field full">
                    <label>Complete address *</label>
                    <textarea class="form-control" name="address" rows="2" required><?= e($resident['address'] ?? '') ?></textarea>
                </div>
                <div class="form-field">
                    <label>Purok / Sitio</label>
                    <select class="form-control" name="purok_id">
                        <option value="">Select</option>
                        <?php foreach ($puroks as $purok): ?>
                            <option value="<?= (int) $purok['id'] ?>" <?= selected($resident['purok_id'] ?? '', $purok['id']) ?>><?= e($purok['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-field">
                    <label>Purok classification</label>
                    <select class="form-control" name="purok_classification">
                        <option value="">Select</option>
                        <?php foreach ($purokClassifications as $pc): ?>
                            <option value="<?= e($pc) ?>" <?= selected($resident['purok_classification'] ?? '', $pc) ?>><?= e($pc) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <h3 class="section-heading">Civil &amp; Demographic</h3>

                <div class="form-field">
                    <label>Civil status</label>
                    <select class="form-control" name="civil_status">
                        <option value="">Select</option>
                        <?php foreach ($civilStatuses as $cs): ?>
                            <option value="<?= e($cs) ?>" <?= selected($resident['civil_status'] ?? '', $cs) ?>><?= e($cs) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-field">
                    <label>Voter status</label>
                    <select class="form-control" name="voter_status">
                        <option value="">Select</option>
                        <?php foreach ($voterStatuses as $vs): ?>
                            <option value="<?= e($vs) ?>" <?= selected($resident['voter_status'] ?? '', $vs) ?>><?= e($vs) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-field">
                    <label>Residency status</label>
                    <select class="form-control" name="residency_status">
                        <?php foreach ($residencyStatuses as $rs): ?>
                            <option value="<?= e($rs) ?>" <?= selected($resident['residency_status'] ?? 'Resident', $rs) ?>><?= e($rs) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-field">
                    <label>Occupation</label>
                    <input class="form-control" name="occupation" placeholder="e.g. Teacher, Farmer" value="<?= e($resident['occupation'] ?? '') ?>">
                </div>
                <div class="form-field full">
                    <label>Education</label>
                    <input class="form-control" name="education" placeholder="e.g. Bachelor's degree, High school" value="<?= e($resident['education'] ?? '') ?>">
                </div>

                <h3 class="section-heading">Household</h3>

                <?php if ($household): ?>
                    <div class="form-field full">
                        <small class="muted">
                            Currently linked to
                            <strong><?= e($household['household_no'] ?? 'HH-' . (int) $household['id']) ?></strong>
                            <?php if (!empty($household['address'])): ?>
                                — <?= e($household['address']) ?>
                            <?php endif; ?>
                            <?php if (!empty($resident['household_role'])): ?>
                                (<?= e($resident['household_role']) ?>)
                            <?php endif; ?>
                        </small>
                    </div>
                <?php endif; ?>

                <div class="form-field">
                    <label class="muted">Household mode</label>
                    <select class="form-control" name="household_mode" id="household_mode_select">
                        <option value="keep"     <?= selected('keep',     'keep') ?>>Keep current (no change)</option>
                        <option value="existing" <?= selected('',         'existing') ?>>Link to existing household</option>
                        <option value="new"      <?= selected('',         'new') ?>>Create new household</option>
                    </select>
                </div>
                <div class="form-field">
                    <label class="muted">Role in household</label>
                    <select class="form-control" name="household_role">
                        <option value="">Select</option>
                        <?php foreach ($householdRoles as $role): ?>
                            <option value="<?= e($role) ?>" <?= selected($resident['household_role'] ?? '', $role) ?>><?= e($role) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-field full household-block" id="existing-household-block">
                    <label class="muted">Choose an existing household</label>
                    <select class="form-control" name="household_id">
                        <option value="">Select household</option>
                        <?php foreach ($allHouseholds as $h): ?>
                            <?php
                                $hLabel = $h['household_no'] ?? ('HH-' . (int) $h['id']);
                                if (!empty($h['head_name'])) { $hLabel .= ' - ' . $h['head_name']; }
                                if (!empty($h['address']))   { $hLabel .= ' - ' . $h['address']; }
                            ?>
                            <option value="<?= (int) $h['id'] ?>" <?= selected($resident['household_id'] ?? '', $h['id']) ?>>
                                <?= e($hLabel) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (!$allHouseholds): ?>
                        <small class="muted">No existing households yet — use "Create new household" below.</small>
                    <?php endif; ?>
                </div>

                <div class="form-field full household-block" id="new-household-block">
                    <label class="muted">New household details</label>
                    <div class="grid grid-3">
                        <input class="form-control" name="new_household_head"    placeholder="Household head name"    value="">
                        <input class="form-control" name="new_household_address" placeholder="Household address *"   value="">
                        <select class="form-control" name="new_household_purok_id">
                            <option value="">Select purok</option>
                            <?php foreach ($puroks as $purok): ?>
                                <option value="<?= (int) $purok['id'] ?>"><?= e($purok['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <small class="muted">
                        A household number will be generated automatically.
                        Leave "Household head name" blank if you are not the head.
                    </small>
                </div>

                <h3 class="section-heading">Classifications</h3>

                <div class="form-field full">
                    <div class="split-actions">
                        <label><input type="checkbox" name="is_pwd"         <?= checked((bool) ($resident['is_pwd'] ?? false)) ?>> PWD</label>
                        <label><input type="checkbox" name="is_senior"      <?= checked((bool) ($resident['is_senior'] ?? false)) ?>> Senior Citizen</label>
                        <label><input type="checkbox" name="is_solo_parent" <?= checked((bool) ($resident['is_solo_parent'] ?? false)) ?>> Solo Parent</label>
                        <label><input type="checkbox" name="is_4ps"         <?= checked((bool) ($resident['is_4ps'] ?? false)) ?>> 4Ps</label>
                    </div>
                    <small class="muted">Changing these flags may require staff re-verification.</small>
                </div>

                <h3 class="section-heading">Security</h3>

                <div class="form-field full">
                    <label>Current password (required to save) *</label>
                    <input class="form-control" type="password" name="current_password" required autocomplete="current-password">
                    <small class="muted">Re-authentication prevents unauthorized changes to your record.</small>
                </div>

                <div class="form-actions full">
                    <button class="btn" type="submit">Save Changes</button>
                    <a class="btn btn-ghost" href="<?= e(app_url('dashboard.php')) ?>">Back to Dashboard</a>
                </div>
            </form>
        </div>
    </div>

</section>

<script>
(function () {
    var modeSelect = document.getElementById('household_mode_select');
    if (!modeSelect) { return; }

    var existingBlock = document.getElementById('existing-household-block');
    var newBlock      = document.getElementById('new-household-block');

    function refresh() {
        var mode = modeSelect.value;
        existingBlock.classList.toggle('is-visible', mode === 'existing');
        newBlock.classList.toggle('is-visible', mode === 'new');
    }

    modeSelect.addEventListener('change', refresh);
    refresh();
})();
</script>

<?php render_footer(); ?>