<?php

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';

require_login();

if (!in_array(role_slug(), ['admin', 'punong_barangay'], true)) {
    flash('danger', 'You do not have access to that page.');
    redirect('dashboard.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'save') {
        $rows = $_POST['official'] ?? [];
        foreach ($rows as $slug => $data) {
            $slug     = (string) $slug;
            $fullName = trim((string) ($data['full_name'] ?? ''));
            $position = trim((string) ($data['position']  ?? ''));
            $order    = (int) ($data['sort_order'] ?? 0);
            $active   = isset($data['is_active']) ? 1 : 0;

            if ($fullName === '' || $position === '') {
                continue;
            }

            run_query(
                'UPDATE barangay_officials
                 SET full_name = ?, position = ?, sort_order = ?, is_active = ?, updated_at = NOW()
                 WHERE role_slug = ?',
                [$fullName, $position, $order, $active, $slug]
            );
        }
        audit_log('Updated signatories', 'Barangay Officials', null, 'Bulk update');
        flash('success', 'Signatories updated.');
        redirect('modules/officials.php');
    }
}

$officials = fetch_all('SELECT * FROM barangay_officials ORDER BY sort_order ASC, id ASC');

render_header('Signatories');
page_header('Barangay Signatories', 'Names embedded on printed documents.', '<a class="btn btn-ghost" href="' . e(app_url('dashboard.php')) . '">Back to Dashboard</a>');
?>

<section class="panel">
    <div class="panel-header"><h2>Officials</h2></div>
    <div class="panel-body">
        <form method="post" class="form-grid">
            <input type="hidden" name="action" value="save">

            <?php foreach ($officials as $o): ?>
                <div class="form-field">
                    <label><?= e(ucfirst((string) $o['role_slug'])) ?> — Name</label>
                    <input class="form-control"
                           name="official[<?= e($o['role_slug']) ?>][full_name]"
                           value="<?= e($o['full_name']) ?>" required>
                </div>
                <div class="form-field">
                    <label>Position / Title</label>
                    <input class="form-control"
                           name="official[<?= e($o['role_slug']) ?>][position]"
                           value="<?= e($o['position']) ?>" required>
                </div>
                <div class="form-field">
                    <label>Sort order</label>
                    <input class="form-control" type="number"
                           name="official[<?= e($o['role_slug']) ?>][sort_order]"
                           value="<?= (int) $o['sort_order'] ?>">
                </div>
                <div class="form-field">
                    <label>Active</label>
                    <input type="checkbox"
                           name="official[<?= e($o['role_slug']) ?>][is_active]"
                           <?= checked((bool) $o['is_active']) ?>>
                </div>
            <?php endforeach; ?>

            <div class="form-actions full">
                <button class="btn" type="submit">Save Signatories</button>
            </div>
        </form>
    </div>
</section>

<?php render_footer(); ?>