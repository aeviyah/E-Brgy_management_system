<?php

declare(strict_types=1);

/*
|==========================================================================
| Application configuration
|==========================================================================
*/

/**
 * Registered modules keyed by slug.
 * type: 'records' → handled by modules/records.php
 *       'page'    → handled by the URL directly
 */
if (!function_exists('app_modules')) {
    function app_modules(): array
    {
        return [
            'residents' => [
                'label'       => 'Residents',
                'description' => 'Register, verify and manage resident records.',
                'type'        => 'page',
                'url'         => 'modules/residents.php',
                'group'       => 'Community',
                'icon'        => 'users',
            ],
            'households' => [
                'label'       => 'Households',
                'description' => 'Group residents into households.',
                'type'        => 'page',
                'url'         => 'modules/households.php',
                'group'       => 'Community',
                'icon'        => 'home',
            ],
            'puroks' => [
                'label'       => 'Puroks',
                'description' => 'Manage purok / sitio assignments.',
                'type'        => 'page',
                'url'         => 'modules/puroks.php',
                'group'       => 'Community',
                'icon'        => 'map',
            ],
            'documents' => [
                'label'       => 'Documents & Certificates',
                'description' => 'Barangay Clearance, Indigency, Residency, Cedula, Good Moral, Business Permit, Resolution.',
                'type'        => 'records',
                'prefix'      => 'DOC',
                'group'       => 'Transactions',
                'icon'        => 'file',
            ],
            'services' => [
                'label'       => 'Barangay Services',
                'description' => 'Request barangay services.',
                'type'        => 'records',
                'prefix'      => 'SVC',
                'group'       => 'Transactions',
                'icon'        => 'heart',
            ],
            'complaints' => [
                'label'       => 'Complaints & Blotter',
                'description' => 'File and manage complaints and blotter entries.',
                'type'        => 'records',
                'prefix'      => 'CMP',
                'group'       => 'Cases',
                'icon'        => 'alert',
            ],
            'katarungang' => [
                'label'       => 'Katarungang Pambarangay',
                'description' => 'Mediation and conciliation proceedings.',
                'type'        => 'records',
                'prefix'      => 'KAT',
                'group'       => 'Cases',
                'icon'        => 'scale',
            ],
            'payments' => [
                'label'       => 'Treasury & Receipts',
                'description' => 'Record payments and issue receipts.',
                'type'        => 'page',
                'url'         => 'modules/payments.php',
                'group'       => 'Finance',
                'icon'        => 'receipt',
            ],
            'announcements' => [
                'label'       => 'Announcements',
                'description' => 'Post barangay announcements.',
                'type'        => 'records',
                'prefix'      => 'ANN',
                'group'       => 'Communication',
                'icon'        => 'megaphone',
            ],
            'events' => [
                'label'       => 'Events & Activities',
                'description' => 'Schedule barangay events.',
                'type'        => 'records',
                'prefix'      => 'EVT',
                'group'       => 'Community',
                'icon'        => 'calendar',
            ],
            'reports' => [
                'label'       => 'Reports',
                'description' => 'Generate barangay reports.',
                'type'        => 'page',
                'url'         => 'modules/reports.php',
                'group'       => 'Control',
                'icon'        => 'trending',
            ],
            'audit' => [
                'label'       => 'Audit Logs',
                'description' => 'Review system activity.',
                'type'        => 'page',
                'url'         => 'modules/audit.php',
                'group'       => 'Control',
                'icon'        => 'lock',
            ],
        ];
    }
}

/**
 * Modules planned for a later release — displayed as locked.
 */
if (!function_exists('future_modules')) {
    function future_modules(): array
    {
        return [
            'SK Management',
            'Barangay ID System',
            'Health Records',
            'Disaster Response',
        ];
    }
}

/*
|==========================================================================
| Workflow statuses (strict 4-status model)
|==========================================================================
*/

if (!function_exists('workflow_statuses')) {
    function workflow_statuses(): array
    {
        return [
            'Pending',
            'For Review',
            'Approved',
            'Rejected',
        ];
    }
}

if (!function_exists('workflow_transitions')) {
    function workflow_transitions(): array
    {
        return [
            'Pending'    => ['For Review', 'Approved', 'Rejected'],
            'For Review' => ['Approved', 'Rejected', 'Pending'],
            'Approved'   => ['For Review'],
            'Rejected'   => ['Pending', 'For Review'],
        ];
    }
}

/*
|==========================================================================
| Payment statuses (used by modules/payments.php)
|==========================================================================
*/

if (!function_exists('payment_statuses')) {
    function payment_statuses(): array
    {
        return [
            'Pending',
            'Paid',
            'Partial',
            'Refunded',
            'Cancelled',
        ];
    }
}

/*
|==========================================================================
| Resident record statuses (used by modules/residents.php)
|==========================================================================
*/

if (!function_exists('resident_statuses')) {
    function resident_statuses(): array
    {
        return [
            'Active',
            'Pending Verification',
            'Inactive',
            'Archived',
        ];
    }
}