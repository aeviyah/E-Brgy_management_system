<?php

declare(strict_types=1);

date_default_timezone_set('Asia/Manila');

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'path'     => '/',
    ]);
    session_start();
}

// ---------------------------------------------------------------------
// Bootstrap order matters:
//   1. database.php  → constants + PDO helper
//   2. app.php       → module + workflow definitions
//   3. functions.php → general helpers
//   4. auth.php      → session / RBAC / current user
//
// _ide_helper.php is intentionally NOT included here. It is an IDE stub
// only; loading it at runtime causes "Cannot redeclare function" fatals.
// ---------------------------------------------------------------------
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/app.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

// ---------------------------------------------------------------------
// CSRF protection: inject a token into every POST form and verify
// every incoming POST request. Skipped under CLI (cron / scripts).
// ---------------------------------------------------------------------
if (PHP_SAPI !== 'cli') {
    ob_start('csrf_inject_forms');

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_verify()) {
        http_response_code(419);
        exit('Your session expired or the form was invalid. Go back, refresh the page and try again.');
    }
}