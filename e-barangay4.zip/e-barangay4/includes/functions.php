<?php

declare(strict_types=1);

/* ============ Core utilities ============ */

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function base_url(): string
{
    $script = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    $base   = preg_replace('#/(modules|public)$#', '', $script);
    return rtrim($base === '/' ? '' : $base, '/');
}

function app_url(string $path = ''): string
{
    return base_url() . '/' . ltrim($path, '/');
}

function redirect(string $path): never
{
    header('Location: ' . app_url($path));
    exit;
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function flash_messages(): array
{
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $messages;
}

function old(string $key, mixed $default = ''): mixed
{
    return $_POST[$key] ?? $_GET[$key] ?? $default;
}

function selected(mixed $actual, mixed $expected): string
{
    return (string) $actual === (string) $expected ? 'selected' : '';
}

function checked(bool $condition): string
{
    return $condition ? 'checked' : '';
}

/* ============ DB helpers ============ */

function fetch_one(string $sql, array $params = []): ?array
{
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $row = $stmt->fetch();
    return $row ?: null;
}

function fetch_all(string $sql, array $params = []): array
{
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function fetch_value(string $sql, array $params = []): mixed
{
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchColumn();
}

function run_query(string $sql, array $params = []): bool
{
    $stmt = db()->prepare($sql);
    return $stmt->execute($params);
}

/* ============ Misc ============ */

function generate_reference(string $prefix): string
{
    return strtoupper($prefix) . '-' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
}

function module_meta(string $slug): ?array
{
    $modules = app_modules();
    return $modules[$slug] ?? null;
}

function module_url(string $slug): string
{
    $module = module_meta($slug);
    if (!$module) {
        return 'dashboard.php';
    }
    if (($module['type'] ?? '') === 'records') {
        return 'modules/records.php?module=' . urlencode($slug);
    }
    return $module['url'] ?? 'dashboard.php';
}

function status_class(string $status): string
{
    $normalized = strtolower(str_replace([' ', '/'], '-', $status));
    return 'status status-' . preg_replace('/[^a-z0-9-]/', '', $normalized);
}

function peso(mixed $amount): string
{
    return 'PHP ' . number_format((float) $amount, 2);
}

function current_ip(): string
{
    return $_SERVER['REMOTE_ADDR'] ?? 'local';
}

/* ============ Audit / history / notify ============ */

function audit_log(string $action, string $entity, ?int $entityId = null, string $details = ''): void
{
    $current = current_user();
    $userId  = $current['id'] ?? null;
    run_query(
        'INSERT INTO audit_logs (user_id, action, entity, entity_id, details, ip_address, created_at)
         VALUES (?, ?, ?, ?, ?, ?, NOW())',
        [$userId, $action, $entity, $entityId, $details, current_ip()]
    );
}

function record_history(int $recordId, string $status, string $notes = ''): void
{
    $current = current_user();
    $userId  = $current['id'] ?? null;
    run_query(
        'INSERT INTO record_history (record_id, status, notes, changed_by, created_at)
         VALUES (?, ?, ?, ?, NOW())',
        [$recordId, $status, $notes, $userId]
    );
}

function notify_user(?int $userId, string $title, string $message, string $channel = 'In-App'): void
{
    if (!$userId) {
        return;
    }
    run_query(
        'INSERT INTO notifications (user_id, title, message, channel, is_read, created_at)
         VALUES (?, ?, ?, ?, 0, NOW())',
        [$userId, $title, $message, $channel]
    );
}

/* ============ Module / resident ============ */

function group_modules_for_sidebar(): array
{
    $groups = [];
    foreach (app_modules() as $slug => $module) {
        if (!can_access_module($slug)) {
            continue;
        }
        $groups[$module['group']][] = [$slug, $module];
    }
    return $groups;
}

function resident_full_name(array $resident): string
{
    return trim(
        ($resident['first_name']  ?? '') . ' ' .
        ($resident['middle_name'] ?? '') . ' ' .
        ($resident['last_name']   ?? '') . ' ' .
        ($resident['suffix']      ?? '')
    );
}

function current_resident_id(): ?int
{
    $user = current_user();
    return isset($user['resident_id']) ? (int) $user['resident_id'] : null;
}

/* ============ CSRF ============ */

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_verify(): bool
{
    $sent = (string) ($_POST['_csrf'] ?? '');
    return $sent !== '' && hash_equals(csrf_token(), $sent);
}

function csrf_inject_forms(string $html): string
{
    $field = '<input type="hidden" name="_csrf" value="' . csrf_token() . '">';
    return preg_replace('/(<form\b[^>]*\bmethod=["\']post["\'][^>]*>)/i', '$1' . $field, $html) ?? $html;
}

/* ============ Role helpers ============ */

if (!function_exists('is_resident')) {
    function is_resident(): bool
    {
        return role_slug() === 'resident';
    }
}

if (!function_exists('is_barangay_official')) {
    function is_barangay_official(): bool
    {
        return !is_resident();
    }
}

if (!function_exists('can_full_control_records')) {
    function can_full_control_records(string $slug): bool
    {
        if (!is_barangay_official()) {
            return false;
        }
        return can_manage_module($slug) || can_approve_module($slug);
    }
}

/* ============ Workflow transitions ============ */

function can_transition(string $from, string $to, string $slug): bool
{
    $allowed = workflow_transitions()[$from] ?? [];

    if (!in_array($to, $allowed, true)) {
        return false;
    }

    // Residents never transition records.
    if (is_resident()) {
        return false;
    }

    return true;
}

/* ============ Password helpers ============ */

if (!function_exists('current_user_password_column')) {
    function current_user_password_column(): ?string
    {
        $row = fetch_one('SELECT * FROM users LIMIT 1');
        if (!$row) {
            return null;
        }
        foreach (['password_hash', 'password', 'passwd', 'user_password'] as $candidate) {
            if (array_key_exists($candidate, $row)) {
                return $candidate;
            }
        }
        return null;
    }
}

if (!function_exists('verify_user_password')) {
    function verify_user_password(int $userId, string $plainPassword): bool
    {
        if ($userId <= 0 || $plainPassword === '') {
            return false;
        }
        $row = fetch_one('SELECT * FROM users WHERE id = ?', [$userId]);
        if (!$row) {
            return false;
        }

        $column = null;
        $stored = null;
        foreach (['password_hash', 'password', 'passwd', 'user_password'] as $candidate) {
            if (!array_key_exists($candidate, $row)) {
                continue;
            }
            $value = $row[$candidate];
            if ($value !== null && (string) $value !== '') {
                $column = $candidate;
                $stored = (string) $value;
                break;
            }
        }
        if ($column === null || $stored === null) {
            return false;
        }

        $matched = false;
        $needsRehash = false;
        $newHash = null;

        if (password_verify($plainPassword, $stored)) {
            $matched = true;
            if (password_needs_rehash($stored, PASSWORD_DEFAULT)) {
                $newHash = password_hash($plainPassword, PASSWORD_DEFAULT);
                $needsRehash = $newHash !== false;
            }
        } elseif (strlen($stored) === 32 && ctype_xdigit($stored) && hash_equals(strtolower($stored), md5($plainPassword))) {
            $matched = true;
            $newHash = password_hash($plainPassword, PASSWORD_DEFAULT);
            $needsRehash = $newHash !== false;
        } elseif (strlen($stored) === 40 && ctype_xdigit($stored) && hash_equals(strtolower($stored), sha1($plainPassword))) {
            $matched = true;
            $newHash = password_hash($plainPassword, PASSWORD_DEFAULT);
            $needsRehash = $newHash !== false;
        } elseif (hash_equals($stored, $plainPassword)) {
            $matched = true;
            $newHash = password_hash($plainPassword, PASSWORD_DEFAULT);
            $needsRehash = $newHash !== false;
        }

        if (!$matched) {
            return false;
        }

        if ($needsRehash && $newHash !== null && in_array($column, ['password_hash', 'password', 'passwd', 'user_password'], true)) {
            run_query("UPDATE users SET `{$column}` = ? WHERE id = ?", [$newHash, $userId]);
        }

        return true;
    }
}

/* ============ Schema introspection ============ */

if (!function_exists('table_columns')) {
    function table_columns(string $table): array
    {
        static $cache = [];
        if (isset($cache[$table])) {
            return $cache[$table];
        }
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
            return $cache[$table] = [];
        }
        try {
            $rows = fetch_all("SHOW COLUMNS FROM `{$table}`");
        } catch (PDOException $e) {
            return $cache[$table] = [];
        }
        $cols = [];
        foreach ($rows as $row) {
            if (isset($row['Field'])) {
                $cols[] = (string) $row['Field'];
            }
        }
        return $cache[$table] = $cols;
    }
}

/* ============ Attachment helpers ============ */

if (!function_exists('attachments_for_record')) {
    function attachments_for_record(int $recordId): array
    {
        try {
            return fetch_all(
                'SELECT * FROM service_record_attachments WHERE record_id = ? ORDER BY created_at ASC',
                [$recordId]
            );
        } catch (PDOException $e) {
            return [];
        }
    }
}

if (!function_exists('attachment_storage_dir')) {
    function attachment_storage_dir(): string
    {
        $dir = __DIR__ . '/../storage/uploads/attachments';
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }
        return $dir;
    }
}

if (!function_exists('handle_attachment_uploads')) {
    function handle_attachment_uploads(int $recordId, int $userId): array
    {
        if (empty($_FILES['attachments']) || !is_array($_FILES['attachments']['name'])) {
            return [];
        }

        $errors = [];
        $allowedMime = [
            'image/jpeg'      => 'jpg',
            'image/png'       => 'png',
            'image/webp'      => 'webp',
            'application/pdf' => 'pdf',
        ];
        $maxBytes = 5 * 1024 * 1024;

        $dir   = attachment_storage_dir();
        $file  = $_FILES['attachments'];
        $count = count($file['name']);

        for ($i = 0; $i < $count; $i++) {
            $name    = (string) ($file['name'][$i]     ?? '');
            $tmp     = (string) ($file['tmp_name'][$i] ?? '');
            $err     = (int)    ($file['error'][$i]    ?? UPLOAD_ERR_NO_FILE);
            $size    = (int)    ($file['size'][$i]     ?? 0);
            $docType = (string) ($_POST['attachment_type'][$i] ?? 'other');

            if ($err === UPLOAD_ERR_NO_FILE || $name === '') {
                continue;
            }
            if ($err !== UPLOAD_ERR_OK) {
                $errors[] = "Upload failed for {$name} (error code {$err}).";
                continue;
            }
            if ($size <= 0 || $size > $maxBytes) {
                $errors[] = "{$name} exceeds the 5 MB limit.";
                continue;
            }

            $finfo    = new finfo(FILEINFO_MIME_TYPE);
            $realType = (string) $finfo->file($tmp);

            if (!isset($allowedMime[$realType])) {
                $errors[] = "{$name} has an unsupported type ({$realType}).";
                continue;
            }

            $ext    = $allowedMime[$realType];
            $stored = bin2hex(random_bytes(16)) . '.' . $ext;
            $dest   = $dir . '/' . $stored;

            if (!@move_uploaded_file($tmp, $dest)) {
                $errors[] = "Could not save {$name}.";
                continue;
            }

            if (!in_array($docType, ['valid_id', 'birth_certificate', 'other'], true)) {
                $docType = 'other';
            }

            try {
                run_query(
                    'INSERT INTO service_record_attachments
                     (record_id, doc_type, original_name, stored_name, mime_type, size_bytes, uploaded_by, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, NOW())',
                    [$recordId, $docType, $name, $stored, $realType, $size, $userId]
                );
            } catch (PDOException $e) {
                @unlink($dest);
                $errors[] = "Could not save metadata for {$name}.";
            }
        }

        return $errors;
    }
}

if (!function_exists('delete_attachment')) {
    function delete_attachment(int $attachmentId, int $recordId): bool
    {
        $row = fetch_one(
            'SELECT * FROM service_record_attachments WHERE id = ? AND record_id = ?',
            [$attachmentId, $recordId]
        );
        if (!$row) {
            return false;
        }
        $path = attachment_storage_dir() . '/' . $row['stored_name'];
        if (is_file($path)) {
            @unlink($path);
        }
        run_query('DELETE FROM service_record_attachments WHERE id = ?', [$attachmentId]);
        return true;
    }
}

/* ============ Document printing fallback ============ */

if (!function_exists('document_allows_printing')) {
    /** Only Approved records may be printed / exported. */
    function document_allows_printing(string $status): bool
    {
        return strtolower(trim($status)) === 'approved';
    }
}