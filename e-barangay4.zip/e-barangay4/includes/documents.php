<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Document templates + renderer
|--------------------------------------------------------------------------
| Paths expected (drop your logos here):
|   assets/img/philippine-seal.png
|   assets/img/barangay-logo.png
|
| Missing logos are skipped gracefully.
|--------------------------------------------------------------------------
*/

if (!function_exists('barangay_signatories')) {
    function barangay_signatories(): array
    {
        try {
            $rows = fetch_all(
                'SELECT role_slug, full_name, position, sort_order
                 FROM barangay_officials
                 WHERE is_active = 1
                 ORDER BY sort_order ASC, id ASC'
            );
        } catch (PDOException $e) {
            return [];
        }

        $out = [];
        foreach ($rows as $r) {
            $out[(string) $r['role_slug']] = $r;
        }
        return $out;
    }
}

if (!function_exists('document_type_for_category')) {
    function document_type_for_category(string $category): ?string
    {
        $c = strtolower(trim($category));

        $map = [
            'barangay clearance'                  => 'clearance',
            'clearance'                           => 'clearance',
            'certificate of indigency'            => 'indigency',
            'indigency'                           => 'indigency',
            'business permit'                     => 'business_permit',
            'business clearance'                  => 'business_permit',
            'mayor\'s permit'                     => 'business_permit',
            'certificate of residency'            => 'residency',
            'residency'                           => 'residency',
            'cedula'                              => 'cedula',
            'community tax certificate'           => 'cedula',
            'ctc'                                 => 'cedula',
            'certificate of good moral character' => 'good_moral',
            'good moral character'                => 'good_moral',
            'good moral'                          => 'good_moral',
            'barangay resolution'                 => 'resolution',
            'resolution'                          => 'resolution',
            'barangay ordinance'                  => 'resolution',
            'ordinance'                           => 'resolution',
        ];

        foreach ($map as $needle => $key) {
            if (str_contains($c, $needle)) {
                return $key;
            }
        }

        return null;
    }
}

if (!function_exists('document_type_label')) {
    function document_type_label(string $key): string
    {
        return [
            'clearance'       => 'BARANGAY CLEARANCE',
            'indigency'       => 'CERTIFICATE OF INDIGENCY',
            'business_permit' => 'BARANGAY BUSINESS CLEARANCE',
            'residency'       => 'CERTIFICATE OF RESIDENCY',
            'cedula'          => 'COMMUNITY TAX CERTIFICATE (CEDULA)',
            'good_moral'      => 'CERTIFICATE OF GOOD MORAL CHARACTER',
            'resolution'      => 'BARANGAY RESOLUTION / ORDINANCE',
        ][$key] ?? 'BARANGAY DOCUMENT';
    }
}

if (!function_exists('document_allows_printing')) {
    /**
     * Per requirements: only APPROVED documents may be printed / downloaded.
     */
    function document_allows_printing(string $status): bool
    {
        return strtolower(trim($status)) === 'approved';
    }
}

if (!function_exists('document_resident_owns')) {
    function document_resident_owns(array $record): bool
    {
        $myResidentId = current_resident_id();
        if (!$myResidentId) {
            return false;
        }

        if ((int) ($record['resident_id'] ?? 0) === (int) $myResidentId) {
            return true;
        }

        $myProfile = fetch_one(
            'SELECT first_name, middle_name, last_name, suffix FROM residents WHERE id = ?',
            [(int) $myResidentId]
        );
        if (!$myProfile) {
            return false;
        }

        $myName = trim(
            (string) ($myProfile['first_name']  ?? '') . ' ' .
            (string) ($myProfile['middle_name'] ?? '') . ' ' .
            (string) ($myProfile['last_name']   ?? '') . ' ' .
            (string) ($myProfile['suffix']      ?? '')
        );
        $requester = trim((string) ($record['requester_name'] ?? ''));

        if ($requester === '' || $myName === '') {
            return false;
        }

        $norm = static function (string $s): string {
            $s = strtolower($s);
            $s = preg_replace('/\s+/', ' ', $s) ?? $s;
            return trim($s);
        };

        return $norm($requester) === $norm($myName);
    }
}

if (!function_exists('document_can_be_printed')) {
    /**
     * @param array $record
     * @param bool  $isStaff True for admins/officials; false for residents
     */
    function document_can_be_printed(array $record, bool $isStaff): bool
    {
        // Only approved documents can be issued — no exceptions.
        if (!document_allows_printing((string) ($record['status'] ?? ''))) {
            return false;
        }

        // Approved: staff can print any, residents only their own.
        if ($isStaff) {
            return true;
        }

        return document_resident_owns($record);
    }
}

if (!function_exists('document_body_html')) {
    function document_body_html(string $key, array $record, array $resident, array $signatories): string
    {
        $fullName = trim(
            (string) ($resident['first_name']  ?? '') . ' ' .
            (string) ($resident['middle_name'] ?? '') . ' ' .
            (string) ($resident['last_name']   ?? '') . ' ' .
            (string) ($resident['suffix']      ?? '')
        );
        $fullName = $fullName !== '' ? $fullName : (string) ($record['requester_name'] ?? '________________');

        $address   = trim((string) ($resident['address'] ?? '')) ?: '________________';
        $civil     = trim((string) ($resident['civil_status'] ?? '')) ?: '________';
        $birthDate = trim((string) ($resident['birth_date'] ?? ''));
        $age       = '';
        if ($birthDate !== '') {
            try {
                $age = (string) (new DateTime($birthDate))->diff(new DateTime('today'))->y;
            } catch (Exception $e) {
                $age = '';
            }
        }

        $purpose  = trim((string) ($record['description'] ?? '')) ?: 'whatever legal purpose it may serve';
        $refNo    = (string) ($record['reference_no'] ?? '');
        $dateLong = date('jS \d\a\y \o\f F, Y');

        switch ($key) {
            case 'clearance':
                return <<<HTML
<p style="text-align:center;"><strong>TO WHOM IT MAY CONCERN:</strong></p>
<p style="text-align:justify; text-indent:48px;">
This is to certify that <strong>{$fullName}</strong>, of legal age, {$civil}, Filipino citizen,
and a bona fide resident of <strong>{$address}</strong>, is known to be of
<em>good moral character</em> and a <em>law-abiding citizen</em> in this community.
</p>
<p style="text-align:justify; text-indent:48px;">
This further certifies that the above-named person has <strong>no derogatory record</strong>
filed in this Barangay as of this date.
</p>
<p style="text-align:justify; text-indent:48px;">
Issued this {$dateLong} at the Barangay Hall, upon the request of the above-named person
for <em>{$purpose}</em>.
</p>
<p style="text-align:right; font-size:11pt; color:#444;">
Reference No.: <strong>{$refNo}</strong>
</p>
HTML;

            case 'indigency':
                return <<<HTML
<p style="text-align:center;"><strong>TO WHOM IT MAY CONCERN:</strong></p>
<p style="text-align:justify; text-indent:48px;">
This is to certify that <strong>{$fullName}</strong>, of legal age, {$civil}, Filipino citizen,
and a bona fide resident of <strong>{$address}</strong>, belongs to an
<strong>indigent family</strong> in this Barangay.
</p>
<p style="text-align:justify; text-indent:48px;">
This certification is issued upon the request of the above-named person
for <em>{$purpose}</em> and for whatever assistance it may entitle them to.
</p>
<p style="text-align:justify; text-indent:48px;">
Issued this {$dateLong} at the Barangay Hall.
</p>
<p style="text-align:right; font-size:11pt; color:#444;">
Reference No.: <strong>{$refNo}</strong>
</p>
HTML;

            case 'business_permit':
                return <<<HTML
<p style="text-align:center;"><strong>TO WHOM IT MAY CONCERN:</strong></p>
<p style="text-align:justify; text-indent:48px;">
This is to certify that <strong>{$fullName}</strong>, of legal age, {$civil}, Filipino citizen,
and a bona fide resident of <strong>{$address}</strong>, is hereby granted this
<strong>Barangay Business Clearance</strong> to operate a business within the territorial
jurisdiction of this Barangay, subject to existing laws, ordinances, and regulations.
</p>
<p style="text-align:justify; text-indent:48px;">
This clearance is issued upon the request of the above-named person for <em>{$purpose}</em>.
</p>
<p style="text-align:justify; text-indent:48px;">
Issued this {$dateLong} at the Barangay Hall.
</p>
<p style="text-align:right; font-size:11pt; color:#444;">
Reference No.: <strong>{$refNo}</strong>
</p>
HTML;

            case 'residency':
                return <<<HTML
<p style="text-align:center;"><strong>TO WHOM IT MAY CONCERN:</strong></p>
<p style="text-align:justify; text-indent:48px;">
This is to certify that <strong>{$fullName}</strong>, of legal age, {$civil}, Filipino citizen,
is a bona fide resident of <strong>{$address}</strong> and has been residing in this
Barangay for a considerable period of time.
</p>
<p style="text-align:justify; text-indent:48px;">
This certification is issued upon the request of the above-named person
for <em>{$purpose}</em>.
</p>
<p style="text-align:justify; text-indent:48px;">
Issued this {$dateLong} at the Barangay Hall.
</p>
<p style="text-align:right; font-size:11pt; color:#444;">
Reference No.: <strong>{$refNo}</strong>
</p>
HTML;

            case 'cedula':
                return <<<HTML
<p style="text-align:center;"><strong>COMMUNITY TAX CERTIFICATE</strong></p>
<table style="width:100%; border-collapse:collapse; margin-top:12px;">
  <tr><td style="padding:6px 0; width:35%;"><strong>Name</strong></td><td style="padding:6px 0;">{$fullName}</td></tr>
  <tr><td style="padding:6px 0;"><strong>Address</strong></td><td style="padding:6px 0;">{$address}</td></tr>
  <tr><td style="padding:6px 0;"><strong>Civil Status</strong></td><td style="padding:6px 0;">{$civil}</td></tr>
  <tr><td style="padding:6px 0;"><strong>Age</strong></td><td style="padding:6px 0;">{$age}</td></tr>
  <tr><td style="padding:6px 0;"><strong>Date Issued</strong></td><td style="padding:6px 0;">{$dateLong}</td></tr>
  <tr><td style="padding:6px 0;"><strong>Reference No.</strong></td><td style="padding:6px 0;">{$refNo}</td></tr>
</table>
<p style="text-align:justify; text-indent:48px; margin-top:12px;">
This certifies that the above-named person has paid the corresponding community tax
in this Barangay for the current year, for <em>{$purpose}</em>.
</p>
HTML;

            case 'good_moral':
                return <<<HTML
<p style="text-align:center;"><strong>TO WHOM IT MAY CONCERN:</strong></p>
<p style="text-align:justify; text-indent:48px;">
This is to certify that <strong>{$fullName}</strong>, of legal age, {$civil}, Filipino citizen,
and a bona fide resident of <strong>{$address}</strong>, is known to be of
<strong>good moral character</strong> and has not been involved in any illegal activity
within this Barangay.
</p>
<p style="text-align:justify; text-indent:48px;">
This certification is issued upon the request of the above-named person
for <em>{$purpose}</em>.
</p>
<p style="text-align:justify; text-indent:48px;">
Issued this {$dateLong} at the Barangay Hall.
</p>
<p style="text-align:right; font-size:11pt; color:#444;">
Reference No.: <strong>{$refNo}</strong>
</p>
HTML;

            case 'resolution':
                return <<<HTML
<p style="text-align:center;"><strong>BARANGAY RESOLUTION NO. {$refNo}</strong></p>
<p style="text-align:justify; text-indent:48px; margin-top:12px;">
<strong>WHEREAS</strong>, the Sangguniang Barangay of this Barangay has deemed it necessary
to address the matter of <em>{$purpose}</em>;
</p>
<p style="text-align:justify; text-indent:48px;">
<strong>WHEREAS</strong>, the said matter is within the powers and jurisdiction of the
Sangguniang Barangay under the Local Government Code;
</p>
<p style="text-align:justify; text-indent:48px;">
<strong>NOW, THEREFORE, BE IT RESOLVED</strong>, as it is hereby resolved, that the
Sangguniang Barangay hereby adopts this resolution for the purpose stated above.
</p>
<p style="text-align:justify; text-indent:48px;">
<strong>RESOLVED FURTHER</strong>, that copies of this resolution be furnished to
all concerned for their information and guidance.
</p>
<p style="text-align:justify; text-indent:48px;">
<strong>ADOPTED</strong> this {$dateLong} at the Barangay Hall,
by the members of the Sangguniang Barangay present and voting.
</p>
HTML;
        }

        return '<p style="text-align:justify;">' . nl2br(e((string) ($record['description'] ?? ''))) . '</p>';
    }
}

if (!function_exists('document_logo_html')) {
    /**
     * Returns a two-logo letterhead row (Philippine seal on left, barangay
     * logo on right). Any missing file is silently skipped.
     */
    function document_logo_html(string $mode = 'print'): string
    {
        $base      = dirname(__DIR__);
        $sealPath  = $base . '/assets/img/philippine-seal.png';
        $brgyPath  = $base . '/assets/img/barangay-logo.png';

        // For Word, we embed as absolute file:// or http URL. For browser, relative works.
        $prefix = ($mode === 'word') ? (app_url('assets/img/')) : '';

        $sealSrc = '';
        $brgySrc = '';

        if (is_file($sealPath)) {
            $sealSrc = ($mode === 'word') ? $prefix . 'philippine-seal.png' : app_url('assets/img/philippine-seal.png');
        }
        if (is_file($brgyPath)) {
            $brgySrc = ($mode === 'word') ? $prefix . 'barangay-logo.png' : app_url('assets/img/barangay-logo.png');
        }

        $left  = $sealSrc !== '' ? '<img src="' . e($sealSrc) . '" alt="Philippine Seal" style="height:80px;">' : '';
        $right = $brgySrc !== '' ? '<img src="' . e($brgySrc) . '" alt="Barangay Logo" style="height:80px;">' : '';

        return '<table style="width:100%; border:0; margin-bottom:8px;"><tr>'
             . '<td style="width:90px; text-align:left; vertical-align:middle;">' . $left . '</td>'
             . '<td style="text-align:center; vertical-align:middle;">'
             .   '<div class="republic">Republic of the Philippines</div>'
             .   '<div class="province">Province of ' . e(defined('APP_PROVINCE') ? APP_PROVINCE : '________') . '</div>'
             .   '<div class="province">Municipality of ' . e(defined('APP_MUNICIPALITY') ? APP_MUNICIPALITY : '________') . '</div>'
             .   '<div class="barangay-name">BARANGAY ' . e(strtoupper(defined('APP_BARANGAY') ? APP_BARANGAY : '________')) . '</div>'
             .   '<div class="office">OFFICE OF THE PUNONG BARANGAY</div>'
             . '</td>'
             . '<td style="width:90px; text-align:right; vertical-align:middle;">' . $right . '</td>'
             . '</tr></table>';
    }
}

if (!function_exists('render_document_shell')) {
    function render_document_shell(
        string $title,
        string $bodyHtml,
        array $signatories,
        array $record,
        string $mode = 'print'
    ): string {
        $captain   = $signatories['captain']   ?? null;
        $secretary = $signatories['secretary'] ?? null;

        $captainName = $captain['full_name']   ?? '________________';
        $captainPos  = $captain['position']    ?? 'Punong Barangay';
        $secName     = $secretary['full_name'] ?? '________________';
        $secPos      = $secretary['position']  ?? 'Barangay Secretary';

        $isWord = $mode === 'word';

        $head = $isWord
            ? '<html xmlns:o="urn:schemas-microsoft-com:office:office" '
            . 'xmlns:w="urn:schemas-microsoft-com:office:word" '
            . 'xmlns="http://www.w3.org/TR/REC-html40"><head>'
            . '<meta charset="utf-8"><title>' . e($title) . '</title>'
            . '<!--[if gte mso 9]><xml><w:WordDocument>'
            . '<w:View>Print</w:View><w:Zoom>100</w:Zoom>'
            . '</w:WordDocument></xml><![endif]--></head>'
            : '<!doctype html><html lang="en"><head><meta charset="utf-8"><title>' . e($title) . '</title>';

        return $head . '
<style>
    @page { size: 8.5in 11in; margin: 1in; }
    body {
        font-family: "Times New Roman", Times, serif;
        font-size: 12pt; line-height: 1.6; color: #111;
        max-width: 7in; margin: 0 auto; padding: 24px 16px; position: relative;
    }
    .republic { font-size: 11pt; letter-spacing: 0.04em; }
    .province { font-size: 11pt; }
    .barangay-name {
        font-family: "Old English Text MT", "Times New Roman", serif;
        font-size: 20pt; font-weight: 700; margin: 4px 0;
    }
    .office { font-size: 11pt; letter-spacing: 0.06em; }
    .doc-title {
        text-align: center; font-size: 16pt; font-weight: 700;
        letter-spacing: 0.08em; margin: 20px 0 28px; text-decoration: underline;
    }
    .signature-block { margin-top: 60px; }
    .signature-line {
        display: inline-block; border-top: 1px solid #111;
        padding-top: 4px; min-width: 260px; text-align: center; margin-top: 48px;
    }
    .signature-line strong { font-size: 12pt; }
    .signature-line small { display: block; font-size: 11pt; letter-spacing: 0.04em; }
    .signature-row { display: flex; justify-content: space-between; gap: 24px; margin-top: 48px; }
    .signature-row > div { flex: 1; text-align: center; }
    .footer-note {
        margin-top: 40px; font-size: 9pt; color: #666;
        text-align: center; border-top: 1px dashed #bbb; padding-top: 8px;
    }
    .print-toolbar {
        position: sticky; top: 0; background: #f8fafc;
        border-bottom: 1px solid #e2e8f0; padding: 10px 16px;
        margin: -24px -16px 24px; display: flex; gap: 10px; align-items: center;
        font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
        font-size: 13px; z-index: 10;
    }
    .print-toolbar .btn-print {
        background: #1d4ed8; color: #fff; border: none;
        padding: 8px 14px; border-radius: 6px; cursor: pointer; font-weight: 600;
    }
    .print-toolbar .btn-print:hover { background: #1e40af; }
    .print-toolbar .muted { color: #64748b; }
    @media print {
        .print-toolbar { display: none !important; }
        body { padding: 0; }
    }
</style>
<body>'
        . ($isWord ? '' : '<div class="print-toolbar no-print">
                <button class="btn-print" onclick="window.print()">🖨  Print / Save as PDF</button>
                <span class="muted">Use the print dialog and choose <strong>Save as PDF</strong> as the destination.</span>
            </div>')
        . document_logo_html($mode)
        . '<hr style="border:none; border-top:1px solid #111; margin:12px 0 0;">'
        . '<div class="doc-title">' . e($title) . '</div>'
        . '<div class="body">' . $bodyHtml . '</div>'
        . '<div class="signature-block">
                <div class="signature-row">
                    <div>
                        <small>Prepared by:</small>
                        <div class="signature-line">
                            <strong>' . e($secName) . '</strong>
                            <small>' . e($secPos) . '</small>
                        </div>
                    </div>
                    <div>
                        <small>Attested by:</small>
                        <div class="signature-line">
                            <strong>' . e($captainName) . '</strong>
                            <small>' . e($captainPos) . '</small>
                        </div>
                    </div>
                </div>
           </div>
           <div class="footer-note">
                Reference No.: ' . e((string) ($record['reference_no'] ?? '')) . '
                &nbsp;&bull;&nbsp;
                Generated: ' . e(date('F j, Y g:i A')) . '
           </div>
</body></html>';
    }
}