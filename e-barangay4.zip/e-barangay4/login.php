<?php

require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

// If already signed in, skip the login form.
if (current_user()) {
    redirect('dashboard.php');
}

$error    = '';
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();

    $username = trim((string) ($_POST['username'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    if ($username === '' || $password === '') {
        $error = 'Please enter your username and password.';
    } else {
        $user = fetch_one(
            'SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1',
            [$username, $username]
        );

        if (!$user) {
            $error = 'Invalid username or password.';
        } elseif (!verify_user_password((int) $user['id'], $password)) {
            $error = 'Invalid username or password.';
        } elseif (strtolower((string) ($user['status'] ?? 'Active')) !== 'active') {
            $error = 'Your account is not active. Please contact the barangay office.';
        } else {
            $_SESSION['user_id'] = (int) $user['id'];
            audit_log('Logged in', 'User', (int) $user['id'], (string) ($user['full_name'] ?? ''));
            redirect('dashboard.php');
        }
    }
}

render_header('Sign in');
?>

<section style="max-width:440px; margin:60px auto; padding:0 16px;">

    <div class="panel">

        <div class="panel-header">
            <h2>Sign in</h2>
        </div>

        <div class="panel-body">

            <?php if ($error !== ''): ?>
                <div class="alert alert-danger" style="margin-bottom:16px;">
                    <?= e($error) ?>
                </div>
            <?php endif; ?>

            <form method="post" class="form-grid">
                <div class="form-field full">
                    <label for="login-username">Username or Email</label>
                    <input
                        id="login-username"
                        class="form-control"
                        name="username"
                        value="<?= e($username) ?>"
                        autocomplete="username"
                        autofocus
                        required
                    >
                </div>

                <div class="form-field full">
                    <label for="login-password">Password</label>
                    <input
                        id="login-password"
                        class="form-control"
                        type="password"
                        name="password"
                        autocomplete="current-password"
                        required
                    >
                </div>

                <div class="form-actions full">
                    <button class="btn" type="submit">Log in</button>
                </div>
            </form>

            <?php if (defined('APP_DEMO') && APP_DEMO === true): ?>
                <p class="muted" style="margin-top:16px; font-size:13px;">
                    <strong>Demo credentials:</strong><br>
                    Admin — username <code>admin</code>, password <code>admin</code>
                </p>
            <?php endif; ?>

        </div>

    </div>

    <p class="muted" style="text-align:center; margin-top:20px; font-size:12px;">
        <?= e(APP_NAME) ?> &middot; <?= e(APP_BARANGAY) ?>
    </p>

</section>

<?php render_footer(); ?>